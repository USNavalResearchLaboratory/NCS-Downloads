package agentj.nativeimp.util;

/**
 * The ... class ...
 * <p/>
 * Created by scmijt
 * Date: Dec 24, 2007
 * Time: 2:54:34 PM
 */
public interface TimerCallback {

    /**
     * The timerTrgger method is called when a native timer times out. 
     */
    public void timerTrigger();

}
