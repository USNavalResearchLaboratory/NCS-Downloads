package agentj.nativeimp.api;

/**
 * The ... class ...
 * <p/>
 * Created by scmijt
 * Date: Dec 31, 2007
 * Time: 12:28:14 PM
 */
public interface ProtolibTimerListener {
    /**
     * Called when the timer has timed out.
     *
     */
    public void timeOut();
}
