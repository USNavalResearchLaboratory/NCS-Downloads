Agentj Route.  Version 2, release August 10th 2009.

The RELEASE_NOTES.TXT file contain fixes, which will be added to from now on for changes of the source code.

The core directory is where the main source code lives

The instrumentation directory is a module that does the class bytecode rewriting and instrumentation for loading in Java classes into agentj.

the doc contains the manual (needs updating)

etc contains useful tools used by core developers. 

config contains the config for agentj for its properties and logging (both native (C/C++) and the Java side)

tcl contains several agentj examples.