This directory contains wireless scenarios using mulitcast.  Therefore
the NRLOLSR package needs to be installed in order to run these. It
can be found here: http://cs.itd.nrl.navy.mil/work/olsr/index.php