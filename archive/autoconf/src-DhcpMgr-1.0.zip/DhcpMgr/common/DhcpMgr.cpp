/*********************************************************************
 *
 * AUTHORIZATION TO USE AND DISTRIBUTE
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that: 
 *
 * (1) source code distributions retain this paragraph in its entirety, 
 *  
 * (2) distributions including binary code include this paragraph in
 *     its entirety in the documentation or other materials provided 
 *     with the distribution, and 
 *
 * (3) all advertising materials mentioning features or use of this 
 *     software display the following acknowledgment:
 * 
 *      "This product includes software written and developed 
 *       by Brian Adamson and Joe Macker of the Naval Research 
 *       Laboratory (NRL)." 
 *         
 *  The name of NRL, the name(s) of NRL  employee(s), or any entity
 *  of the United States Government may not be used to endorse or
 *  promote  products derived from this software, nor does the 
 *  inclusion of the NRL written and developed software  directly or
 *  indirectly suggest NRL or United States  Government endorsement
 *  of this product.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 ********************************************************************/

/********************************************************************
 * Author: Ian Downard
 * Date: 10 Apr 2006
 *
 * Purpose:
 *   Implement missing dhclient-exit-hooks type functionality for
 * the DHCP client in Windows XP, so that routing and dhcrelay 
 * applications can be automatically started/restarted after the 
 * host's address is acquired or changed.  Notification of address 
 * updates is acquired in Protolib by catching the 
 * FD_ADDRESS_LIST_CHANGE WSA event on a dummy socket.
 *
 * Arguments:
 *   -The "background" optional argument will put this in the 
 *    background.
 *   -The "-mac <mac addr>" optional argument will run DhcpMgr on the 
 *    specified network interface.  Expected as a colon delimited 
 *    12 digit hex value
 *   -The "-d" optional arg will run nrlolsr and dhcrelay in the 
 *    foreground
 *
 * Preconditions and assumptions:
 *   -niether nrlolsr nor dhcrelay is running when DhcpMgr starts.
 *   -The Microsoft .NET Framework must be installed (recommend 
 *    version 1.1).  This is required because its Process class is 
 *    used for finding and killing running processes of nrlolsr and 
 *    dhcrelay.
 *
 * Caviats and FAQs:
 *   The shell commands (for routing and dhcrelay) which start after
 *   the host address changes are hardcoded into this program (for 
 *   now).
 *
 *   IPv6 compatibility is supported, but untested.
 *
 *   Dhcrelay hardcoded to run on Cygwin's eth0, but I don't think
 *   it matters.  I think it'll bcast out every interface.  Untested.
 *
 *   If you run the program and get the error message "A required dll, 
 *   MSCOREE.dll can not be found" or "The application failed to 
 *   initialize properly", then you probably don't have Microsoft's .NET 
 *   framework installed properly.  It can be downloaded from Microsoft's
 *   web site.  Just use google to find it.
 *
 * Compile Options: 
 *   /I "..\common" /I "..\win32" /I "..\protolib\common" /I \
 *   "..\protolib\win32" /D "_DEBUG" /D "PROTO_DEBUG" /D "HAVE_IPV6" \
 *   /D "HAVE_ASSERT" /D "WIN32" /D "_WINDOWS" /D "_MBCS" /FD /EHsc \
 *   /MDd /GS /Yc"StdAfx.h" /Fp".\Debug\DhcpMgr.pch" /Fo".\Debug/" \
 *   /Fd".\Debug/" /W3 /nologo /c /clr
 *
 *     The "/clr" option is important.  That includes the .NET 
 *     framework (also known as the Common Language Runtime framework)
 *
 *
 *
 *******************************************************************/

#include "protoApp.h"
#include "protoRouteMgr.h"
#include <stdlib.h>  // for atoi()
#include <stdio.h>   // for stdout/stderr printouts
#include <string.h>

#include "stdafx.h"
#using <mscorlib.dll>
#using <System.dll>

using namespace System;
using namespace System::Diagnostics;
using namespace System::ComponentModel;

class DhcpMgr : public ProtoApp
{
    public:
        DhcpMgr();
        ~DhcpMgr();

        // Overrides from ProtoApp or NsProtoSimAgent base
        bool OnStartup(int argc, const char*const* argv);
        bool ProcessCommands(int argc, const char*const* argv);
        void OnShutdown();

		void Kill();
//		bool IsOLSRActive() {return (NULL != OLSR_processor_handle);}
//		bool IsDHCPActive() {return (NULL != DHCP_processor_handle);}

    private:
        void Usage();
        
        void OnSocketEvent(ProtoSocket&       theSocket, 
                              ProtoSocket::Event theEvent);
        static void SignalHandler(int sigNum);
		void SetAddressListener();
		bool GetAddress(char*);
		void ForkOLSR();
		void ForkDhcpRelay();
		void KillProcess(HANDLE, char*);

		char macName[256];		// expected as a colon delimited 12 digit hex value
		char ifaceName[256];
		bool debug;

		ProtoSocket         dummy_socket;
        unsigned int        client_msg_count;
        ProtoSocket::List   connection_list;

		HANDLE OLSR_processor_handle;
		HANDLE DHCP_processor_handle;
}; // end class DhcpMgr


DhcpMgr::DhcpMgr()
: dummy_socket(ProtoSocket::UDP),
  client_msg_count(0), debug(false)
{    
    dummy_socket.SetNotifier(&GetSocketNotifier());
    dummy_socket.SetListener(this, &DhcpMgr::OnSocketEvent);
	memset((void *)macName, 0, 256);
	memset((void *)ifaceName, 0, 256);
}

// Our application instance 
PROTO_INSTANTIATE_APP(DhcpMgr) 

DhcpMgr::~DhcpMgr()
{
    
}

void DhcpMgr::Usage()
{
    fprintf(stderr, "DhcpMgr\n");
}  // end DhcpMgr::Usage()


bool DhcpMgr::OnStartup(int argc, const char*const* argv)
{
    if (!ProcessCommands(argc, argv))
    {
        DMSG(0, "DhcpMgr: exiting\n");
        return false;
    }  

	// open dummy socket to receive WSA events
	fprintf(stderr, "opening dummy socket ...\n");
    if (!dummy_socket.Open())
    {
        DMSG(0, "DhcpMgr::Startup() error opening dummy_socket\n");
        return false;    
    }    
    fprintf(stderr, "dummy socket opened ...\n");

	dummy_socket.StartExceptionNotification();
	SetAddressListener();

	// find interface name, if MAC addr is specified
	if (strlen(macName) == 17) {
		char macAddr[6];
		char* ptr = macName;
		ProtoAddress localAddress;

		int i=0;
		while (ptr && ('\0' != *ptr))
		{
			int val;
			if (1==sscanf(ptr, "%x:", &val))
			{
				macAddr[i++] = (char)val;
			}
			else
			{
				fprintf(stderr,"Error reading macAddr ...\n");
			}

			ptr = strchr(ptr, ':');
			if (ptr) ptr++;
		}
		localAddress.SetRawHostAddress(ProtoAddress::ETH, macAddr, 6);
		dummy_socket.GetInterfaceName(localAddress, ifaceName, 256);
		fprintf(stderr, "Found MAC address %s.\nUsing interface %s\n", macName, ifaceName);
	} else {
		char address[256];
		memset((void*)address, 0, 256);
		GetAddress(address);
		fprintf(stderr, "MAC address not specified.  Defaulting to %s interface.\n", address);
	}

	// TODO: check for and kill existing instances of olsr and dhcrelay
	// Fork OLSR
	ForkOLSR();
	// Fork Dhcp Relay
	ForkDhcpRelay();


	fprintf(stderr, "\nDhcpMgr: entering main loop (<CTRL-C> to exit)...\n");

	return true;
}  // end DhcpMgr::OnStartup()

void DhcpMgr::OnShutdown()
{
	int i=0;

	fprintf(stderr, "Killing nrlolsr...\n");
	KillProcess(OLSR_processor_handle, "nrlolsr");
	fprintf(stderr, "Killing dhcrelay...\n");
	KillProcess(DHCP_processor_handle, "dhcrelay");

	if (dummy_socket.IsOpen()) dummy_socket.Close();
    connection_list.Destroy();   
    DMSG(0, "DhcpMgr: Done.\n");
    CloseDebugLog();
}  // end DhcpMgr::OnShutdown()


bool DhcpMgr::ProcessCommands(int argc, const char*const* argv)
{
	for (int i=0; i<argc; i++) {
        if (!strcmp(argv[i], "-mac"))
		{
			strcpy(macName, argv[i+1]);
		} else if (!strcmp(argv[i], "-d")) {
			debug = true;
		} else if (!strcmp(argv[i], "-h")) {
			fprintf(stderr, "Example: DhcpMgr.exe -d -mac <macAddr>\n");
			fprintf(stderr, "\t-d for debug mode\n");
			return false;
		}
	}
    return true;  
}  // end DhcpMgr::ProcessCommands()


void DhcpMgr::SetAddressListener()
{
	DWORD dwBytesXfer;
    // set dummy socket mode for receiving WSA events
	int result = (int)WSAIoctl(dummy_socket.GetHandle(), SIO_ADDRESS_LIST_CHANGE, NULL, 0, NULL, 0, &dwBytesXfer, NULL, NULL);
	
	if (0 == result)
	{
		//TRACE("WSAIoctl() returned 0 ...\n");
	}
	else if (WSAEWOULDBLOCK == WSAGetLastError())
	{
		//TRACE("WSAIoctl() says WSAEWOULDBLOCK\n");
	}
	else
	{
		//TRACE("WSAIoctl returned error: %s\n", ProtoSocket::GetErrorString());
	}
	return;
}


void DhcpMgr::OnSocketEvent(ProtoSocket& theSocket, ProtoSocket::Event theEvent)
{
	int i=0;

    switch (theEvent)
    {
        case ProtoSocket::INVALID_EVENT:
            fprintf(stderr, "ERROR) ...\n");
            break;
        case ProtoSocket::DISCONNECT:
            fprintf(stderr, "DISCONNECT) ...\n");
            break;
		case ProtoSocket::EXCEPTION:
		{
			fprintf(stderr, "Received socket exception event\n");
			/* Protolib has defined this EXCEPTION event to indicate when
			   the host's IP addr has changed. */
			SetAddressListener();		// restart address notification listener

			fprintf(stderr, "Killing OLSR...\n");
			KillProcess(OLSR_processor_handle, "nrlolsr");
			ForkOLSR();

			fprintf(stderr, "Killing Dhcp relay...\n");
			KillProcess(DHCP_processor_handle, "dhcrelay");
			ForkDhcpRelay();

			break;
		}
		default:
			fprintf(stderr, "OnSocketEvent received unknown event.\n");
	}
	//GetAddress();

}  // end DhcpMgr::OnSocketEvent()

bool DhcpMgr::GetAddress(char* address) {
    ProtoAddress localAddress;
    if (localAddress.ResolveLocalAddress())
    {
        unsigned int index = dummy_socket.GetInterfaceIndex(localAddress.GetHostString());
		strcpy(address, (char*)localAddress.GetHostString());
		fprintf(stderr, "DhcpMgr::GetAddress() got interface addr: %s\n", address);

        char buffer[256];
        buffer[255] = '\0';
        ProtoAddress ifAddr;
#ifdef HAVE_IPV6
        if (dummy_socket.GetInterfaceAddress(buffer, ProtoAddress::IPv6, ifAddr))
        {
			strcpy(address, (char*)ifAddr.GetHostString());
            fprintf(stderr, "DhcpMgr::GetAddress() got IPv6 address: %s\n", address);
        }
#endif // HAVE_IPV6
		return true;
	} else {
		fprintf(stderr, "ERROR: DhcpMgr failed to get host address!\n");
		return false;
	}
}

void DhcpMgr::ForkDhcpRelay() {
	// grab the gateway address, and use it as the dhcp server.
	ProtoAddress address;
	ProtoAddress GWaddr;
	char cmdArgs[256];
	memset((void*)cmdArgs, 0, 256);
	unsigned int myint = 0;
	int myint2 = 0;
	char buffer[64];
	memset(buffer, 0, 64);
	ProtoRouteMgr* routeMgr = ProtoRouteMgr::Create();
	if (!routeMgr->GetRoute((const ProtoAddress&)address, 0, (ProtoAddress&)GWaddr, myint, myint2))
	{
		fprintf(stderr, "ERROR! DhcpMgr failed to get gateway address!\n");
		fprintf(stderr, "ERROR! DhcpMgr failing to fork Dhcp relay!\n");
		return;
	}
	if (debug) {
        sprintf(cmdArgs ,"-d -i eth0 %s", GWaddr.GetHostString(buffer, 64));
		fprintf(stderr ,"DhcpMgr: Calling dhcrelay with args %s\n", cmdArgs);
	} else {
		sprintf(cmdArgs ,"-i eth0 %s", GWaddr.GetHostString(buffer, 64));
		fprintf(stderr ,"DhcpMgr: Calling dhcrelay with args %s\n", cmdArgs);
	}

    // Fork dhcrelay once on startup, and never again (because it remains running
	// as a Cygwin daemon.
	SHELLEXECUTEINFO execinfo;
	execinfo.cbSize = sizeof(SHELLEXECUTEINFO);
	execinfo.fMask = SEE_MASK_NOCLOSEPROCESS;
	execinfo.hwnd = NULL;
	execinfo.lpVerb = NULL;
	execinfo.lpFile = "dhcrelay.exe";
	execinfo.lpParameters = cmdArgs;
	execinfo.lpDirectory = "C:\\WINDOWS\\NRLDhcpExt";
	execinfo.nShow = SW_SHOW;
	execinfo.hInstApp = NULL;
	if (!ShellExecuteEx(&execinfo))
	{
		fprintf(stderr, "ERROR: DhcpMgr failed to fork shell command %s!\n", execinfo.lpFile);
	} else {
		DHCP_processor_handle = execinfo.hProcess;
		fprintf(stderr, "DhcpMgr forked dhcrelay command.\n");

	}
}


void DhcpMgr::ForkOLSR() {
    
	char cmdArgs[256];
	memset((void*)cmdArgs, 0, 256);

	char interfaceString[256];
	memset((void*)interfaceString, 0, 256);

	if (strlen(ifaceName) > 0) {
		strcpy(interfaceString,ifaceName);
	} else {
		GetAddress(interfaceString);
	}

	if (debug) {
		sprintf(cmdArgs ,"-d 0 -i %s", interfaceString);
		fprintf(stderr ,"DhcpMgr: Calling nrlolsr with args %s\n", cmdArgs);
	} else {
		sprintf(cmdArgs ,"-d 0 -i %s background", interfaceString);
		fprintf(stderr ,"DhcpMgr: Calling nrlolsr with args %s\n", cmdArgs);	
	}

// Fork nrlOLSR
	SHELLEXECUTEINFO execinfo;
	execinfo.cbSize = sizeof(SHELLEXECUTEINFO);
	execinfo.fMask = SEE_MASK_NOCLOSEPROCESS;
	execinfo.hwnd = NULL;
	execinfo.lpVerb = NULL;
	execinfo.lpFile = "nrlolsr.exe";
	execinfo.lpParameters = cmdArgs;
	execinfo.lpDirectory = "C:\\WINDOWS\\NRLDhcpExt";
	execinfo.nShow = SW_SHOW;
	execinfo.hInstApp = NULL;

	if (!ShellExecuteEx(&execinfo))
	{
		fprintf(stderr, "ERROR: DhcpMgr failed to fork shell command %s!\n", execinfo.lpFile);
	} else {
		OLSR_processor_handle = execinfo.hProcess;
		fprintf(stderr, "DhcpMgr forked shell command.\n");
	}
}

void DhcpMgr::KillProcess(HANDLE post_processor_handle, char processName[256]) {
	Process* processes[] = Process::GetProcessesByName(processName);
	fprintf(stderr, "Got %d instances\n", processes->Length);

	for(int i=0; i<processes->Length; i++)
	{
		fprintf(stderr, "Process ID %d is instance %d of %d running %s\n", 
			processes[i]->Id, i+1, processes->Length, processName);
		processes[i]->Kill();
		fprintf(stderr, "%s process killed\n", processName);
	}
	CloseHandle(DHCP_processor_handle);
	DHCP_processor_handle = NULL;
}