#ifndef _PROTO_PKT
#define _PROTO_PKT

#include "protoDefs.h"

#include <string.h>     // for memcpy()
#include <netinet/in.h> // for ntohl(), htonl(), etc

// This is a base class that maintains a 32-bit aligned buffer for "packet"
// (or message) building and parsing.  Generally, classes will be derived
// from this base class to create classed for protocol-specific packet/message
// building and parsing (For examples, see ProtoPktIP, ProtoPktRTP, etc)

class ProtoPkt
{
    public:
        ProtoPkt();
        ProtoPkt(UINT32* bufferPtr, unsigned int numBytes, bool freeOnDestruct = false);
        virtual ~ProtoPkt();
        
        bool AllocateBuffer(unsigned int numBytes)
        {
            unsigned int len = numBytes / sizeof(unsigned int);
            len += (0 == (len % sizeof(int))) ? 0 : 1;
            buffer = buffer_allocated = new UINT32[len];
            buffer_bytes = (NULL != buffer) ? numBytes : 0;
            return (NULL != buffer);
        }
        void AttachBuffer(UINT32* bufferPtr, unsigned int numBytes, bool freeOnDestruct = false)
        {
            buffer = bufferPtr;
            buffer_bytes = (NULL != bufferPtr) ? numBytes : 0;
            if (NULL != buffer_allocated) delete[] buffer_allocated;
            if (freeOnDestruct) buffer_allocated = bufferPtr;
        }
        bool InitFromBuffer(unsigned int packetLength)
        {
            bool result = (packetLength <= buffer_bytes);
            length = result ? packetLength : 0;
            return result;
        }
        
        const char* GetBuffer() const {return (char*)buffer;} 
        unsigned int GetLength() const {return length;} 
        unsigned int GetLengthMax() const {return buffer_bytes;} 
        
        UINT32* AccessBuffer() {return buffer;}
        void SetLength(unsigned int bytes) {length = bytes;}
            
    protected:
        
        // These helper methods are defined for setting multi-byte protocol
        // fields in one of two ways:  1) "cast and assign", or 2) memcpy()
        //
#ifdef CAST_AND_ASSIGN
        static UINT16 GetUINT16(UINT16* ptr)
            {return ntohs(*ptr);}
        static UINT32 GetUINT32(UINT32* ptr)
            {return ntohl(*ptr);}
        static void SetUINT16(UINT16* ptr, UINT16 value) 
            {*ptr = htons(value);}
        static void SetUINT32(UINT32* ptr, UINT32 value)
            {*ptr = htonl(value);}
#else
        static UINT16 GetUINT16(UINT16* ptr)
        {
            UINT16 value;
            memcpy(&value, ptr, sizeof(UINT16));
            return ntohs(value);
        } 
        static UINT32 GetUINT32(UINT32* ptr)
        {
            UINT32 value;
            memcpy(&value, ptr, sizeof(UINT32));
            return ntohl(value);
        }
        static void SetUINT16(UINT16* ptr, UINT16 value)
        {
            value = htons(value);
            memcpy(ptr, &value, sizeof(UINT16));
        }
        static void SetUINT32(UINT32* ptr, UINT32 value)
        {
            value = htonl(value);
            memcpy(ptr, &value, sizeof(UINT32));
        }
#endif // if/else CAST_AND_ASSIGN            
            
            
        UINT32*         buffer;
        UINT32*         buffer_allocated;
        unsigned int    buffer_bytes;
        unsigned int    length;
        
};  // end class ProtoPkt

#endif // _PROTO_PKT
