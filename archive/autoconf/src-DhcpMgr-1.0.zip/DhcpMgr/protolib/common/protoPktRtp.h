#ifdef _PROTO_RTP
#define _PROTO_RTP

#include "protoPkt.h"

class ProtoPktRtp : public ProtoPkt
{
    public:             
        ProtoPktRtp();
        ProtoPktRtp(UINT32* bufferPtr, unsigned int numBytes);
        virtual ~ProtoPktRtp();
        
        enum {VERSION = 2};
        
        enum PayloadType
        {
            PCMU    =   0,
            CELP    =   1,
            G721    =   2,
            GSM     =   3,
            DVI48K  =   5,  //  8k sample rate
            DVI416K =   6,  // 16k sample rate
            LPC     =   7,
            PCMA    =   8,
            G722    =   9,
            L16S    =  10,  // stereo
            L16M    =  11   // monaural       
            // ... (more to add)
        };
        
        class HeaderExtension
        {
            public:
                HeaderExtension();
                virtual ~HeaderExtension();
                
                enum Type {INVALID};
                // This needs to be overridden for different extension types
                virtual void Init(UINT32* theBuffer) 
                {
                    buffer = theBuffer;
                    SetType(INVALID);
                    SetLength(0);
                }
                const UINT32* GetBuffer() {return buffer;}
                Type GetType() const
                {   
                    return buffer ? (Type)(((UINT16*)buffer)[TYPE_OFFSET]) : INVALID;
                }      
                unsigned int GetLength() const
                {
                    return buffer ? (4 * ((UINT16*)buffer)[LENGTH_OFFSET]) : 0;
                }
                
                void AttachBuffer(const UINT32* theBuffer) 
                    {buffer = (UINT32*)theBuffer;}
                void SetType(ProtoRtpMessage::HeaderExtension::Type type)
                {
                   (((UINT16*)buffer)[TYPE_OFFSET]) = (UINT16)type; 
                }
                void SetLength(unsigned int length)
                {
                    ((UINT16*)buffer)[LENGTH_OFFSET] = (UINT16)length;
                }
                
            protected:
                enum
                {
                    TYPE_OFFSET = 0,
                    LENGTH_OFFSET = (TYPE_OFFSET*2 + 2)/2,
                    CONTENT_OFFSET = (LENGTH_OFFSET*2 + 2);
                }
                UINT32* buffer;
        };  // end class ProtoPktRtp::HeaderExtension
        
        // RTP packet parsing
        bool InitFromBuffer(unsigned int packetLength);
        UINT8 GetVersion() const
        {
            UINT8 version = ((UINT8*)buffer)[VERSION_OFFSET];
            version >>= 6;
            return version;
        }   
        PayloadType GetPayloadType() const
        {
            UINT8 payloadType = ((UINT8*)buffer)[PAYLOAD_TYPE_OFFSET];
            return ((PayloadType)(0x7f & payloadType));
        }
        bool HasMarker() const
        {
            UINT8 marker = ((UINT8*)buffer)[MARKER_OFFSET];
            return (0 != (0x80 & marker));
        }
        UINT16 GetSequence() const
        {
            return (noths((((UINT16*)buffer)[SEQUENCE_OFFSET])));   
        }
        UINT32 GetTimestamp() const
        {
            return (nothl(buffer[TIMESTAMP_OFFSET]));
        }
        UINT32 GetSSRC() const
        {
            return ntohl(buffer[SSRC_OFFSET]);
        }
        UINT8 GetCsrcCount() const
        {
            return (((UINT8*)buffer)[CSRC_COUNT_OFFSET] & 0x0f);
        }
        UINT32 GetCSRC(UINT8 index) const
        {
            return ntohl(buffer[CSRC_OFFSET+index]);   
        }
        bool HasExtension() const 
        {
            UINT32 extension = buffer[EXTENSION_OFFSET]; 
            return (0 != (extension & 0x10000000));   
        }
        bool GetExtension(HeaderExtension& extension) const
        {
            if (HasExtension())
            {
                extension.AttachBuffer(buffer+3+GetCsrcCount());
                return true;
            }
            else
            {
                return false;
            }
        }
        unsigned int GetPayloadLength() 
        {
            unsigned int padding = HasPadding() ? ((UINT8*)buffer)[length-1] : 0;
            return (length - header_length - padding);
        }
        const char* GetPayload() {return (((char*)buffer) + header_length);}
        char* AccessPayload() {return (((char*)buffer) + header_length);}
        bool HasPadding() const
        {
            UINT32 padding = buffer[PADDING_OFFSET]; 
            return (0 != (padding & 0x20000000));  
        }
        UINT8 GetPaddingCount() const
        {
            return (HasPadding() ? ((UINT8*)buffer)[length-1] : 0);
        }
        
        // Message building 
        // The packet should be init'd first after attaching
        // or allocating a buffer
        void Init()
        {
            memset(buffer, 0, 12);
            SetVersion(VERSION);
            length = header_length = 12;  // 12 bytes with crsc_count = 0
        }
        void SetVersion(UINT8 version) 
        {
            version &= 0x03;
            ((UINT8*)buffer)[VERSION_OFFSET] &= 0x03f
            ((UINT8*)buffer)[VERSION_OFFSET] |= (version << 6);
        }
        void SetPayloadType(PayloadType payloadType)
        {
            ((UINT8*)buffer)[PAYLOAD_TYPE_OFFSET] &= 0x80;
            ((UINT8*)buffer)[PAYLOAD_TYPE_OFFSET] |= ((UINT8)payloadType & 0x7f);
        }
        void SetMarker(bool state)
        {
            ((UINT8*)buffer)[MARKER_OFFSET] = state ?
                (((UINT8*)buffer)[MARKER_OFFSET] | 0x80) :
                (((UINT8*)buffer)[MARKER_OFFSET] & 0x7f);
        }
        void SetSequence(UINT16 sequence)
        {
            (((UINT16*)buffer)[SEQUENCE_OFFSET]) = htons(sequence);
        }
        UINT32 SetTimestamp(UINT32 timestamp)
        {
            buffer[TIMESTAMP_OFFSET] = htonl(timestamp);
        }
        void SetSSRC(UINT32 ssrc)
        {
            buffer[SSRC_OFFSET] = htonl(ssrc);
        }
        // Must append any/all csrc before attaching extension or payload
        bool AppendCsrc(UINT32 csrc);
        // Must be called _before_ payload is set
        void AttachExtension(HeaderExtension& extension)
        {
            extension.Init(buffer + (header_length >> 2));
            header_length += (4 + extension.GetLength());
            length = header_length;
            buffer[EXTENSION_OFFSET] = (buffer[EXTENSION_OFFSET] | 0x10000000);
        }
        // Set payload last (before any needed padding)
        void SetPayload(const char* payload, unsigned int numBytes)
        {
            memcpy(AccessPayload(), payload, numBytes);
            length = header_length + numBytes;
        }
        // Set any needed padding last!
        void SetPadding(UINT8 numBytes, char* paddingPtr = NULL);
            
    private:
        unsigned int    header_length;
        enum
        {
            VERSION_OFFSET = 0,
            PADDING_OFFSET = VERSION_OFFSET,
            EXTENSION_OFFSET = PADDING_OFFSET,
            CSRC_COUNT_OFFSET = EXTENSION_OFFSET,
            MARKER_OFFSET = EXTENSION_OFFSET + 1,
            PAYLOAD_TYPE_OFFSET = MARKER_OFFSET,
            SEQUENCE_OFFSET = (PAYLOAD_TYPE_OFFSET + 1)/2,
            TIMESTAMP_OFFSET = (SEQUENCE_OFFSET*2 + 2)/4,
            SSRC_OFFSET = (TIMESTAMP_OFFSET*4 + 4)/4,
            CSRC_LIST_OFFSET = (SSRC_OFFSET*4 + 4)/4         
        };    
};  // end class ProtoPktRtp



#endif  // _PROTO_PKT_RTP
