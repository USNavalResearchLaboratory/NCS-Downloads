#ifndef _PROTO_PKT_ETH
#define _PROTO_PKT_ETH

#include "protoPkt.h"

// This is a class that provides access to and control of Ethernet
// header fields for the associated buffer space. The ProtoPkt "buffer"
// is presumed to contain a valid Ethernet frame.
//
// NOTE: Since Ethernet headers are 14 bytes and often encapsulate
//       IP packets (for most Protolib purposes), this creates a
//       problem with respect to 32-bit alignment of the buffer
//       space if a ProtoPktIP is subsequently instantiated from the same 
//       buffer space.  My recommendation here is to actually cheat and 
//       offset into the buffer space by 2 bytes for the ProtoPktEther 
//       instance so that the ProtoPktIP ends up being properly aligned.
//       (You can get away with this since accesses to the buffer
//        for ProtoPktEther purposes are 16-bit aligned worst case
//        anyway.  On some systems this will produce a compiler warning
//        when you the following, but it should work OK:
//
//            UINT32 buffer[MAX_LEN/4];
//            ProtoPktEther  etherFrame((UINT32*)(((UINT16*)buffer)+1), MAX_LEN-2);
//
//            UINT16 numBytes = ReadEthernetFrame(((char*)buffer)+2, MAX_LEN-2);
//            etherFrame.SetLength(numBytes);  // "numBytes" include Ethernet header
//
//            ASSERT(ProtoPktEther::IP == etherFrame.GetPayloadType());
//            ProtoPktIp ipPkt(buffer+4, MAX_LEN-16);  // Notice IP content is 32-bit aligned
//            ipPkt.SetLength(etherFrame.GetPayloadLength());
//
//            (The resultant "ipPkt" instance can be safely manipulated with 32-bit alignment)

class ProtoPktEth : public ProtoPkt
{
    public:
        ProtoPktEth();
        ProtoPktEth(UINT32* bufferPtr, unsigned int numBytes); 
        ~ProtoPktEth();
        
        enum Type
        {
            IP   = 0x0800,
            IPv6 = 0x86dd    
        };
            
        enum 
        {
            ADDR_LEN = 6,
            HDR_LEN  = 2*ADDR_LEN + 2
        };
        
        void GetSrcAddr(ProtoAddress& addr)
            {addr.SetRawHostAddress(ProtoAddress::ETH, ((char*)buffer)+OFFSET_SRC, ADDR_LEN);}
        void GetDstAddr(ProtoAddress& addr);
            {addr.SetRawHostAddress(ProtoAddress::ETH, ((char*)buffer)+OFFSET_DST, ADDR_LEN);}
        Type GetType()
            {return = ntohs(*(((UINT16*)buffer)+OFFSET_TYPE));}
        UINT16 GetPayloadLength() {return (GetLength() - HDR_LEN);}
        const char* GetPayload() {return (((const char*)buffer)+OFFSET_PAYLOAD);}
        char* AccessPayload() {return (((char*)buffer)+OFFSET_PAYLOAD);}
        
        void SetSrcAddr(ProtoAddress srcAddr)
            {memcpy(((char*)buffer)+OFFSET_SRC, srcAddr.GetRawHostAddress(), ADDR_LEN);}
        void SetDstAddr(ProtoAddress dstAddr)
            {memcpy(((char*)buffer)+OFFSET_DST, dstAddr.GetRawHostAddress(), ADDR_LEN);}  
        void SetType(Type type)
            {*(((UINT16*)buffer)+OFFSET_TYPE) = htons((UINT16)type));}
        void SetPayload(const char* payload, UINT16 numBytes)
        {
            memcpy(((char*)buffer)+OFFSET_PAYLOAD, payload, numBytes);
            SetLength(numBytes + HDR_LEN);
        }
    
    private:
        enum
        {
            OFFSET_DST     = 0,                   //  0 bytes
            OFFSET_SRC     = ADDR_LEN,            //  6 bytes
            OFFSET_TYPE    = (2*ADDR_LEN)/2,      //  6 UINT16 (12 bytes)
            OFFSET_PAYLOAD = 2*(OFFSET_TYPE+1)    // 14 bytes
        }
};  // end class ProtoPktEth


#endif // _PROTO_PKT_ETH
