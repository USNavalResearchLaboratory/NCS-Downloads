#include "protoPkt.h"

ProtoPkt::ProtoPkt()
 : buffer(NULL), buffer_allocated(NULL),
   buffer_bytes(0), length(0)
{
}

ProtoPkt::ProtoPkt(UINT32* bufferPtr, unsigned int numBytes, bool freeOnDestruct)
 : buffer(bufferPtr), buffer_allocated(freeOnDestruct ? bufferPtr : NULL),
   buffer_bytes(numBytes), length(0)
{    
    
}

ProtoPkt::~ProtoPkt()
{
    if (buffer_allocated)
    {
        buffer = NULL;
        delete[] buffer_allocated;
        buffer_allocated = NULL;
        buffer_bytes = 0;
    }   
}


