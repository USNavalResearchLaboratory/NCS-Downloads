#ifndef _PROTO_PKT_IP
#define _PROTO_PKT_IP

// This class provides a representation of an IP packet with
// methods to access and control various packet header fields
// (and the payload)

// For the moment, some methods common to IPv4 and IPv6 are 
// provided in this basic class, but in the future,
// we will derive separate ProtoPktIPv4 and ProtoPktIPv6 
// to access additional fields

class ProtoPktIP : public ProtoPkt
{
    public:
        ProtoPktIP();
        ProtoPktIP(UINT32* bufferPtr, unsigned int numBytes); 
        ~ProtoPktIP();
        
        UINT8 GetVersion() const
            {return (((UINT8*)buffer)[OFFSET_VERSION] >> 4);}
        
        void SetVersion(UINT8 version)
        {
            ((UINT8*)buffer)[OFFSET_VERSION] &= 0x0f;
            ((UINT8*)buffer)[OFFSET_VERSION] |= (version << 4);
        }
        
        // This is a partial list at the moment
        enum Protocol
        {
            HOPOPT   =   0,  // IPv6 hop-by-hop option                    
            ICMP     =   1,  // Internet Control Message Protocol         
            IGMP     =   2,  // Internet Group Mgmnt Protocol             
            IPIP     =   3,  // IP in IP encapsulation                    
            TCP      =   6,  // Transmission Control Protocol             
            UDP      =  17,  // User Datagram Protocol                    
            ICMPv6   =  58,  // ICMP for IPv6                             
            MLD      =  58,  // IPv6 Multicast Listener Discovery  
            EXP1     = 253,  // for experimental use
            EXP2     = 254,  // for experimental use     
            RESERVED = 255        
        };
        
    private:
        enum
        {
            OFFSET_VERSION = 0,   // 0 bytes (masked)
        }
    
};  // end class ProtoPktIP


class ProtoPktIPv4 : public ProtoPktIP
{
    public:
        ProtoPktIPv4();
        ProtoPktIPv4(UINT32* bufferPtr, unsigned int numBytes); 
        ~ProtoPktIP();
        
        UINT8 GetHeaderLength() const  // in bytes
            {return ((((UINT8*)buffer)[OFFSET_HDR_LEN] & 0x0f) << 2); }
        UINT8 GetTOS() const
            {return (((UINT8*)buffer)[OFFSET_TOS]);}
        UINT16 GetTotalLength() const
            {return ntohs(((UINT16*)buffer)[OFFSET_LEN]);}
        UINT16 GetId() const
            {return ntohs(((UINT16*)buffer)[OFFSET_ID]);}
        UINT8 GetFlags() const
            {return (((UINT8*)buffer)[OFFSET_FLAGS]);}
        UINT16 GetFragmentOffset() const
            {return (0x0fff & ((UINT16*)buffer)[OFFSET_FRAGMENT]);
        UINT8 GetTTL() const
            {return (((UINT8*)buffer)[OFFSET_TTL]);}
        Protocol GetProtocol() const
            {return (((UINT8*)buffer)[OFFSET_PROTOCOL]);}
        UINT16 GetChecksum() const
            {return ntohs(((UINT16*)buffer)[OFFSET_CHECKSUM]);} // (TBD) ??? is ntohs() needed ???   
        void GetSrcAddr(ProtoAddress& addr) const
            {addr.SetRawHostAddress(ProtoAddress::IPv4, (char*)(buffer+OFFSET_SRC_ADDR), 4);}
        void GetDstAddr(ProtoAddress& addr) const
                {addr.SetRawHostAddress(ProtoAddress::IPv4, (char*)(buffer+OFFSET_DST_ADDR), 4);}
        
        // (TBD) provide methods to get/set header options
        
        UINT16 GetPayloadLength() {return (GetTotalLength() - GetHeaderLength());}
        const char* GetPayload() {return ((const char*)buffer + GetHeaderLength());}
        char* AccessPayload() {return ((char*)buffer + GetHeaderLength());}
        
        // Use these to build a packet
        void SetHeaderLength(UINT8 hdrBytes) 
        {  
            ((UINT8*)buffer)[OFFSET_HDR_LEN] &= 0xf0;
            ((UINT8*)buffer)[OFFSET_HDR_LEN] |= (hdrLen >> 2);
        }
        void SetTOS(UINT8 tos) 
            {((UINT8*)buffer)[OFFSET_TOS] = tos;}
        void SetTotalLength(UINT16 numBytes) 
            {((UINT16*)buffer)[OFFSET_LEN] = htons(numBytes);}
        void SetId(UINT16 id)  
            {((UINT16*)buffer)[OFFSET_ID] = htons(id);}
        void SetFlags(UINT8 flags)
            {((UINT8*)buffer)[OFFSET_TOS] = flags;}
        void SetFragmentOffset(UINT16 fragmentOffset)  
        {
            ((UINT16*)buffer)[OFFSET_ID] &= 0xf000;
            ((UINT16*)buffer)[OFFSET_ID] |= htons(fragmentOffset);
        }
        void SetTOS(UINT8 ttl) 
            {((UINT8*)buffer)[OFFSET_TTL] = ttl;}
        void SetProtocol(Protocol protocol) 
            {((UINT8*)buffer)[OFFSET_PROTOCOL] = (UINT8)protocol;}
        void SetChecksum(UINT16 checksum)
            {((UINT16*)buffer)[OFFSET_CHECKSUM] = htons(checksum);}  // (TBD) ??? is htons() needed ???
        void SetSrcAddr(const ProtoAddress& addr)
            {memcpy((char*)(buffer+OFFSET_SRC_ADDR), addr.GetRawHostAddress(), 4);} // (TBD) leverage alignment?
        void SetDstAddr(const ProtoAddress& addr)
            {memcpy((char*)(buffer+OFFSET_DST_ADDR), addr.GetRawHostAddress(), 4);} // (TBD) leverage alignment?
        
        void SetPayloadLength(UINT16 numBytes)
            {SetTotalLength(numBytes + GetHeaderLength());}
        void SetPayload(const char* payload, UINT16 numBytes)
        {
            memcpy(AccessPayload(), payload, numBytes);
            SetPayloadLength(numBytes);   
        }
           
    private:
        enum
        {
            OFFSET_HDR_LEN  = OFFSET_VERSION,           // 0 bytes (masked)            
            OFFSET_TOS      = OFFSET_VERSION + 1,       // 1 bytes                     
            OFFSET_LEN      = (OFFSET_TOS+1)/2,         // 1 UINT16 (2 bytes)          
            OFFSET_ID       = OFFSET_LEN+1,             // 2 UINT16 (4 bytes)          
            OFFSET_FLAGS    = (OFFSET_ID+1)*2,          // 6 bytes  (masked)           
            OFFSET_FRAGMENT = OFFSET_FLAGS/2,           // 3 UINT16 (6 bytes) (masked) 
            OFFSET_TTL      = (OFFSET_FRAGMENT+1)*2,    // 8 bytes                     
            OFFSET_PROTOCOL = OFFSET_TTL+1,             // 9 bytes
            OFFSET_CHECKSUM = (OFFSET_PROTOCOL+1)/2,    // 5 UINT16 (10 bytes)
            OFFSET_SRC_ADDR = (OFFSET_CHECKSUM+1)*2)/4, // 3 UINT32 (12 bytes)
            OFFSET_DST_ADDR = OFFSET_SRC_ADDR+1,        // 4 UINT32 (16 bytes)
            OFFSET_OPTIONS  = (OFFSET_DST_ADDR+1)*4     // 20 bytes
        };  
};  // end classProtoPktIPv4


#endif // _PROTO_PKT_IP
