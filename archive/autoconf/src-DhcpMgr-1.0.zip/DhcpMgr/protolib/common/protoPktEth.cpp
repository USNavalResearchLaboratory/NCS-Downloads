#include "protoPktEth.h"

ProtoPktEth::ProtoPktEth()
{
}

ProtoPktEth::ProtoPktEth(UINT32* bufferSpace, unsigned int numBytes)
 : ProtoPkt(bufferSpace, numBytes)
{    
}

ProtoPktEth::ProtoPktEth()
{
}

