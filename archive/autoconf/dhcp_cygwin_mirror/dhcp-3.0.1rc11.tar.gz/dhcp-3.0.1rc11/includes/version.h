/* Current version of ISC DHCP Distribution. */

#define DHCP_VERSION	"V3.0.1rc11"
