#ifndef __TCSBOOT_H

#define __TCSBOOT_H

/* $Id: tcsboot.h,v 1.1 2005/09/15 14:30:17 bstern Exp $ */

/* What should we identify ourselves as in syslog? */
#define PROGRAM "tcsboot"

/* What facility should we syslog at? */
#define FACILITY LOG_DAEMON

/* What TCP port should tcsboot listen on for systems to phone home and let us
    know that installation was successful and they don't need to be netbooted
    again?  This MUST match the port number in netboot.pl to work properly. */
#define PORTNO 31678

/* Where is the TCS- and tcsboot-generated netboot.conf stored?
    This MUST be the directory that is NFS exported to serve as the netbooted
    system's / (and must be specified in the dhcpd.conf). */
#define NETBOOT_CONF "/export/miniroot/netboot.conf"

/* Where is the TCS-generated hw.config file stored? */
#define HW_CONF "/mantis/hw.config"

/* How do we restart dhcpd?  Note that Fedora Core 3's stock init script appears
    to be totally broken.  The accompanying init script has been tested and
    worked for me. */
#define RESTART "/etc/init.d/dhcpd restart"

/* Where is your dhcpd.conf stored? */
#define DHCPD_CONF "/etc/dhcpd.conf"

/* Indicates where we can start to rewirte the dhcpd.conf. */
#define NOEDIT "# DO NOT EDIT BELOW THIS LINE\n"

/* If your dhcpd.conf has "deny unknown-clients;" as it ought, define the next
    line to leave out non-netbooting hosts from the dhcpd.conf (and thereby
    make it easier to read for humans. */
#define UNKNOWN_DENIED

/* You should not normally need to edit anything below this line. */

/* Hold interesting information from the TCS hw.config file.
    It is currently a simple linked list, but since it is only expected to hold
    about 100 entries, the linear search is adequate. */
struct hosts {
    struct hosts *next;
    int netboot;
    char ip[16]; /* "123.567.9ab.def" */
    char mac[18]; /* 12:45:78:ab:de:01" */
    char name[0]; /* We don't know how long this needs to be at decl time. */
};

/* Signal handler for HUP and TERM */
void hup(int signum);

/* Marks hosts for netbooting. */
int markup(struct hosts *h, const char *name);

/* Processes hw.config to learn about test nodes. */
int process(void);

/* Removes nodename from netboot.conf and triggers rewrite of dhcpd.conf. */
int rewrite(int sock);

#endif
