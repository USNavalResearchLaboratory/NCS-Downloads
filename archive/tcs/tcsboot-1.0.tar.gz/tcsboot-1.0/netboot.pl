#!/usr/bin/perl -w

# $Id: netboot.pl,v 1.17 2005/11/07 17:56:15 bstern Exp $

use Sys::Hostname;
use Socket;
# use Data::Dumper;
use strict;

my $DEV = 'hda'; # Which device are we stomping on?
my $NETBOOT_CONF = "/netboot.conf"; # From the NFS root POV, where is config?
my $PORT = 31678; # Where does tcsboot listen for successful boot indication?

## my $PARTED = "/sbin/parted -s";
#my $DD = "/bin/dd bs=512b if=/dev/zero";
my $DD = "/bin/dd if=/dev/zero";
my $RSYNC = "/usr/bin/rsync -rzlxHpogDtSP --progress --stats"; # --rsh=ssh";

# Side note: The 60GB hard drives we are using are 117210240 blocks large.
# 117210240 blocks = (2^7 * 3^4 * 5 * 7 * 17 * 19) blocks * 2^9 bytes/block

# Local variables.
my ($hwaddr, $wipedisk, %chgpart, %parts, @curparts, $rv, @fsli);
my %newpars = ();
my $nbh;

# Prettyprint some information.  This function arguments gets Yoda like.
# showmsg(LEVEL, "bar", "foo:") will print "foo: bar\n" in some manner.
# showmsg(LEVEL, "baz") will print "baz\n" in some manner.
sub showmsg($$;$) {
    my ($level, $msg, $prefix) = @_;

    print "$prefix " if defined $prefix;
    if ($level eq 'fail') { print "\033[1;31m"; }
    elsif ($level eq 'warn') { print "\033[1;33m"; }
    elsif ($level eq 'success') { print "\033[1;32m"; }
    print $msg;
    print "\033[0;39m\n";
    if ($level eq 'fail') { sleep 5; exit 1; }
    # elsif ($level eq 'warn') { sleep 2; }
}

sub checkpoint($;$) {
    my ($name, $state) = @_;
    my @ipb = split /\./, $nbh, 4;
    my $binip = pack('CCCC', @ipb);
    my $paddr = sockaddr_in($PORT, $binip);

    showmsg('success', $nbh, 'Checking in with remote server');
    socket(NBH, PF_INET, SOCK_STREAM, 0) or
        showsmg('fail', $!, 'Could not open socket:');
    connect NBH, $paddr or showmsg('fail', $!, 'Could not connect:');
    my $hid = pack('C', length $name);
    print NBH $hid;
    print NBH $name;
    $state = '' unless defined $state;
    $hid = pack('C', length $state);
    print NBH $hid;
    print NBH $state if $state ne '';
    close NBH;
}

sub fixfstab($) {
    my $i = shift;
    my $ft = lc $newpars{$i}{'fstype'};
    my $opt = $newpars{$i}{'fsopts'};

    showmsg('success', '/etc/fstab', 'Fixing up');
    $opt =~ s/;/,/g; # fix the options line
    open FSTAB, ">/mnt/dc/etc/fstab" or
        showmsg('fail', $!, 'Could not open (/mnt/dc)/etc/fstab:');
    print FSTAB qq|LABEL=/\t/\t$ft\t$opt\t1 1
none\t/dev/pts\tdevpts\tgid=5,mode=620\t0 0
none\t/dev/shm\ttmpfs\tdefaults\t0 0
none\t/proc\tproc\tdefaults\t0 0
none\t/sys\tsysfs\tdefaults\t0 0
|;
# pulled #/dev/hdc       /media/cdrecorder   auto  pamconsole,fscontext=system_u:object_r:removable_t,ro,exec,noauto,managed  0 0
    print "Adding variable partitions...\n";
    foreach my $j (@fsli) {
        my $mp = $newpars{$j}{'mountpoint'};
        my $d = $newpars{$j}{'fsopts'};
        next unless defined $mp and $mp ne '' and $mp ne '/';
        my $jf = $newpars{$j}{'fstype'};
        next if $jf ne 'swap' and $jf ne 'ext2' and $jf ne 'ext3';
        if ($jf ne 'swap') {
            print FSTAB "LABEL=$mp\t\t$mp\t\t$jf\t$d\t1 2\n";
        } else {
            print FSTAB "LABEL=SWAP-$DEV$j\tswap\t\tswap\t" .
                "defaults\t0 0\n";
        }
        showmsg('success', $mp, 'Adding:');
    }
    close FSTAB;
}

sub fixsyscfg($$) {
    my ($a, $n) = @_;
    my @hnp;
    my $i;

    $n =~ s/-ctrl//; # in case someone used a weird name
    @hnp = split(/-/, $n);
    $i = pop @hnp;

    $i = 161 if $i eq 'alpha';
    $i = 162 if $i eq 'bravo';
    $i = 163 if $i eq 'charlie';
    $i = 164 if $i eq 'delta';
    $i = 165 if $i eq 'echo';
    $i = 166 if $i eq 'foxtrot';
    $i = 167 if $i eq 'golf';
    $i = 168 if $i eq 'hotel';
    $i = 169 if $i eq 'india';
    $i = 170 if $i eq 'juliet';
    $i = 171 if $i eq 'kilo';
    $i = 172 if $i eq 'lima';
    showmsg('fail', 'Invalid hostname', 'Could not determine IP from name:')
        unless defined $i and ($i =~ /\d+/);
    
    open NETW, ">/mnt/dc/etc/sysconfig/network" or
        showmsg('fail', $!, 'Could not open .../etc/sysconfig/network:');
    print NETW "NETWORKING=yes\nHOSTNAME=$n\nNOZEROCONF=1\n" or
        showmsg('fail', $!, 'Could not write to .../etc/sysconfig/network:');
    close NETW or
        showmsg('fail', $!, 'Could not close .../etc/sysconfig/network:');

    open CFGE, ">/mnt/dc/etc/sysconfig/network-scripts/ifcfg-eth0" or
        showmsg('fail', $!, 'Could not open ifcfg-eth0 for writing:');
    print CFGE "DEVICE=eth0\nONBOOT=yes\nBOOTPROTO=static\nIPADDR=192.168.3." or
        showmsg('fail', $!, 'Could not write to ifcfg-eth0:');
    print CFGE sprintf("%d\nNETMASK=255.255.255.0\nGATEWAY=0.0.0.0\n", $i) or
        showmsg('fail', $!, 'Could not write IP to ifcfg-eth0:');
    print CFGE "HWADDR=$a\n" or
        showmsg('fail', $!, 'Could not write MAC to ifcfg-eth0:');
    close CFGE or showmsg('fail', $!, 'Could not close ifcfg-eth0:');

    open HOSTSO, "</mnt/dc/etc/hosts" or
        showmsg('fail', $!, 'Could not open .../etc/hosts for read:');
    open HOSTSN, ">/mnt/dc/etc/hosts.$$" or
        showmsg('fail', $!, "Could not open .../etc/hosts.$$ for write:");
    while (my $l = <HOSTSO>) {
        if ($l =~ /127\.0\.0\.1/) {
            print HOSTSN "127.0.0.1\t$n\tlocalhost.localdomain\tlocalhost\n";
        } else {
            print HOSTSN $l;
        }
    }
    close HOSTSO or showmsg('fail', $!, 'Could not close hosts:');
    close HOSTSN or showmsg('fail', $!, "Could not close hosts.$$:");
    rename "/mnt/dc/etc/hosts.$$", '/mnt/dc/etc/hosts' or
        showmsg('fail', $!, "Could not rename hosts.$$ to hosts:");
}

sub fixgrub($) {
    my $i = shift;
    $rv = shellwrap("/bin/mount /dev/$DEV$i /boot");
    exit $rv if $rv;
    $rv = shellwrap("/sbin/grub-install hd0");
    exit $rv if $rv;
    $rv = shellwrap("umount /boot");
    exit $rv if $rv;
}

sub sleeper($$) {
    my ($len, $msg) = @_;

    print $msg . "You have $len seconds to stop me: ";
    foreach (1 .. $len) {
        print '.';
        sleep 1;
    }
    print " Starting.\n";
}

sub readparts() {
    @curparts = ();
    open PF, '</proc/partitions' or
       showmsg('fail', $!, 'Could not open /proc/partitions:');
    while (<PF>) {
        chomp;
        if ($_ =~ /$DEV(\d+)/) {
            push @curparts, $1;
        }
    }
    close PF;
}

sub shellwrap($) {
    my $cmd = shift;
    print "Running `$cmd'... ";
    my $rv = system($cmd);
    my @name = split(/ /, $cmd);
    $cmd = shift @name;
    @name = split(/\//, $cmd);
    $cmd = pop @name;
    if ($rv < 0) {
        showmsg('fail', $!, "\nCould not execute $cmd:");
    } elsif ($rv & 127) {
        ## $msg .= " (core dumped)" if $rv & 128;
        showmsg('warn', $rv & 127, "\n$cmd killed by signal");
    } elsif ($rv) {
        $rv >>= 8;
        showmsg('warn', $rv, "\n$cmd returned");
    } else {
        showmsg('success', 'done');
    }
    return $rv;
}

sub runfdisk(@) {
    my @cmds = @_;
    my $cmd = 0;

    print "About to issue fdisk commands...\n";
    print join(' ', @cmds, "\n");

    open FDISK, "|/sbin/fdisk /dev/$DEV" or
        showmsg('fail', $!, 'Could not run fdisk:');
    foreach (@cmds) {
        print FDISK "$_\n" or
            showmsg('fail', $!, "Could not issue command $cmd ($_):");
        $cmd++;
    }
    print FDISK "w\n" or
         showmsg('fail', $!, 'Could not tell fdisk to write:');
    close FDISK or showmsg('fail', $!, 'Could not end fdisk commands:');
}


# main

print "*** I have just booted. ***\n";

open FOO, '/sbin/ifconfig eth0|' or
    showmsg('fail', $!, 'Could not run /sbin/ifconfig:');
$hwaddr = <FOO>;
while (<FOO>) { } # consume the rest of the output
close FOO;
my @tmp = split(' ', $hwaddr);
$hwaddr = pop @tmp;
$hwaddr = lc $hwaddr;
#$hwaddr =~ s/://g;

my $hostname = hostname();

print "My hardware address is $hwaddr and my hostname is $hostname.\n";
readparts;

my $cmds;

open CFG, "</netboot.conf" or
    showmsg('fail', $!, "Could not open $NETBOOT_CONF:");
my $scenario = <CFG>;
showmsg('fail', $! ne '' ? $! : 'syntax error',
    "Insufficient information in $NETBOOT_CONF:") unless
    defined $scenario and $scenario ne '';

chomp $scenario;
showmsg('success', $scenario, "Will look for scenario information in:\n");

while (<CFG>) {
    chomp;
    next unless /^$hostname:(.*)/;
    $cmds = $1;
}
close CFG;

showmsg('fail', 'Stop.', "Commands not found in $NETBOOT_CONF -") unless
    defined $cmds;

showmsg('success', $cmds, 'My command string is');

my @toks = split //, $cmds;
my $start = shift @toks;

showmsg('success', $start, 'Starting at state');

showmsg('fail', 'Bailing out.') if ($start eq 'Z');

open DMESG, "</var/log/dmesg" or
    showmsg('fail', $!, 'Could not open /var/log/dmesg:');
while (<DMESG>) {
    if ($_ =~ /Got DHCP answer from (\d+\.\d+\.\d+\.\d+)/) {
        $nbh = $1;
        last;
    }
}
close DMESG;
showmsg('fail', 'Stop.', 'Could not find netboot server. ') unless defined $nbh;

print "Mounting server with disk.conf ...\n" if 0;
$rv = shellwrap("/bin/mount $scenario/$hostname /mnt/di");
exit $rv if $rv;

open DCONF, "</mnt/di/control/disk.conf" or
    showmsg('fail', $!, 'Could not open disk.conf:');
while (<DCONF>) {
    chomp;
    my @items = split /,/;
    my $idx = shift @items;
    my ($start, $end) = split /-/, shift @items;
    my %h;
    $h{'start'} = $start;
    $h{'end'} = $end if defined $end;
    $h{'fstype'} = shift @items;
    if ($h{'fstype'} ne 'EXTENDED') {
        $h{'mountpoint'} = shift @items;
        $h{'fsopts'} = shift @items;
        $h{'source'} = shift @items;
    }
    $newpars{$idx} = \%h;
}
close DCONF;
@fsli = (keys %newpars);

if ($start == 0) {
    my $step = shift @toks;

    if ($step eq 'D') { # delete all partitions
        print "Deleting all partitions.\n";
    } elsif ($step eq 'W' or $step eq 'X') { # wipe entire disk
        print "Wiping disk";
        print " and halting" if $step eq 'X';
        print ".\n";
        $rv = shellwrap("$DD bs=65536 count=915705 of=/dev/$DEV");
        exit $rv if $rv;
        # $rv = shellwrap("/bin/touch /tmp/dd.done");
        # exit $rv if $rv;
        checkpoint($hostname, '0D') if $step eq 'W'; # transition from 0W to 0D
    }

    runfdisk(qw(o)) if $step ne 'R' and $step ne 'C';

    if ($step eq 'X') {
        checkpoint($hostname); # Take it out of netbooting
        exec "/sbin/shutdown -h now" or
            showmsg('fail', $!, 'Could not shut down:');
    }

    if ($step ne 'R' and $step ne 'C') {
        @curparts = ();

        my $i;
        my @fcm = ();
        foreach $i (sort keys %newpars) {
            my $ft = lc $newpars{$i}{'fstype'};
            my $s = $newpars{$i}{'start'};
            my $e = $newpars{$i}{'end'};

            # XXX assume that partitions are contiguous
            # Assume there are always 4 primary partitions
            push @fcm, 'n'; # new
            if ($i < 5) {
                if ($ft eq 'extended') { push @fcm, 'e'; }
                else { push @fcm, 'p'; }
                push @fcm, $i unless $i == 4; # fdisk chooses 4 automatically
            }
            push @fcm, ''; # select default start cylinder
            if (defined $e and $e ne '') {
                push @fcm, sprintf("+%dM", $e - $s); # size in megs
            } else {
                push @fcm, '';
            }
            push @fcm, 't', $i, 82 if $ft eq 'swap';
        }
        push @fcm, 'p';

        runfdisk(@fcm);

        my @parlist = (sort keys %newpars);
        for (my $wait = 0; $wait < 50; $wait++) {
            my @npl = ();
            foreach (@parlist) {
                if (open NONSENSE, "</dev/$DEV$_") {
                    close NONSENSE;
                    next;
                } else {
                    push @npl, $_;
                }
            }
            last unless scalar @npl > 0;
            sleep 1;
            print "Still waiting for partitions: " . join('/', @npl) .
                " [$wait]\n";
        }
        checkpoint($hostname, '0R');
    }

    if ($step ne 'C') {
        foreach my $i (sort keys %newpars) {
            my $ft = lc $newpars{$i}{'fstype'};

            if ($ft eq 'ext2' or $ft eq 'ext3') {
                my $mp = $newpars{$i}{'mountpoint'};
                $rv = shellwrap("/sbin/mkfs.$ft -L $mp /dev/$DEV$i");
                exit $rv if $rv;
            } elsif ($ft eq 'swap') {
                $rv = shellwrap("/sbin/mkswap /dev/$DEV$i");
                exit $rv if $rv;
            } else {
                print "Not placing a new fs on partition $i of type $ft.\n";
            }
        }
        checkpoint($hostname, '0C');
    }

    my $sl = '1C';
    my @parl = ();
    foreach (sort keys %newpars) {
        my $src = $newpars{$_}{'source'};
        next unless defined $src and $src ne '';
        $sl .= $_;
        push @parl, $_;
    }
    checkpoint($hostname, $sl);

    foreach my $i (sort keys %newpars) {
        my $src = $newpars{$i}{'source'};
        next unless defined $src and $src ne '';
        # now we have to lay new data down, since we torched the last set
        next unless defined $src and $src ne '';
        showmsg('success', "$src -> $DEV$i", 'Copying data:');
        $rv = shellwrap("/bin/mount /dev/$DEV$i /mnt/dc");
        exit $rv if $rv;
        $src =~ s/\//:/; # convert to rsync path
        $rv = shellwrap("$RSYNC $src/ /mnt/dc");
        exit $rv if $rv;
        $rv = shellwrap("/bin/umount /mnt/dc");
        exit $rv if $rv;
        shift @parl;
        checkpoint($hostname, '1C' . join('', @parl));
    }

} elsif ($start == 1) {
    my $step;
    my $mode;
    my %pars = ();
    my %modes = (
        'W' => 'wipe', # dd the partition
        'R' => 'reformat', # newfs the partition
        'S' => 'sync', # synchronize (deleting unneeded files)
        # 'D' => 'delete', # delete the partition and readd - not useful
        'O' => 'overwrite', # overwrite existing files, no deletion though
        'C' => 'copy', # copy only - no overwrite, no delete
    );
    my %revmodes = (
        'wipe' => 'W',
        'reformat' => 'R',
        'sync' => 'S',
        'overwrite' => 'O',
        'copy' => 'C',
    );

    foreach $step (@toks) {
        if (defined $modes{$step}) {
            showmsg('success', $modes{$step}, 'Identified mode:');
            $mode = $modes{$step};
        } elsif (defined $mode and ($step =~ /^\d$/)) {
            showmsg('success', $step, "Applying $mode to partition");
            $pars{$step} = $mode;
        } else {
            showmsg('fail', $step, 'Undefined mode in stage 1:');
        }
    }

    my @opl = sort keys %pars;
    foreach $step (@opl) {
        next unless $pars{$step} eq 'wipe';
        $rv = shellwrap("$DD bs=512 of=/dev/$DEV$step");
        exit $rv if $rv;
        $pars{$step} = 'reformat';
        my $sl = '1';
        my $last = '';
        foreach (sort keys %pars) {
            $sl .= $revmodes{$pars{$_}} unless $last eq $revmodes{$pars{$_}};
            $last = $revmodes{$pars{$_}};
            $sl .= $_;
        }
        checkpoint($hostname, $sl);
    }

    # we're done with wiping now
    # if (open DDDONE, ">/tmp/dd.done") {
    #     close DDDONE;
    # } else {
    #     warn "Could not create /tmp/dd.done: $!\n";
    # }

    foreach $step (@opl) {
        next unless $pars{$step} eq 'reformat';
        my $t = $newpars{$step}{'fstype'};
        if ($t eq 'ext2' or $t eq 'ext3') {
            my $mp = $newpars{$step}{'mountpoint'};
            $rv = shellwrap("/sbin/mkfs.$t -L $mp /dev/$DEV$step");
            exit $rv if $rv;
            $pars{$step} = 'copy'; # can't sync other partition types
        } elsif ($t eq 'swap') {
            $rv = shellwrap("/sbin/mkswap /dev/$DEV$step");
            exit $rv if $rv;
            delete $pars{$step}; # It's done.
        } else {
            showmsg('warn', $t, "Refusing to newfs partition $step of type:");
        }
        my $sl = '1';
        my $last = '';
        foreach (sort keys %pars) {
            $sl .= $revmodes{$pars{$_}} unless $last eq $revmodes{$pars{$_}};
            $last = $revmodes{$pars{$_}};
            $sl .= $_;
        }
        checkpoint($hostname, $sl);
    }

    foreach $step (sort keys %pars) {
        my $ft = lc $newpars{$step}{'fstype'};
        my $src = $newpars{$step}{'source'};
                                
        shift @opl;
        next unless defined $src and $src ne ''; # skips swap, raw, and extended

        my $cmd = $RSYNC;
        my $act;
        if ($pars{$step} eq 'copy') {
            $cmd .= ' -u';
            $act = 'Copying';
        } elsif ($pars{$step} eq 'sync') {
            $cmd .= ' --delete --delete-excluded --force';
            $act = 'Synchronizing';
        } elsif ($pars{$step} eq 'overwrite') {
            # nothing else needed
            # (This is of especial interest if one is copying a series of
            # directories on top of each other.)
            $act = 'Overwriting changed';
        } else {
            showmsg('fail', $step, 'Cannot act on partition');
        }
        $src =~ s/\//:/; # convert to rsync path
        $cmd .= " $src/ /mnt/dc";

        showmsg('success', "$src -> $DEV$step", "$act data:");
        $rv = shellwrap("/bin/mount /dev/$DEV$step /mnt/dc");
        exit $rv if $rv;
        $rv = shellwrap($cmd);
        exit $rv if $rv;
        $rv = shellwrap("/bin/umount /mnt/dc");
        exit $rv if $rv;

        my $sl = '1';
        my $last = '';
        foreach (@opl) {
            $sl .= $revmodes{$pars{$_}} unless $last eq $revmodes{$pars{$_}};
            $last = $revmodes{$pars{$_}};
            $sl .= $_;
        }
        checkpoint($hostname, $sl);
    }
}

checkpoint($hostname, '2'); # We've done all of the prep work.

# do rotation through mount points

foreach my $i (sort keys %newpars) {
    my $src = $newpars{$i}{'source'};
    next unless defined $newpars{$i}{'mountpoint'};
    if ($newpars{$i}{'mountpoint'} eq '/') { # assume /etc is on /
        $rv = shellwrap("/bin/mount /dev/$DEV$i /mnt/dc");
        exit $rv if $rv;
        fixfstab($i);
        fixsyscfg($hwaddr, $hostname);
        $rv = shellwrap("/bin/umount /mnt/dc");
        exit $rv if $rv;
    } elsif ($newpars{$i}{'mountpoint'} eq '/boot') {
        showmsg('success', "/dev/$DEV$i", 'Adding GRUB configuration for:');
        fixgrub($i);
    }
}

# Now sync with root_base_1
my @inter = ();
foreach (keys %newpars) {
    push @inter, $_ if defined $newpars{$_}{'mountpoint'} and
        $newpars{$_}{'mountpoint'} ne '' and
        $newpars{$_}{'mountpoint'} ne 'swap';
}
my @tree = sort {
    $newpars{$a}{'mountpoint'} cmp $newpars{$b}{'mountpoint'}
} @inter;
foreach (@tree) {
    $rv = shellwrap("/bin/mount /dev/$DEV$_ /mnt/dc" .
        $newpars{$_}{'mountpoint'});
    exit $rv if $rv;
}

showmsg('success', "$scenario/$hostname/root_base_1/",
    'Now synchronizing with:');
$rv = shellwrap("$RSYNC /mnt/di/root_base_1/ /mnt/dc");
exit $rv if $rv;

print "Activating SELinux system relabelling on next boot...\n";
$rv = shellwrap("/bin/touch /mnt/dc/.autorelabel");
exit $rv if $rv;

while (scalar @tree) {
    my $remove = pop @tree;
    $rv = shellwrap("/bin/umount /mnt/dc" . $newpars{$remove}{'mountpoint'});
    exit $rv if $rv;
}

print "Unmounting server with disk.conf ...\n";
$rv = shellwrap("/bin/umount /mnt/di");
exit $rv if $rv;

checkpoint($hostname); # take us out of netbooting

print "Getting ready to reboot...\n";

showmsg('success', '[Netbooting completed successfully.]');

exit 0;
