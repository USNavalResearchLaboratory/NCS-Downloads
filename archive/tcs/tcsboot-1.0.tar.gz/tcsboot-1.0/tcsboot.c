#include <stdio.h>
#include <errno.h>
#include <syslog.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <features.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <sys/time.h>

#include "tcsboot.h"

/* $Id: tcsboot.c,v 1.3 2005/11/07 16:05:43 bstern Exp $ */

volatile sig_atomic_t reread = 1; /* triggers reread of netboot.conf */
volatile sig_atomic_t die = 0; /* we got a TERM or we're in trouble */

/* Helper function to clear the struct hosts linked list. */
static void freehosts(struct hosts *h) {
    register struct hosts *i = h;

    while (i != NULL) {
        h = i->next;
        free(i);
        i = h;
    }
}

void hup(int signum) {
    if (signum == SIGHUP) {
        reread = 1;
    } else /* if (signal == SIG_TERM) */ {
        die = 1; /* We're done. */
    }

#if !(defined(__GLIBC__) && (__GLIBC__ >= 2))
    /* Old GNU C libraries require that the signal handler be reset. */
    if (signal(signum, hup) == SIG_ERR) {
        die = 1; /* We couldn't reset the signal handler. */
    }
#endif
}

int markup(struct hosts *h, const char *name) {
    int rv = 0;
    struct hosts *i = h;

    while (i != NULL) {
        if (!strcmp(i->name, name)) {
#if 0
            syslog(LOG_DEBUG, "Tagging node %s for netbooting", name);
#endif
            i->netboot = 1;
            rv++;
            break;
        } else {
            i = i->next;
        }
    }
    return rv;
}

int process(void) {
    struct hosts *iter, *h = NULL;
    FILE *f = fopen(HW_CONF, "r");
    int rv = 0;
    char line[BUFSIZ];
    char *idx;
    int i, t, ln = 0;
    char *mac, *ip, *name;
    char tn[] = DHCPD_CONF ".XXXXXX";

    if (f == NULL) {
        rv = errno;
        syslog(LOG_ERR, "Could not open " HW_CONF ": %m");
        return rv;
    }
    do {
        idx = fgets(line, BUFSIZ, f);
        if (idx != NULL) {
            ln++;
            idx = strchr(line, '#');
            if (idx != NULL) *idx = 0;
            if ((line[0] == '\0') || (line[0] == '\n')) continue;
            i = 0;
            idx = strtok(line, ",");
            mac = ip = name = NULL;
            while ((idx != NULL) && (i++ < /* 6 */ 3)) {
                /* Actually, we don't want the first word anyway. */
                idx = strtok(NULL, ",");
                if (i == 1) mac = idx;
                else if (i == 2) ip = idx;
                else if (i == 3) name = idx;
            }
            if ((ip == NULL) || (mac == NULL) || (name == NULL)) {
                syslog(LOG_WARNING, "Skipping line %d of " HW_CONF
                    ": not enough commas", ln);
            } else {
#if 0
                syslog(LOG_DEBUG, "Identified system %s: %s/%s", name, ip, mac);
#endif
                iter = malloc(sizeof (struct hosts) + strlen(name) + 1);
                if (iter == NULL) {
                    rv = errno;
                    syslog(LOG_ERR, "Could not allocate %u bytes: %m",
                        sizeof (struct hosts) + strlen(name) + 1);
                    freehosts(h);
                    return rv;
                }
                strcpy(iter->name, name);
                strcpy(iter->ip, ip);
                strcpy(iter->mac, mac);
                iter->next = h;
                iter->netboot = 0;
                h = iter;
            }
        } /* fgets != NULL */
    } while (!feof(f));
    fclose(f);

    f = fopen(NETBOOT_CONF, "r");
    if (f == NULL) {
        rv = errno;
        syslog(LOG_ERR, "Could not open " NETBOOT_CONF ": %m");
        freehosts(h);
        return rv;
    }
    idx = fgets(line, BUFSIZ, f); /* skip this line */
    ln = 1;
    while (!feof(f) && ((idx = fgets(line, BUFSIZ, f)) != NULL)) {
        ln++;
        idx = strchr(line, '#');
        if (idx != NULL) *idx = 0;
        if ((line[0] == '\0') || (line[0] == '\n')) continue;
        idx = strtok(line, ":,"); /* should be , but is : right now */
        if (idx == NULL) {
            syslog(LOG_WARNING, "Skipping line %d of " NETBOOT_CONF
                ": no host entry", ln);
        } else if (!markup(h, idx)) {
            syslog(LOG_WARNING, "Ignoring line %d of " NETBOOT_CONF
                ": no match for %s", ln, idx);
        }
    }
    fclose(f);

    f = fopen(DHCPD_CONF, "r");
    if (f == NULL) {
        rv = errno;
        syslog(LOG_ERR, "Could not open " DHCPD_CONF ": %m");
        fclose(f);
        freehosts(h);
        return rv;
    }
    t = mkstemp(tn);
    if (t < 0) {
        rv = errno;
        syslog(LOG_ERR, "Could not create temp file: %m");
        fclose(f);
        freehosts(h);
        return rv;
    }
    do {
        if (fgets(line, BUFSIZ, f) != NULL) {
            write(t, line, strlen(line));
            if (!strcmp(line, NOEDIT)) break;
        }
    } while (!feof(f));

    iter = h;
    while (iter != NULL) {
#if 0
        syslog(LOG_DEBUG, "Adding entry for %s: %s/%s (%u)", iter->name,
            iter->ip, iter->mac, iter->netboot);
#endif
        if (iter->netboot) {
            snprintf(line, BUFSIZ, "\t\thost %s {\n\t\t\thardware ethernet "
                "%s;\n\t\t\tfixed-address %s;\n\t\t}\n", iter->name, iter->mac,
                iter->ip);
        } else {
#ifdef UNKNOWN_DENIED
            line[0] = 0;
#else
            snprintf(line, BUFSIZ, "\t\thost %s {\n\t\t\thardware ethernet "
                "%s;\n\t\t\tdeny booting;\n\t\t}\n", iter->name, iter->mac);
#endif
        }
        line[BUFSIZ] = 0;
        if (write(t, line, strlen(line)) < 0) {
            rv = errno;
            syslog(LOG_ERR, "Could not write to temporary DHCPD config: %m");
            close(t);
            freehosts(h);
            return rv;
        }
        iter = iter->next;
    }
    if (write(t, "\t}\n}\n", 5) < 0) {
        rv = errno;
        syslog(LOG_ERR, "Could not write suffix to temp config: %m");
        close(t);
    } else if (close(t) < 0) {
        rv = errno;
        syslog(LOG_ERR, "Could not close temporary file: %m");
    } else if (rename(tn, DHCPD_CONF) < 0) {
        rv = errno;
        syslog(LOG_ERR, "Could not rename DHCP daemon configuration: %m");
    } else if ((rv = system(RESTART) < 0)) {
        syslog(LOG_ERR, "Could not restart DHCPD: %m");
    } else if (rv) {
        syslog(LOG_WARNING, "DHCPD restart returned %d", rv);
    } else {
        syslog(LOG_INFO, "DHCPD restart was successful");
    }
    freehosts(h); /* Don't leak this list. */
    return rv;
}

int rewrite(int sock) {
    char buf[BUFSIZ];
    unsigned char nb;
    int had, want, got = 0;
    char tn[] = NETBOOT_CONF ".XXXXXX";
    int t = 0;
    FILE *f;
    char *idx;
    int ln = 0;
    char *name = NULL;
    size_t l = 0;
    int rv = 0;
    int found = 0;
    char *newstage = NULL;

    if (read(sock, &nb, 1) < 0) {
        rv = errno;
        syslog(LOG_ERR, "Could not read from socket: %m");
        return rv;
    } else {
        want = nb;
        while (got < want) {
            had = read(sock, &buf[got], want - got);
            if (had < 0) {
                rv = errno;
                syslog(LOG_ERR, "Read failed %d bytes into packet: %m", got);
                return rv;
            } else {
                got += had;
            }
        }
        buf[got] = 0;
#if 0
        syslog(LOG_DEBUG, "Learnt nodename %s", buf);
#endif
        l = strlen(buf);
        name = malloc(l);
        if (name == NULL) {
            rv = errno;
            syslog(LOG_ERR, "Could not malloc name: %m");
            return rv;
        } else {
            strcpy(name, buf);
        }
    }

    if (read(sock, &nb, 1) < 0) {
        rv = errno;
        syslog(LOG_ERR, "Could not read second stage from socket: %m");
        free(name);
    } else if (nb) {
        want = nb;
        got = 0;
        while (got < want) {
            had = read(sock, &buf[got], want - got);
            if (had < 0) {
                rv = errno;
                syslog(LOG_ERR, "Reread failed %d bytes into packet: %m", got);
                free(name);
                return rv;
            } else {
                got += had;
            }
        }
        buf[got] = 0;
#if 0
        syslog(LOG_DEBUG, "Learnt nodename %s should go to state `%s'", name,
            buf);
#endif
        newstage = strdup(buf);
        if (newstage == NULL) {
            rv = errno;
            syslog(LOG_ERR, "Could not strdup stage: %m");
            free(name);
            return rv;
        }
    }

#if 0
    syslog(LOG_DEBUG, "Now hunting for %s in " NETBOOT_CONF, name);
#endif

    f = fopen(NETBOOT_CONF, "r");
    if (f == NULL) {
        rv = errno;
        syslog(LOG_ERR, "Could not read " NETBOOT_CONF ": %m");
    } else if ((t = mkstemp(tn)) < 0) {
        rv = errno;
        syslog(LOG_ERR, "Could not create temp file for netboot: %m");
    } else do {
        ln++;
        if (fgets(buf, BUFSIZ, f) != NULL) {
#if 0
            syslog(LOG_DEBUG, "Now on line %d of " NETBOOT_CONF, ln);
#endif
            idx = strchr(buf, '#');
            if (idx != NULL) *idx = 0;
            if ((buf[0] == '\0') || (buf[0] == '\n')) continue;
            idx = strchr(buf, ':');
            if (idx == NULL) idx = strchr(buf, ',');
            if (idx == NULL) {
                syslog(LOG_NOTICE, "Ignoring line %d of " NETBOOT_CONF, ln);
            } else if ((ln >= 1) && ((idx - buf) == l) &&
                !strncmp(buf, name, l)) {
#if 0
                syslog(LOG_DEBUG, "Found line with %s", name);
#endif
                if (newstage != NULL) {
                    if ((write(t, name, strlen(name)) < 0) ||
                        (write(t, ":", 1) < 1) || /* XXX should be , */
                        (write(t, newstage, strlen(newstage)) < 0) ||
                        (write(t, "\n", 1) < 1)) {
                        rv = errno;
                        syslog(LOG_ERR, "Could not write '%s:%s' to %s: %m",
                            name, newstage, tn);
                        fclose(f);
                        close(t);
                        free(name);
                        free(newstage);
                        return rv;
                    } else {
                        syslog(LOG_NOTICE, "Changed %s to %s", name, newstage);
                        found++;
                        rv--; /* Don't relaunch dhcpd, though. */
                    }
                } else { /* No new stage to go to. */
                    syslog(LOG_NOTICE, "Removing %s from netbooting", name);
                    found++;
                }
            } else if (write(t, buf, strlen(buf)) < 0) {
                rv = errno;
                syslog(LOG_ERR, "Could not write `%s' to %s: %m", buf, tn);
                fclose(f);
                close(t);
                free(name);
                if (newstage != NULL) free(newstage);
                return rv;
            }
#if 0
        } else {
            syslog(LOG_DEBUG, "got NULL from fgets: %m");
#endif
        }
    } while ((rv <= 0) && !feof(f));
    if (!found) {
        syslog(LOG_WARNING, "Node `%s' is already not being netbooted", name);
    }
    if (newstage != NULL) free(newstage);
    free(name);
    fclose(f);
    if (close(t) < 0) {
        rv = errno;
        syslog(LOG_ERR, "Could not close temporary " NETBOOT_CONF ": %m");
    }
    if (rv <= 0) {
        if (rename(tn, NETBOOT_CONF) < 0) {
            rv = errno;
            syslog(LOG_ERR, "Could not rename %s to " NETBOOT_CONF ": %m", tn);
        }
    }
    if (rv) return rv;
    else if (found) return 0;
    else return -1;
}

int main(int argc, char *argv[]) {
    int rv = 0;
    pid_t child;
    int sock = -1;
    struct sockaddr_in sin;
    int conn;
    fd_set fs;
    struct timeval tv;
    /* struct linger l = { 0, 0 };
    int one = 1; */
    int i;

    sin.sin_family = AF_INET;
    sin.sin_port = htons(PORTNO);
    sin.sin_addr.s_addr = INADDR_ANY;

    openlog(PROGRAM ": ", LOG_PID|LOG_ODELAY, FACILITY);
    if (chdir("/") < 0) {
        rv = errno;
        perror("Could not cd /");
        return rv;
    } else if (close(0) < 0) {
        rv = errno;
        perror("Could not close standard input");
        return rv;
    } else if (close(1) < 0) {
        rv = errno;
        perror("Could not close standard output");
        return rv;
    } else if (close(2) < 0) {
        syslog(LOG_ERR, "Could not close standard error: %m");
        closelog();
        return errno; 
    } else if ((child = fork()) < 0) {
        syslog(LOG_ERR, "Could not fork: %m");
        closelog();
        return errno; 
    } else if (child) {
        return 0;
    } else if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        rv = errno;
        syslog(LOG_ERR, "Could not open socket: %m");
    } else if (bind(sock, (struct sockaddr *)&sin,
        sizeof (struct sockaddr_in)) < 0) {
        rv = errno;
        syslog(LOG_ERR, "Could not bind socket: %m");
    } else if (listen(sock, 5) < 0) {
        rv = errno;
        syslog(LOG_ERR, "Could not listen to socket: %m");
    } else if (signal(SIGHUP, hup) == SIG_ERR) { /* We're the child process. */
        rv = errno;
        syslog(LOG_ERR, "Could not register signal handler for HUP: %m");
    } else if (signal(SIGTERM, hup) == SIG_ERR) {
        rv = errno;
        syslog(LOG_ERR, "Could not register signal handler for TERM: %m");
    } else while (!die) {
        FD_ZERO(&fs);
        FD_SET(sock, &fs);
        tv.tv_sec = 0;
        tv.tv_usec = 500; /* 0.5 secs between sweeps */

        if (reread) {
            syslog(LOG_DEBUG, "Rereading...");
            process();
            reread = 0;
        }
        i = select(sock + 1, &fs, NULL, NULL, &tv);
        if ((i < 0) && (errno != EINTR)) {
            rv = errno;
            syslog(LOG_WARNING, "Could not select: %m");
            break;
        } else if (i > 0) {
            if ((conn = accept(sock, NULL, NULL)) < 0) {
                if (errno != EINTR) syslog(LOG_WARNING, "Could not accept: %m");
            }
            if (conn >= 0) {
                if (!rewrite(conn)) reread = 1;
                shutdown(conn, SHUT_RDWR);
                close(conn);
            }
        }
    }
    syslog(LOG_NOTICE, "Exiting...");
    if (sock >= 0) {
        if (shutdown(sock, SHUT_RDWR) < 0) {
            syslog(LOG_WARNING, "Could not shutdown socket: %m");
        }
        if (close(sock) < 0) {
            rv = errno;
            syslog(LOG_WARNING, "Could not close socket: %m");
        }
    }
    return rv;
}
