package p2psx.imp.srss;

import p2ps.peer.Peer;
import p2ps.discovery.AdvertisementFactory;
import p2ps.discovery.Advertisement;
import p2ps.discovery.Query;
import p2ps.pipe.PipeAdvertisement;
import p2ps.pipe.PipeQuery;
import p2ps.imp.pipe.PipeAdvertisementInstantiator;
import p2ps.imp.pipe.PipeQueryInstantiator;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: scmijt
 * Date: Jun 25, 2004
 * Time: 12:20:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class SRSSFactory {

    /**
     * Convenience factory method for registering SRSS adverts and queries
     *
     * @param peer
     */
    public static void registerAdverts(Peer peer) {

        AdvertisementFactory adverts = peer.getAdvertisementFactory();;

        adverts.register(SRSSAdvert.SRSS_ADVERT, new SRSSAdvertInstantiator());
        adverts.register(SRSSQuery.SRSS_QUERY, new SRSSQueryInstantiator());
    }

    /**
     * Convenience factory method for creating an SRSS advert
     *
     * @param peer
     * @return
     */
    public static SRSSAdvert createSRSSAdvert(Peer peer) {
        AdvertisementFactory adverts = peer.getAdvertisementFactory();;
        SRSSAdvert srssad=null;
        Advertisement ad;
        try {
            ad = adverts.newAdvertisement(SRSSAdvert.SRSS_ADVERT);
            System.out.println("Ad is a " + ad.getClass().getName());
            srssad = (SRSSAdvert)ad;

        } catch (IOException ee) {
            System.out.println("SRSSFactory: Could not create SRSS Advert !!!");
        }
        return srssad;
    }

    /**
     * Convenience factory method for creating an SRSS query
     *
     * @param peer
     * @return
     */
    public static SRSSQuery createSRSSQuery(Peer peer) {
        AdvertisementFactory adverts = peer.getAdvertisementFactory();;
        SRSSQuery srssq=null;
        try {
            srssq = (SRSSQuery)adverts.newAdvertisement(SRSSQuery.SRSS_QUERY);
        } catch (IOException ee) {
            System.out.println("SRSSFactory: Could not create SRSS Advert !!!");
        }
        return srssq;
    }
}
