package p2psx.imp.endpoint.NativeUDP_OLD;

import org.jdom.Document;
import org.jdom.output.XMLOutputter;

import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Iterator;

import p2ps.pipe.PipeTypes;
import p2ps.discovery.Advertisement;
import p2ps.endpoint.EndpointMessageListener;
import p2ps.peer.Peer;
import p2ps.peer.IDFactory;
import p2ps.endpoint.*;
import p2ps.endpoint.EndpointResolverAdvertisement;
import p2psx.imp.endpoint.NativeUDP_OLD.UDPEndpointTypes;
import p2ps.peer.Config;
import pai.imp.broker.JavaBroker;

/**
 * The resolver for socket using UDP
 *
 * @author      stolen by Ian...
 * @created     18th March 2002
 * @version     $Revision: 1.1 $
 * @date        $Date: 2003/11/04 16:53:07 $ modified by $Author: ian $
 * @todo
 */

public class UDPResolver implements EndpointResolver, EndpointMessageListener, PipeTypes, UDPEndpointTypes {

    public static final String UDP_PROTOCOL = "UDP";

    public static final String UDP_DISCOVERY_ADDR = pai.imp.broker.JavaBroker.getMulticastAddress();
    public static final int UDP_DISCOVERY_PORT = 5555;

    /**
     * the resolver socker
     */
    private UDPSocket ressocket;

    /**
     * the main peer
     */
    private Peer peer;

    /**
     * the advert for the resolver
     */
    private EndpointResolverAdvertisement advert;

    /**
     * a list of all the input sockets
     */
    private ArrayList sockets = new ArrayList();

    /**
     * an array list of the listeners that are notified when a pipe is resolved
     */
    private ArrayList listeners = new ArrayList();

    /**
     * a flag indicating whether input pipes are enabled
     */
    private boolean inpipes = true;

    /**
     * a flag indicating whether output pipes are enabled
     */
    private boolean outpipes = true;

    /**
     * a flag indicating whether output pipes are enabled
     */
    private boolean discovery = true;


    /**
     * Initialises the endpoint resolver
     */
    public void init(Peer peer, Config config) throws IOException {
        ressocket = new UDPSocket(IDFactory.newPipeID(), peer);
        ressocket.addEndpointMessageListener(this);

        if (peer.getAdvertisementFactory() == null)
            throw(new RuntimeException("Error instantiating UDP resolver: Advertisement factory not registered on peer"));

        this.peer = peer;

        advert = (EndpointResolverAdvertisement) peer.getAdvertisementFactory().newAdvertisement(EndpointResolverAdvertisement.ENDPOINT_RESOLVER_ADVERTISEMENT_TYPE);
        advert.setEndpointAddress(getResolverEndpointAddress());
        advert.setPipeTypes(new String[] {STANDARD, DISCOVERY});
        advert.setResolverForPeerIDs(new String[]{peer.getPeerID()});
        advert.setTransportProtocols(new String[]{UDP_PROTOCOL});
    }

    /**
     * @return true if input pipes of the specified type are enabled with this
     * resolver
     */
    public boolean isInputPipesEnabled(String type) {
        if (type.equals(STANDARD))
            return inpipes;
        else if (type.equals(DISCOVERY))
            return discovery;
        else
            return false;
    }

    /**
     * Sets whether input pipes of the specified type are enabled with this
     * resolver
     */
    public void setInputPipesEnabled(String type, boolean state)  {
        if (type.equals(STANDARD))
            this.inpipes = state;
        else if (type.equals(DISCOVERY))
            this.discovery = state;
    }

    /**
     * @return true if output pipes of the specified type are enabled with this
     * resolver
     */
    public boolean isOutputPipesEnabled(String type) {
        if (type.equals(STANDARD))
            return outpipes;
        else if (type.equals(DISCOVERY))
            return discovery;
        else
            return false;
    }

    /**
     * Sets whether output pipes of the specified type are enabled with this
     * resolver
     */
    public void setOutputPipesEnabled(String type, boolean state) {
        if (type.equals(STANDARD))
            this.outpipes = state;
        else if (type.equals(DISCOVERY))
            this.discovery = state;
    }


    /**
     * @return the resolver endpoint
     */
    public Endpoint getResolverEndpoint() {
        return ressocket;
    }

    /**
     * @return the address of the resolver socket
     */
    public EndpointAddress getResolverEndpointAddress() throws IOException {
        return ressocket.getEndpointAddress();
    }


    /**
     * @return an array of the pipe types handled by this resolver
     */
    public String[] getPipeTypes() {
        return advert.getPipeTypes();
    }

    /**
     * @return the ids of the peers this resolver handles endpoint resolution for
     */
    public String[] getResolverForPeerIDs() {
        return advert.getResolverForPeerIDs();
    }

    /**
     * @return the transport protocol used by this socket
     */
    public String[] getTransportProtocols() {
        return advert.getTransportProtocols();
    }

    /**
     * @return a pipe resolver advert for this resolver
     */
    public EndpointResolverAdvertisement getAdvertisement() throws IOException {
        return advert;
    }


    /**
     * Add a listener to be notified when a pipe is resolved
     */
    public void addEndpointResolutionListener(EndpointResolutionListener listener) {
        if (!listeners.contains(listener))
            listeners.add(listener);
    }

    /**
     * Removes a pipe resolution listener
     */
    public void removeEndpointResolutionListener(EndpointResolutionListener listener) {
        listeners.remove(listener);
    }


    /**
     * Create a endpoint for the specified input pipe
     */
    public Endpoint createInputEndpoint(String pipeid, String pipetype) throws IOException {
        if ((!pipetype.equals(STANDARD)) && (!pipetype.equals(DISCOVERY)))
            throw(new RuntimeException("UDP Resolver Error: Cannot create input endpoint for non-standard/discovery pipe"));

        Endpoint socket;

        if (pipetype.equals(STANDARD))
            socket = new UDPSocket(pipeid, peer);
        else
            socket = new UDPSocket(UDP_DISCOVERY_ADDR, UDP_DISCOVERY_PORT, pipeid, peer);

        sockets.add(socket);

        return socket;
    }

    /**
     * Create a endpoint for the specified input pipe bound the specified endpoint
     * address
     */
    public Endpoint createInputEndpoint(String pipeid, EndpointAddress address) throws IOException {
        String protocol = address.getProtocol();
        Endpoint socket;

        if ((!address.getType().equals(UDP_UNICAST)) && (!address.getType().equals(UDP_MULTICAST)))
            throw(new RuntimeException("UDP Endpoint Error: Cannot create output endpoint for non-unicast/multicast pipe"));

        if (!protocol.equals(UDP_PROTOCOL))
            throw(new RuntimeException("UDP Resolver Error: Cannot create input endpoint for non-UDP address"));

        if (address.getType().equals(UDP_UNICAST))
            socket = new UDPSocket(getPort(address), pipeid, peer);
        else
            socket = new UDPSocket(getHostAddress(address), getPort(address), pipeid, peer);

        sockets.add(socket);
        return socket;
    }

    /**
     * Connects an endpoint to output to the specified address
     */
    public Endpoint connectOutputEndpoint(String pipeid, EndpointAddress address) throws IOException {
        String protocol = address.getProtocol();

        if ((!address.getType().equals(UDP_UNICAST)) && (!address.getType().equals(UDP_MULTICAST)))
            throw(new RuntimeException("UDP Endpoint Error: Cannot create output endpoint for non-unicast/multicast pipe"));

        if (!protocol.equals(UDP_PROTOCOL))
            throw(new RuntimeException("UDP Endpoint Error: Cannot create output endpoint for non-UDP address"));

        UDPSocket socket = new UDPSocket(pipeid, peer);
        socket.connect(getHostAddress(address), getPort(address));
        return socket;
    }

    /**
     * Sends out a pipe resolution query for the specified pipe to the specified
     * pipe resolver address.
     *
     * @param pipeid the id of the pipe being resolved
     * @param resaddress the address of the endpoint resolver
     */
    public void resolveEndpoint(String pipeid, EndpointAddress resaddress) throws IOException {
        EndpointQuery query = (EndpointQuery) peer.getAdvertisementFactory().newAdvertisement(EndpointQuery.ENDPOINT_QUERY_TYPE);
        query.setQueryPipeID(pipeid);
        query.setQueryTransportProtocol(UDP_PROTOCOL);
        query.setReplyEndpointAddress(getResolverEndpointAddress());

        XMLOutputter xmlout = new XMLOutputter("    ", true);
        ByteArrayOutputStream outstream = new ByteArrayOutputStream();
        xmlout.output(new Document(query.getXMLElement()), outstream);
        ressocket.send(outstream.toByteArray(), resaddress);
    }


    public void dataMessageReceived(DataMessageEvent event) {
        try {
            // : " + new String(event.getDataMessage().getData()));

            Advertisement advert = peer.getAdvertisementFactory().createAdvertisement(event.getDataMessage().getData());

            if (advert instanceof EndpointQuery)
                handleEndpointQuery((EndpointQuery) advert);
            else if (advert instanceof EndpointAdvertisement)
                handleEndpointAdvertisement((EndpointAdvertisement) advert);
        } catch (IOException except) {
            except.printStackTrace();
        }
    }

    /**
     * Replies to a resolver query (if the pipe is known to this resolver)
     */
    public void handleEndpointQuery(EndpointQuery query) throws IOException {
        Endpoint[] endpoints = (Endpoint[]) sockets.toArray(new Endpoint[sockets.size()]);
        ArrayList matches = new ArrayList();

        for (int count = 0; count < endpoints.length; count++) {
            if (endpoints[count].isClosed())
                sockets.remove(endpoints[count]);
            else {
                if (query.isMatch(endpoints[count].getAdvertisement()))
                    matches.add(endpoints[count].getAdvertisement());
            }
        }

        if (matches.size() > 0)
            notifyMatches(query.getReplyEndpointAddress(), matches);
    }

    /**
     * Sends matching adverts to either the reply address, or publishes them
     * if no reply address
     */
    private void notifyMatches(EndpointAddress replyaddr, ArrayList matches) throws IOException {
        Iterator iter = matches.iterator();
        Endpoint outsocket = null;

        if (replyaddr != null) {
            EndpointResolver resolver = peer.getPipeService().getPipeResolver(replyaddr.getTransportProtocol());
            outsocket = resolver.connectOutputEndpoint(IDFactory.newPipeID(), replyaddr);
        }

        while (iter.hasNext()) {
            Advertisement advert = (Advertisement) iter.next();

            if (outsocket == null)
                peer.getDiscoveryService().publish(advert);
            else {
                XMLOutputter xmlout = new XMLOutputter("    ", true);
                ByteArrayOutputStream outstream = new ByteArrayOutputStream();
                xmlout.output(new Document(advert.getXMLElement()), outstream);
                outsocket.send(outstream.toByteArray());
            }
        }
    }


    private void handleEndpointAdvertisement(EndpointAdvertisement advert) {
        EndpointResolutionEvent event = new EndpointResolutionEvent(advert.getPipeID(), advert.getEndpointAddress(), this);
        EndpointResolutionListener[] copy = (EndpointResolutionListener[]) listeners.toArray(new EndpointResolutionListener[listeners.size()]);

        for (int count = 0; count < copy.length; count++)
            copy[count].pipeResolved(event);
    }

    /**
     * @return an host specified in the full address
     */
    public static final String getHostAddress(EndpointAddress address) {
        String protocol = address.getProtocol();

        if (!protocol.equals(UDP_PROTOCOL))
            throw(new RuntimeException("UDP Address Error: Cannot get host address for non-UDP address"));

        return address.getAddress().substring(0, address.getAddress().indexOf(':'));
    }

    /**
     * @return the port specified in the address address
     */
    public static final int getPort(EndpointAddress address) {
        String protocol = address.getProtocol();

        if (!protocol.equals(UDP_PROTOCOL))
            throw(new RuntimeException("UDP Address Error: Cannot get port for non-UDP address"));

        return Integer.parseInt(address.getAddress().substring(address.getAddress().indexOf(':') + 1));
    }

}
