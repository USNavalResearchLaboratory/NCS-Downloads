package p2psx.imp.endpoint.NativeUDP_OLD;

import p2ps.endpoint.DataMessage;

/**
 * Created by IntelliJ IDEA.
 * User: scmijt
 * Date: Apr 16, 2004
 * Time: 9:58:03 AM
 * To change this template use Options | File Templates.
 */
public class PAIDataMessageImp implements DataMessage {

    byte[] data;

    public PAIDataMessageImp(byte data[]) {
        this.data=data;
    }

    public byte[] getData() {
        return data;
    }

}
