package p2psx.imp.endpoint.NativeUDP_OLD;

//import p2ps.imp.endpoint.ThreadPool;

import p2ps.imp.pipe.DataMessageImp;
import p2ps.endpoint.DataMessage;
import p2ps.endpoint.DataMessageEvent;
import p2ps.endpoint.EndpointMessageListener;

//import java.util.ArrayList;
import java.util.Hashtable;

import java.io.*;
import java.net.SocketTimeoutException;
import java.net.SocketException;
import pai.net.PAIDatagramSocketImpl;

import pai.net.PAIDatagramSocketImpl;
import pai.api.PAIInterface;
import pai.event.PAISocketListener;
import pai.event.PAISocketEvent;
import pai.imp.PAIFactory;

/**
 * This hooks up Wangy's code to the listening capabilities of Protlib.
 * We don't have to mess around with multi-threaded polling when we have event
 * notification from the source Datagram sockets. This class therefore just acts
 * as a gateway between existing P2PS code and the PAI interface.
 *
 * Of course, this could be implemented more efficiently if the socket got
 * notified directly but then I'd have to cut out the model Ian built up for
 * implementing Endpoint protocols, which is nasty.  This way, we lose a little
 * performance but keep a nice design ...
 *
 * @author      Ian Taylor
 * @created     29th July 2003
 * @version     $Revision: 1.1 $
 * @date        $Date: 2003/11/04 16:53:07 $ modified by $Author: ian $
 * @todo
 */

public class UDPInputMonitor implements PAISocketListener {

   // private String messid;
   // private DatagramPacket packet;
   // private UDPSocket socket;

    public static int UDP_SOCKET_TIMEOUT = 10;
    public static int MONITOR_SLEEP_TIME = 100;

    PAIInterface pai = PAIFactory.getCurrentNativePAIObj();

    Hashtable sockets = new Hashtable();

    /**
     * a hashtable of the half built messages
     */
    private static Hashtable messages = new Hashtable();

    public UDPInputMonitor() {
//        setName("UDPInputMonitor");
    }

    public void monitorSocket(UDPSocket udpsocket) throws IOException {
        monitorSocket(udpsocket.getSocket());
        sockets.put(udpsocket.getSocket(), udpsocket);
    }

    public void unmonitorSocket(UDPSocket socket) {
        unmonitorSocket(socket.getSocket());
        sockets.remove(socket.getSocket());
    }

    /**
     * This hooks up Wangy's code to the listening capabilities of Protlib.
     * We don't have to mess around with multi-threaded polling when we have event
     * notification from the source.
     * @param socket
     * @throws java.io.IOException
     */
    private void monitorSocket(pai.net.PAIDatagramSocketImpl socket) throws IOException {
        socket.setSoTimeout(UDP_SOCKET_TIMEOUT);
        pai.addPAISocketListener(socket, this);
    }

    private void unmonitorSocket(pai.net.PAIDatagramSocketImpl socket) {
        pai.removePAISocketListener(socket, this);
    }

    /**
     * This function gets called every time there is a event notification at a
     * socket that P2PS has registered an interest in.  The code here then reads
     * the data from the socket and builds a P2PS message.
     *
     * @param event
     */
    public void dataReceived(PAISocketEvent event) {
        PAIDatagramSocketImpl socket;
        UDPSocket udpsocket;
        DatagramPacket packet;
        //String messid;

   //     System.out.println("UDPInputMonitor: dataReceived, packet size is: "
     //           + DataMessageImp.PACKET_SIZE);

        packet = new DatagramPacket(new byte[DataMessageImp.PACKET_SIZE], DataMessageImp.PACKET_SIZE);
        socket = event.getSocket();
        udpsocket = (UDPSocket)sockets.get(socket);

        try {
            socket.receive(packet);
            DataMessage message = new PAIDataMessageImp(packet.getData());
            if (message != null)
                handleMessage(message, udpsocket);
        } catch (IOException except) {
            except.printStackTrace();
            unmonitorSocket(socket);
        }

/*    Wangy's code: todo fix the splitting up of inputs and outputs

        try {
            System.out.println("UDPInputMonitor: receiving ");

            socket.receive(packet);

            System.out.println("UDPInputMonitor: received " + new String(packet.getData()));

            if (DataMessageImp.isValid(packet.getData())) {
                messid = DataMessageImp.getMessageID(packet.getData());

                if (messid != null) {
                    this.messid = messid;
                    this.packet = packet;
                    this.socket = udpsocket;
                   DataMessage message = buildMessage();

                    if (message != null)
                        handleMessage(message);
                }
            }
        } catch (SocketTimeoutException except) {
        } catch (SocketException except) {
            unmonitorSocket(socket);
        } catch (IOException except) {
            except.printStackTrace();
            unmonitorSocket(socket);
        }  */
    }

    /**
     * handles a partial message either by creating a new message
     */
/**    private DataMessage buildMessage() {
        String key = packet.getAddress().toString() + "&" + messid;
        DataMessageImp message;

        if (!messages.containsKey(key)) {
            message = new DataMessageImp();
            message.addPacket(packet.getData());

            if (!message.isComplete())
                messages.put(key, message);
        } else {
            message = (DataMessageImp) messages.get(key);
            message.addPacket(packet.getData());

            if (message.isComplete())
                messages.remove(key);
        }

        if (message.isComplete())
            return message;
        else
            return null;
    }      */

    /**
     * Called by a single input socket when a message is received. The input
     * socket notifies all the data message listeners
     */
    private void handleMessage(DataMessage message, UDPSocket socket) {
        DataMessageEvent event = new DataMessageEvent(socket, message);
        EndpointMessageListener[] copy = socket.getEndpointMessageListeners();

        for (int count = 0; count < copy.length; count++) {
     //       System.out.println("UDPInputMonitor: Notifying Listener " + count);

       //     System.out.println("UDPInputMonitor: Object being notified is an " + copy[count].getClass().getName());
            copy[count].dataMessageReceived(event);
            // Thread.yield();
        }


     //   System.out.println("UDPInputMonitor: End handleMessage");
    }
}
