package p2psx.imp.endpoint.UDP;

// import p2ps.imp.endpoint.ThreadPool;
import p2ps.endpoint.DataMessage;
import p2ps.endpoint.DataMessageEvent;
import p2ps.endpoint.EndpointMessageListener;
import p2ps.imp.endpoint.UDP.DataMessageImp;
import p2ps.imp.endpoint.UDP.UDPHeader;

import java.util.Hashtable;

import java.io.*;

import pai.imp.event.PAISocketListener;
import pai.imp.event.PAISocketEvent;
import pai.imp.jni.PAIFactory;
import pai.api.PAIInterface;
import pai.net.PAIDatagramPacket;

import java.net.DatagramPacket;
import agentj.imp.agentj.AgentJFactory;
import agentj.api.AgentJ;
import org.apache.log4j.Logger;

/**
 * This hooks up Wangy's code to the listening capabilities of Protlib.
 * We don't have to mess around with multi-threaded polling when we have event
 * notification from the source Datagram sockets. This class therefore just acts
 * as a gateway between existing P2PS code and the PAI interface.
 *
 * Of course, this could be implemented more efficiently if the socket got
 * notified directly but then I'd have to cut out the model Ian built up for
 * implementing Endpoint protocols, which is nasty.  This way, we lose a little
 * performance but keep a nice design ...
 *
 * @author      Ian Taylor
 * @created     29th July 2003
 * @version     $Revision: 1.1 $
 * @date        $Date: 2003/11/04 16:53:07 $ modified by $Author: ian $
 * @todo
 */

public class UDPInputMonitor implements PAISocketListener {

    static Logger logger = Logger.getLogger(UDPInputMonitor.class);

    public static int UDP_SOCKET_TIMEOUT = 10;
    public static int MONITOR_SLEEP_TIME = 100;

    PAIInterface pai = AgentJFactory.getAgentJ().getPAI();

    /**
     * a pool of threads used to handle messages
     */
    // private static ThreadPool threads = new ThreadPool("UDPSocketThread");

    /**
     * a hashtable of the half built messages
     */
    private static Hashtable messages = new Hashtable();

//    private ArrayList sockets = new ArrayList();

    Hashtable sockets = new Hashtable();

    public UDPInputMonitor() {
 //       setName("UDPInputMonitor");
 //       start();
    }



    public void monitorSocket(UDPSocket udpsocket) throws IOException {
        logger.info("Entering");
        udpsocket.getSocket().setSoTimeout(UDP_SOCKET_TIMEOUT);
        pai.addPAISocketListener(udpsocket.getSocket(), this);
        sockets.put(udpsocket.getSocket(), udpsocket);
        logger.info("Exiting");
    }

    public void unmonitorSocket(UDPSocket udpsocket) {
        logger.info("Entering");
        pai.removePAISocketListener(udpsocket.getSocket(), this);
        sockets.remove(udpsocket.getSocket());
        logger.info("Exiting");
    }


  /*
   *  Don't need this -> we have a proper calback mechanism...

   * public void run() {
        UDPSocket udpsocket;
        DatagramPacket packet;

        while (true) {
            for (int count = 0; count < sockets.size(); count++) {
                udpsocket = (UDPSocket) sockets.get(count);

                packet = new DatagramPacket(new byte[UDPSocket.PACKET_SIZE], UDPSocket.PACKET_SIZE);

                try {
                    udpsocket.getSocket().receive(packet);

                    p2ps.imp.endpoint.UDP.UDPHeader header = DataMessageImp.getHeader(packet.getData());

                    if (header != null)
                        threads.addTask(new HandleMessage(header, packet, udpsocket));
                } catch (SocketTimeoutException except) {
                } catch (SocketException except) {
                    unmonitorSocket(udpsocket);
                } catch (IOException except) {
                    except.printStackTrace();
                    unmonitorSocket(udpsocket);
                }
            }

            try {
                Thread.sleep(MONITOR_SLEEP_TIME);
            } catch (InterruptedException except) {
            }
        }      */

    /**
     * This function gets called every time there is a event notification at a
     * socket that P2PS has registered an interest in.  The code here then reads
     * the data from the socket and builds a P2PS message.
     *
     * @param event
     */
    public void dataReceived(PAISocketEvent event) {
        logger.info("Entering");
        pai.net.PAIDatagramSocketImpl socket;
        UDPSocket udpsocket;
        PAIDatagramPacket packet;
        //String messid;


        // packet = new pai.net.DatagramPacket(new byte[DataMessageImp.PACKET_SIZE], DataMessageImp.PACKET_SIZE);
        packet = new PAIDatagramPacket(new byte[UDPSocket.PACKET_SIZE], UDPSocket.PACKET_SIZE);

        socket = event.getSocket();
        udpsocket = (UDPSocket)sockets.get(socket);

        try {
            socket.receive(packet);

            UDPHeader header = DataMessageImp.getHeader(packet.getData());

      //      System.out.println("UDPInputMonitor: Data : " + new String(packet.getData()));

            if (header != null)
                handleMessage(header, packet, udpsocket);
        } catch (IOException except) {
            except.printStackTrace();
            unmonitorSocket(udpsocket);
        }
        logger.info("Exiting");
    }


//    private class HandleMessage implements Runnable {

        private UDPHeader header;
        private PAIDatagramPacket packet;
        private UDPSocket socket;


        public void handleMessage(UDPHeader header, PAIDatagramPacket packet, UDPSocket socket) {
            logger.info("Entering");
            this.header = header;
            this.packet = packet;
            this.socket = socket;
            run();
            logger.info("Exiting");
        }

    public void run() {
        logger.info("Entering");
        DataMessage message = buildMessage();

        if (message != null)
            handleMessage(message);
        logger.info("Exiting");
     }

    /**
     * handles a partial message either by creating a new message
     */
    private DataMessage buildMessage() {
        logger.info("Entering");
        String key = packet.getAddress().toString() + "&" + header.getMessageID();
        DataMessageImp message;

        if (!messages.containsKey(key)) {
            synchronized(messages) {
                message = new DataMessageImp(header);
                messages.put(key, message);
            }
        } else
            message = (DataMessageImp) messages.get(key);

        message.addPacket(packet.getData());

        logger.info("Exiting");

         if (message.isComplete()) {
            messages.remove(key);
            return message;
        } else
            return null;
    }

    /**
     * Called by a single input socket when a message is received. The input
     * socket notifies all the data message listeners
     */
    private void handleMessage(DataMessage message) {
        logger.info("Entering");
        DataMessageEvent event = new DataMessageEvent(socket, message);
        EndpointMessageListener[] copy = socket.getEndpointMessageListeners();

        for (int count = 0; count < copy.length; count++) {
            copy[count].dataMessageReceived(event);
            // Thread.yield();
        }
        logger.info("Exiting");
     }

}
