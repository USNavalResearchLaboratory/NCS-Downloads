package p2psx.imp.endpoint.NativeUDP_OLD;

/**
 * The standard p2ps pipe types.
 *
 * @author      Ian Wang
 * @created     4th August 2003
 * @version     $Revision: 1.1 $
 * @date        $Date: 2003/11/04 16:53:07 $ modified by $Author: ian $
 * @todo
 */

public interface UDPEndpointTypes {

    public static String UDP_UNICAST = "unicast";
    public static String UDP_MULTICAST = "multicast";

}
