package p2psx.imp.endpoint.UDP;

import org.jdom.Document;
import org.jdom.output.XMLOutputter;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Iterator;

import p2ps.pipe.PipeTypes;
import p2ps.discovery.Advertisement;
import p2ps.endpoint.EndpointMessageListener;
import p2ps.peer.Peer;
import p2ps.peer.IDFactory;
import p2ps.endpoint.*;
import p2ps.endpoint.EndpointResolverAdvertisement;
import p2ps.peer.Config;
import p2ps.imp.discovery.DiscoveryCache;
import p2ps.imp.endpoint.UDP.UDPEndpointTypes;

/**
 * The resolver for socket using UDP
 *
 * @author      Ian Wang
 * @created     18th March 2002
 * @version     $Revision: 1.5 $
 * @date        $Date: 2004/05/11 14:16:35 $ modified by $Author: spxinw $
 * @todo
 */

public class UDPResolver implements EndpointResolver, EndpointMessageListener, PipeTypes, UDPEndpointTypes {

    static Logger logger = Logger.getLogger(UDPResolver.class);

    public static final String UDP_PROTOCOL = "UDP";
    
    public static final String UDP_DISCOVERY_ADDR = pai.imp.broker.JavaBroker.getMulticastAddress();
    public static final int UDP_DISCOVERY_PORT = 2221;

    /**
     * the resolver socker
     */
    private UDPSocket ressocket;

    /**
     * the main peer
     */
    private Peer peer;

    /**
     * the protocol used by this resolver (UDP_PROTOCOL by default)
     */
    private String protocol = UDP_PROTOCOL;

    /**
     * the advertisement type used to advertise this resolver
     */
    private String adverttype = EndpointResolverAdvertisement.ENDPOINT_RESOLVER_ADVERTISEMENT_TYPE;

    /**
     * the query type used to query for other resolvers
     */
    private String querytype = EndpointQuery.ENDPOINT_QUERY_TYPE;

    /**
     * the advert for the resolver
     */
    private EndpointResolverAdvertisement advert;

    /**
     * a list of all the input sockets
     */
    private ArrayList sockets = new ArrayList();

    /**
     * an array list of the listeners that are notified when a pipe is resolved
     */
    private ArrayList listeners = new ArrayList();

    /**
     * a flag indicating whether input pipes are enabled
     */
    private boolean inpipes = true;

    /**
     * a flag indicating whether output pipes are enabled
     */
    private boolean outpipes = true;

    /**
     * a flag indicating whether output pipes are enabled
     */
    private boolean discovery = true;


    /**
     * Create a UDPResolver that uses the standard UDP_PROTOCOL
     */
    public UDPResolver() {
    }

    /**
     * Create a UDPResolver the uses a custom protocol but uses the default
     * endpoint resolver advertisement and query types
     */
    protected UDPResolver(String protocol) {
        logger.info("Entering");
        this.protocol = protocol;
        logger.info("Exiting");
    }

    /**
     * Create a UDPResolver the uses a custom protocol, endpoint resolver advert
     * type and endpoint query type
     */
    protected UDPResolver(String protocol, String adverttype, String querytype) {
        logger.info("Entering");
        this.protocol = protocol;
        this.adverttype = adverttype;
        this.querytype = querytype;
        logger.info("Exiting");
    }


    /**
     * Initialises the endpoint resolver
     */
    public void init(Peer peer, Config config) throws IOException {
        logger.info("Entering");
        this.peer = peer;

        ressocket = new UDPSocket(IDFactory.newPipeID(), protocol, peer);
        ressocket.addEndpointMessageListener(this);

        if (peer.getAdvertisementFactory() == null)
            throw(new RuntimeException("Error instantiating UDP resolver: Advertisement factory not registered on peer"));

        advert = (EndpointResolverAdvertisement) peer.getAdvertisementFactory().newAdvertisement(adverttype);
        advert.setEndpointAddress(getResolverEndpointAddress());
        advert.setPipeTypes(new String[]{STANDARD, DISCOVERY});
        advert.setResolverForPeerIDs(new String[]{peer.getPeerID()});
        advert.setTransportProtocols(new String[]{protocol});
        logger.info("Exiting");
    }

    /**
     * @return true if input pipes of the specified type are enabled with this
     *         resolver
     */
    public boolean isInputPipesEnabled(String endpointtype) {
        if (endpointtype.equals(UDP_UNICAST) || endpointtype.equals(STANDARD))
            return inpipes;
        else if (endpointtype.equals(UDP_MULTICAST) || endpointtype.equals(DISCOVERY))
            return discovery;
        else
            return false;
    }

    /**
     * Sets whether input pipes of the specified type are enabled with this
     * resolver
     */
    public void setInputPipesEnabled(String endpointtype, boolean state) {
        if (endpointtype.equals(STANDARD))
            this.inpipes = state;
        else if (endpointtype.equals(DISCOVERY))
            this.discovery = state;
    }

    /**
     * @return true if output pipes of the specified type are enabled with this
     *         resolver
     */
    public boolean isOutputPipesEnabled(String endpointtype) {
        if (endpointtype.equals(UDP_UNICAST) || endpointtype.equals(STANDARD))
            return outpipes;
        else if (endpointtype.equals(UDP_MULTICAST) || endpointtype.equals(DISCOVERY))
            return discovery;
        else
            return false;
    }

    /**
     * Sets whether output pipes of the specified type are enabled with this
     * resolver
     */
    public void setOutputPipesEnabled(String endpointtype, boolean state) {
        logger.info("Entering");
        if (endpointtype.equals(STANDARD))
            this.outpipes = state;
        else if (endpointtype.equals(DISCOVERY))
            this.discovery = state;
        logger.info("Exiting");
    }


    /**
     * @return the resolver endpoint
     */
    public Endpoint getResolverEndpoint() {
        return ressocket;
    }

    /**
     * @return the address of the resolver socket
     */
    public EndpointAddress getResolverEndpointAddress() throws IOException {
        return ressocket.getEndpointAddress();
    }


    /**
     * @return an array of the pipe types handled by this resolver
     */
    public String[] getPipeTypes() {
        return advert.getPipeTypes();
    }

    /**
     * @return the ids of the peers this resolver handles enpoint resolution for
     */
    public String[] getResolverForPeerIDs() {
        return advert.getResolverForPeerIDs();
    }

    /**
     * @return the endpoint protocol used by this socket
     */
    public String[] getEndpointProtocols() {
        return advert.getTransportProtocols();
    }

    /**
     * @return a pipe resolver advert for this resolver
     */
    public EndpointResolverAdvertisement getAdvertisement() throws IOException {
        return advert;
    }


    /**
     * Add a listener to be notified when a pipe is resolved
     */
    public void addEndpointResolutionListener(EndpointResolutionListener listener) {
        logger.info("Entering");
        if (!listeners.contains(listener))
            listeners.add(listener);
        logger.info("Exiting");
    }

    /**
     * Removes a pipe resolution listener
     */
    public void removeEndpointResolutionListener(EndpointResolutionListener listener) {
        logger.info("Entering");
        listeners.remove(listener);
        logger.info("Exiting");
    }


    /**
     * Create a endpoint for the specified input pipe
     */
    public Endpoint createInputEndpoint(String pipeid, String pipetype) throws IOException {
        logger.info("Entering");
        if ((!pipetype.equals(STANDARD)) && (!pipetype.equals(DISCOVERY)))
            throw(new RuntimeException("UDP Resolver Error: Cannot create input endpoint for non-standard/discovery pipe"));

        Endpoint socket;

        if (pipetype.equals(STANDARD))
            socket = new UDPSocket(pipeid, protocol, peer);
        else
            socket = new UDPSocket(UDP_DISCOVERY_ADDR, UDP_DISCOVERY_PORT, pipeid, protocol, peer);

        sockets.add(socket);
        logger.info("Exiting");

        return socket;
    }

    /**
     * Create a endpoint for the specified input pipe bound the specified endpoint
     * address
     */
    public Endpoint createInputEndpoint(String pipeid, EndpointAddress address) throws IOException {
        logger.info("Entering");
        String protocol = address.getProtocol();
        Endpoint socket;

        if ((!address.getEndpointType().equals(UDP_UNICAST)) && (!address.getEndpointType().equals(UDP_MULTICAST)))
            throw(new RuntimeException("UDP Endpoint Error: Cannot create output endpoint for non-unicast/multicast pipe"));

        if (!protocol.equals(this.protocol))
            throw(new RuntimeException("UDP Resolver Error: Cannot create input endpoint for non-" + protocol + " address"));

        if (address.getEndpointType().equals(UDP_UNICAST))
            socket = new UDPSocket(getPort(address), pipeid, protocol, peer);
        else
            socket = new UDPSocket(getHostAddress(address), getPort(address), pipeid, protocol, peer);

        sockets.add(socket);
        logger.info("Exiting");
        return socket;
    }

    /**
     * Connects an endpoint to output to the specified address
     */
    public Endpoint connectOutputEndpoint(String pipeid, EndpointAddress address) throws IOException {
        logger.info("Entering");
        String protocol = address.getProtocol();

        if ((!address.getEndpointType().equals(UDP_UNICAST)) && (!address.getEndpointType().equals(UDP_MULTICAST)))
            throw(new RuntimeException("UDP Endpoint Error: Cannot create output endpoint for non-unicast/multicast pipe"));

        if (!protocol.equals(this.protocol))
            throw(new RuntimeException("UDP Endpoint Error: Cannot create output endpoint for non-" + protocol + " address"));

        UDPSocket socket = new UDPSocket(pipeid, protocol, peer);
        socket.connect(getHostAddress(address), getPort(address));
        logger.info("Exiting");
        return socket;
    }

    /**
     * Sends out a pipe resolution query for the specified pipe to the specified
     * pipe resolver address.
     *
     * @param pipeid     the id of the pipe being resolved
     * @param resaddress the address of the endpoint resolver
     */
    public void resolveEndpoint(String pipeid, EndpointAddress resaddress) throws IOException {
        logger.info("Entering");
        EndpointQuery query = (EndpointQuery) peer.getAdvertisementFactory().newAdvertisement(querytype);
        query.setQueryPipeID(pipeid);
        query.setQueryTransportProtocol(protocol);
        query.setReplyEndpointAddress(getResolverEndpointAddress());

        XMLOutputter xmlout = new XMLOutputter("    ", true);
        ByteArrayOutputStream outstream = new ByteArrayOutputStream();
        xmlout.output(new Document(query.getXMLEnvelope()), outstream);
        ressocket.send(outstream.toByteArray(), resaddress);
    }


    public void dataMessageReceived(DataMessageEvent event) {
        logger.info("Entering");
        try {
            Advertisement advert = peer.getAdvertisementFactory().createAdvertisement(event.getDataMessage().getData());

            if (advert instanceof EndpointQuery)
                handleEndpointQuery((EndpointQuery) advert);
            else if (advert instanceof EndpointAdvertisement)
                handleEndpointAdvertisement((EndpointAdvertisement) advert);
        } catch (IOException except) {
            except.printStackTrace();
        }
        logger.info("Exiting");
    }

    /**
     * Replies to a resolver query (if the pipe is known to this resolver)
     */
    public void handleEndpointQuery(EndpointQuery query) throws IOException {
        logger.info("Entering");
        Endpoint[] endpoints = (Endpoint[]) sockets.toArray(new Endpoint[sockets.size()]);
        ArrayList matches = new ArrayList();

        for (int count = 0; count < endpoints.length; count++) {
            if (endpoints[count].isClosed())
                sockets.remove(endpoints[count]);
            else {
                if (DiscoveryCache.isMatch(query, endpoints[count].getAdvertisement()))
                    matches.add(endpoints[count].getAdvertisement());
            }
        }

        if (matches.size() > 0)
            notifyMatches(query.getReplyEndpointAddress(), matches);
        logger.info("Exiting");
    }

    /**
     * Sends matching adverts to either the reply address, or publishes them
     * if no reply address
     */
    private void notifyMatches(EndpointAddress replyaddr, ArrayList matches) throws IOException {
        logger.info("Entering");
        Iterator iter = matches.iterator();
        Endpoint outsocket = null;

        if (replyaddr != null) {
            EndpointResolver resolver = peer.getPipeService().getPipeResolver(replyaddr.getProtocol());
            outsocket = resolver.connectOutputEndpoint(IDFactory.newPipeID(), replyaddr);
        }

        while (iter.hasNext()) {
            Advertisement advert = (Advertisement) iter.next();

            if (outsocket == null)
                peer.getDiscoveryService().publish(advert);
            else {
                XMLOutputter xmlout = new XMLOutputter("    ", true);
                ByteArrayOutputStream outstream = new ByteArrayOutputStream();
                xmlout.output(new Document(advert.getXMLEnvelope()), outstream);
                outsocket.send(outstream.toByteArray());
            }
        }
        logger.info("Exiting");
    }


    private void handleEndpointAdvertisement(EndpointAdvertisement advert) {
        logger.info("Entering");
        EndpointResolutionEvent event = new EndpointResolutionEvent(advert.getPipeID(), advert.getEndpointAddress(), this);
        EndpointResolutionListener[] copy = (EndpointResolutionListener[]) listeners.toArray(new EndpointResolutionListener[listeners.size()]);

        for (int count = 0; count < copy.length; count++)
            copy[count].pipeResolved(event);
        logger.info("Exiting");
    }

    /**
     * @return an host specified in the full address
     */
    public static final String getHostAddress(EndpointAddress address) {
        logger.info("Entering");
        if (address.getAddress().indexOf(':') == -1)
            throw (new RuntimeException("Invalid UDP address: " + address.getAddress()));

        logger.info("Exiting");
        return address.getAddress().substring(0, address.getAddress().indexOf(':'));
    }

    /**
     * @return the port specified in the address address
     */
    public static final int getPort(EndpointAddress address) {
        logger.info("Entering");
        if (address.getAddress().indexOf(':') == -1)
            throw (new RuntimeException("Invalid UDP address: " + address.getAddress()));

        logger.info("Exiting");
        return Integer.parseInt(address.getAddress().substring(address.getAddress().indexOf(':') + 1));
    }

}
