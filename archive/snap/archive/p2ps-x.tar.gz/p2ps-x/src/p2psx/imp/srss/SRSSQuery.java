package p2psx.imp.srss;

import org.jdom.Element;
import org.apache.log4j.Logger;

import java.io.IOException;
import pai.net.PAIInetAddress;

import p2ps.pipe.PipeAdvertisement;
import p2ps.discovery.Advertisement;
import p2ps.discovery.AdvertisementFactory;
import p2ps.service.ServiceQuery;
import p2ps.service.ServiceAdvertisement;
import p2ps.imp.endpoint.EndpointAddressImp;
import p2ps.imp.service.ServiceQueryImp;
import p2ps.endpoint.EndpointAddress;
import p2ps.endpoint.EndpointAddressFactory;
import pai.net.PAIInetAddress;

/**
 * An implementation of the SRSS Query interface
 *
 * @author      Ian Taylor
 * @created     24th June 2004
 * @version     $Revision: 1.0 $
 * @date
 * @todo
 */

public class SRSSQuery extends ServiceQueryImp {

    static Logger logger = Logger.getLogger(SRSSQuery.class);

    public static String SRSS_QUERY = "SRSSQuery";


    public SRSSQuery(String advertid, String peerid) {
        super(advertid,peerid);
    }

    public SRSSQuery(Element root, AdvertisementFactory adfactory, EndpointAddressFactory fact) throws IOException {
        super(root,adfactory,fact);
        logger.info("Exiting");
    }

    /**
     * @return the type for this advertisement
     */
    public String getType() {
        return SRSS_QUERY;
    }

    /**
     * @return the type of advertisement this query is interested in (e.g.
     * PipeAdvertisement)
     */
    public String getQueryType() {
        return SRSSAdvert.SRSS_ADVERT;
    }


    /**
     * Output the advert as an xml document
     */
    public Element getXMLAdvert() throws IOException {
        logger.info("Entering");
        Element root = super.getXMLAdvert();

         System.out.println(PAIInetAddress.getLocalHost().getHostAddress()
                + ": SRSS QUERY: the name of the root was " + root.getName());

         root.setName(SRSS_QUERY);

         System.out.println(pai.net.PAIInetAddress.getLocalHost().getHostAddress()
                + ": SRSS QUERY: the name of the root is now " + root.getName());

        logger.info("Exiting");
         return root;
     }

    /**
       * @return an XML element for the full enveloped advert (returns the same
       *         as getXMLAdvert if no envelope)
       */
      public Element getXMLEnvelope() throws IOException {
          return getXMLAdvert();
      }

}
