package p2psx.imp.srss;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;
import org.apache.log4j.Logger;

import java.io.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

import p2ps.service.ServiceAdvertisement;
import p2ps.pipe.PipeAdvertisement;
import p2ps.discovery.AdvertisementFactory;
import p2ps.imp.service.ServiceAdvertisementImp;
import pai.net.PAIInetAddress;

/**
 * A basic implementation of an SRSS advert, sued to publish
 * an SRSS node and its capabilities on a network. An SRSS
 * advert is a service with extra parameters
 *
 * @author      Ian Taylor
 * @created     24th June 2004
 * @version     $Revision: 1.0 $
 * @date
 * @todo
 */
public class SRSSAdvert extends ServiceAdvertisementImp {

    static Logger logger = Logger.getLogger(SRSSAdvert.class);
    public static String SRSS_ADVERT = "SRSSAdvert";

    public static String PORT_TAG = "PORT";

    public int port;


    public SRSSAdvert(String advertid, String peerid, String servid) {

        super(advertid, peerid, servid);
    }

    public SRSSAdvert(Element root, AdvertisementFactory adfactory) throws IOException {
        super(root,adfactory);
        logger.info("Entering");

        Element elem = root.getChild(PORT_TAG);
        if (elem != null) {
            System.out.println("%%"  +elem.getText() + "%%");
            port = Integer.valueOf(elem.getText()).intValue();
        }
        logger.info("Exiting");
    }


    /**
     * @return the type for this advertisement
     */
    public String getType() {
        return SRSS_ADVERT;
    }

    /**
      * @return the name of the port
      */
     public void setPort(int port) {
         this.port=port;
     }

    /**
     * @return the name of the port
     */
    public int getPort() {
        return port;
    }

    /**
     * Output the advert as an xml document
     */
    public Element getXMLAdvert() throws IOException {
        logger.info("Entering");

        Element root = super.getXMLAdvert();

        root.setName(SRSS_ADVERT);

        Element elem = new Element(PORT_TAG);
        elem.addContent(String.valueOf(port));
        root.addContent(elem);

        logger.info("Exiting");
        return root;
    }

    /**
       * @return an XML element for the full enveloped advert (returns the same
       *         as getXMLAdvert if no envelope)
       */
      public Element getXMLEnvelope() throws IOException {
          return getXMLAdvert();
      }
}
