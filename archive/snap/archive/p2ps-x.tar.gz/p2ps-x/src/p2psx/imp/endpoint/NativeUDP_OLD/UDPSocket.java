package p2psx.imp.endpoint.NativeUDP_OLD;

import p2ps.peer.Peer;
import p2ps.imp.endpoint.UDP.UDPResolver;
import p2ps.imp.endpoint.EndpointAddressImp;
import p2ps.imp.endpoint.PortFactory;
import p2ps.imp.pipe.DataMessageImp;
import p2ps.endpoint.Endpoint;
import p2ps.endpoint.EndpointAdvertisement;
import p2ps.endpoint.EndpointMessageListener;
import p2ps.endpoint.EndpointAddress;
import p2ps.endpoint.NativeUDP.UDPEndpointTypes;
import p2ps.endpoint.NativeUDP.UDPInputMonitor;

import java.io.IOException;
import java.util.ArrayList;

// ha! fool it into using my implementations : rest of the code stays the same

import pai.net.PAIDatagramSocketImpl;

import pai.net.PAIInetAddress;
import pai.net.PAIMulticastSocketImpl;
import java.net.*;

/**
 * A class that sends and receives message bytes to/from a Datagram Socket. If
 * the message bytes exceed the packet size the message is split into multiple
 * packets.
 *
 * @author      Ian Wang stolen by Ian...
 * @created     17th March 2003
 * @version     $Revision: 1.1 $
 * @date        $Date: 2003/11/04 16:53:07 $ modified by $Author: ian $
 * @todo
 */

public class UDPSocket implements Endpoint, UDPEndpointTypes {

    public static int SEND_BUFFER_SIZE = 100000;
    public static int RECEIVE_BUFFER_SIZE = 100000;


    /**
     * a thread that monitors all input sockets and launches threads to
     * handle incoming messages
     */
    private static UDPInputMonitor inputMonitor = new UDPInputMonitor();

    /**
     * the socket data is sent to
     */
    private pai.net.PAIDatagramSocketImpl socket;

    /**
     * the inet address and port for the receive/group
     */
    private pai.net.PAIInetAddress inet;
    private int port;

    /**
     * an advert for this endpoint
     */
    private EndpointAdvertisement advert;

    /**
     * an array of the listeners that receive messages from this socket
     */
    private ArrayList listeners = new ArrayList();


    /**
     * Creates a standard UDP socket for an available port
     */
    public UDPSocket(String pipeid, Peer peer) throws IOException {
        Object key = PortFactory.getNewFactoryKey();
        boolean success = false;
        int port;

        while (!success) {
            port = PortFactory.getNextPort(key);

            try {
                socket = new PAIDatagramSocketImpl(port);
                success = true;
            } catch(IOException except) {
            }
        }

        initSocket();
        initUnicastAdvert(pipeid, peer);
    }


    /**
     * Creates a standard UDP socket for the specified port
     */
    public UDPSocket(int port, String pipeid, Peer peer) throws IOException {
        socket = new PAIDatagramSocketImpl(port);

        initSocket();
        initUnicastAdvert(pipeid, peer);
    }


    /**
     * Creates a multicast socket attaches to the specified group address and
     * port
     */
    public UDPSocket(String groupaddr, int port, String pipeid, Peer peer) throws IOException {
        try {
            this.inet = PAIInetAddress.getByName(groupaddr);
            this.port = port;

            socket = new PAIMulticastSocketImpl(port);
            ((pai.net.PAIMulticastSocketImpl) socket).joinGroup(inet);

            initSocket();
            initMulticastAdvert(groupaddr, port, pipeid, peer);
        } catch (UnknownHostException except) {
            throw(new IOException(except.getMessage()));
        }
    }

    /**
     * Initialises the buffer size on the socket
     */
    private void initSocket() throws IOException {
        socket.setReuseAddress(true);
        socket.setReceiveBufferSize(RECEIVE_BUFFER_SIZE);
        socket.setSendBufferSize(SEND_BUFFER_SIZE);

        inputMonitor.monitorSocket(this);
    }

    /**
     * Initialises the advert for this socket
     */
    private void initUnicastAdvert(String pipeid, Peer peer) throws IOException {
        String address = PAIInetAddress.getLocalHost().getHostAddress() + ":" + socket.getLocalPort();

        advert = (EndpointAdvertisement) peer.getAdvertisementFactory().newAdvertisement(EndpointAdvertisement.ENDPOINT_ADVERTISEMENT_TYPE);
        advert.setPipeID(pipeid);
        advert.setEndpointAddress(new EndpointAddressImp(address, UDP_UNICAST, UDPResolver.UDP_PROTOCOL));
    }


    /**
     * Initialises the advert for this socket
     */
    private void initMulticastAdvert(String addr, int port, String pipeid, Peer peer) throws IOException {
        String address = addr + ":" + port;

        advert = (EndpointAdvertisement) peer.getAdvertisementFactory().newAdvertisement(EndpointAdvertisement.ENDPOINT_ADVERTISEMENT_TYPE);
        advert.setPipeID(pipeid);
        advert.setEndpointAddress(new EndpointAddressImp(address, UDP_MULTICAST, UDPResolver.UDP_PROTOCOL));
    }


    /**
     * Adds a listener to receive data from this endpoint
     */
    public void addEndpointMessageListener(EndpointMessageListener listener) {
        if (!listeners.contains(listener))
            listeners.add(listener);
    }

    /**
     * Removes a listener from this endpoint
     */
    public void removeEndpointMessageListener(EndpointMessageListener listener) {
        listeners.remove(listener);
    }

    /**
     * @return an array of the listeners to this socket
     */
    EndpointMessageListener[] getEndpointMessageListeners() {
        return (EndpointMessageListener[]) listeners.toArray(new EndpointMessageListener[listeners.size()]);
    }

    /**
     * @return the datagram socket for this udp socket
     */
    PAIDatagramSocketImpl getSocket() {
        return socket;
    }


    /**
     * @return the transport protocol for this socket
     */
    public EndpointAddress getEndpointAddress() {
        return advert.getEndpointAddress();
    }

    /**
     * @return an EndpointAdvertisement for this endpoint
     */
    public EndpointAdvertisement getAdvertisement() {
        return advert;
    }


    /**
     * @return true if this endpoint is input enabled
     */
    public boolean isInputEndpoint() {
        return true;
    }

    /**
     * @return true if this endpoint is output enabled
     */
    public boolean isOutputEndpoint() {
        return (inet != null);
    }


    /**
     * Connects the socket to the specified address
     */
    public void connect(String address, int port) throws IOException {
        this.inet = PAIInetAddress.getByName(address);
        this.port = port;
    }


    /**
     * Send a message from the socket
     */
    public void send(byte[] message) throws IOException {
        send(message, null);
    }


    /**
     * Sends a message from the socket to the specified address
     */
    public void send(byte[] message, EndpointAddress address) throws IOException {
        DatagramPacket packet;
        byte[] data;
        pai.net.PAIInetAddress sendinet = inet;
        int sendport = port;

        if ((address == null) && (inet == null))
            throw (new IOException("Unspecified address on send from non-multicast socket"));

        if (address != null) {
            sendinet = PAIInetAddress.getByName(UDPResolver.getHostAddress(address));
            sendport = UDPResolver.getPort(address);
        }

        // OLD code here -> changed to avoid splitting
        //  Tested and tested this and really don't know why this is happeneing
        // except that I know DataMessageImp is corrupting the data in
        // such a way that the JNI thinks only the first 4 bytes are valid
        // perhaps reinserting a NULL character or something ???????

//        DataMessageImp datamess = new DataMessageImp(message);

  //      for (int count = 0; count < datamess.getPacketCount(); count++) {
    //        data = datamess.getPacket(count);
      //      packet = new DatagramPacket(data, data.length, sendinet, sendport);

    //        socket.send(packet);
//    }

        String tmp1 = new String(message);
        String tmp2 = tmp1.trim();
        //System.out.println("UDPSocket:send, data is :" + tmp2 + ":END");

        byte b[] = (tmp2.getBytes());

        packet = new DatagramPacket(b, b.length, sendinet, sendport);

        socket.send(packet);
    }


    /**
     * Closes the socket
     */
    public void close() throws IOException {
        if (!socket.isClosed()) {
            socket.close();
            inputMonitor.unmonitorSocket(this);
            listeners.clear();
        }
    }

    /**
     * @return true is the socket is closed
     */
    public boolean isClosed() {
        return socket.isClosed();
    }

}


