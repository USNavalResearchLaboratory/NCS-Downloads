package p2psx.examples;

import p2ps.discovery.AdvertisementFactory;
import p2ps.discovery.DiscoveryService;
import p2ps.imp.peer.PeerImp;
import p2ps.peer.Peer;
import p2ps.peer.Config;


import p2psx.imp.peer.config.DefaultPAIConfig;
import p2psx.imp.srss.SRSSAdvert;
import p2psx.imp.srss.SRSSFactory;

import java.io.IOException;
import java.net.SocketException;

import pai.api.PAIInterface;
import pai.imp.Logging;
import pai.imp.event.PAISocketListener;
import pai.imp.event.PAISocketEvent;
import java.net.DatagramPacket;
import pai.net.PAIDatagramSocketImpl;
import pai.net.PAIDatagramPacket;
import agentj.api.AgentJObject;
import agentj.api.AgentJ;
import agentj.imp.agentj.AgentJFactory;



public class P2PSServer implements AgentJObject, PAISocketListener {

    private AdvertisementFactory adverts;
    private DiscoveryService discovery;
    PAIInterface pai;
    Peer peer;
    pai.net.PAIDatagramSocketImpl s;
    int port = 3333;
    AgentJ agentj;

    public P2PSServer() {
        agentj=AgentJFactory.getAgentJ();
        pai = agentj.getPAI();
    }

    public void init(Config conf) throws IOException {
        Logging.setEnabled(true);

        System.out.println("P2PSServer: ------------------> Server initialising");

        try {
            peer = new PeerImp(conf);
        } catch (IOException ee) {
            System.out.println("Couldn't create peer");
            ee.printStackTrace();
        }

        System.out.println("P2PSServer: ------------------> Peer Created");

        try {
            peer.init();
        } catch (IOException ee) {
            System.out.println("Couldn't create peer");
            ee.printStackTrace();
        }

        SRSSFactory.registerAdverts(peer); // registers the adverts and queries for SRSS
    }

    public void initPAISocket() {
        try {
            s = pai.addSocket(port);
            pai.addPAISocketListener(s, this);
            System.out.println("P2PSServer: ID: " + agentj.getID() +
                    " opened Socket ok on port " + port);

        } catch (SocketException e) {
            System.out.println("P2PSServer: Error opening socket");
        } catch (IOException ep) {
            System.out.println("P2PSServer: Error opening socket");
        }
    }

    public void advertise() {
        System.out.println("P2PSServer: ------------------> Peer initialised");

        discovery = peer.getDiscoveryService();

        System.out.println("P2PSServer: ------------------> Server Started");

        try {


            SRSSAdvert srssadd = SRSSFactory.createSRSSAdvert(peer);
            srssadd.setPort(port);
            //srssadd.setServiceName(InetAddress.getLocalHost().getHostName());
            srssadd.setServiceName(pai.getLocalHost().getHostAddress());

            discovery.publish(srssadd);

            System.out.println("P2PSServer: ------------------> init finished... waiting");

        } catch (IOException ee) {
            System.out.println("Couldn't create peer");
            ee.printStackTrace();
        }
    }

    public void dataReceived(PAISocketEvent sv) {
        try {
            System.out.println("Receiving ----------------------------");
            byte b[] = new byte[1000];
            PAIDatagramPacket p = new PAIDatagramPacket(b, b.length);
            pai.receive(s, p);
            System.out.println("P2PSServer: Received " +
                        new String(p.getData()) +
                  " from " + p.getAddress().getHostAddress() +
                         " port: " + p.getPort());
        } catch (IOException ep) {
            System.out.println("PAICommands: Error opening socket");
        }
    }

    public String command(String command, String args[]) {
        if (command.equals("init")) {
            try{
                init(new DefaultPAIConfig());
                initPAISocket();
            } catch (IOException ee) {

            }
            return "OK";
        }
        if (command.equals("advertise")) {
            advertise();
            return "OK";

        } else if (command.equals("cleanUp")) {
            pai.cleanUp();
            System.out.println("P2PSServer: Cleaned up ok");
            return "OK";
        }

        return "ERROR";
    }


    public static void main(String[] args) throws IOException {
        P2PSServer p = new P2PSServer();
        p.init(new p2ps.imp.peer.config.DefaultConfig());
        p.advertise();
    }
}
