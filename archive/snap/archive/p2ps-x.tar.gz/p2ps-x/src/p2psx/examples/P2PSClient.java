package p2psx.examples;

import p2ps.discovery.Advertisement;
import p2ps.discovery.AdvertisementFactory;
import p2ps.discovery.DiscoveryEvent;
import p2ps.discovery.DiscoveryListener;
import p2ps.discovery.DiscoveryService;
import p2ps.imp.peer.PeerImp;
import p2ps.imp.peer.config.DefaultConfig;
import p2ps.peer.Peer;
import p2ps.peer.Config;
import p2psx.imp.peer.config.DefaultPAIConfig;
import p2psx.imp.srss.SRSSQuery;
import p2psx.imp.srss.SRSSAdvert;
import p2psx.imp.srss.SRSSFactory;

import java.io.IOException;
import java.net.SocketException;

import pai.api.PAIInterface;
import java.net.DatagramPacket;
import java.net.InetAddress;

import pai.net.PAIInetAddress;
import pai.net.PAIDatagramPacket;
import agentj.api.AgentJObject;
import agentj.api.AgentJ;
import agentj.imp.agentj.AgentJFactory;

public class P2PSClient implements AgentJObject, DiscoveryListener {

    private AdvertisementFactory adverts;
    private DiscoveryService discovery;

    PAIInterface pai;
    pai.net.PAIDatagramSocketImpl s;
    int portToSendTo = -1;
    String addressToSendTo = null;
    Peer peer;

    AgentJ agentj;

    public P2PSClient() {
        agentj=AgentJFactory.getAgentJ();
        pai = agentj.getPAI();
    }

    public void init(Config conf) throws IOException {
        System.out.println("P2PSClient: ------------------> creating");
        peer = new PeerImp(conf);
        System.out.println("P2PSClient: ------------------> Peer initialising");
        peer.init();

        discovery = peer.getDiscoveryService();
        discovery.addDiscoveryListener(this);

        SRSSFactory.registerAdverts(peer); // registers the adverts and queries for SRSS

    }

public void initPAISocket() {
    try {
          s = pai.addSocket(3333); // for sending to
      } catch (SocketException e) {
          System.out.println("Error opening socket");
      } catch (IOException ep) {
          System.out.println("Error opening socket");
      }
}

    public void query() throws IOException {
        System.out.println("P2PSClient: ------------------> Started: Locating SRSS nodes");

        SRSSQuery query = SRSSFactory.createSRSSQuery(peer);

        discovery.publish(query);
    }

    public void advertDiscovered(DiscoveryEvent event) {
        Advertisement advert = event.getAdvertisement();

        System.out.println("P2PSClient: Discovered a " + advert.getType());
        System.out.println("P2PSClient: Advert class is a " + advert.getClass().getName());

        if (advert instanceof SRSSAdvert) {
            System.out.println("P2PSClient: ------------------> Advert discovered: PeerID "
                    + advert.getPeerID() + " Service Name = " +
                    ((SRSSAdvert) advert).getServiceName() + " port: "
                        + ((SRSSAdvert) advert).getPort());
            // set sending address
            portToSendTo = ((SRSSAdvert) advert).getPort();
            addressToSendTo = ((SRSSAdvert) advert).getServiceName();

            sendData(); // send it a hello message !
        }
    }

    public void sendData() {
        try {
            byte b[] = (new String("Hello Proteus").getBytes());

            System.out.println("P2PSClient: My ID is " + agentj.getID());

            System.out.println("P2PSClient: Sending: " + new String(b) + " to " +
                    addressToSendTo + " on port " + portToSendTo);

            PAIDatagramPacket p = new PAIDatagramPacket(b, b.length,
                            PAIInetAddress.getByName(addressToSendTo), portToSendTo);
            pai.send(s, p);
        } catch (IOException eh) {
            System.out.println("Error Sending Data");
        }
    }

    public String command(String command, String args[]) {
        if (command.equals("init")) {
            try {
                init(new DefaultPAIConfig());
                initPAISocket();
            } catch (IOException ee) {
                System.out.println("Could not instantiate peer");
                ee.printStackTrace();
            }
            return "OK";
        }
        if (command.equals("query")) {
            try {
                query();
            } catch (IOException ee) {
                System.out.println("Could not instantiate peer");
                ee.printStackTrace();
            }
            return "OK";
        } else if (command.equals("cleanUp")) {
            pai.cleanUp();
            return "OK";
        }

        return "ERROR";
    }

    /**
     * This is the real-world implementation ...
     *
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        P2PSClient p = new P2PSClient();
        p.init(new DefaultConfig()); // default config for real-world
        p.query();
    }

}
