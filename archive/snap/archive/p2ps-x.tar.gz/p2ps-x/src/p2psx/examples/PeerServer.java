package p2psx.examples;

import p2ps.discovery.AdvertisementFactory;
import p2ps.discovery.DiscoveryService;
import p2ps.imp.peer.PeerImp;
import p2ps.peer.Peer;
import p2ps.peer.Config;
import p2ps.pipe.InputPipe;
import p2ps.pipe.MessageListener;
import p2ps.pipe.MessageReceivedEvent;
import p2ps.pipe.PipeAdvertisement;
import p2ps.pipe.PipeService;

import java.io.IOException;

import agentj.api.AgentJObject;
import p2psx.imp.peer.config.DefaultPAIConfig;


public class PeerServer implements MessageListener, AgentJObject {

    private AdvertisementFactory adverts;
    private DiscoveryService discovery;
    private PipeService pipes;

    public PeerServer() {
    }

    public void init(Config conf) throws IOException  {

        Peer peer = new PeerImp(conf);
        peer.init();

        // retrieve services
        adverts = peer.getAdvertisementFactory();
        discovery = peer.getDiscoveryService();
        pipes = peer.getPipeService();

        System.out.println("PEER SERVER:       Started");

    }


    public void publish () throws IOException  {
        // initialise server pipe advertisement
        PipeAdvertisement pipead = (PipeAdvertisement) adverts.newAdvertisement(PipeAdvertisement.PIPE_ADVERTISEMENT_TYPE);
        pipead.setPipeName("serverPipe");

        // create server pipe and attach listener
        InputPipe inpipe = pipes.createInputPipe(pipead);
        inpipe.addPipeListener(this);

        // publish server pipe advertisement
        discovery.publish(pipead);
        System.out.println("PEER SERVER:       published");
    }


    public void messageReceived(MessageReceivedEvent event) {
        System.out.println("PEER SERVER:       MESSAGE !!!!!!!!!!!!!!!!!!!!!");
        // display received messages
        System.out.println("\nMessage: " + new String(event.getMessage()));
        System.out.println("(Received on " + event.getInputPipe().getPipeName() + " " + event.getInputPipe().getPipeID() + ")");
    }


    public static void main(String[] args) throws IOException {
        PeerServer p = new PeerServer();
        p.init(new p2psx.imp.peer.config.DefaultSimulConfig());
        p.publish();
    }

    public String command(String command, String args[]) {
        if (command.equals("init")) {
            try {            init(new DefaultPAIConfig());
            } catch (IOException ee) {
                System.out.println("Could not instantiate peer");
                ee.printStackTrace();
            }
            return "OK";
        }
        if (command.equals("advertise")) {
            try {           publish();
            } catch (IOException ee) {
                System.out.println("Could not instantiate peer");
                ee.printStackTrace();
            }
            return "OK";

        } else if (command.equals("cleanUp")) {
            return "OK";
        }

        return "ERROR";
    }
}
