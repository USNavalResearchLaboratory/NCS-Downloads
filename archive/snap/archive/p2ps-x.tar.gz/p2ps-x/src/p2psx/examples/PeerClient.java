package p2psx.examples;

import p2ps.discovery.Advertisement;
import p2ps.discovery.AdvertisementFactory;
import p2ps.discovery.DiscoveryEvent;
import p2ps.discovery.DiscoveryListener;
import p2ps.discovery.DiscoveryService;
import p2ps.imp.peer.PeerImp;
import p2ps.peer.Peer;
import p2ps.peer.Config;
import p2ps.pipe.*;

import java.io.IOException;

import agentj.api.AgentJObject;
import pai.imp.Logging;
import p2psx.imp.peer.config.DefaultPAIConfig;

public class PeerClient implements DiscoveryListener, AgentJObject, PipeConnectionListener {

    private AdvertisementFactory adverts;
    private DiscoveryService discovery;
    private PipeService pipes;
    public static final String SERVER_PIPE_NAME = "serverPipe";


    public PeerClient() {
        }

    public void init(Config conf) throws IOException  {

        Logging.setEnabled(true);

        Peer peer = new PeerImp(conf);
        peer.init();

        // retrieve services
        adverts = peer.getAdvertisementFactory();
        discovery = peer.getDiscoveryService();
        pipes = peer.getPipeService();

        // listen for discovered advertisements
        discovery.addDiscoveryListener(this);
        pipes.addPipeConnectionListener(this);

        // listen for discovered advertisements
        discovery.addDiscoveryListener(this);

        System.out.println("Client Started: Locating Server Pipe");

    }


    public void query() throws IOException {
        // create pipe query for server pipe
          PipeQuery pipequery = (PipeQuery) adverts.newAdvertisement(PipeQuery.PIPE_QUERY_TYPE);
          pipequery.setQueryPipeName(SERVER_PIPE_NAME);

          // publish pipe query
          discovery.publish(pipequery);
          System.out.println("PEERCLIENT:       Query Published");
    }


    public void advertDiscovered(DiscoveryEvent event) {
        try {
            Advertisement advert = event.getAdvertisement();

            // handle discovered server pipe advertisement
            if ((advert instanceof PipeAdvertisement) && ((PipeAdvertisement) advert).getPipeName().equals(SERVER_PIPE_NAME)) {
                System.out.println("\nPipe discovered: " + ((PipeAdvertisement) advert).getPipeName() + " " + ((PipeAdvertisement) advert).getPipeID());

                // connect output pipe to discovered pipe
                pipes.connectOutputPipe((PipeAdvertisement) advert);
            }
        } catch (IOException except) {
            except.printStackTrace();
        }
    }


    /**
     * Called when an output pipe is successfully connected
     */
    public void outpipeConnected(PipeConnectedEvent event) {
        // only interested in server pipes
        if (event.getPipeAdvertisement().getPipeName().equals(SERVER_PIPE_NAME)) {
            try {
                // send test message
                event.getOutputPipe().send("HELLO".getBytes());

                System.out.println("Pipe Connected: 'HELLO' message sent");
            } catch (IOException except) {
            }
        }
    }

    /**
     * Called when an output pipe is successfully connected
     */
    public void outpipeConnectFailure(PipeConnectFailureEvent event) {
        // only interested in server pipes
        if (event.getPipeAdvertisement().getPipeName().equals(SERVER_PIPE_NAME)) {
            System.out.println("Pipe connect failure!");

            if (event.getException() != null)
                event.getException().printStackTrace();
        }
    }



    public String command(String command, String args[]) {
        if (command.equals("init")) {
            try {
                init(new DefaultPAIConfig());
            } catch (IOException ee) {
                System.out.println("Could not instantiate peer");
                ee.printStackTrace();
            }
            return "OK";
        }
        if (command.equals("query")) {
            try {
                query();
            } catch (IOException ee) {
                System.out.println("Could not instantiate peer");
                ee.printStackTrace();
            }
            return "OK";
        }

        return "ERROR";
    }

    public static void main(String[] args) throws IOException {
        PeerClient p = new PeerClient();
        p.init(new p2psx.imp.peer.config.DefaultSimulConfig());
        p.query();
    }

}
