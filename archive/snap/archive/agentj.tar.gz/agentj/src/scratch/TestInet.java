package src.scratch;

import pai.net.PAIInetAddress;

/**
 * Created by IntelliJ IDEA.
 * User: scmijt
 * Date: Aug 4, 2004
 * Time: 11:22:13 AM
 * To change this template use File | Settings | File Templates.
 */
public class TestInet {

    public static void main(String args[]) {

        System.out.println("Starting....");

        try {
            System.out.println(pai.net.PAIInetAddress.getLocalHost());
        } catch(Exception e) {
            e.printStackTrace();
        }

    }
}
