#include <iostream>
#include <string>
using namespace std;

class b {
    public:
    int count;

    b() { 
        ++count;
        cout << "Called B" << endl; 
        }
};

class bird {

public:
	static b *num;
        bird() {
            cout << "Bird called ...." << endl;
            if (num==0) 
                num=new b();
            }
};

b *bird::num=0;

int main() {
    bird chick;
    bird swan;
    bird swani;
    bird swan7;
    bird swan9;
    bird swan0;


    cout << "Count is " << bird::num->count << endl;
}
