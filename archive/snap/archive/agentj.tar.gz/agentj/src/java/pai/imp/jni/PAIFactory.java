package pai.imp.jni;

import pai.api.PAIInterface;
import org.apache.log4j.Logger;

/**
 * A simple factory for creating a reference to the external PAI native library.
 * This can easily be extended to offer different bindings of the PAIInterface
 * class.
 *
 * User: Ian Taylor
 * Date: Nov 3, 2003
 * Time: 3:13:56 PM
 * To change this template use Options | File Templates.
 */
public class PAIFactory {
    static Logger logger = Logger.getLogger(PAIFactory.class);

    static PAINative nativePAIImp=null;

    /**
     * Gets the current PAINAtive Object or returns a new instance
     * if its is currently null
     * @return
     */
    public static PAIInterface getNativePAIObj() {
        logger.info("Entering");
        if (nativePAIImp==null)
            nativePAIImp=new PAINative();
        logger.info("Exiting");
        return nativePAIImp;
    }
}
