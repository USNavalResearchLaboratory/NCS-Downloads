package pai.api;

import pai.imp.event.PAITimerListener;
import pai.imp.timers.PAITimer;

/**
 * Created by IntelliJ IDEA.
 * User: Ian
 * Date: Nov 3, 2003
 * Time: 3:12:04 PM
 * To change this template use Options | File Templates.
 */
public interface PTIInterface {
    PAITimer addTimer(double delay, int repeat);

    void removeTimer(PAITimer timer);

    void addPAITimerListener(PAITimer timerID, PAITimerListener listener);

    void removePAITimerListener(PAITimer timerID, PAITimerListener listener);

    boolean runTimers();
}
