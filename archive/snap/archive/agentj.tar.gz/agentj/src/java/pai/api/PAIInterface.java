package pai.api;

import pai.imp.event.PAISocketListener;
import java.net.DatagramPacket;
import pai.net.PAIInetAddress;
import pai.imp.event.PAISocketListener;
import pai.net.*;

import pai.net.PAIMulticastSocketImpl;
import java.net.*;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: Ian
 * Date: Nov 3, 2003
 * Time: 3:12:04 PM
 * To change this template use Options | File Templates.
 */
public interface PAIInterface extends PTIInterface {
    void init();
    
    void addPAISocketListener(pai.net.PAIDatagramSocketImpl sock, PAISocketListener listener);

    void removePAISocketListener(pai.net.PAIDatagramSocketImpl sock, PAISocketListener listener);

    void open(pai.net.PAIDatagramSocketImpl sock, int port) throws SocketException;

    pai.net.PAIDatagramSocketImpl addSocket(int port) throws SocketException;

    void removeSocket(pai.net.PAIDatagramSocketImpl sock) throws SocketException;

    void setReuseAddress(pai.net.PAIDatagramSocketImpl sock, boolean on) throws SocketException;

    void setSendBufferSize(pai.net.PAIDatagramSocketImpl sock, int size) throws SocketException;

    void setReceiveBufferSize(pai.net.PAIDatagramSocketImpl sock, int size) throws SocketException;

    void setSoTimeout(pai.net.PAIDatagramSocketImpl sock, int timeout) throws SocketException;

    void send(pai.net.PAIDatagramSocketImpl sock, PAIDatagramPacket p) throws IOException;

    void receive(pai.net.PAIDatagramSocketImpl sock, PAIDatagramPacket p) throws IOException;

    void close(pai.net.PAIDatagramSocketImpl sock);

    void joinGroup(pai.net.PAIMulticastSocketImpl sock, PAIInetAddress mcastaddr) throws IOException;

    void leaveGroup(PAIMulticastSocketImpl sock, PAIInetAddress mcastaddr) throws IOException;

    void setMulticast(PAIMulticastSocketImpl sock, boolean val);

    public PAIInetAddress getByName(String host) throws UnknownHostException;

    public PAIInetAddress getLocalHost();

    public boolean cleanUp();
    public boolean runBlock();
    public boolean runNonBlock();

    /**
     * This allows the Java program to set the referennce to the actual C++
     * object of thiis Ns2 node.
     *
     * @param nodeID
     */
    public void setNS2Node(String nodeID);

    public void setNS2Scheduler(String schedulerID);
}
