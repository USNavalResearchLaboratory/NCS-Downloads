package pai.examples.ns2;

import pai.api.PAIInterface;
import pai.net.PAIDatagramSocketImpl;
import java.net.DatagramPacket;
import pai.net.PAIInetAddress;
import pai.imp.timers.PAITimer;
import pai.imp.Logging;
import pai.imp.timers.PAITimer;
import pai.imp.event.PAISocketEvent;
import pai.imp.event.*;
import pai.imp.event.PAITimerListener;

import java.net.SocketException;
import java.net.InetAddress;

import pai.net.PAIInetAddress;
import pai.net.PAIDatagramPacket;

import java.io.IOException;

import agentj.api.AgentJObject;
import agentj.api.AgentJObject;
import agentj.api.AgentJ;
import agentj.imp.agentj.AgentJFactory;

/**
 * THIS CLASS DOES NOT WORK !!!  The code here is ok but the
 * underlying timing mechanisms do not operate correctly.
 * It is left here only for debugging later if WE NEED THIS
 * ...
 */
public class PAIProtoApp implements AgentJObject,
                                        PAISocketListener, PAITimerListener {
    PAIInterface pai;
    String sendTo;
    PAIDatagramSocketImpl s;
    PAITimer t;
    int count=0;
    AgentJ agentj;

    public void init() {
        agentj = AgentJFactory.getAgentJ();
        pai = agentj.getPAI();

        try {
            if (Logging.isEnabled())
                System.out.println("PAICommands: init, creating Socket...");
            s = pai.addSocket(5555);
            if (Logging.isEnabled())
                System.out.println("PAICommands: init, creating listener for Socket...");
            pai.addPAISocketListener(s,this);
        } catch (SocketException e) {
            System.out.println("Error opening socket");
        }
        catch (IOException ep) {
            System.out.println("Error opening socket");
        }
    }

    void start() {
        if (Logging.isEnabled())
            System.out.println("PAICommands: start...");
        startTimer();
	    timerTriggered(null);  // transmit first packet right away
        }

    void startTimer() {
        if (Logging.isEnabled())
            System.out.println("PAICommands: startTimer...");
	    t = pai.addTimer(1.0, -1);

        if (Logging.isEnabled())
            System.out.println("PAICommands: startTimer, adding timer listener");

        pai.addPAITimerListener(t, this);
        if (Logging.isEnabled())
            System.out.println("PAICommands: startTimer, exiting");
    }

    public void dataReceived(PAISocketEvent sv) {
        try {
            ++count;
            if (Logging.isEnabled())
                System.out.println("PAICommands: dataReceived...");
            byte b[] = new byte[15];
            PAIDatagramPacket p = new PAIDatagramPacket(b,b.length);
            pai.receive(s, p);
            if (Logging.isEnabled()) {
                System.out.println("PAICommands: Received PACKET NUMBER ----------------> " + count);

                System.out.println("PAICommands: Received " + new String(p.getData()) +
                        " from " + p.getAddress().getHostAddress());
            }
        } catch (IOException ep) {
            System.out.println("PAICommands: Error opening socket");
        }
    }

    public void timerTriggered(PAITimerEvent t) {
        if (Logging.isEnabled())
            System.out.println("PAICommands: timerTriggered...");
        try {
              //  System.out.println("ProtoApp: Timer Triggered: setting up data...");
                byte b[] = (new String("Hello Proteus " + String.valueOf(count)).getBytes());
                PAIDatagramPacket p =new PAIDatagramPacket(b, b.length, PAIInetAddress.getByName(sendTo), 5555);
                // System.out.println("Sending " + new String(b));
                pai.send(s,p);
        }      catch (IOException eh) {
            System.out.println("Error Sending Data");
        }
        if (Logging.isEnabled())
            System.out.println("PAICommands: timerTriggered: Data Packet Number >>>>>>> " + count);
    }


    public String command(String command, String args[]) {
        if (Logging.isEnabled())
            System.out.println("PAICommands: command: " + command+ " called with " +
                  args.length + " args: " + args[0]);

        if (command.equals("init")) {
            init();
            return "OK";
        }
        else if (command.equals("setSendTo")) {
            sendTo = args[0];
            return "OK";
         }
        else if (command.equals("start")) {
            start();
            return "OK";
        }
      /* else if (command.equals("startTimer")) {
            startTimer();
            return "OK";
        }  */
       else if (command.equals("trigger")) {
             timerTriggered(null);
             return "OK";
         }
       else if (command.equals("cleanUp")) {
             pai.cleanUp();
             return "OK";
         }

        return "ERROR";
    }
}
