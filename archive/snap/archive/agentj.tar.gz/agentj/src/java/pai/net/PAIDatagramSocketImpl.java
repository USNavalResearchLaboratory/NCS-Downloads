package pai.net;

import pai.api.PAIInterface;
import pai.imp.jni.PAIFactory;

import java.net.*;
import java.net.DatagramPacket;
import java.io.IOException;

import org.apache.log4j.Logger;


/**
 * This class represents a socket for sending and receiving datagram packets.
 * It communicates directly with the PAI C++ classes. Ripped off the java class
 * directly to make the integration into P2PS as seamless as a seamless thing ...
 *
 * <p>A datagram socket is the sending or receiving point for a packet
 * delivery service. Each packet sent or received on a datagram socket
 * is individually addressed and routed. Multiple packets sent from
 * one machine to another may be routed differently, and may arrive in
 * any order.
 *
 */
public class PAIDatagramSocketImpl {  // extends DatagramSocketImpl LATER

    static Logger logger = Logger.getLogger(PAIDatagramSocketImpl.class);

    /**
     * Various states of this socket.
     */
    private boolean closed = false;

    int connectedPort = -1;

    PAIInterface pai = PAIFactory.getNativePAIObj();

    /**
     * Constructs a datagram socket and binds it to the specified port
     * on the local host machine.  The socket will be bound to the wildcard
     * address, an IP address chosen by the kernel.
     * 
     * <p>If there is a security manager, 
     * its <code>checkListen</code> method is first called
     * with the <code>port</code> argument
     * as its argument to ensure the operation is allowed. 
     * This could result in a SecurityException.
     *
     * @param      port port to use.
     * @exception  java.net.SocketException  if the socket could not be opened,
     *               or the socket could not bind to the specified local port.
     *
     */
    public PAIDatagramSocketImpl(int port) throws SocketException {
        logger.info("Entering");
        this.connectedPort=port;
        pai.open(this, port);
        logger.info("Exiting");
    }


    /**
     * Returns the port for this socket. Returns -1 if the socket is not
     * connected.
     *
     * @return the port to which this socket is connected.
     */
    public int getPort() {
        return connectedPort;
    }

    /**
     * Enable/disable the SO_REUSEADDR socket option.
     * <p>
     *
     * @param on  whether to enable or disable the
     * @exception SocketException if an error occurs enabling or
     *            disabling the <tt>SO_RESUEADDR</tt> socket option,
     *	   	  or the socket is closed.
     * @see #isClosed()
     */
    public synchronized void setReuseAddress(boolean on) throws SocketException {
        logger.info("Entering");
        if (isClosed())
            throw new SocketException("Socket is closed");
        pai.setReuseAddress(this, on);
        logger.info("Exiting");
    }


    /**
     * Sets the SO_SNDBUF option to the specified value for this
     * <tt>DatagramSocket</tt>. The SO_SNDBUF option is used by the
     * network implementation as a hint to size the underlying
     * network I/O buffers. The SO_SNDBUF setting may also be used
     * by the network implementation to determine the maximum size
     * of the packet that can be sent on this socket.
     * <p>
     * Increasing the buffer size may allow multiple outgoing packets
     * to be queued by the network implementation when the send rate
     * is high.
     * <p>
     *
     * @param size the size to which to set the send buffer
     * size. This value must be greater than 0.
     *
     * @exception SocketException if there is an error
     * in the underlying protocol, such as an UDP error.
     * @exception IllegalArgumentException if the value is 0 or is
     * negative.
     */
    public synchronized void setSendBufferSize(int size)
            throws SocketException{
        logger.info("Entering");
        if (!(size > 0)) {
            throw new IllegalArgumentException("negative send size");
        }
        if (isClosed())
            throw new SocketException("Socket is closed");

        pai.setSendBufferSize(this,size);
        logger.info("Exiting");
    }

    /**
     * Returns the port number on the local host to which this socket is bound.
     *
     * @return  the port number on the local host to which this socket is bound.
     */
    public int getLocalPort() {
        if (isClosed())
            return -1;
        return connectedPort;
    }


    /**
     * Sets the SO_RCVBUF option to the specified value for this
     * <tt>DatagramSocket</tt>. The SO_RCVBUF option is used by the
     * the network implementation as a hint to size the underlying
     * network I/O buffers. The SO_RCVBUF setting may also be used
     * by the network implementation to determine the maximum size
     * of the packet that can be received on this socket.
     * <p>
     * Increasing SO_RCVBUF may allow the network implementation
     * to buffer multiple packets when packets arrive faster than
     * are being received.
     * <p>
     *
     * @param size the size to which to set the receive buffer
     * size. This value must be greater than 0.
     *
     * @exception SocketException if there is an error in
     * the underlying protocol, such as an UDP error.
     * @exception IllegalArgumentException if the value is 0 or is
     * negative.
     */
    public synchronized void setReceiveBufferSize(int size)
            throws SocketException{
        logger.info("Entering");
        if (size <= 0) {
            throw new IllegalArgumentException("invalid receive size");
        }
        if (isClosed())
            throw new SocketException("Socket is closed");

        pai.setReceiveBufferSize(this,size);
        logger.info("Exiting");
    }

    /** Enable/disable SO_TIMEOUT with the specified timeout, in
     *  milliseconds. With this option set to a non-zero timeout,
     *  a call to receive() for this DatagramSocket
     *  will block for only this amount of time.  If the timeout expires,
     *  a <B>java.net.SocketTimeoutException</B> is raised, though the
     *  DatagramSocket is still valid.  The option <B>must</B> be enabled
     *  prior to entering the blocking operation to have effect.  The
     *  timeout must be > 0.
     *  A timeout of zero is interpreted as an infinite timeout.
     *
     * @param timeout the specified timeout in milliseconds.
     * @throws SocketException if there is an error in the underlying protocol, such as an UDP error.
     */
    public synchronized void setSoTimeout(int timeout) throws SocketException {
        if (isClosed())
            throw new SocketException("Socket is closed");
        logger.info("Entering");
        pai.setSoTimeout(this,timeout);
        logger.info("Exiting");
    }

    /**
     * Sends a datagram packet from this socket. The
     * <code>DatagramPacket</code> includes information indicating the
     * data to be sent, its length, the IP address of the remote host,
     * and the port number on the remote host.
     *
     *
     * @param      p   the <code>DatagramPacket</code> to be sent.
     * 
     * @exception  java.io.IOException  if an I/O error occurs.
     *
     * @see        java.net.DatagramPacket
     */
    public void send(PAIDatagramPacket p) throws IOException  {
        logger.info("Entering");
        logger.debug("NS2 NODE ID: " + PAIFactory.getNativePAIObj().getLocalHost().getHostName());
        pai.send(this,p);
        logger.info("Exiting");
    }

    /**
     * Receives a datagram packet from this socket. When this method
     * returns, the <code>DatagramPacket</code>'s buffer is filled with
     * the data received. The datagram packet also contains the sender's
     * IP address, and the port number on the sender's machine.
     *
     * @param      p   the <code>DatagramPacket</code> into which to place
     *                 the incoming data.
     * @exception  IOException  if an I/O error occurs.
     * @see        java.net.DatagramPacket
     */
    public synchronized void receive(PAIDatagramPacket p) throws IOException {
        logger.info("Entering");
        logger.debug("NS2 NODE ID: " + PAIFactory.getNativePAIObj().getLocalHost().getHostName());
        synchronized (p) {
            pai.receive(this,p);
        }
        logger.info("Exiting");
    }


    /**
     * Closes this datagram socket.
     * <p>
     * Any thread currently blocked in {#link receive} upon this socket
     * will throw a {@link SocketException}.
     *
     * <p> If this socket has an associated channel then the channel is closed
     * as well.
     *
     */
    public void close() {
        closed = true;
        logger.info("Entering");
        pai.close(this);
        logger.info("Exiting");
    }

    /**
     * Returns wether the socket is closed or not.
     *
     * @return true if the socket has been closed
     */
    public boolean isClosed() {
        return closed;
    }
}
