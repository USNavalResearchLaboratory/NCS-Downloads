package pai.examples.javaPAI;

import pai.net.PAIDatagramSocketImpl;
import java.net.DatagramPacket;
import pai.net.PAIInetAddress;
import pai.net.PAIDatagramPacket;
import pai.imp.event.PAISocketListener;
import pai.imp.event.PAISocketEvent;
import pai.imp.event.PAITimerListener;
import pai.imp.event.PAITimerEvent;
import pai.api.PAIInterface;
import pai.imp.jni.PAIFactory;
import pai.imp.timers.PAITimer;
import pai.imp.event.PAISocketEvent;
import pai.imp.event.PAITimerEvent;
import pai.examples.javaPAI.JavaPAITest;

import java.net.SocketException;
import java.net.UnknownHostException;
import java.net.InetAddress;
import java.io.IOException;

/**
 * A simple example that kicks off the Protolib scheduler and then
 * sends 10 messages to port 6666 on the destination machine (i.e.
 * this machine).  The messages
 * @author     Ian Taylor
 * @created    September 5th, 2003
 * @version    $Revision: 1.1 $
 * @date       $Date: 2003/11/06 15:43:47 $ modified by $Author: ian $
 */
public class JavaProtoApp implements PAISocketListener, PAITimerListener {
    PAIInterface pai;
    pai.net.PAIDatagramSocketImpl s;
    PAITimer t;
    int count=0;

    public JavaProtoApp() {
        pai = PAIFactory.getNativePAIObj();
        try {
            s = pai.addSocket(5555);
            pai.addPAISocketListener(s,this);
            t = pai.addTimer(1.0, -1);
            pai.addPAITimerListener(t, this);
            pai.runBlock();
        } catch (SocketException e) {
            System.out.println("Error opening socket");
        }
        catch (IOException ep) {
            System.out.println("Error opening socket");
        }

    pai.cleanUp();
    }

    public void dataReceived(PAISocketEvent sv) {
        try {
            byte b[] = new byte[13];
            PAIDatagramPacket p = new PAIDatagramPacket(b,b.length);
            pai.receive(s, p);
            System.out.println("Received " + new String(p.getData()) +
                " from " + p.getAddress().getHostAddress());
        } catch (IOException ep) {
            System.out.println("Error opening socket");
        }
    }

    public void timerTriggered(PAITimerEvent t) {
        try {
                System.out.println("ProtoApp: Timer Triggered: setting up data...");
                byte b[] = (new String("Hello Proteus " + String.valueOf(count)).getBytes());
                PAIDatagramPacket p =new PAIDatagramPacket(b, b.length, PAIInetAddress.getByName("127.0.0.1"), 5555);
                System.out.println("Sending " + new String(b));
                pai.send(s,p);
                ++count;
        }      catch (IOException eh) {
            System.out.println("Error Sending Data");
        }
    }

    public static void main(String[] args) throws Exception {
        new JavaProtoApp();
    }
}

