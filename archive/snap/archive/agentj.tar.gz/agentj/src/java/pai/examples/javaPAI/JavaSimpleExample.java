package pai.examples.javaPAI;

import pai.api.PAIInterface;
import pai.net.PAIDatagramSocketImpl;
import pai.net.PAIDatagramPacket;

import java.net.DatagramPacket;
import pai.imp.jni.PAIFactory;
import pai.imp.event.PAISocketEvent;

import java.net.SocketException;
import java.net.UnknownHostException;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: ian
 * Date: 04-Nov-2003
 * Time: 19:05:53
 * To change this template use Options | File Templates.
 */
public class JavaSimpleExample {
    PAIInterface pai;
    pai.net.PAIDatagramSocketImpl s;
    pai.net.PAIDatagramSocketImpl s1;

    public JavaSimpleExample() {
        pai = PAIFactory.getNativePAIObj();

        try {
            //System.out.println("Local host " + pai.getLocalHost().getHostAddress());
            System.out.println("Local host " + pai.getByName("localhost").getHostAddress());
            System.out.println("Remote host " + pai.getByName("bender.astro.cf.ac.uk").getHostAddress());

            s = pai.addSocket(5555);
            s1 = pai.addSocket(6666);

            byte b[] = (new String("Hello Proteus ").getBytes());

            PAIDatagramPacket p =new PAIDatagramPacket(
                    b, b.length, pai.getLocalHost(), 6666);

            pai.send(s,p);

            byte br[] = new byte[15];

            PAIDatagramPacket pr = new PAIDatagramPacket(br,br.length);
            pai.receive(s1, pr);

            System.out.println("Data Received in Java Code " + new String(pr.getData()));
        } catch (Exception ee) {
            ee.printStackTrace();
        }
    }
    public static void main(String[] args) throws Exception {
        new JavaSimpleExample();
    }
}
