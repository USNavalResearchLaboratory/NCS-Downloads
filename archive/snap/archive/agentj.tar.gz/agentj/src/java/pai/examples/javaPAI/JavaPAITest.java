package pai.examples.javaPAI;

import pai.net.PAIDatagramSocketImpl;
import java.net.DatagramPacket;
import pai.net.PAIInetAddress;
import pai.imp.event.PAISocketListener;
import pai.imp.event.PAISocketEvent;
import pai.imp.event.PAISocketListener;
import pai.api.PAIInterface;
import pai.imp.jni.PAIFactory;

import java.net.SocketException;
import java.net.UnknownHostException;
import pai.net.PAIDatagramSocketImpl;
import pai.net.PAIDatagramPacket;

import java.io.IOException;

/**
 * @author     Ian Taylor
 * @created    September 5th, 2003
 * @version    $Revision: 1.2 $
 * @date       $Date: 2003/11/06 15:43:47 $ modified by $Author: ian $
 */
public class JavaPAITest extends Thread implements PAISocketListener {
    PAIInterface pai;
    pai.net.PAIDatagramSocketImpl s;
    PAIDatagramSocketImpl s1;
    int runs=10, count=0;

    public JavaPAITest() {
        pai = PAIFactory.getNativePAIObj();
        try {
            s = pai.addSocket(5555);
            s1 = pai.addSocket(6666);
            pai.addPAISocketListener(s1,this);

            start();

            pai.runBlock(); // kick off remote dispatcher
        } catch (SocketException e) {
            System.out.println("Error opening socket");
        }
        catch (IOException ep) {
            System.out.println("Error opening socket");
        }
    }

    public void run() {

        byte b[] = (new String("Hello Proteus").getBytes());
        PAIDatagramPacket p =new PAIDatagramPacket(b, b.length, pai.getLocalHost(), 6666);
        try {
            for (int i=0; i<runs; ++i) {
                try {
                    Thread.sleep(1000);
                } catch(InterruptedException ee) {
                }
                pai.send(s,p);
            }
        }      catch (IOException eh) {
            System.out.println("Error Sending Data");
        }
//        pai.cleanUp();
    }

    public void dataReceived(PAISocketEvent s) {
        try {
            byte b[] = new byte[13];
            PAIDatagramPacket p = new PAIDatagramPacket(b,b.length);
            pai.receive(s1, p);
            System.out.println("Data Received in Java Code " + String.valueOf(p.getData()));
        } catch (IOException ep) {
            System.out.println("Error opening socket");
        }
        ++count;
    }

    public static void main(String[] args) throws Exception {
        new JavaPAITest();
    }
}

