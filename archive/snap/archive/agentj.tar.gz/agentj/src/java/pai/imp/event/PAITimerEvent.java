package pai.imp.event;

import pai.net.PAIDatagramSocketImpl;
import pai.imp.timers.PAITimer;

/**
 * The event generated when a socket receives data
 *
 * @author      Ian Taylor
 * @created     8th Sept 2003
 * @version     $Revision: 1.2 $
 * @date        $Date: 2003/11/04 16:53:07 $ modified by $Author: ian $
 */
public class PAITimerEvent {
    PAITimer timer;

    /**
     * Constructs a Socket Event 
     *
     */
    public PAITimerEvent(PAITimer timer) {
        this.timer=timer;
    }

    /**
     * @return the socket where the daya is ready to collect...
     */
    public PAITimer getTimer() {
        return timer;
    }
}
