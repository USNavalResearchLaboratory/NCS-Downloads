package pai.examples.ns2;

import agentj.api.AgentJObject;
import agentj.api.AgentJObject;


/**
 * Created by IntelliJ IDEA.
 * User: scmijt
 * Date: Mar 26, 2004
 * Time: 4:48:44 PM
 * To change this template use Options | File Templates.
 */
public class SimpleCommand implements AgentJObject {

    static int count=0;

    int myID;

    public SimpleCommand() {
        ++count;
        myID=count;
    }

    public String command(String command, String args[]) {

        if (command.equals("hello"))
            System.out.println("SimpleCommand(" + myID + ") called with Val: " + args[0]);

        return "All called ok from node " + myID;
    }
}
