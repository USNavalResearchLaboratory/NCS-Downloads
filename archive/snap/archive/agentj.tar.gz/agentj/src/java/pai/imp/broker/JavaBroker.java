package pai.imp.broker;

import pai.api.PAIInterface;
import pai.imp.jni.PAIFactory;
import pai.imp.Logging;
import pai.imp.jni.PAIFactory;
import pai.net.PAIDatagramSocketImpl;

import java.util.Hashtable;
import pai.net.PAIDatagramSocketImpl;

import agentj.api.AgentJObject;
import agentj.imp.broker.JavaBasicBroker;
import org.apache.log4j.Logger;
import autolog.DefaultLogConfig;

/**
 * This is a broker class for creating Java objects and
 * allowing them to be attached to NS-2 agents.  The JavaBroker
 * can use the PAI Native implementations (in C++) in order
 * to communicate with other nodes (if used within the NS-2 mode)
 * or to communicate with other distributed computers in the
 * networked mode.
 *
 * User: scmijt
 * Date: Mar 26, 2004
 * Time: 4:16:44 PM
 * To change this template use Options | File Templates.
 */
public class JavaBroker extends JavaBasicBroker {

    static Logger logger = Logger.getLogger(JavaBroker.class);

    static String groupAddress = null;

    static String currentNs2Node = null;

    static Hashtable socketObjects; // hashtable of sockets associated
    // to IDs so we know which Ns2
    // node created it

    static String nsSchedulerPtr=null;


    private static PAIInterface pai=null;

    private static void initPAI() {
        DefaultLogConfig.setup(); // configure the logging system first!
        logger.info("Entering");
        pai = PAIFactory.getNativePAIObj();
        socketObjects = new Hashtable();
        logger.info("Exiting");
    }


    /**
     * Creates a Java object from the given class name and adds it to an internal
     * Hashtable, registering as an object that can be accessed via the JavaBroker
     * Class.  The id value is the actuaal C++ pointer to the Agent class, which is
     * guarenteed to be unique for the agents.  This implies that there is
     * a necessary restriction of only allowing one Java class to be triggered
     * by a NS2 Agent.
     *
     * Overrides basic functionality - duplicate of JavaBasicBroker
     * but extends the PAI sections.
     *
     * @param args: arg[0] = the java class name and arg[1] is its id (i.e. the
     * pointer to the NS2 agent)
     * @return
     */
    public static int register(String[] args) {
        logger.info("Entering");
        Class c = null;
        String javaClass = args[0];
        String id = args[1];

        try {
            c = Class.forName(javaClass);
        } catch (ClassNotFoundException cnf) {
            logger.error("JavaBroker.java:  Class " + javaClass + " NOT FOUND\n" +
                     "TIP: Check the your classpath and name of class\n" +
                    "TIP: Check you have inclued the correct Java package");
            return ERROR;
        }

        AgentJObject obj = null;

        try {
            obj = (AgentJObject) c.newInstance();
        } catch (InstantiationException ie) {
            logger.error("JavaBroker.java:  Class " + javaClass + " could not be instantiated"
              + "\nTIP: Does it implement the CommandInterface ?");
            return ERROR;
        } catch (IllegalAccessException iae) {
            logger.error("JavaBroker.java:  Class " + javaClass + " threw an illegal Access Exception"
             + "\nTIP: is the class public ?");
            return ERROR;
        }

        logger.debug("Registered classname: " + javaClass);

        objects.put(id, obj);
        logger.info("Exiting");

        return OK;
    }


    /**
     * This is called from C2JBroker and is used to set the pointer to the NS2 Scheduler
     * instance, which does not get carried over to the JNI dynamic library side of this
     * cope by defualt.
     *
     * @param nsSchedulerPtr
     */
    public static int setNSScheduler(String nsSchedulerPtr) {
        System.out.println("Scheduler function");
        // System.out.println("Scheduler =" +  nsSchedulerPtr);
        JavaBroker.nsSchedulerPtr=nsSchedulerPtr;
        if (pai==null) initPAI();
        pai.setNS2Scheduler(nsSchedulerPtr);
        pai.init();
        return OK;
    }

    /**
     * Gets the instance to the NS2 Scheduler classes instance
     * @return
     */
    public static String getNSScheduler() {
        return JavaBroker.nsSchedulerPtr;
    }

    /**
     *
     * @return the group address that should be used for multicast
     * comms
     *
     */
    public static String getMulticastAddress() {
        return groupAddress;
    }


    /**
     * invokes the command, which the given arguments on the object identified by the
     * supplied identifier
     *
     * @param args: args[0] = id; args[1]= the command to be performed and
     * args[2] is the arguments for that command.
     * @return
     */
    public static String invokeCommand(String args[]) {
        logger.info("Entering");

        String id = args[0];
        String command = args[1];
        String progArgs = args[2];

        if (command.equals("setGroupAddress")) { // special case - set group address
            groupAddress = progArgs;
            logger.debug("Group Address set to " + groupAddress);
            return "OK";
        }

        /**
         * sets the id in the native library:
         */

        setCurrentNS2Node(id);
        logger.info("Exiting");
        return JavaBasicBroker.invokeCommand(args); // invoke the command on the given object
    }

    /**
     * Unregisters the given Java object and frees the reference
     *
     * @param id
     * @return
     */
    public static int unregister(String id) {
        logger.info("Entering");
        JavaBasicBroker.unregister(id);
        logger.info("Exiting");
        return OK;
    }

    /**
     * Clears the hashtable and unreferences all of the objects
     */
    public static void cleanUp() {
        logger.info("Entering");
        JavaBasicBroker.cleanUp();
        logger.info("Exiting");
    }


    /**
     * returns the current NS2 node that is in focus
     * @return
     */
    public static String getCurrentNS2Node() {
        return currentNs2Node;
    }

    /**
     * This is a static call - assumes we're using one PAI instance
     * (which we are) and is used if a node gets a callback i.e.
     * we need to resent the ID of the processing node if this happens
     */
     public static void setCurrentNS2Node(String id) {
        logger.info("Entering");
        currentNs2Node = id;
        pai.setNS2Node(id); // set the pointer for the C++ NS2 node
        logger.info("Exiting");
    }

    public static void registerSocket(pai.net.PAIDatagramSocketImpl sock) {
        socketObjects.put(sock, currentNs2Node);
    }

    public static void unregisterSocket(PAIDatagramSocketImpl sock) {
        socketObjects.remove(sock);
    }

    public static String getNS2NodeforSocket(PAIDatagramSocketImpl sock) {
        Object s = socketObjects.get(sock);

        if (s != null)
            return (String) s;
        else
            return null;
    }
}
