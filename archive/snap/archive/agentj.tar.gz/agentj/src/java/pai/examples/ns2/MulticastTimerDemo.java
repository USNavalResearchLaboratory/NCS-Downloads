package pai.examples.ns2;

import pai.imp.broker.JavaBroker;
import pai.api.PAIInterface;
import java.net.DatagramPacket;
import pai.net.PAIInetAddress;
import pai.imp.timers.PAITimer;
import pai.imp.Logging;
import pai.imp.event.PAISocketEvent;
import pai.imp.event.PAISocketListener;
import pai.imp.timers.PAITimer;
import pai.imp.timers.PAITimer;
import pai.imp.event.PAISocketEvent;
import pai.imp.event.PAISocketListener;

import pai.net.PAIMulticastSocketImpl;
import pai.net.PAIDatagramPacket;

import java.net.*;
import java.io.IOException;

import agentj.api.AgentJObject;
import agentj.api.AgentJObject;
import agentj.api.AgentJ;
import agentj.imp.agentj.AgentJFactory;

/**
 * @author Ian Taylor.
 * A demo of a NS2 Java Object that
 */
public class MulticastTimerDemo implements AgentJObject, PAISocketListener {
    PAIInterface pai;
    PAIMulticastSocketImpl s;
    PAITimer t;
    int count=0;
    AgentJ agentj;

    public void init() {
        agentj = AgentJFactory.getAgentJ();
        pai = agentj.getPAI();

        try {
            s = new PAIMulticastSocketImpl(5555);
            pai.addPAISocketListener(s,this);
            pai.joinGroup(s, PAIInetAddress.getByName(JavaBroker.getMulticastAddress()));
        } catch (SocketException e) {
            System.out.println("Error opening socket");
        }
        catch (IOException ep) {
            System.out.println("Error opening socket");
        }
    }

    void start() {
   	    timerTriggered();  // transmit first packet right away
        }

    public void dataReceived(PAISocketEvent sv) {
        try {
            System.out.println("Receiving ----------------------------");
            ++count;
            byte b[] = new byte[15];
            PAIDatagramPacket p = new PAIDatagramPacket(b,b.length);
            pai.receive(s, p);
            if (Logging.isEnabled()) {
                System.out.println("PAICommands, node: " + pai.getLocalHost().getHostAddress() + " : Received PACKET NUMBER ----------------> " + count);

                System.out.println("PAICommands: Received " + new String(p.getData()) +
                        " from " + p.getAddress().getHostAddress());
            }
        } catch (IOException ep) {
            System.out.println("PAICommands: Error opening socket");
        }
    }

    public void timerTriggered() {
        try {
                byte b[] = (new String("Hello Proteus " + String.valueOf(count)).getBytes());
                System.out.println("Address is " +  JavaBroker.getMulticastAddress());
                PAIDatagramPacket p =new PAIDatagramPacket(b, b.length,
                            PAIInetAddress.getByName(JavaBroker.getMulticastAddress()), 5555);
                pai.send(s,p);
        }      catch (IOException eh) {
            System.out.println("Error Sending Data");
        }
    }


    public String command(String command, String args[]) {
        if (command.equals("init")) {
            init();
            return "OK";
        }
        else if (command.equals("start")) {
            start();
            return "OK";
        }
       else if (command.equals("trigger")) {
             timerTriggered();
             return "OK";
         }
       else if (command.equals("cleanUp")) {
             pai.cleanUp();
             return "OK";
         }

        return "ERROR";
    }

}
