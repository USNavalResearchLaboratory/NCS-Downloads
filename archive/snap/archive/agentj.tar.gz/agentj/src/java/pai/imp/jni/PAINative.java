package pai.imp.jni;

import java.net.DatagramPacket;

import pai.imp.event.PAITimerListener;
import pai.imp.event.PAITimerEvent;
import pai.api.PAIInterface;
import pai.api.PTIInterface;
import pai.imp.broker.JavaBroker;
import pai.imp.event.PAISocketEvent;
import pai.imp.event.PAISocketListener;
import pai.imp.event.*;
import pai.imp.Logging;
import pai.imp.timers.PAITimer;
import pai.imp.timers.PAITimer;

import java.util.Hashtable;
import java.util.ArrayList;
import java.util.Enumeration;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.net.InetAddress;

import pai.net.PAIDatagramSocketImpl;
import pai.net.*;

import java.io.IOException;

import org.apache.log4j.Logger;

/**
 * @author     Ian Taylor
 * @created    September 5th, 2003
 * @version    $Revision: 1.2 $
 * @date       $Date: 2003/11/06 15:43:47 $ modified by $Author: ian $
 *
 * The PAINative Imp is a native implementation of the Java PAI interface.  This hooks
 * into the native C++ PAI library to provide the necessary functionality of these
 * function calls.  The PAIFactory is used to create an instance of this object when the
 * programmer wishes to use the native implementation.  It is conceivable that
 * a native Java implementation could be implemented also but this is beyond the
 * scope of the current work.         s
 */
public class PAINative implements PAIInterface, PTIInterface {
    static Logger logger = Logger.getLogger(PAINative.class);

    PAIInetAddress address = null;

    public int _port = -1; // set in native code

    public int _objPtr; // the pointer to our JNI C++ JavaEnv object that
    // contains all of the data necessary for the JNI interaction with
    // THIS Java object PAINative and JavaEnv have a one-to-one
    // relationship

    // pointer to the NS2 C++ Java Broker:, the current
    // NS2 agent invoking this class
    public int _brokerPtr;

    // The pointer to the NS2 scheduler...
    public int _schedulerPtr;

    /**
     * An array list of the task's listeners. These have to be static because
     * of the C++ callback issue
     */
    private static ArrayList listeners = new ArrayList();
    private static Hashtable sockets;

    private static ArrayList tlisteners = new ArrayList();
    private static Hashtable timers;

    static {
        logger.info("Entering");
        logger.debug("PAINative: Java library path = " + System.getProperty("java.library.path"));

        System.loadLibrary("agentj");

        logger.debug("PAINative: agentj library loaded successfully");
    }

    /**
     * Constructs and initializes the natove library
     */
    public PAINative() {
        logger.info("Entering");
        sockets = new Hashtable();
        timers = new Hashtable();
        logger.info("Entering");
    }


    // NATIVE FUNCTIONS To C++ PAI Library

    public synchronized native void init();

    public synchronized native int addNativeSocket(int portNumber);

    public synchronized native void removeNativeSocket(int sockID);

    public synchronized native int addListener(int sockID);

    public synchronized native void removeListener(int sockID, int listenerID);

    public synchronized native boolean send(int sockID, String address, int port, byte[] data, int length);

    public synchronized native byte[] recv(int sockID); // receives data - see setDatagramPacketAddress for sender ID

    public synchronized native void setMulticast(int sockID, boolean val);

    public synchronized native void joinGroup(int sockID, String groupAddress);

    public synchronized native void leaveGroup(int sockID, String groupAddress);

    public synchronized native String getNativeLocalHost();

    public synchronized static native String getAddressByName(String name);

    public synchronized native boolean cleanUp();

    public synchronized native boolean runBlock();

    public synchronized native boolean runNonBlock();

    public synchronized native void setReuseAddress(int sock, boolean on);

    public synchronized native void setSendBufferSize(int sock, int size);

    public synchronized native void setReceiveBufferSize(int sock, int size);

    public synchronized native void setSoTimeout(int sock, int timeout);

    public synchronized native int addNativeTimer(double delay, int repeat);

    public synchronized native void removeNativeTimer(int timerID);

    public synchronized native int addPAITimerListener(int timerID);

    public synchronized native void removePAITimerListener(int timerID, int listenerID);

    public synchronized native boolean runTimers();

    /**
     * Sets the pointer to the current NS2 node that is invoking
     * the functions in the native JNI PAI library.  This is
     * set by the JavaBroker for any node that wants
     * to the use the native PAI library. This instance variable
     * is used by some JNI functions that require to gain
     * access to the actual NS2 node instance directly
     * e.g. getLocalAddress and for setting up timers etc.
     *
     * @param nodeID
     */
    public void setNS2Node(String nodeID) {
        logger.info("Entering");
        _brokerPtr = Integer.valueOf(nodeID).intValue();
        logger.info("Exiting");
    }


    public void setNS2Scheduler(String schedulerID) {
        logger.info("Entering");
        _schedulerPtr = Integer.valueOf(schedulerID).intValue();
        logger.info("Exiting");
    }

    /**
     * Adds a PAI Socket listener to this PAI object.
     */
    public void addPAISocketListener(PAIDatagramSocketImpl sock, PAISocketListener listener) {
        logger.info("Entering");

        SListener l = new SListener(sock, listener);

        if (!listeners.contains(l))
            listeners.add(l);

        int sockID = getSocketID(sock);
        l.remoteListenerID = addListener(sockID); // attaches a remote listener to the socket
        logger.info("Exiting");
    }

    /**
     * Removes a PA~I~ Socket listener from this taskgraph.
     */
    public void removePAISocketListener(pai.net.PAIDatagramSocketImpl sock, PAISocketListener listener) {
        logger.info("Entering");

        SListener[] copy = (SListener[]) listeners.toArray(new SListener[listeners.size()]);

        SListener pl = null;
        boolean found = false;

        for (int count = 0; count < copy.length; count++) {
            pl = copy[count];
            if ((pl.sock == sock) && (pl.listener == listener)) {
                found = true;
                break;
            }
        }

        if (found) {
            listeners.remove(pl);
            int sockID = getSocketID(sock);
            if (sockID != -1)
                removeListener(sockID, pl.remoteListenerID); // removes remote listener
        }
        logger.info("Exiting");
    }

    /**
     * Callback function called from C++ library when data has arrived at a UDP socket.
     *
     * Notifies all the socket listeners that data has been received at the sock with the specified ID.
     */
    public synchronized static void dataReceivedAtNativeSocket(int socketID) {
        logger.info("Entering");

        SListener[] copy = (SListener[]) listeners.toArray(new SListener[listeners.size()]);

        PAIDatagramSocketImpl sock = getSocket(socketID);

        // ok must now change the NS2 node ID to the sockets parent ID i.e.
        // the NS2 node that created the socket which generated this callback
        // Therefore, any sockets that are created during this callback will
        // get attached to the correct NS2 node, which enables the getLocalHost
        // to function correctly

        String currentID = pai.imp.broker.JavaBroker.getCurrentNS2Node();
        String thisSocketID = pai.imp.broker.JavaBroker.getNS2NodeforSocket(sock);
        JavaBroker.setCurrentNS2Node(thisSocketID);

        // Just set the global ID for the duration of this callback (and other calls)
        PAISocketEvent event = new PAISocketEvent(sock);

        SListener pl;

        logger.debug("PAINative: notifying Listeners");

        for (int count = 0; count < copy.length; count++) {
            pl = copy[count];
            if (pl.sock == sock) { // just send it to listeners registered for this socket
                pl.listener.dataReceived(event);
            }
        }

        pai.imp.broker.JavaBroker.setCurrentNS2Node(currentID);
        logger.info("Exiting");
    }

    /**
     * Called from native code to set the address of the sender of the UDP packet
     * @param daddress : address set from the C++ code through callback in the
     * recv JNI function.
     */
    public void setDatagramDetails(String daddress) {
        logger.info("Entering");

        try{
            address = PAIInetAddress.getByName(daddress);
        } catch(Exception ee) {
            ee.printStackTrace();
        }
        
        logger.debug("PAINative: setDatagramDetails: Port - " + _port + " address is " + address.getHostName());
        logger.info("Exiting");
    }


    // Helper method to get IDs
    private static int getSocketID(PAIDatagramSocketImpl sock) {
        String val = (String) sockets.get(sock);
        if (val == null) return -1;
        logger.info("Exiting");
        return Integer.parseInt(val);
    }

    // Helper method to get Socket from IDs
    private static PAIDatagramSocketImpl getSocket(int socketID) {
        logger.info("Entering");
        Enumeration keys = sockets.keys();
        Enumeration values = sockets.elements();
        int cur;
        String strInt;
        PAIDatagramSocketImpl sock = null;
        pai.net.PAIDatagramSocketImpl cursock = null;

        do {
            strInt = ((String) values.nextElement());
            if (strInt == null) break; // exit if end of list
            cur = Integer.parseInt(strInt);
            cursock = (PAIDatagramSocketImpl) keys.nextElement();
            if (cur == socketID) // exit if found
                sock = cursock;
        } while (sock == null);

        logger.info("Exiting");
        return sock;
    }

    // From DatagramSocket

    /**
     *  This function opens a native socket for a DatagramSocket.  Java
     * programmers can use DatagramSocket AS IS and still bind to PAI.
     * Fora more "PAI" interface, use addSocket below
     * @param sock
     * @param port
     * @throws java.net.SocketException
     */
    public synchronized void open(PAIDatagramSocketImpl sock, int port) throws SocketException {
        logger.info("Entering");
        // add the socket identifier to the socket hashtable
        int id = addNativeSocket(port);

        // register this socket with the NS2 node it was created for
        // we have to keep this up-to-date especially in the callbacks....

        pai.imp.broker.JavaBroker.registerSocket(sock);

        sockets.put(sock, String.valueOf(id));
        logger.info("Exiting");
    }

    public synchronized pai.net.PAIDatagramSocketImpl addSocket(int port) throws SocketException {
        logger.info("Entering");
        logger.debug("PAINative: addSocket on port " + port);
        return new pai.net.PAIDatagramSocketImpl(port); // this in turn creates the necessary hooks
    }

    public void removeSocket(PAIDatagramSocketImpl sock) throws SocketException {
        logger.info("Entering");

        JavaBroker.unregisterSocket(sock);

        int id = getSocketID(sock);

        removeNativeSocket(id); // native call
        sockets.remove(sock);
        logger.info("Exiting");
    }

    public void close(PAIDatagramSocketImpl sock) {
        logger.info("Entering");
        try {
            removeSocket(sock);

        } catch (SocketException ss) {
        }
        logger.info("Exiting");
    }

    public synchronized void setReuseAddress(PAIDatagramSocketImpl sock, boolean on) throws SocketException {
        logger.info("Entering");
        setReuseAddress(getSocketID(sock), on);
        logger.info("Exiting");
    }

    public synchronized void setSendBufferSize(pai.net.PAIDatagramSocketImpl sock, int size) throws SocketException {
        logger.info("Entering");
        setSendBufferSize(getSocketID(sock), size);
        logger.info("Exiting");
    }

    public synchronized void setReceiveBufferSize(pai.net.PAIDatagramSocketImpl sock, int size) throws SocketException {
        logger.info("Entering");
        setReceiveBufferSize(getSocketID(sock), size);
        logger.info("Exiting");
    }

    public synchronized void setSoTimeout(PAIDatagramSocketImpl sock, int timeout) throws SocketException {
        logger.info("Entering");
        setSoTimeout(getSocketID(sock), timeout);
        logger.info("Exiting");
    }

    public void send(PAIDatagramSocketImpl sock, PAIDatagramPacket p) throws IOException {
        logger.info("Entering");
        logger.debug("PAINative: send, Host Address " + p.getAddress().getHostAddress() +
            "\nPAINative: send, Port " + p.getPort() +
            "\nPAINative: send, Data " + new String(p.getData()) +
            "\nPAINative: send, Data Length " + p.getLength());

        send(getSocketID(sock), p.getAddress().getHostAddress(), p.getPort(), p.getData(), p.getLength());
        logger.info("Exiting");
    }

    public synchronized void receive(pai.net.PAIDatagramSocketImpl sock, PAIDatagramPacket p) throws IOException {
        logger.info("Entering");
        byte data[] = recv(getSocketID(sock));

        logger.debug("PAINative: recv, Host Address " + address.getHostName() +
            "\nPAINative: recv, Port " + _port +
            "\nPAINative: recv, Data " + new String(data) +
            "\nPAINative: recv, Data Length " + data.length);

        if (address != null)
            p.setAddress(address);

        if (data != null) { // data received through C++ callback to receiveData call
            p.setData(data);
            p.setLength(data.length);
        } else
            throw new IOException("Data NULL for Native UDP receive");

        p.setPort(_port);
        logger.info("Exiting");
    }

// From Multicast socket

    public void joinGroup(PAIMulticastSocketImpl sock, PAIInetAddress mcastaddr) throws IOException {
        logger.info("Entering");
        logger.debug("PAINAtive: joingroup, address is " + mcastaddr.getHostName());
        joinGroup(getSocketID(sock), mcastaddr.getHostName());
        logger.info("Exiting");
    }

    public void leaveGroup(PAIMulticastSocketImpl sock, PAIInetAddress mcastaddr) throws IOException {
        logger.info("Entering");
        leaveGroup(getSocketID(sock), mcastaddr.getHostName());
        logger.info("Exiting");
    }

    public void setMulticast(PAIMulticastSocketImpl sock, boolean val) {
        logger.info("Entering");
        setMulticast(getSocketID(sock), val);
        logger.info("Exiting");
    }

    // From InitAddress

    public PAIInetAddress getByName(String host) throws UnknownHostException {
        logger.info("Entering");
        return PAIInetAddress.getByName(getAddressByName(host));
    }

    public PAIInetAddress getLocalHost() {
        logger.info("Entering");

        PAIInetAddress in=null;

        try{
            in=PAIInetAddress.getByName(getNativeLocalHost());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return in;
    }

    class SListener {
        PAIDatagramSocketImpl sock;
        PAISocketListener listener;
        int remoteListenerID;

        SListener(PAIDatagramSocketImpl sock, PAISocketListener listener) {
            logger.info("Entering");
            this.sock = sock;
            this.listener = listener;
            logger.info("Exiting");
        }

        /**
         * Implemented for the contains method in ArrayList ...
         * @param o
         * @return
         */
        public boolean equals(Object o) {
            logger.info("Entering");
            if (!(o instanceof SListener))
                return false;
            SListener l = (SListener) o;
            logger.info("Exiting");
            return l.sock.equals(sock) &&
                    l.listener.equals(listener);
        }
    }

    /**********************************************************************************
     ** TIMER Section
     */

    // Helper method to get IDs
    private static int getTimerID(PAITimer timer) {
        logger.info("Entering");
        String val = (String) timers.get(timer);
        logger.info("Exiting");
        return Integer.parseInt(val);
    }

    // Helper method to get Socket from IDs
    private static PAITimer getTimer(int timerID) {
        logger.info("Entering");
        Enumeration keys = timers.keys();
        Enumeration values = timers.elements();
        int cur;
        String strInt;
        PAITimer timer = null;
        PAITimer curTimer = null;

        do {
            strInt = ((String) values.nextElement());
            if (strInt == null) break; // exit if end of list
            cur = Integer.parseInt(strInt);
            curTimer = (PAITimer) keys.nextElement();
            if (cur == timerID) // exit if found
                timer = curTimer;
        } while (timer == null);

        logger.info("Exiting");
        return timer;
    }

    public PAITimer addTimer(double delay, int repeat) {
        logger.info("Entering");

        int id = addNativeTimer(delay, repeat);
        PAITimer pt = new PAITimer(delay, repeat);
        timers.put(pt, String.valueOf(id));
        logger.info("Exiting");
        return pt;
    }

    public void removeTimer(PAITimer timer) {
        logger.info("Entering");
        removeNativeTimer(getTimerID(timer));
        timers.remove(timer);
        logger.info("Exiting");
    }

    public void addPAITimerListener(PAITimer timer, PAITimerListener listener) {
        logger.info("Entering");

        TListener l = new TListener(timer, listener);

        if (!tlisteners.contains(l)) {
            System.out.println("Adding listener");
            tlisteners.add(l);
        }
        int timerID = getTimerID(timer);
        l.remoteListenerID = addPAITimerListener(timerID); // attaches a remote listener to the socket
        logger.info("Exiting");
    }

    public void removePAITimerListener(PAITimer timer, PAITimerListener listener) {
        logger.info("Entering");

        TListener[] copy = (TListener[]) tlisteners.toArray(new TListener[tlisteners.size()]);

        TListener tl = null;
        boolean found = false;

        for (int count = 0; count < copy.length; count++) {
            tl = copy[count];
            if ((tl.timer == timer) && (tl.listener == listener)) {
                found = true;
                break;
            }
        }

        if (found) {
            tlisteners.remove(tl);
            int timerID = getTimerID(timer);
            removePAITimerListener(timerID, tl.remoteListenerID); // removes remote listener
        }
        logger.info("Exiting");
    }

    /**
     * Callback function called from C++ library when data has arrived at a UDP socket.
     *
     * Notifies all the socket listeners that data has been received at the sock with the specified ID.
     */
    public synchronized static void triggerReceived(int timerID) {
        logger.info("Entering");

        TListener[] copy = (TListener[]) tlisteners.toArray(new TListener[tlisteners.size()]);

        PAITimer timer = getTimer(timerID);

        PAITimerEvent event = new PAITimerEvent(timer);

        TListener tl;

        for (int count = 0; count < copy.length; count++) {
            tl = copy[count];
            if (tl.timer == timer) // just send it to listeners registered for this socket
                tl.listener.timerTriggered(event);
        }
        logger.info("Exiting");
    }

    class TListener {
        PAITimer timer;
        PAITimerListener listener;
        int remoteListenerID;

        TListener(PAITimer timer, PAITimerListener listener) {
            logger.info("Entering");
            this.timer = timer;
            this.listener = listener;
            logger.info("Exiting");
        }

        /**
         * Implemented for the contains method in ArrayList ...
         * @param o
         * @return
         */
        public boolean equals(Object o) {
            logger.info("Entering");
            if (!(o instanceof SListener))
                return false;
            SListener l = (SListener) o;
            logger.info("Exiting");
            return l.sock.equals(timer) &&
                    l.listener.equals(listener);
        }
    }
}

