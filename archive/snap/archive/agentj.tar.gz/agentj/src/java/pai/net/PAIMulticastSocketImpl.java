package pai.net;

import org.apache.log4j.Logger;

import java.io.IOException;
import java.net.SocketException;


/**
 * The multicast datagram socket class is useful for sending
 * and receiving IP multicast packets.  A MulticastSocket is
 * a (UDP) DatagramSocket, with additional capabilities for
 * joining "groups" of other multicast hosts on the internet.
 * <P>
 * A multicast group is specified by a class D IP address
 * and by a standard UDP port number. Class D IP addresses
 * are in the range <CODE>224.0.0.0</CODE> to <CODE>239.255.255.255</CODE>,
 * inclusive. The address 224.0.0.0 is reserved and should not be used.
 * <P>
 * One would join a multicast group by first creating a MulticastSocket
 * with the desired port, then invoking the
 * <CODE>joinGroup(InetAddress groupAddr)</CODE>
 * method:
 * <PRE>
 * // join a Multicast group and send the group salutations
 * ...
 * String msg = "Hello";
 * InetAddress group = InetAddress.getByName("228.5.6.7");
 * MulticastSocket s = new MulticastSocket(6789);
 * s.joinGroup(group);
 * DatagramPacket hi = new DatagramPacket(msg.getBytes(), msg.length(),
 *                             group, 6789);
 * s.send(hi);
 * // get their responses!
 * byte[] buf = new byte[1000];
 * DatagramPacket recv = new DatagramPacket(buf, buf.length);
 * s.receive(recv);
 * ...
 * // OK, I'm done talking - leave the group...
 * s.leaveGroup(group);
 * </PRE>
 */
public class PAIMulticastSocketImpl extends pai.net.PAIDatagramSocketImpl {
    static Logger logger = Logger.getLogger(PAIMulticastSocketImpl.class);

    /**
     * Create a multicast socket and bind it to a specific port.
     * 
     * @param port port to use
     * @exception java.io.IOException if an I/O exception occurs
     * while creating the MulticastSocket
     */
    public PAIMulticastSocketImpl(int port) throws IOException {
        super(port);
    }


    /**
     * Joins a multicast group. Its behavior may be affected by
     * <code>setInterface</code> or <code>setNetworkInterface</code>.
     *
     * @param mcastaddr is the multicast address to join
     * 
     * @exception IOException if there is an error joining
     * or when the address is not a multicast address.
     */
    public void joinGroup(PAIInetAddress mcastaddr) throws IOException {
        logger.info("Entering");
        if (isClosed()) {
            throw new SocketException("Socket is closed");
        }

        // needed to put this here - where else - in the constructor
        // the socket has NOT been added to the list yet ...
        pai.setMulticast(this,true);
        pai.joinGroup(this,mcastaddr);
        logger.info("Exiting");        
    }

    /**
     * Leave a multicast group.
     *
     * @param mcastaddr is the multicast address to leave
     * @exception IOException if there is an error leaving
     * or when the address is not a multicast address.
     *
     */
    public void leaveGroup(PAIInetAddress mcastaddr) throws IOException {
        logger.info("Entering");
        if (isClosed()) {
            throw new SocketException("Socket is closed");
        }
        pai.leaveGroup(this, mcastaddr);
        logger.info("Exiting");
    }
}
