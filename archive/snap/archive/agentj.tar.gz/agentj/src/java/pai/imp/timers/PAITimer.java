package pai.imp.timers;

import org.apache.log4j.Logger;

/**
 * Created by IntelliJ IDEA.
 * User: Ian
 * Date: Nov 6, 2003
 * Time: 1:40:00 PM
 * To change this template use Options | File Templates.
 */
public class PAITimer {
    static Logger logger = Logger.getLogger(PAITimer.class);
    double delay;
    int repeat;

    public PAITimer(double delay, int repeat) {
        logger.info("Entering");
        setDelay(delay);
        setRepeat(repeat);
        logger.info("Exiting");

    }

    public void setDelay(double delay) {
        this.delay=delay;
    }

    public void setRepeat(int repeat) {
        this.repeat=repeat;
    }

    public double getDelay() {
        return delay;
    }

    public double getRepeat() {
        return repeat;
    }
}
