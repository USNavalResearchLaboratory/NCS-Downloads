package pai.examples.javaPAI;

import pai.net.PAIDatagramSocketImpl;
import java.net.DatagramPacket;
import pai.net.PAIInetAddress;
import pai.imp.event.PAISocketListener;
import pai.imp.event.PAISocketEvent;
import pai.imp.event.PAISocketListener;
import pai.api.PAIInterface;
import pai.imp.jni.PAIFactory;
import pai.imp.jni.PAIFactory;

import java.net.SocketException;
import java.net.UnknownHostException;
import java.net.InetAddress;

import pai.net.PAIDatagramSocketImpl;
import pai.net.PAIDatagramPacket;

import java.io.IOException;

/**
 * A simple example that kicks off the Protolib scheduler and then
 * sends 10 messages to port 6666 on the destination machine (i.e.
 * this machine).  The messages
 * @author     Ian Taylor
 * @created    September 5th, 2003
 * @version    $Revision: 1.1 $
 * @date       $Date: 2003/11/06 15:43:47 $ modified by $Author: ian $
 */
public class JavaPAINativeScheduler implements PAISocketListener {
    PAIInterface pai;
    pai.net.PAIDatagramSocketImpl s;
    pai.net.PAIDatagramSocketImpl s1;
    int runs=10;

    public JavaPAINativeScheduler() {
        pai = PAIFactory.getNativePAIObj();
        try {
            s = pai.addSocket(5555);
            s1 = pai.addSocket(6666);
            pai.addPAISocketListener(s1,this);

            pai.runNonBlock(); // kick off remote dispatcher in background ....
        } catch (SocketException e) {
            System.out.println("Error opening socket");
        }
        catch (IOException ep) {
            System.out.println("Error opening socket");
        }

        try {
            for (int i=0; i<runs; ++i) {
                byte b[] = (new String("Hello Proteus " + String.valueOf(i)).getBytes());
                PAIDatagramPacket p =new PAIDatagramPacket(b, b.length, PAIInetAddress.getByName("127.0.0.1"), 6666);
                System.out.println("Sending " + new String(b));
                pai.send(s,p);
                try {
                    Thread.sleep(2000);
                } catch(InterruptedException ee) {
                }
            }
        }      catch (IOException eh) {
            System.out.println("Error Sending Data");
        }
    pai.cleanUp();
    }

    public void dataReceived(PAISocketEvent s) {
        try {
            byte b[] = new byte[13];
            PAIDatagramPacket p = new PAIDatagramPacket(b,b.length);
            pai.receive(s1, p);
            System.out.println("Received " + new String(p.getData()) +
                " from " + p.getAddress().getHostAddress());
        } catch (IOException ep) {
            System.out.println("Error opening socket");
        }
    }

    public static void main(String[] args) throws Exception {
        new JavaPAINativeScheduler();
    }
}

