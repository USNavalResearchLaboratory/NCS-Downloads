package pai.imp.event;

import pai.imp.event.PAITimerEvent;

/**
 * An interface implemented by classes that want to receive socket events.
 *
 * @author      Ian Taylor
 * @created     8th September 2003
 * @version     $Revision: 1.1 $
 * @date        $Date: 2003/09/11 22:39:13 $ modified by $Author: ian $
 */
public interface PAITimerListener {

    /**
     * Socket Received Data
     */
    public void timerTriggered(PAITimerEvent event);
}
