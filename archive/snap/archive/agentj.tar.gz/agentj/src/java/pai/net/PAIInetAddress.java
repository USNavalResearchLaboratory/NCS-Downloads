package pai.net;

import pai.api.PAIInterface;
import pai.imp.jni.PAIFactory;

import java.net.*;

import org.apache.log4j.Logger;


/**
 * This class represents an Internet Protocol (IP) address.
 *
 * Be nice to get this to
 */
public class PAIInetAddress implements java.io.Serializable {

    static Logger logger = Logger.getLogger(PAIInetAddress.class);

    static PAIInterface pai = PAIFactory.getNativePAIObj();


    String hostName;


    public String getHostName() {
        return hostName;
    }

    public String getHostAddress() {
        return hostName;
    }


    /**
     * Determines the IP address of a host, given the host's name.
     *
     * <p> The host name can either be a machine name, such as
     * "<code>java.sun.com</code>", or a textual representation of its
     * IP address. If a literal IP address is supplied, only the
     * validity of the address format is checked.
     *
     *
     * @param      host   the specified host, or <code>null</code>.
     * @return     an IP address for the given host name.
     * @exception  java.net.UnknownHostException  if no IP address for the
     *               <code>host</code> could be found.
     */
    public static PAIInetAddress getByName(String host) throws UnknownHostException {
         logger.info("Entering");

        PAIInetAddress pai = new PAIInetAddress();

        pai.hostName=host;

        return pai;

        // disabled this for now ->  in NS2 WE ARE NOT INTERESTED IN NAMES...�
        //pai.getByName(host);
    }


    /**
     * Returns the local host.
     *
     * @return     the IP address of the local host.
     */
    public static PAIInetAddress getLocalHost() throws UnknownHostException {
        logger.info("Entering");
        return pai.getLocalHost();
    }
}

