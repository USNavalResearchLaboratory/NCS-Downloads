package pai.examples.ns2;

import pai.imp.broker.JavaBroker;
import pai.api.PAIInterface;
import java.net.DatagramPacket;
import pai.net.PAIInetAddress;
import pai.imp.timers.PAITimer;
import pai.imp.Logging;
import pai.imp.timers.PAITimer;
import pai.imp.event.PAISocketEvent;
import pai.imp.event.PAISocketEvent;
import pai.imp.event.PAISocketListener;
import pai.imp.event.PAISocketListener;

import pai.net.PAIDatagramSocketImpl;
import pai.net.PAIMulticastSocketImpl;
import pai.net.PAIDatagramPacket;

import java.net.*;
import java.io.IOException;

import agentj.api.AgentJObject;
import agentj.api.AgentJObject;
import agentj.api.AgentJ;
import agentj.imp.agentj.AgentJFactory;

/**
 * @author Ian Taylor.
 * A demo of a NS2 Java Object that
 */
public class MultiSocketDemo implements AgentJObject, PAISocketListener {
    PAIInterface pai;
    PAIMulticastSocketImpl s;
    pai.net.PAIDatagramSocketImpl s1;
    PAITimer t;
    int count=0;
    String addr;
    AgentJ agentj;

    public void init() {
        agentj = AgentJFactory.getAgentJ();
        pai = agentj.getPAI();

        addr = pai.getLocalHost().getHostAddress();

        try {
            s1 = new PAIDatagramSocketImpl(5555);
            pai.addPAISocketListener(s1,this);
            s = new PAIMulticastSocketImpl(5555);
            pai.addPAISocketListener(s,this);
            pai.joinGroup(s, PAIInetAddress.getByName(JavaBroker.getMulticastAddress()));
        } catch (SocketException e) {
            System.out.println("Error opening socket");
        }
        catch (IOException ep) {
            System.out.println("Error opening socket");
        }
    }

    void start() {
   	    timerTriggered();  // transmit first packet right away
        }

    public void dataReceived(PAISocketEvent sv) {
        try {
            System.out.println("Receiving ----------------------------");
            ++count;
            byte b[] = new byte[1000];
            PAIDatagramPacket p = new PAIDatagramPacket(b,b.length);
            pai.receive(s, p);
            if (Logging.isEnabled()) {
                System.out.println("PAICommands, node: " + addr + " : Received PACKET NUMBER ----------------> " + count);

                System.out.println("PAICommands: Received " + new String(p.getData()) +
                        " from " + p.getAddress().getHostAddress());
            }
        } catch (IOException ep) {
            System.out.println("PAICommands: Error opening socket");
        }
    }

    public void timerTriggered() {
        try {
                String txt = "dddd~3<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                     "<EndpointResolverAdvertisement>\n"
     + "<advertId>127.0.0.1-1082049068648-786628495</advertId>"
     + "    <peerId>127.0.0.1-1082049068511-439024402</peerId>"
     + "    <endpointAddress>"
     + "        <address>0:2223</address>"
     + "        <endpointType>unicast</endpointType>"
     + "        <transportProtocol>UDP</transportProtocol>"
     + "    </endpointAddress>"
     + "    <resolverPipeTypes>standard</resolverPipeTypes>"
     + "    <resolverPipeTypes>discovery</resolverPipeTypes>"
     + "    <resolverForPeerID>127.0.0.1-1082049068511-439024402</resolverForPeerID>"
     + "    <transportProtocol>UDP</transportProtocol>"
     + "</EndpointResolverAdvertisement>";

                String txt2 = "954839000000000000000009999995483900000000000000000999999548390000000000000000099999954839000000000000000009999995483900000000000000000999999548390000000000000000099999954839000000000000000009999995483900000000000000000999999548390000000000000000099999954839000000000000000009999995483900000000000000000999999548390000000000000000099999954839000000000000000009999995483900000000000000000999999548390000000000000000099999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999";
                byte b[] = (txt.getBytes());
                System.out.println("Address is " +  JavaBroker.getMulticastAddress());
                PAIDatagramPacket p =new PAIDatagramPacket(b, b.length,
                            PAIInetAddress.getByName(JavaBroker.getMulticastAddress()), 5555);
                pai.send(s,p);
                b = (new String("Hello Proteus " + String.valueOf(count)).getBytes());
                System.out.println("Address is " +  JavaBroker.getMulticastAddress());
                p =new PAIDatagramPacket(b, b.length,
                         PAIInetAddress.getByName("1"), 5555);
            pai.send(s,p);
        }      catch (IOException eh) {
            System.out.println("Error Sending Data");
        }
    }


    public String command(String command, String args[]) {
        if (command.equals("init")) {
            init();
            return "OK";
        }
        else if (command.equals("start")) {
            start();
            return "OK";
        }
       else if (command.equals("trigger")) {
             timerTriggered();
             return "OK";
         }
       else if (command.equals("cleanUp")) {
             pai.cleanUp();
             return "OK";
         }

        return "ERROR";
    }
}
