package agentj.imp.agentj;

import agentj.api.AgentJObject;
import agentj.api.AgentJ;
import org.apache.log4j.Logger;

/**
 * Created by IntelliJ IDEA.
 * User: scmijt
 * Date: Jun 28, 2004
 * Time: 2:23:49 PM
 * To change this template use File | Settings | File Templates.
 */
public class AgentJFactory {

    static Logger logger = Logger.getLogger(AgentJFactory.class);

        private static AgentJImp aimp =null;

        /**
         * AgentJ is an interface for the AgentJ objects to use
         * to find out specific information from Ns2
         *
         * @return the AgentJ instance
         */
        public static final AgentJ getAgentJ() {
            logger.info("Entering");
            if (aimp==null)
                aimp = new AgentJImp();
            logger.info("Exiting");
            return (AgentJ)aimp;
        }
}
