package agentj.imp.agentj;

import agentj.api.AgentJ;
import agentj.api.NS2NodeAddressException;
import pai.api.PAIInterface;
import pai.imp.broker.JavaBroker;
import pai.imp.jni.PAIFactory;
import org.apache.log4j.Logger;

/**
 * Created by IntelliJ IDEA.
 * User: scmijt
 * Date: Jun 28, 2004
 * Time: 1:48:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class AgentJImp implements AgentJ {
    static Logger logger = Logger.getLogger(AgentJImp.class);

    /**
     *
     * @return the NS2 group address that can be used for multicast
     * communications
     *
     */
    public String getMulticastAddress() {
        return pai.imp.broker.JavaBroker.getMulticastAddress();
    }

    /**
     * @return the ID of the node that is currently in focus.  And
     * because NS2 is singlethreaded, the node that is in focus
     * IS THE NODE that called this function !  Therefore, this
     * function call gets the correct NS2 node ID of the calling
     * node.
     */
    public int getID() throws NS2NodeAddressException {
        logger.info("Entering");

        String address = getPAI().getLocalHost().getHostAddress();
        int id=-1;

        try {
            id = Integer.valueOf(address).intValue();
        } catch(Exception ee) {
            throw new NS2NodeAddressException(address);
        }
        logger.info("Exiting");
        return id;
    }

    /**
     *
     * The PAI interface is the Java interface to the underlying
     * PAI C++ code, which can be used to interact with Protolib
     * and NS2 directly. Normally, you would use the native
     * Java interfaces to create sockets etc instead of using PAI
     * but if you want to use this interface directly, then
     * use this method to obtain your reference.
     *
     */
    public PAIInterface getPAI() {
        logger.info("Entering");
        return PAIFactory.getNativePAIObj();
    }
}
