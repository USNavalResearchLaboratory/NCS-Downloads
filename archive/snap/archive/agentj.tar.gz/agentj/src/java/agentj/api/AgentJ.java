package agentj.api;

import pai.api.PAIInterface;

/**
 * AgentJ interface is an interface to that any AgentJ object can use
 * to get certain information that they may require from the
 * AgentJ subsystem. For example, you can get the NS2 node ID
 * associated with your node.
 *
 * Created by IntelliJ IDEA.
 * User: scmijt
 * Date: Jun 28, 2004
 * Time: 1:43:57 PM
 * To change this template use File | Settings | File Templates.
 */
public interface AgentJ {

    /**
     *
     * @return the NS2 group address that can be used for multicast
     * communications
     *
     */
    public String getMulticastAddress();

    /**
     * @return the ID of the node that is currently in focus.  And
     * because NS2 is singlethreaded, the node that is in focus
     * IS THE NODE that called this function !  Therefore, this
     * function call gets the correct NS2 node ID of the calling
     * node.
     */
    public int getID() throws NS2NodeAddressException;

    /**
     *
     * The PAI interface is the Java interface to the underlying
     * PAI C++ code, which can be used to interact with Protolib
     * and NS2 directly. Normally, you would use the native
     * Java interfaces to create sockets etc instead of using PAI
     * but if you want to use this interface directly, then
     * use this method to obtain your reference.
     *
     */
    public PAIInterface getPAI();
}
