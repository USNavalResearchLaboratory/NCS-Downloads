package agentj.api;

/**
 * Created by Ian Taylor.
 * User: scmijt
 * Date: Jun 28, 2004
 * Time: 3:02:54 PM
 * To change this template use File | Settings | File Templates.
 */
public class NS2NodeAddressException extends RuntimeException {

    String nodeAddress;

    public NS2NodeAddressException(String nodeAddress) {
        this.nodeAddress=nodeAddress;
    }

    /**
     *
     * @return the exception
     */
    public String toString() {
         return "Invalid node address: " + nodeAddress + " :valid NS2 addresses must be integers";
    }

}
