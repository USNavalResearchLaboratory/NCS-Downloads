package agentj.imp.broker;

import pai.api.PAIInterface;
import pai.imp.jni.PAIFactory;
import agentj.imp.util.StringSplitter;
import pai.imp.Logging;
import pai.net.PAIDatagramSocketImpl;

import java.util.Hashtable;

import agentj.api.AgentJObject;
import agentj.api.AgentJObject;
import agentj.imp.util.StringSplitter;
import org.apache.log4j.Logger;

/**
 * This is a broker class for creating Java objects and associating
 * then to ID's.  Typically, this is used by the NS-2 PAI
 * implementation and therefore the ID's are pointers to the
 * NS2 nodes that the Java objects are attached to. Therefore
 * the useful brokering functionality is when this class is extended
 * to include the PAI objects that can actually create sockets
 * and communicate with other NS2 nodes.
 *
 * @see pai.imp.broker.JavaBroker
 * 
 * User: scmijt
 * Date: Mar 26, 2004
 * Time: 4:16:44 PM
 * To change this template use Options | File Templates.
 */
public class JavaBasicBroker {

    static Logger logger = Logger.getLogger(JavaBasicBroker.class);

    public static final int ERROR = 0;
    public static final int OK = 1;

    protected static Hashtable objects;

    protected static String delimiter = " "; // set delimiter to space by default


    static {
        objects = new Hashtable();
    }


    /**
     * Creates a Java object from the given class name and adds it to an internal
     * Hashtable, registering as an object that can be accessed via the JavaBroker
     * Class.  The id value is the actuaal C++ pointer to the Agent class, which is
     * guarenteed to be unique for the agents.  This implies that there is
     * a necessary restriction of only allowing one Java class to be triggered
     * by a NS2 Agent.
     *
     * @param args: arg[0] = the java class name and arg[1] is its id (i.e. the
     * pointer to the NS2 agent
     * @return
     */
    public static int register(String[] args) {
        logger.info("Entering");

        Class c = null;
        String javaClass = args[0];
        String id = args[1];

        try {
            c = Class.forName(javaClass);
        } catch (java.lang.ClassNotFoundException cnf) {
            System.err.println("JavaBroker.java:  Class " + javaClass + " NOT FOUND");
            System.err.println("TIP: Check the your classpath and name of class");
            System.err.println("TIP: Check you have inclued the correct Java package");
            return ERROR;
        }

        AgentJObject obj = null;

        try {
            obj = (AgentJObject) c.newInstance();
        } catch (java.lang.InstantiationException ie) {
            System.err.println("JavaBroker.java:  Class " + javaClass + " could not be instantiated");
            System.err.println("TIP: Does it implement the CommandInterface ?");
            return ERROR;
        } catch (java.lang.IllegalAccessException iae) {
            System.err.println("JavaBroker.java:  Class " + javaClass + " threw an illegal Access Exception");
            System.err.println("TIP: is the class public ?");
            return ERROR;
        }

        if (Logging.isEnabled())
            System.out.println("JavaBroker.java: Classname: " + javaClass);

        objects.put(id, obj);

        logger.info("Exiting");
        return OK;
    }



    /**
     * invokes the command, which the given arguments on the object identified by the
     * supplied identifier
     *
     * @param args: args[0] = id; args[1]= the command to be performed and
     * args[2] is the arguments for that command.
     * @return
     */
    public static String invokeCommand(String args[]) {
        logger.info("Entering");

        String id = args[0];
        String command = args[1];
        String progArgs = args[2];

        AgentJObject obj = null;

        obj = (AgentJObject) objects.get(id); // gets the Java object to
        // issue command with

        if (obj == null) return null; // not a valid object - this is a core problem
        // with the underlying code and should NOT HAPPEN

        if (command.equals("setDelimiter")) { // special case
            delimiter = progArgs;
            return "OK";
        }


        String[] delims = new String[1];
        delims[0] = delimiter;

        StringSplitter s = new StringSplitter(progArgs, delims);

        String[] splitArgs = new String[s.size()];

        for (int i = 0; i < s.size(); ++i)
            splitArgs[i] = s.at(i);


        logger.info("Exiting");
        return obj.command(command, splitArgs); // invoke the command on the given object
    }

    /**
     * Unregisters the given Java object and frees the reference
     *
     * @param id
     * @return
     */
    public static int unregister(String id) {
        logger.info("Entering");

        if (objects.remove(id) == null)
            return ERROR; // Not able to remove this object - already deleted perhaps ?

        logger.info("Exiting");
        return OK;
    }

    /**
     * Clears the hashtable and unreferences all of the objects
     */
    public static void cleanUp() {
        logger.info("Entering");
        objects.clear();
        logger.info("Exiting");
    }

}
