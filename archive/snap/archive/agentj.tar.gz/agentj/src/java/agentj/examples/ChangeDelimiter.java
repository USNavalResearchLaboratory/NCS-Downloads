package agentj.examples;

import agentj.api.AgentJObject;
import agentj.api.AgentJObject;

/**
 * Created by IntelliJ IDEA.
 * User: scmijt
 * Date: Mar 26, 2004
 * Time: 4:48:44 PM
 * To change this template use Options | File Templates.
 */
public class ChangeDelimiter implements AgentJObject {

    static int count=0;

    int myID;

    public ChangeDelimiter() {
        ++count;
        myID=count;
    }

    public String command(String command, String args[]) {

        if (command.equals("hello")) {
            System.out.println("SimpleCommand(" + myID + ") has "
                    + args.length + " arguments");
            for (int i=0; i<args.length; ++i) {
                System.out.println("Arg[" + i + "] = " + args[i]);
            }
        }

        return "All called ok from node " + myID;
    }
}
