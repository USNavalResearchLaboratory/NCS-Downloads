package agentj.api;

/**
 * AgentJObject is a AgentJ's interface to your Java object
 * being broker. AjentJObject therefore contains methods
 * that need to be able to be called on your Java object.
 * This interface therefore MUST be implemented by any
 * Java object wishiing to be used within AgentJ.
 *
 * @author Ian Taylor
 * User: scmijt
 * Date: Mar 26, 2004
 * Time: 4:30:15 PM
 */
public interface AgentJObject {

    /**
     * Enables commands invoked in NS2 scripts to be passed along
     * to your Java object. The 'command' is the name of the
     * command and the 'args' are the arguments for the command
     *
     * @param command
     * @param args
     * @return
     */
    public String command(String command, String args[]);
}
