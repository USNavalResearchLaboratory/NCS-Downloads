package pai.imp;

/**
 * @author Ian Taylor
 *
 * Simple loggin facility for enabling STD output or not. Interfaced
 * through a method so we could change method at a later stage here
 * and not affect the implementation.
 *
 */
public class Logging {
    static boolean logging=true;


    public static boolean isEnabled() {
        return logging;
    }

    public static void setEnabled(boolean state) {
        logging=state;
    }

}
