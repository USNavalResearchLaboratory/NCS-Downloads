#include "PAISimpleAgent.h"
#include <iostream.h>

static class PAISimpleAgentExampleClass : public TclClass
{
	public:
		PAISimpleAgentExampleClass() : TclClass("Agent/PAISimpleAgent") {}
	 	TclObject *create(int argc, const char*const* argv) {
			cout << "creating PAISimpleAgent .... " << endl;
			return (new PAISimpleAgent());
			}
} class_protean_example;

PAISimpleAgent::PAISimpleAgent() {
	timestep=0;
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAISimpleAgent: created PAISimpleAgent " << endl;

	pai.setDispatcher(static_cast<ProtoSim*>(this));

	pti = pai.getPTI(); // get the timing library
	pci = pai.getPCI(); // get the socket library
 
	// printf("local Host is %s\n", pci->getLocalHost());
//	printf("Host teaspoon is %s\n", pci->getAddressByName("teaspoon"));
}

void PAISimpleAgent::start() {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAISimpleAgent: start " << endl;
	CallbackFunc timerCallback = (CallbackFunc)&PAISimpleAgent::OnTxTimeout;
	PAIOwner *owner = (PAIOwner *)this;

	timer = pti->addTimer(1.0, -1);

	pti->addListener(timer, owner, timerCallback); // set timer off
	// getchar();
	}

bool PAISimpleAgent::OnTxTimeout() {
	char* buf;
	unsigned int len = strlen(buffer) + 1;

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAISimpleAgent: TxTimerout " << endl;

    buf = new char[len];
	strcpy(buf, buffer);
	
	pci->send(sock, sendTo, buf, len);
	
	delete buf;
	return true;
} 

bool PAISimpleAgent::OnSocketRecv() {
	char *buf;
	PAIInetAddress *address;
	unsigned int len=512;

    address = new PAIInetAddress();

    if (PAIEnvironment::getEnvironment()->isVerbose())
	    cout << "PAISimpleAgent: Data about to receive...." << endl;

	buf = pci->recv(sock, &address, &len);
	
//	cout << "Data Received...." << endl;

	if (PAIEnvironment::getEnvironment()->isVerbose())
		printf("%i...Received %s from %s, port %i \n", ++timestep, buf, address->getAddress(), address->getPort());

    delete address;
	
	delete buf;
	return true;
}

PAISimpleAgent::~PAISimpleAgent()
{
}

int PAISimpleAgent::command(int argc, const char*const* argv) {

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAISimpleAgent: Command: .... " << argv[1] << " : parameters = " <<  argc << endl;

    if (3 == argc) { // open socket
        if (!strcmp(argv[1], "open")) {
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAISimpleAgent: open: on port " << argv[2] << endl;
		    sock = pci->addSocket(atoi(argv[2]));
			CallbackFunc socketCallback = (CallbackFunc)&PAISimpleAgent::OnSocketRecv;
			PAIOwner *owner = (PAIOwner *)this;
			pci->addListener(sock, owner, socketCallback);
            return TCL_OK;
		}
        else if (!strcmp(argv[1], "joinGroup")) { // <groupAddr>
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAISimpleAgent: joinGroup: on address " << argv[2] << endl;
			pci->joinGroup(sock, argv[2]);
            return TCL_OK;
        }
		else if (!strcmp(argv[1], "send")) {
		    buffer = new char[strlen(argv[2])];
			strcpy(buffer, argv[2]);
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAISimpleAgent: sending: " << buffer << endl;
            OnTxTimeout();  // transmit first packet right away
            return TCL_OK; 
        }

	}	
    else if (4 == argc) {
        if (!strcmp(argv[1], "setSendTo")) {
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAISimpleAgent: sendto: " << argv[2] << " on port " << argv[3] << endl;
			sendTo = new PAIInetAddress(argv[2], atoi(argv[3]));
            return TCL_OK;
			}
    }		
        if (2 == argc) {
		if (!strcmp(argv[1], "start")) {
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAISimpleAgent: start: " << endl;
			start();
            return TCL_OK; 
        }
		else if (!strcmp(argv[1], "send")) {
		    buffer = new char[17];
			strcpy(buffer, "Hello PAI Node!!");
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAISimpleAgent: sending: " << buffer << endl;
            OnTxTimeout();  // transmit first packet right away
            return TCL_OK; 
        }
		else if (!strcmp(argv[1], "stopTimer")) {
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAISimpleAgent: PTI Stopping Timer..." << endl;
			pti->removeTimer(timer);
			return TCL_OK;
		}
		else if (!strcmp(argv[1], "cleanUp")) {
			pai.cleanUp();
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAISimpleAgent: PAI Stopped..." << endl;
			return TCL_OK;
		}
	}

    return NsProtoAgent::command(argc, argv);
}  // end PAISimpleAgent::command()



