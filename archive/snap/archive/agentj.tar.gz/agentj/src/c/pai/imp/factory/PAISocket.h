#ifndef _PAISocket
#define _PAISocket

#include "PAIMultipleListener.h"
#include "PAIDispatcher.h"
#include "PAIInetAddress.h"

/**
 * A PAI Socket: There are different implementations depending on what type of socket
 * we are dealing with i.e. UDP or TCP etc.  One implementation exits - UDPSocket which
 * binds this to the Protolib UDP implementation
 */
class PAISocket : public PAIMultipleListener {
	public:		
		/**
		 * Sets the length of the receive buffer and allocates the memory
		 */
		PAISocket(PAIEnvironment *penv, PAIDispatcher *eventDispatcher);

		~PAISocket();

		/**
		 * On my Java hobby horse again ..  This sets a listener for events from this socket.
		 * A listener is an object that wants to be notified when something happens e.g.
		 * in this case a "data received" event from the socket.  This is implemented
		 * using C++ callback functions.
		 *
		 * This function adds a listener to this socket and returns the listener object
		 * that is used to represent this listener i.e. it contains the callback pointers
		 * and has a machanism for instigating a callback.
		 */
		virtual PAISocketListener* addListener(PAIOwner *callingClass, CallbackFunc socketListener);

		/**
		 *
		 * Removes the specified listener from this socket 
		 */
		virtual bool removeListener(PAISocketListener* listener);


		/**
		 * @return the port this socket talks to 
		 */
		unsigned int getPort();

		/**
		 * Sets the port this socket talks to - every socket implementation has to
		 * have a port
		 */
		void setPort(unsigned int portNumber);

		void setSocketBufferLength(unsigned int length) { socketBufferLength=length; }

		unsigned int getSocketBufferLength() { return socketBufferLength; }

		/**
		 * generalized sending routine .... the = 0 makes it act like a Java
		 * interface 8^)  i.e. subclasses HAVE to implement this function
		 */
		virtual bool send(const PAIInetAddress *address, const char *data, unsigned int length)=0;

		/**
		 * generalized receiving routine ....
		 */
		virtual char *recv(PAIInetAddress **address, unsigned int *length)=0;


		/**
		 * Virtual function: MUST be implemented in classes inherited from
		 * this.  PAI allows for multicast, but really multicast is only
		 * support from vertain sockets.  This must be implemented to state
		 * whether your socket supports multicast or not. You should throw
		 * an error if not.
		 */
		virtual void setMulticast(bool val)=0;

		/**
		 * Virtual function: MUST be implemented in classes inherited from
		 * this.  see enableMutlicast above
		 */
		virtual void joinGroup(const char* groupAddress)=0;
		
		/**
		 * Virtual function: MUST be implemented in classes inherited from
		 * this.  see enableMutlicast above
		 */
		virtual void leaveGroup(const char* groupAddress)=0;

		virtual void setReuseAddress(bool on)=0;
		
		virtual void setSendBufferSize(int size)=0;
		
		virtual void setReceiveBufferSize(int size)=0;
		
		virtual void setSoTimeout(int timeout)=0;
		
    private:		

		PAIEnvironment *env;
		unsigned int port;

		// this is the particular event dispatcher you want to use to
		// generate the events.  For the protolib classes, this will be dispatcher
		PAIDispatcher *edispatcher;
		unsigned int socketBufferLength;
	protected:
		
		PAIDispatcher *getEventDispatcher();

		// general purpose address reusable buffer

		char addressBuf[512];
		char *socketBuffer; // buffer for incoming data

}; // end class PCISocket

#endif // _PAISocket
