#include "PAIMultipleListener.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>

PAIMultipleListener::PAIMultipleListener(const char *objectString) { 
	objectName=objectString;
	}

PAIMultipleListener::~PAIMultipleListener() { }


PAIListener* PAIMultipleListener::addListener(PAIOwner *callingClass, CallbackFunc listenerFunction) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "MultipleListtener: Adding listener" << endl;
	PAIListener *psl = new PAIListener(this,callingClass,listenerFunction);
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "MultipleListtener: created PAIListener object" << endl;
	ListItem *l = listeners.addItem(psl);
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "MultipleListtener: added listener to the list" << endl;
	return psl;
}

bool PAIMultipleListener::removeListener(PAIListener* listener) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "MultipleListtener: Removing listener" << endl;
	delete listener; // delete is and keep proper typing...
    return listeners.removeItem(listener); // this deletes it also
}

void PAIMultipleListener::deleteListeners() {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "MultipleListtener: Removing all listeners" << endl;
		
		listeners.rewind();
		
	    PAIListener* listener = (PAIListener*)listeners.getCurrentItem();
		
		if (listener==NULL) return;
		
		cout << "MultipleListtener: found and deleted 1 listener" << endl;

		delete listener;
		
		while ( (listener = (PAIListener*)listeners.getNextItem()) != NULL) { 	
   		    cout << "MultipleListtener: found another" << endl;
		    delete listener;
		}
    listeners.destroy(); // this deletes it also
}

/**
 * Generivc callback to the registered socket listener function. The
 * actual socket reference is passed to this function and this will 
 * be the end implementing protolib class e.g. UdpSocket etc
 *
 * Called from PAIUDPSocket.h and PAITimer.cpp
 */
bool PAIMultipleListener::sendEventsToListeners(PAIEvent *event) {
	ListItem *li;
	PAIListener *sl;
	// notify all of the listeners .....

	listeners.rewind();
	li=(ListItem *)listeners.getCurrentListItem();
	
	if (li==NULL) 
		return true; // this is ok since there don;t have to be listeners attached ....

	do {
		sl=(PAIListener *)li->getItem();
		if (PAIEnvironment::getEnvironment()->isVerbose())
			cout << "PAIMultipleListener: " << li->getID() << ", of " << 
					getClassName() << " - " << getID() << " making callback.... " << endl;
		sl->generateCallback(event); // makes the callback to the listener function
		li=listeners.getNextListItem();
	} while (li != NULL);

    return true;
}
