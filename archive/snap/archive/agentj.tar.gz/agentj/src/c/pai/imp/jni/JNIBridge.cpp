/**
 * Java JNI callback for PAI Sockets: This class acts as a go-between in order
 * to channel events from PAI thorugh one function call to send to the Java program.
 * Needed because you cannot create pointers to Java functions directly but here,
 * I simply send the events through a JNI Callback function (dataReceivedAtJNISocket())
 * along with the PAIListener identify (PAIListeners IDs - i.e. its
 * references - pointers).
 *
 * There is one copy of this class - the listeners identify themselves
 * through the events they generate.
 */
#include "JNIBridge.h"

#define PAINATIVE_JAVA_CLASS "pai/imp/jni/PAINative"
#define PAINATIVE_CALLBACK_FUNCTIN_CALL "dataReceivedAtNativeSocket"

JNIBridge::JNIBridge() {
    pai = new PAI();
 	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIBridge: creating ..." << endl;

	cls=0;
	env=0;
	jvm=0; /* The virtual machine instance */

	socketListenerCallbackFuncID=0;
	timerListenerCallbackFuncID=0;
		
	pti = pai->getPTI(); // get the timing library
	pci = pai->getPCI(); // get the socket library
}  

int JNIBridge::createJavaSocketCallback(int sockID) {
	CallbackFunc socketCallback = (CallbackFunc)&JNIBridge::socketCallbackFunc;
	PAIOwner *owner = (PAIOwner *)this;

 	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIBridge: creating callback ..." << endl;

	PAISocket* sock = (PAISocket *)sockets.getItem(sockID);
	if (sock==NULL) {
		cerr << "JavaPAI: AddListener: PAISocket ID NOT FOUND ....!!!" << endl;
		return -1;
		}
 
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIBridge: socket in JNIBridge::createJavaCallback is " << sock << endl;

	PAISocketListener *plist = getPCI()->addListener(sock, owner, socketCallback);

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIBridge:created listener ...: " << plist << endl;

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIBridge: socket in JNIBridge::createJavaCallback: added listener"  << endl;

	slisteners.addItem(plist);
	ListItem *li = slisteners.getListItem(plist);

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIBridge: added Listener ... - as a list item: " << li << endl;
		
	return li->getID();
}

void JNIBridge::removeJavaSocketCallback(int sockID, int listenerID) {
 	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIBridge: removeJavaSocketCallback" << endl;
	PAISocket* sock = (PAISocket *)sockets.getItem(sockID);
	PAISocketListener *plist = (PAISocketListener *)slisteners.getItem(listenerID);
	pci->removeListener(sock, plist);
	slisteners.removeItem(plist);
}


bool JNIBridge::socketCallbackFunc(PAIEvent *e) {
	ListItem *li = sockets.getListItem(e->getObject()); // get ListItem of

	if (li==NULL) {
		cerr << "JNIBridge:callbackFunc:  CANNOT FIND SOCKET .... " << endl;
		return false;
		}

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIBridge::socketCallbackFunc, GOT CALLBACK: Socket ID = " << li->getID() << endl;


	if (cls==0) {
		jint res;
		if (PAIEnvironment::getEnvironment()->isVerbose())
			cout << "JNIBridge::socketCallbackFunc, Attaching Dispatcher Thread..." << endl;

		res = jvm->AttachCurrentThread((void**)&env, NULL);

		if (res < 0) {
			cerr << "JNIBridge::socketCallbackFunc, Attach failed" << endl;
			return false;
			}

		jclass clsl = env->FindClass(PAINATIVE_JAVA_CLASS);

		if (clsl == NULL) {
			cerr << "JNIBridge::socketCallbackFunc, ERROR cannot find Class\n" << endl;
			exit(0);
			return false;
			}

    		cls = (jclass)env->NewGlobalRef(clsl);
		} 

	if (socketListenerCallbackFuncID==0) {
		socketListenerCallbackFuncID = env->GetStaticMethodID(cls,
							PAINATIVE_CALLBACK_FUNCTIN_CALL, "(I)V");

		if (socketListenerCallbackFuncID == NULL)
			cerr << "JNIBridge::socketCallbackFunc, Cannot find Method\n" << endl;
		}

	if (PAIEnvironment::getEnvironment()->isVerbose()) {
		cout << "JNIBridge::socketCallbackFunc, CLS " << cls << endl;
		cout << "JNIBridge::socketCallbackFunc, env " << env << endl;
		cout << "JNIBridge::socketCallbackFunc, socketListenerCallbackFuncID " << socketListenerCallbackFuncID << endl;
	}

	if (socketListenerCallbackFuncID != 0) {
		// cout << "JNIBridge::socketCallbackFunc, function ok, MAKING CALLBACK NOW: ID is: " << li->getID() << endl;
		env->CallStaticVoidMethod(cls, socketListenerCallbackFuncID, li->getID());
		env->ExceptionDescribe();
		env->ExceptionClear();
	} else
		cerr << "JNIBridge::socketCallbackFunc, CANNOT MAKE CALLBACK - INVALID FUNCTION" << endl;

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIBridge::socketCallbackFunc, MADE CALLBACK" << endl;

	return true;
}


/******************************************************************
 ** Timer section below ...
 */

int JNIBridge::createJavaTimerCallback(int timerID) {

	CallbackFunc timerCallback = (CallbackFunc)&JNIBridge::timerCallbackFunc;
	PAIOwner *owner = (PAIOwner *)this;

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIBridge: createJavaTimerCallback, entering " << endl;

	PAITimer* timer = (PAITimer *)timers.getItem(timerID);

	if (timer==NULL) {
		cerr << "JavaPAI: AddListener: PAITimer ID NOT FOUND ....!!!" << endl;
		return -1;
		}

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIBridge: createJavaTimerCallback, timer is " << timer << endl;

	PAITimerListener *plist = getPTI()->addListener(timer, owner, timerCallback);
	tlisteners.addItem(plist);
	ListItem *li = tlisteners.getListItem(plist);
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "Added Listener ..." << endl;
	return li->getID();
}
 
void JNIBridge::removeJavaTimerCallback(int timerID, int listenerID) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIBridge: removeJavaTimerCallback " << endl;
	PAITimer* timer = (PAITimer *)timers.getItem(timerID);
	PAITimerListener *plist = (PAITimerListener *)tlisteners.getItem(listenerID);
	pti->removeListener(timer, plist);
	tlisteners.removeItem(plist);
}


bool JNIBridge::timerCallbackFunc(PAIEvent *e) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIBridge::timerCallbackFunc, entering" << endl;

	ListItem *li = timers.getListItem(e->getObject()); // get ListItem of

	if (li==NULL) {
		cerr << "JNIBridge: timerCallbackFunc:  CANNOT FIND TIMER.... " << endl;
		return false;
		}

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "GOT CALLBACK: Timer ID = " << li->getID() << endl;


	if (cls==0) {
		jint res;
//		cout << "JNIBridge: timerCallbackFunc: Attaching Dispatcher Thread...\n" << endl;

		res = jvm->AttachCurrentThread((void**)&env, NULL);

		if (res < 0) {
			cerr << "JNIBridge: timerCallbackFunc: Attach failed\n" <<endl;
			return false;
			}

		jclass clsl = env->FindClass(PAINATIVE_JAVA_CLASS);

		if (clsl == NULL) {
			cerr << "Cannot find Class\n" << endl;
			exit(0);
			return false;
			}

    		cls = (jclass)env->NewGlobalRef(clsl);
		}

	if (timerListenerCallbackFuncID==0) {
		timerListenerCallbackFuncID = env->GetStaticMethodID(cls,
							"triggerReceived", "(I)V");

		if (timerListenerCallbackFuncID == NULL)
			cerr << "JNIBridge: timerCallbackFunc: Cannot find Method\n" << endl;
		}

	if (timerListenerCallbackFuncID != 0) {
		env->CallStaticVoidMethod(cls, timerListenerCallbackFuncID, li->getID());
	} else
		cerr << "JNIBridge: timerCallbackFunc: CANNOT MAKE CALLBACK - INVALID FUNCTION" << endl;

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIBridge: timerCallbackFunc: MADE TIMER CALLBACK" << endl;

	return true;
}
