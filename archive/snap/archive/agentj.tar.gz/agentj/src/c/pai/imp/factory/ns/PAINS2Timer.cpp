#include "PAINS2Timer.h"
#include "iostream.h"
#include "SchedulerInstance.h"

PAINS2Timer::PAINS2Timer(double delay, int repeat, PAIDispatcher *eventDispatcher)
: PAITimer(delay, repeat, eventDispatcher) {

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAINS2Timer: creating, delay: " << delay << " repeat:" << repeat << endl;

	disp = (NsProtoAgent *)eventDispatcher->getDispatcher();
	
	timer.Init(delay, repeat,
                 (ProtocolTimerOwner*)this,
                 (ProtocolTimeoutFunc)&PAITimer::TimerTimeOut);

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAINS2Timer: Timer Created OK..." << endl;
}

PAINS2Timer::~PAINS2Timer() {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAINS2Timer: Deactivating NS2 timer" << endl;
	timer.Deactivate();
}


PAITimerListener* PAINS2Timer::addListener(PAIOwner *callingClass, CallbackFunc socketListener) {

#ifndef NETWORK_MODE
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAINS2Timer: Adding NS2 timer installer and listener " << endl;

	cout << "PAINS2Timer: Pointer to Broker is " << disp << endl;
    cout << "PAINS2Timer: Testing Agent pointer -> Calling addr() on agent, result: " << disp->addr() << endl;

    if (NULL == dynamic_cast<ProtoSim*>(disp)) {
        cout << "PAINS2Timer: disp is not actually a ProtoSimAgent!!" << endl;
        }

	timer_mgr.SetInstaller(ProtoSim::TimerInstaller, dynamic_cast<ProtoSim*>(disp)); // which should be set to the NS2 agent  ...

//    timer_mgr.setScheduler(SchedulerInstance::getSchedulerInstance());

    timer_mgr.InstallTimer(&timer);

	#endif
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAINS2Timer: installed timer... " << endl;
	return PAITimer::addListener(callingClass, socketListener);
}

bool PAINS2Timer::removeListener(PAITimerListener* listener) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAINS2Timer: Removing: listener " << endl;
// not sure how to do this
	return PAITimer::removeListener(listener);
}
