#ifndef _PAIDefaultTimer
#define _PAIDefaultTimer

#include "PAIDefs.h"
#include PROTOLIB_HOME

#include "PAITimer.h"

/**
 * A PAI Timer: This catches the timing events for a Protolib Protocol Timer
 * implementation and customizes them for sending back to the PAI application.
 * PAIDefaultTimers can also have ID's and are a much simplified version of Protocol
 * timers.  Later, we may add events to PAI
 */
class PAIDefaultTimer : public PAITimer {
	public:
		/**
		 *
		 */
		PAIDefaultTimer(double delay, int repeat, PAIDispatcher *eventDispatcher);

		~PAIDefaultTimer();

		PAITimerListener* addListener(PAIOwner *callingClass, CallbackFunc socketListener);

		bool removeListener(PAITimerListener* listener);

    private:
		ProtocolTimer timer;
		EventDispatcher *edisp;
}; // end class PAIDefaultTimer

#endif // _PAIDefaultTimer
