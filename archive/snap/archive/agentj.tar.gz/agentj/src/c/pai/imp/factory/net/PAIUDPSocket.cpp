#include "PAIUDPSocket.h"
#include <iostream.h>


bool PAIUDPSocket::win32Called=0;

PAIUDPSocket::PAIUDPSocket(PAIEnvironment *penv, PAIDispatcher *eventDispatcher, unsigned int port)
 : PAISocket(penv, eventDispatcher) {
//	UdpSocketInstallFunc *fun;
	setPort(port);
	sockHelper = new SockCallback(this);

	disp = (EventDispatcher *)eventDispatcher->getDispatcher();

#ifdef WIN32
	if (!win32Called) {
		if (PAIEnvironment::getEnvironment()->isVerbose())
			cout << "WIN32 Socket INIT" << endl;
		if (!disp->Win32Init()) {
			cerr << "PAI_Engine:: Win32Init() error!" << endl;
			}
		win32Called=true;
}
#endif

	socket.Init((UdpSocketOwner*)sockHelper,
		(UdpSocketRecvHandler)&SockCallback::socketReceivedData,
                EventDispatcher::SocketInstaller, disp);

    // Open a udp socket
    if (UDP_SOCKET_ERROR_NONE != socket.Open(getPort())) {
        cerr << "PAIUDPSocket: Error opening UDP socket!" << endl;
    }
}


PAISocketListener* PAIUDPSocket::addListener(PAIOwner *callingClass, CallbackFunc socketListener) {
    // socket is already added so can;t do much here.  Socket Init has to be called before
	// socket.Open for it to work correctly so can't do much

	socket.SetListener((UdpSocketOwner*)sockHelper,
		(UdpSocketRecvHandler)&SockCallback::socketReceivedData);

	return PAISocket::addListener(callingClass, socketListener);
}

bool PAIUDPSocket::removeListener(PAISocketListener* listener) {
	disp->RemoveSocketInput(&socket);
	return PAISocket::removeListener(listener);
	}


/**
 * Send data to the given address and port number
 */
bool PAIUDPSocket::send(const PAIInetAddress *address, const char *data, unsigned int length) {
	NetworkAddress addr;
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIUDPSocket: Sending '" << data << "' to " << address->address_ <<
				", port : " << address->port_ << endl;

// really hate C++ ...  you put a const in and everything gots ugly ....  had to make this class
// a friend just so I could access the private members of PAIInetAddress..... as getPort etc are
// not accessible ....

	// verify the sending location
	if ( !addr.LookupHostAddress(address->address_) ) {
		throw new PAISocketSendError();
		return false;
	}

	addr.SetPort(address->port_);
	socket.SendTo(&addr, data, length);

	return true;
}


char *PAIUDPSocket::recv(PAIInetAddress **address, unsigned int *length) {
    	*length=getSocketBufferLength();
	char *buffer;

	NetworkAddress addr;
	socket.RecvFrom(socketBuffer, length, &addr);

	if (*length==0) {
		if (PAIEnvironment::getEnvironment()->isVerbose())
			cout << "PAIUDPSocket: No Data, returning" << endl;
		// throw new PAISocketReceiveError();
		return NULL;
		}

	(*address)->setAddress(addr.HostAddressString());
	(*address)->setPort(addr.Port());

	buffer = new char[*length];
	strncpy(buffer, socketBuffer, *length);

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIUDPSocket: Receiving '" << buffer << "' (" << *length << " bytes) from "
				<< (*address)->address_ << ", port : " << (*address)->port_ << endl;

	return buffer;
}

void PAIUDPSocket::setMulticast(bool val) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "Setting multicast" << endl;

	socket.SetBroadcast(val);
}

void PAIUDPSocket::joinGroup(const char* groupAddress) {
    NetworkAddress addr;
    addr.LookupHostAddress(groupAddress);
    addr.SetPort(getPort());
	socket.JoinGroup(&addr, NULL);
}

void PAIUDPSocket::leaveGroup(const char* groupAddress) {
    NetworkAddress addr;
    addr.LookupHostAddress(groupAddress);
    addr.SetPort(getPort());
	socket.LeaveGroup(&addr, NULL); 
}
