#ifndef _PAIListener
#define _PAIListener

#include "PAIDefs.h"
#include <iostream.h>

class PAIMultipleListener;

/**
 * A simple class to encapsulate the details of a listener for PAI callbacks. The
 * listener functions typically are identified by a class (the calling class where
 * the function is located) a the pointer to the function within that class. The
 * generateCallback function here makes the callback onto the event listener.  This
 * class is the crux of the event dispatching within PAI and all event callbacks,
 * whether they be sockets or timers are registered within PAIListener objects.
 */
class PAIListener {
public:
	PAIListener(PAIMultipleListener *theParent, PAIOwner *ownerClass, CallbackFunc callbackFunc);

	/**
	 * The owner of this listener is the class which contains the callback function
	 * that will be called when events are generated
	 */
	PAIOwner *getlistenerClass() { return listenerClass; }

	/**
	 * The reference to the actual function that will receive this callback -
	 * this is a pointer offset relative to the listener class defined above
	 */
	CallbackFunc getCallbackFunction() { return sListener; }

	/**
	 * The parent of this listener i.e. the socket or timer that this
	 * is attached to - maybe this should be getSource() ??
	 */
	PAIMultipleListener *getParent() { return parent; }

	bool generateCallback(PAIEvent *event);

private:
	PAIOwner *listenerClass; // Pointer to class that contains the socket listener function
	CallbackFunc sListener; // Offset pointer to socket action
	PAIMultipleListener *parent; // the parent of this listener i.e. the socket or timer that this
	                           // is attached to
};

/**
 * Convenience class for naming the listener a socket listener rather than a generic one.
 * This is used so that users can get PAISocketListener objects when they add a listener
 * to a socket or timer rather than just getting a PAIListener.
 */
class PAISocketListener : public PAIListener {
public:
	PAISocketListener (PAIMultipleListener *theParent, PAIOwner *ownerClass, CallbackFunc callbackFunc)
		: PAIListener( theParent, ownerClass, callbackFunc) {}
};

/**
 * Convenience class for naming the listener a timer listener rather than a generic one.
 * This is used so that users can get PAITimerListener objects when they add a listener
 * to a socket or timer rather than just getting a PAIListener.  
 */
class PAITimerListener : public PAIListener {
public:
	PAITimerListener (PAIMultipleListener *theParent, PAIOwner *ownerClass, CallbackFunc callbackFunc) 
		: PAIListener( theParent, ownerClass, callbackFunc) {}
};

#endif // _PAIListener
