
#ifndef _PAI_AGENT
#define _PAI_AGENT

#include "nsProtoAgent.h"
#include <PAI.h>

/**
 * The class src/c/pai/agent/PAISimpleAgent is a advanced PAI
agent that allows C++ applications to use the PAI interface
and retain as much of the control of the application
as possible rather than relying on the NS2 TCL script.

PAI Agent represents a shift in the 'normal' use of an NS2
agent; that is, it allows the application to take more control 
of the scenario rather than painting the scenario in the TCL 
script.  This is an important distinction because we
are aiming to provide here a pluggable NS2 layer, which
affects the actual implementations of the application as little
as possible.  The 'ideal' would be for the application not
to change a single line of code to be able to run in the
real world or within Ns2.  
 */
class PAIAgent : public NsProtoAgent
{
    public:
        PAIAgent();
        ~PAIAgent();

    protected:
        virtual int command(int argc, const char*const* argv);

    private:
		void initAgent(); // initialise the NS2 node
		void start(); // start NS2 simulation for this node e.g. kcik off timer for example?
        bool OnTxTimeout();
        bool OnSocketRecv();

		char *getLocalAddress() {
		    char *buf= new char[50];
		    sprintf(buf, "%li\0", (unsigned long)addr());
			return buf;
			}

	PAI *pai;
		
	PTI *pti;
	PCI *pci;
	PAITimer *timer;
    PAISocket *sock;
	
    int port;
    int groupPort;
	char *myAddress;

	PAIInetAddress *sendTo;	
	int timestep;
    char* buffer;
	char* multicastAddress;
	

};  // end class


#endif // _PAI_AGENT
