#ifndef _PAIFactory
#define _PAIFactory

#include "PAISocket.h"
#include "PAIEnvironment.h"
#include "PAIError.h"

#ifndef NETWORK_MODE
#include "PAINS2UDPSocket.h"
#include "PAINS2Timer.h"
#else
#include "PAIUDPSocket.h"
#include "PAIDefaultTimer.h"
#endif

/**
 * PAIFactory creates the correct type of object based on the type of environment
 * you have set. For example, we create UDP_PAISocket when we specify that we
 * want to use the UDP socket communication layer but what is returned is the
 * common interface to ALL sockets e.g. PAIScoket.  This makes the PAIEngine
 * unaware of protolib class as it interfaces through common gateways i.e.
 * PAITimers and PAISockets.  This, in turn means that if we want to change
 * anything about how we communicate to the lower layers then 99% of this
 * code stays exactly the same and we simply extend the environment and
 * implement a new type of socket/timer.
 *
 */
class PAIFactory {
	public:
		PAIFactory(PAIEnvironment *envir);
		~PAIFactory();

		/**
		 * Creates a socket based on the environment set by the user.
		 */
		PAISocket *createSocket(int portNumber);

		/**
		 * Creates a timer based on the environment set by the user.
		 */
		PAITimer *createTimer(double delay, int repeat);

		/**
		 * Creates an event dispatcher based on the environment set by the user.
		 */
		PAIDispatcher *createDispatcher();

	private:
		PAIEnvironment *env;
		PAIDispatcher *dispatcher;
}; // end class PAIFactory

#endif // _PAIFactory
