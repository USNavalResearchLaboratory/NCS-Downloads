
#include <iostream.h>
#include <fstream.h>

#ifndef _SCHED_INST
#define _SCHED_INST

// #define TMP_FILE "~/.agentj"

/**
 * A class to maintain a reference to the NS2 scheduler - this has to be maintained
 * by the JNI implementation so it does not go out of scope.
 */
class SchedulerInstance {
public:
static int nsScheduler;  // only valid during one invocation - set when setting up timers
static int getSchedulerInstance() {
    cout << "SchedulerInstance: Scheduler Ptr: " << SchedulerInstance::nsScheduler << endl;

    if (nsScheduler==0) { // read it in ...
        cout << "SchedulerInstance: LOST REFERENCE: to Scheduler...." << endl;

       //char tmp[20];
       //ifstream fin;
       //fin.open(TMP_FILE);
       //fin >> tmp;
       //nsScheduler = atoi(tmp);
       }

    return nsScheduler;
}

static void setScheduler(int sched) {
    //nsScheduler=sched;
    //ofstream fout;
    //fout.open(TMP_FILE);
    //fout << sched << endl;
    //fout.close();
}
};


#endif // _SCHED_INST