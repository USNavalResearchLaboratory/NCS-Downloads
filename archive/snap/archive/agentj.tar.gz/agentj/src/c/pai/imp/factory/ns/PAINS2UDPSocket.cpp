#include "PAINS2UDPSocket.h"
#include <iostream.h>
#include "PAIInetAddress.h"
#include "PAIError.h"

PAINS2UDPSocket::PAINS2UDPSocket(PAIEnvironment *penv, PAIDispatcher *eventDispatcher, unsigned int port)
 : PAISocket(penv, eventDispatcher) {
	setPort(port);
	sockHelper = new SockCallback(this);

#ifndef NETWORK_MODE

	disp = (NsProtoAgent *)eventDispatcher->getDispatcher();

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAINS2Socket: Adding socket " << endl;

	socket.Init((UdpSocketOwner*)sockHelper,
		(UdpSocketRecvHandler)&SockCallback::socketReceivedData,
		ProtoSim::SocketInstaller, static_cast<ProtoSim*>(disp));

#endif

    // Open a udp socket
    if (UDP_SOCKET_ERROR_NONE != socket.Open(getPort())) {
        cerr << "PAINS2UDPSocket: Error opening UDP socket!" << endl;
    }
}


PAISocketListener* PAINS2UDPSocket::addListener(PAIOwner *callingClass, CallbackFunc socketListener) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAINS2Socket: Adding listener " << endl;

	socket.SetListener((UdpSocketOwner*)sockHelper,
		(UdpSocketRecvHandler)&SockCallback::socketReceivedData);

	return PAISocket::addListener(callingClass, socketListener);
}

bool PAINS2UDPSocket::removeListener(PAISocketListener* listener) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAINS2Socket: removing socket listener " << endl;
	return PAISocket::removeListener(listener);
	}


/**
 * Send data to the given address and port number
 */
bool PAINS2UDPSocket::send(const PAIInetAddress *address, const char *data, unsigned int length) {
	NetworkAddress addr;
//	if (PAIEnvironment::getEnvironment()->isVerbose()) {
//		cout << "PAINS2UDPSocket: send, sending to address: " << address->address_ << ", port : " << getPort() << endl;
//		cout << "PAINS2UDPSocket: send, data : " << data << " (" << length << " bytes)" << endl;
//      }
		
	// verify the sending location
	if ( !addr.LookupHostAddress(address->address_) ) {
		throw new PAISocketSendError();
		return false;
	}

	addr.SetPort(address->port_);

//	if (PAIEnvironment::getEnvironment()->isVerbose())
//		cout << "PAINS2UDPSocket: sending now... "<< endl;

	socket.SendTo(&addr, data, length);

//	if (PAIEnvironment::getEnvironment()->isVerbose())
//		cout << "PAINS2UDPSocket: sent... "<< endl;

    return true;
}


char *PAINS2UDPSocket::recv(PAIInetAddress **address, unsigned int *length) {
    *length=getSocketBufferLength();
	char *buffer;

	NetworkAddress addr;
//	if (PAIEnvironment::getEnvironment()->isVerbose())
//        cout << "PAIUDPSocket: Receiving up to " << *length << " bytes" << endl;
	
	socket.RecvFrom(socketBuffer, length, &addr);

//	if (PAIEnvironment::getEnvironment()->isVerbose())
//        cout << "PAIUDPSocket: Received '" << endl;
	
	if (*length==0) {
		if (PAIEnvironment::getEnvironment()->isVerbose())
			cout << "PAIUDPSocket: No Data, returning" << endl;
		// throw new PAISocketReceiveError();
		return NULL;
		}

	buffer = new char[*length];

	memcpy(buffer, socketBuffer, *length);

	(*address)->setAddress(addr.HostAddressString());
	(*address)->setPort(addr.Port());

//	if (PAIEnvironment::getEnvironment()->isVerbose())
//		cout << "PAIUDPSocket: Receiving '" << buffer << "' (" << *length << " bytes) from "
//				<< (*address)->address_ << ", port : " << (*address)->port_ << endl;

    return buffer;
}

void PAINS2UDPSocket::setMulticast(bool val) {
//	if (PAIEnvironment::getEnvironment()->isVerbose())
//		cout << "PAINS2UDPSocket: Warning: No point in setting multicast in NS-2: You have to allocated these addresses youself" << endl;

	// socket.SetBroadcast(val);
}

void PAINS2UDPSocket::joinGroup(const char* groupAddress) {
	NetworkAddress addr;
	addr.LookupHostAddress(groupAddress);
	addr.SetPort(getPort());
	socket.JoinGroup(&addr, NULL);
}

void PAINS2UDPSocket::leaveGroup(const char* groupAddress) {
	NetworkAddress addr;
	addr.LookupHostAddress(groupAddress);
	addr.SetPort(getPort());
	socket.LeaveGroup(&addr, NULL);
}
