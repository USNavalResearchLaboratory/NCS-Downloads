
#ifndef _PAI_AGENT
#define _PAI_AGENT

#include "nsProtoAgent.h"
#include <PAI.h>

/**
 * PAISimpleAgent is a basic hook-up of the PAI library within NS-2.  This
 * class provides basic support but leaves little control to the C++
 * code itself.  PAIAgent is a better example of a fully functional agent,
 * which allows the C++ code to choose many of the settings (e.g. port
 * number etc, rtaher than having to specify these in the TCL scripts.
 
 * It has
 * a limites set of commands that allow you to send up data
 * flows between any 2 PAISimpleAgent nodes, add multicast groups
 * and set up PAI timers.
 * see the 'examples/pai' directory in the pai home directory 
 * for the sample NS2 TCL scripts that illustrate this functionality
 */
class PAISimpleAgent : public NsProtoAgent
{
    public:
        PAISimpleAgent();
        ~PAISimpleAgent();

    protected:
        virtual int command(int argc, const char*const* argv);

    private:
		void start();
        bool OnTxTimeout();
        bool OnSocketRecv();

	PAI pai;
		
	PTI *pti;
	PCI *pci;
	PAITimer *timer;
    PAISocket *sock;
	
	PAIInetAddress *sendTo;
	
	int timestep;
	
    char* buffer;


};  // end class


#endif // _PAI_AGENT
