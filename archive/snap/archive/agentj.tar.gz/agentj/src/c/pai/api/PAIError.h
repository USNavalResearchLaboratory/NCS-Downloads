#ifndef _PAIError
#define _PAIError

#include <iostream.h>

/**
 * PAIError base class: All error type inherit from this but most do nothing except
 * change the name of the class to differentiate the type and set an error
 */
class PAIError {
	public:		
		PAIError(char *setError) {error=setError;}
			
		char *getError() { return error; }

		void printError() {   cout << "PAIError: " << error << endl; }

    private:		
		char *error;
}; // end class PAIError

/**
 * Error when a socket is created because the user has specified an unsupported type 
 * e.g. perhaps they had chosen a TCP socket when this is not supported
 */
class PAISocketCreationError : public PAIError {
	public:
		PAISocketCreationError () : PAIError("Error Creating Socket: Invalid socket type") {}

};

/**
 * Error when a send data to a socket. Normally this is because the socket has 
 * been removed. 
 */
class PAISocketSendError : public PAIError {
	public:
		PAISocketSendError () : PAIError("Error Sending Data: Is Socket Valid?") {}

};

/**
 * Error when a data is received from a socket. Normally this is because the socket has 
 * been removed. 
 */
class PAISocketReceiveError : public PAIError {
	public:
		PAISocketReceiveError () : PAIError("Error Receiving Data: Is Socket Valid?") {}

};

class PAITimerCreationError : public PAIError {
	public:
		PAITimerCreationError () : PAIError("Error Creating Timer: Invalid Socket type") {}

};

class PAISocketNotImplementedError : public PAIError {
	public:
		PAISocketNotImplementedError() : PAIError("Sorry, socket type exists but has not been implemented yet .... ") {}

};

class PAIDispatcherCreationError : public PAIError {
	public:
		PAIDispatcherCreationError() : PAIError("Dispatcher type is not currently supported") {}

};

class SocketListenerException : public PAIError {
	public:
		SocketListenerException() : PAIError("Could not attached Listener: Invalid Socket Identifier - is your PAISocket object NULL") {}

};

class TimerListenerException : public PAIError {
	public:
		TimerListenerException() : PAIError("Could not attached Listener: Invalid Socket Identifier - is your PAISocket object NULL") {}
};

class SocketCreationException : public PAIError {
	public:
		SocketCreationException() : PAIError("Could not create socket: Please try another port or check other errors") {}

};

class TimerCreationException : public PAIError {
	public:
		TimerCreationException() : PAIError("Could not create timer: Unknown error, please check other errors") {}

};

#endif // _PAIError
