#include "PAIAgent.h"
#include <iostream.h>

static class PAIAgentExampleClass : public TclClass
{
	public:
		PAIAgentExampleClass() : TclClass("Agent/PAIAgent") {}
	 	TclObject *create(int argc, const char*const* argv) {
			cout << "creating PAIAgent .... " << endl;
			return (new PAIAgent());
			}
} class_protean_example;

PAIAgent::PAIAgent() {
	timestep=0;
	
    pai = new PAI();
	
	pai->setDispatcher(static_cast<ProtoSim*>(this));
 
    if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIAgent: created PAIAgent " << endl;

	pti = pai->getPTI(); // get the timing library
	pci = pai->getPCI(); // get the socket library
 	port=5000;
	groupPort=5000;
	
	multicastAddress=NULL;
	// printf("Local address in Constructor is %s\n", getLocalAddress());
}

void PAIAgent::initAgent() {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		printf("PAIAgent: INIT Called !!!!!!!!!!!!!\n");

	myAddress = getLocalAddress();
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIAgent: Address from addr() is " << myAddress << endl;
	
	buffer = new char[20];
	strcpy(buffer, "Hello PAI Agent !!");

	if (PAIEnvironment::getEnvironment()->isVerbose())
		printf("PAIAgent: Set Sender String '%s'\n", buffer);
	
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIAgent: open: on port " << port << endl;
	sock = pci->addSocket(port);
	CallbackFunc socketCallback = (CallbackFunc)&PAIAgent::OnSocketRecv;
	PAIOwner *owner = (PAIOwner *)this;
	pci->addListener(sock, owner, socketCallback);

	if (multicastAddress!=NULL) {
		if (PAIEnvironment::getEnvironment()->isVerbose())
			cout << "Joining multicast group " << multicastAddress << endl;
		pci->joinGroup(sock, multicastAddress);
		}
}

void PAIAgent::start() {
	CallbackFunc timerCallback = (CallbackFunc)&PAIAgent::OnTxTimeout;
	PAIOwner *owner = (PAIOwner *)this;
	
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIAgent: sending: " << buffer << endl;
	OnTxTimeout();  // transmit first packet right away
    
	timer = pti->addTimer(1.0, -1);
	pti->addListener(timer, owner, timerCallback); // set timer off
}

bool PAIAgent::OnTxTimeout() {
	char* buf;
	unsigned int len = strlen(buffer) + 1;

    buf = new char[len];
	strcpy(buf, buffer);
	
	if (PAIEnvironment::getEnvironment()->isVerbose())
   	    cout << "PAIAgent Timer before ......" << sendTo->getAddress() << endl;

	pci->send(sock, sendTo, buf, len);

 	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIAgent Timer after ......" << sendTo->getAddress() << endl;
	
	delete buf;
	return true;
} 

bool PAIAgent::OnSocketRecv() {
	char *buf;
	PAIInetAddress *address;
	unsigned int len=512;

    address = new PAIInetAddress();

    if (PAIEnvironment::getEnvironment()->isVerbose())
	    cout << "PAIAgent: Data about to receive...." << endl;

	buf = pci->recv(sock, &address, &len);
	
//	cout << "Data Received...." << endl;

	if (PAIEnvironment::getEnvironment()->isVerbose())
		printf("%i...Received %s from %s, port %i \n", ++timestep, buf, address->getAddress(), address->getPort());

    delete address;
	
	delete buf;
	return true;
}

PAIAgent::~PAIAgent()
{
}

int PAIAgent::command(int argc, const char*const* argv) {

	cout << "PAIAgent: Command: .... " << argv[1] << " : parameters = " <<  argc << endl;

    if (3 == argc) {
        if (!strcmp(argv[1], "setSendTo")) {
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAIAgent: sendto: " << argv[2] << " on port " << port << endl;
			sendTo = new PAIInetAddress(argv[2], port);
            return TCL_OK;
			}
        else if (!strcmp(argv[1], "setMulticastAddress")) { // <groupAddr>
			multicastAddress = argv[2];
            return TCL_OK;
        }
	}	
	if (2 == argc) {
		if (!strcmp(argv[1], "start")) {
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAIAgent: start: " << endl;
			start();
            return TCL_OK; 
        }
		else if (!strcmp(argv[1], "initAgent")) { // init is a reserved word so cannot use it ...
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAIAgent: initAgent: " << endl;
			initAgent();
            return TCL_OK; 
        }
		else if (!strcmp(argv[1], "stopTimer")) {
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAIAgent: Stopping Timer..." << endl;
			pti->removeTimer(timer);
			return TCL_OK;
		}
		else if (!strcmp(argv[1], "cleanUp")) {
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAIAgent: PAI Stopped..." << endl;
			pai->cleanUp();
			return TCL_OK;
		}
	}

    return NsProtoAgent::command(argc, argv);
}  // end PAIAgent::command()



