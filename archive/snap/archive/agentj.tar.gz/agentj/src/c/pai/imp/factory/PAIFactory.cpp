#include "PAIFactory.h"

PAIFactory::PAIFactory(PAIEnvironment *envir) {
	env = envir;
}

PAIFactory::~PAIFactory() {}

PAISocket* PAIFactory::createSocket(int portNumber) {
	PAISocket *socket=NULL;
	PAIEnvType socketType = env->getSocketType();

	switch(socketType) {
#ifndef NETWORK_MODE
        	case UDP_SOCKET:
			socket = new PAINS2UDPSocket(env, dispatcher, portNumber);
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAIFactory: Created NS2 Socket" << endl;
#else
		case UDP_SOCKET:
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAIFactory: created Networked Socket ..." << endl;
			socket = new PAIUDPSocket(env, dispatcher, portNumber);
#endif
			break;
		case TCP_SOCKET:
			throw new PAISocketNotImplementedError();
			break;

		default:
			throw new PAISocketCreationError();
     }
	return socket;
}


PAITimer* PAIFactory::createTimer(double delay, int repeat) {
	PAITimer  *timer=NULL;
	PAIEnvType timerType = env->getTimerType();

	switch(timerType) {
#ifndef NETWORK_MODE
        	case DEFAULT_TIMER:
			timer = new PAINS2Timer(delay, repeat, dispatcher);
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAIFactory: Created NS2 Timer ..." << endl;
#else
        	case DEFAULT_TIMER:
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAIFactory: Created Network Timer ..." << endl;
			timer = new PAIDefaultTimer(delay, repeat, dispatcher);
#endif
	    		break;
		default:
			throw new PAITimerCreationError();
     }

	return timer;
}

PAIDispatcher* PAIFactory::createDispatcher() {
	PAIDispatcher *disp=NULL;
	PAIEnvType dispType = env->getDispatcherType();

	switch(dispType) {
        case DEFAULT_DISPATCHER:
#ifdef NETWORK_MODE
			disp = new ProtolibDispatcher();
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAIFactory: Created Network Dispatcher ..." << endl;
#endif
	    break;
        case NS2_DISPATCHER:
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAIFactory: Created NS2 Dispatcher...." << endl;
#ifndef NETWORK_MODE
		disp = new NSProtolibDispatcher();
#endif
            break;
		default:
			throw new PAIDispatcherCreationError();
     }

	dispatcher=disp;
	return disp;
}
