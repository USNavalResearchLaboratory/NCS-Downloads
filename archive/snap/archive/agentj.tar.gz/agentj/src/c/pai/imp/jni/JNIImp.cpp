#include <jni.h>
#include "pai_imp_jni_PAINative.h"
#include "JNIBridge.h"
#include <iostream.h>
#include <SchedulerInstance.h>

int SchedulerInstance::nsScheduler=0; // in sysdefs

/**
 * returns the current value of the pointer to the NS2
 * Schduler.
 */
int getSchedulerObject(JNIEnv *env, jobject obj) {
    jclass cls = env->GetObjectClass(obj);
    jfieldID fid;

    fid = env->GetFieldID(cls, "_schedulerPtr", "I");

    if (fid==0) {
    //	      cout << "Can't find instance variable ...." << endl;
    	return NULL;
    	}

    jint val = env->GetIntField(obj,fid);

    return val;
    }

/*
 * Class:     pai_imp_PAINative
 * Method:    init
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_pai_imp_jni_PAINative_init(JNIEnv *env, jobject obj) {
    JavaVM *vm;

	JNIBridge *jenv = new JNIBridge();

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JavaPAI: init, created the ONE AND ONLY instance of JNIBridge" << endl;
	 	  
	// set pointer in Java object
	  
	jclass cls = env->GetObjectClass(obj);
	jfieldID fid;
	  
	// get the local Java instance variable for our pointer reference
	 
	fid = env->GetFieldID(cls, "_objPtr", "I");
	  
	if (fid==0) {
		cout << "JNIImp: FATAL Cannot find ESSENTIAL instance variable for C++ pointer _objPtr ...." << endl;
		cout << "JNIImp: This SHOULD NOT HAPPEN - are you using this from your own Java class??? " << endl;
		return;
		}
		  
	// sets the pointer within the Java class so we have a reference to it as long as we need it 	  
	env->SetIntField(obj, fid, (int)jenv);

	env->GetJavaVM(&vm);

	jenv->setJVM(vm);

      // set the sceduler pointer in the SchedulerInstance pointer whenever we
      // make a call.

    jenv->schedulerPtr=getSchedulerObject(env,obj); // set once in object, then set each
                // time for every call from this value.  Its the only way since the reference
                // gets lost every time ....

    SchedulerInstance::nsScheduler = jenv->schedulerPtr;

    cout << "JNIImp: Scheduler ptr is " << SchedulerInstance::nsScheduler << endl;

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: init, leaving" << endl;
	}



/**
 * This is the central point for the JNI binding.  It plugs in one-on-one to
 * the Java class, pai.imp.jni.PAINative.java...
 *
 * See the JNIBridge class for all persitent variables used by this JNI bridge
 *
 * This returns the pointer to the JNIBridge C++ class that the calling Java object has created.
 * There is a one-to-one correspondance with the Java JNI object and a JNIBridge, which
 * encapsulates all the necessary objects for the JNI PAI interaction.
 *
 * This function is used in ALL further JNI calls to redirect the static JNI calls into
 * the appropriate instances - there is one JNIBridge class for each NS2 node so they
 * can all retain their own internal data, if necessary.
 *
 * NOTE: that I use 32-bit for pointers here so this WILL NOT WORK on 64-bit address systems ...
 * TODO !
 */
JNIBridge *getJNIBridgeObject(JNIEnv *env, jobject obj) {
	  jclass cls = env->GetObjectClass(obj);
	  jfieldID fid;
	  
	  fid = env->GetFieldID(cls, "_objPtr", "I");
	  
	  if (fid==0) {
//	      cout << "Can't find instance variable ...." << endl;
		  return NULL;
		  }
		  
      jint val = env->GetIntField(obj,fid);

      // set every time to maintain reference...

      cout << "JNIImp: getJNIBridgeObject, setting scheduler instance" << endl;

      SchedulerInstance::nsScheduler = ((JNIBridge *)val)->schedulerPtr;

      cout << "JNIImp: scheduler instance is " << SchedulerInstance::nsScheduler << endl;

	  return (JNIBridge *)val;
} 

/**
 * returns the current value of the pointer to the NS2
 * agent that is currently using this NI interface to PAI
 * - used by some functions here.
 */
Agentj *getAgentjObject(JNIEnv *env, jobject obj) {
	  jclass cls = env->GetObjectClass(obj);
	  jfieldID fid;
	  
	  fid = env->GetFieldID(cls, "_brokerPtr", "I");
	  
	  if (fid==0) {
//	      cout << "Can't find instance variable ...." << endl;
		  return NULL;
		  }
		  
      jint val = env->GetIntField(obj,fid);
	  
	  return (Agentj *)val;
} 

/* 
 * Class:     pai_imp_PAINative
 * Method:    addNativeSocket
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_pai_imp_jni_PAINative_addNativeSocket
  (JNIEnv *env, jobject obj, jint port) {

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: addNativeSocker, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 

    Agentj *broker = getAgentjObject(env,obj);
	
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: Pointer to broker is " << broker << endl;
	
	jenv->getPAI()->setDispatcher(static_cast<ProtoSim*>(broker)); // sets the dispatcher to the NS node

	LinkedList *sockets = jenv->getSockets();

	PAISocket* ps = (jenv->getPCI())->addSocket(port);
	sockets->addItem(ps);
	ListItem *li = sockets->getListItem(ps);
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: addNativeSocket, leaving" << endl;
	return li->getID(); // returns the ID
}
 
/*
 * Class:     pai_imp_PAINative
 * Method:    addListener
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_pai_imp_jni_PAINative_addListener
  (JNIEnv *env, jobject obj, jint sockID) {

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: addlistener (Socket), entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 
    Agentj *broker = getAgentjObject(env,obj);
	jenv->getPAI()->setDispatcher(static_cast<ProtoSim*>(broker)); // sets the dispatcher to the NS node

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: addlistener (Socket), leaving" << endl;

	// create a Java callback for socket ps and adds created listener
	// to listeners for this socket
	return jenv->createJavaSocketCallback(sockID);
}


/*
 * Class:     pai_imp_PAINative
 * Method:    removeListener
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_pai_imp_jni_PAINative_removeListener
(JNIEnv *env, jobject obj, jint sockID, jint listID) {

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: removeListener, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 
	jenv->removeJavaSocketCallback(sockID, listID); // removes it from withon PAI also
	}

/*
 * Class:     pai_imp_PAINative
 * Method:    removeSocket
 * Signature: (I)V
 */
JNIEXPORT void JNICALL Java_pai_imp_jni_PAINative_removeNativeSocket
(JNIEnv *env, jobject obj, jint sockID) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: removeNativeSocket, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 

	LinkedList *sockets = jenv->getSockets();

	PAISocket* ps = (PAISocket *)sockets->getItem(sockID);

	jenv->getPCI()->removeSocket(ps);
}

/*
 /*
 * Class:     pai_imp_PAINative
 * Method:    send
 * Signature: (ILjava/lang/String;I[BI)Z
 */
JNIEXPORT jboolean JNICALL Java_pai_imp_jni_PAINative_send
(JNIEnv *env, jobject obj, jint sockID, jstring address, jint port, jbyteArray data, jint length) {

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: send, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 

	LinkedList *sockets = jenv->getSockets();
	PAISocket* ps = (PAISocket *)sockets->getItem(sockID);

	const char *str = env->GetStringUTFChars(address, 0);

	jsize len = env->GetArrayLength(data);

	jbyte *bdata = env->GetByteArrayElements(data, 0);
	
//	if (PAIEnvironment::getEnvironment()->isVerbose()) {
//		cout << "JNIImp: sending: " << len << " bytes of data: " << endl;
//		cout << "JNIImp: sending: " << bdata << endl;
  //      }

	jenv->getPCI()->send(ps, jenv->getPCI()->createAddress(str,port), (const char *)bdata, (unsigned int)len);

//	if (PAIEnvironment::getEnvironment()->isVerbose())
//		cout << "JNIImp: sent: "<< endl;

	env->ReleaseStringUTFChars(address, str);
	env->ReleaseByteArrayElements(data, bdata, 0);
	//delete[] tmp_buf;
	
	return true;
}

/*
 * Class:     pai_imp_PAINative
 * Method:    recv
 * Signature: (I)[B
 */
JNIEXPORT jbyteArray JNICALL Java_pai_imp_jni_PAINative_recv
(JNIEnv *env, jobject obj, jint sockID) {
	unsigned int len=50000;
	
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: recv, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 

	PAIInetAddress *address=new PAIInetAddress();
	LinkedList *sockets = jenv->getSockets();
	PAISocket* ps = (PAISocket *)sockets->getItem(sockID);

	char* data = jenv->getPCI()->recv(ps, &address, &len);

	if (len==0) return NULL; // not able to read

	jclass cls = env->GetObjectClass(obj);
	jmethodID mid = env->GetMethodID(cls, "setDatagramDetails", "(Ljava/lang/String;)V");
	if (mid == 0) {
		cerr << "JNIImp: recv, setDatagramPacketAddress Method NOT FOUND !!!!" << endl;
        	return NULL;
	} else {
		env->CallVoidMethod(obj, mid, env->NewStringUTF( address->getAddress() ));
	//	cout << "JNIImp: recv, made Datagram callback!!!!" << endl;
	}

	jfieldID fid;
	  
	// get the local Java instance variable for the _port
	 
	fid = env->GetFieldID(cls, "_port", "I");
	  
	if (fid==0) {
		cout << "JNIImp: FATAL Cannot find PAINative _port ...." << endl;
		return NULL;
		}
		  
	// sets the pointer within the Java class so we have a reference to it as long as we need it 	  
	env->SetIntField(obj, fid, (int)address->getPort());


	jbyteArray bdata = env->NewByteArray(len);

	env->SetByteArrayRegion(bdata, 0, len, (jbyte *)data);

	//delete data;
	//delete address;
	
	// cout << "JNIImp: recv, exiting!!!!" << endl;

	return bdata;
}

/*
 * Class:     pai_imp_PAINative
 * Method:    setMulticast
 * Signature: (IZ)V
 */
JNIEXPORT void JNICALL Java_pai_imp_jni_PAINative_setMulticast
(JNIEnv *env, jobject obj, jint sockID, jboolean val) {

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: setMulticast, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 
	LinkedList *sockets = jenv->getSockets();
	PAISocket* ps = (PAISocket *)sockets->getItem(sockID);

	jenv->getPCI()->setMulticast(ps,val);
}

/*
 * Class:     pai_imp_PAINative
 * Method:    joinGroup
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_pai_imp_jni_PAINative_joinGroup
(JNIEnv *env, jobject obj, jint sockID, jstring address) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: joingGroup, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 
	LinkedList *sockets = jenv->getSockets();
	PAISocket* ps = (PAISocket *)sockets->getItem(sockID);

	const char *str = env->GetStringUTFChars(address, 0);

	jenv->getPCI()->joinGroup(ps, str);

	env->ReleaseStringUTFChars(address, str);
}

/*
 * Class:     pai_imp_PAINative
 * Method:    leaveGroup
 * Signature: (ILjava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_pai_imp_jni_PAINative_leaveGroup
  (JNIEnv *env, jobject obj, jint sockID, jstring address) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: leaveGroup, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 

	LinkedList *sockets = jenv->getSockets();
	PAISocket* ps = (PAISocket *)sockets->getItem(sockID);

	const char *str = env->GetStringUTFChars(address, 0);

	jenv->getPCI()->leaveGroup(ps, str);

	env->ReleaseStringUTFChars(address, str);
}

/*
 * Class:     pai_imp_PAINative
 * Method:    getNativeLocalHost
 * Signature: ()Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_pai_imp_jni_PAINative_getNativeLocalHost
(JNIEnv *env, jobject obj) {

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: getNativeLocalHost, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 

    Agentj *broker = getAgentjObject(env,obj);
	const char* address = broker->getLocalAddress(); // gets NS2 node address
	                 // Need LOCAL Reference here: jenv->getPCI()->getLocalHost();

	return env->NewStringUTF(address);
}
 
/*
 * Class:     pai_imp_PAINative
 * Method:    getAddressByName
 * Signature: (Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_pai_imp_jni_PAINative_getAddressByName
(JNIEnv *env, jobject obj, jstring address) {

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: getAddressByName, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 

	const char *str = env->GetStringUTFChars(address, 0);

	const char* addr = jenv->getPCI()->getAddressByName(str);

	env->ReleaseStringUTFChars(address, str);

	return env->NewStringUTF(addr);
}

/*
 * Class:     pai_imp_PAINative
 * Method:    cleanUp
 * Signature: ()Z
 */
JNIEXPORT jboolean JNICALL Java_pai_imp_jni_PAINative_cleanUp
(JNIEnv *env, jobject obj) {

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: cleanUp, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 

	jenv->getPCI()->cleanUp();
	jenv->getPTI()->cleanUp();

    delete jenv;
	    
	return true;
	}

/*
 * Class:     pai_imp_PAINative
 * Method:    runBlock
 * Signature: ()Z
 */
JNIEXPORT jboolean JNICALL Java_pai_imp_jni_PAINative_runBlock
(JNIEnv *env, jobject obj) {

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: runBlock, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 

	jenv->getPCI()->runBlock();
	return true;
	}

/*
 * Class:     pai_imp_PAINative
 * Method:    runNonBlock
 * Signature: ()Z
 */
JNIEXPORT jboolean JNICALL Java_pai_imp_jni_PAINative_runNonBlock
(JNIEnv *env, jobject obj) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: runNonBlock, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 
	jenv->getPCI()->runNonBlock();
	return true;
}

/*
 * Class:     pai_imp_PAINative
 * Method:    setReuseAddress
 * Signature: (IZ)V
 */
JNIEXPORT void JNICALL Java_pai_imp_jni_PAINative_setReuseAddress
  (JNIEnv *env, jobject obj, jint sockID, jboolean val) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: setReuseAddress, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 

	LinkedList *sockets = jenv->getSockets();
	PAISocket* ps = (PAISocket *)sockets->getItem(sockID);

	jenv->getPCI()->setReuseAddress(ps,val);
}

/*
 * Class:     pai_imp_PAINative
 * Method:    setSendBufferSize
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_pai_imp_jni_PAINative_setSendBufferSize
(JNIEnv *env, jobject obj, jint sockID, jint len) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: setSendBufferSize, entering" << endl;
	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 

	LinkedList *sockets = jenv->getSockets();
	PAISocket* ps = (PAISocket *)sockets->getItem(sockID);

	jenv->getPCI()->setSendBufferSize(ps,len);
}

/*
 * Class:     pai_imp_PAINative
 * Method:    setReceiveBufferSize
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_pai_imp_jni_PAINative_setReceiveBufferSize
  (JNIEnv *env, jobject obj, jint sockID, jint len) {

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: setReceiveBufferSize, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 

	LinkedList *sockets = jenv->getSockets();
	PAISocket* ps = (PAISocket *)sockets->getItem(sockID);

	jenv->getPCI()->setReceiveBufferSize(ps,len);
}

/*
 * Class:     pai_imp_PAINative
 * Method:    setSoTimeout
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_pai_imp_jni_PAINative_setSoTimeout
  (JNIEnv *env, jobject obj, jint sockID, jint timeout) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: setSoTimeout, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 

	LinkedList *sockets = jenv->getSockets();
	PAISocket* ps = (PAISocket *)sockets->getItem(sockID);

	jenv->getPCI()->setSoTimeout(ps,timeout);
}


/*
 * Class:     pai_imp_PAINative
 * Method:    addNativeTimer
 * Signature: (DI)I
 */
JNIEXPORT jint JNICALL Java_pai_imp_jni_PAINative_addNativeTimer
(JNIEnv *env, jobject obj, jdouble delay, jint repeat) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: addNativeTimer, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);

    Agentj *broker = getAgentjObject(env,obj);
    //cout << "JNIImp: addNativeTimer, pointer to broker is " << broker << endl;
	jenv->getPAI()->setDispatcher(broker); // sets the dispatcher to the NS node

	LinkedList *timers = jenv->getTimers();

	PAITimer* timer = (jenv->getPTI())->addTimer(delay, repeat);

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIBridge: addNativeTimer: created timer, pointer is " << timer << endl;

	timers->addItem(timer);
	ListItem *li = timers->getListItem(timer);
	return li->getID(); // returns the ID
}

/*
 * Class:     pai_imp_PAINative
 * Method:    removeNativeTimer
 * Signature: (I)V
 */
JNIEXPORT void JNICALL Java_pai_imp_jni_PAINative_removeNativeTimer
(JNIEnv *env, jobject obj, jint timerID) {

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: removeNativeTimer, entering" << endl;

	LinkedList *timers = jenv->getTimers();

	PAITimer* timer = (PAITimer *)timers->getItem(timerID);

	jenv->getPTI()->removeTimer(timer);

}

/*
 * Class:     pai_imp_PAINative
 * Method:    addPAITimerListener
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL Java_pai_imp_jni_PAINative_addPAITimerListener
(JNIEnv *env, jobject obj, jint timerID) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: addPAITimerListener, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 

    Agentj *broker = getAgentjObject(env,obj);
  //  cout << "JNIImp: addTimerListener, pointer to broker is " << broker << endl;
//	jenv->getPAI()->setDispatcher(static_cast<ProtoSim*>(broker)); // sets the dispatcher to the NS node

	jenv->getPAI()->setDispatcher(dynamic_cast<ProtoSim*>(broker)); // sets the dispatcher to the NS node

	return jenv->createJavaTimerCallback(timerID);
}


/*
 * Class:     pai_imp_PAINative
 * Method:    removePAITimerListener
 * Signature: (II)V
 */
JNIEXPORT void JNICALL Java_pai_imp_jni_PAINative_removePAITimerListener
(JNIEnv *env, jobject obj, jint timerID, jint listID) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: removePAITimerListener, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 

	// create Java callback for socket ps and adds created listener
	// to listeners for this socket
	
	jenv->removeJavaTimerCallback(timerID, listID); // removes it from withon PAI also
}

/*
 * Class:     pai_imp_PAINative
 * Method:    runTimers
 * Signature: ()Z
 */
JNIEXPORT jboolean JNICALL Java_pai_imp_jni_PAINative_runTimers
(JNIEnv *env, jobject obj) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "JNIImp: runTimers, entering" << endl;

	JNIBridge *jenv = getJNIBridgeObject(env, obj);	 
	
	jenv->getPTI()->runTimers();
	return true;
}

