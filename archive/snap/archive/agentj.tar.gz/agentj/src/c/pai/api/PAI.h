#ifndef _PAI
#define _PAI

#include "PAIEngine.h"
#include "PAIFactory.h"
#include "PAIEnvironment.h"
#include "PAIInetAddress.h"

// Class PCI: simple interface to the Protolib library that contains
// the functionality we need for the P2PS NS-2 integration
class PCI {
	friend class PAI;
    public:
		PCI() { };

		PAISocket *addSocket(unsigned int portNumber) {
			return theEngine->addSocket(portNumber); }

		PAISocketListener *addListener(PAISocket *sock, PAIOwner *callingClass, CallbackFunc socketListener) {
			return theEngine->addSocketListener(sock, callingClass, socketListener); }

		void removeListener(PAISocket *sock, PAISocketListener *list) {
			theEngine->removeSocketListener(sock, list); }

		void removeSocket(PAISocket *theSocket) {
			theEngine->removeSocket(theSocket); }

		bool send(PAISocket *sock, const PAIInetAddress *address, const char *data, unsigned int length) {
		    // had to duplicate PAIInetAddress as name was being written over - seems ok now but
			// leave here until testing is over
			// return sock->send(new PAIInetAddress(address->getAddress(), address->getPort()), data, length); }
			return sock->send(address, data, length); }

		char *recv(PAISocket *sock, PAIInetAddress **address, unsigned int *length) {
			return sock->recv(address, length); }

		void setMulticast(PAISocket *sock, bool val) {
			sock->setMulticast(val); }

		void joinGroup(PAISocket *sock, const char* groupAddress) {
			sock->joinGroup(groupAddress); }

		void leaveGroup(PAISocket *sock, const char* groupAddress) {
			sock->leaveGroup(groupAddress); }

		const char *getLocalHost() {
			return PAIInetAddress::getLocalHost(); }

		const char *getAddressByName(const char *address) {
			return PAIInetAddress::getAddressByName(address); }

		const  PAIInetAddress *createAddress(const char *address, int port) {
			return new PAIInetAddress(address, port); }

		void setReuseAddress(PAISocket *sock, bool on) {
			sock->setReuseAddress(on); }

		void setSendBufferSize(PAISocket *sock, int size) {
			sock->setSendBufferSize(size); }

		void setReceiveBufferSize(PAISocket *sock, int size) {
			sock->setReceiveBufferSize(size); }

		void setSoTimeout(PAISocket *sock, int timeout) {
			sock->setSoTimeout(timeout); }

		bool cleanUp() { 	    
			cout << "PCI: cleaning up" << endl;
			return theEngine->CleanUp(); }

		/**
		 * Tells PCI to listen for events indefinitely.  This has the effect of
		 * blocking the calling program so that the control is given to the callback
		 * mechanims.
		 */
		bool runBlock() { theEngine->runDispatcher(); return true; }

		bool runNonBlock() { theEngine->runDispatcherNonBlock(); return true; }

	private:
		PAIEngine *theEngine;

}; // end class PCI

// Class PTI: simple interface to the Protolib timer library
class PTI {
	friend class PAI;
    public:
		PTI() { } 

		PAITimer *addTimer(double delay, int repeat) { return theEngine->addTimer(delay, repeat); }        

		PAITimerListener *addListener(PAITimer *timer, PAIOwner *callingClass, CallbackFunc socketListener) {
			return theEngine->addTimerListener(timer,callingClass, socketListener); }

		void removeListener(PAITimer *timer, PAITimerListener *list) {
			theEngine->removeTimerListener(timer,list); }

		void removeTimer(PAITimer *timer) {
			theEngine->removeTimer(timer); }

		bool cleanUp() { 	    
			cout << "PTI: cleaning up" << endl;
			return theEngine->CleanUp(); }

		/**
		 * Runs PTI until the timers run out. If a timer is set to indefinite repeats
		 * then this function never returns and has the same effect as the listen
		 * function above
		 */
		bool runTimers() { theEngine->runWhilstTimerIsActive(); return true; }

	private:
		PAIEngine *theEngine;

}; // end class PTI_Engine


class PAI {
private:
	PTI pti;
	PCI pci;
	PAIFactory *factory;
	PAIEngine *theEngine;
	PAIDispatcher *dispatcher;
//	PAIEnvironment* env;

	bool DummyTimeOut() { return true; }

	// Move to dispatcher class if this is permanent
	void tempDispatcherFudge();

public:
	PAI();

	PTI *getPTI() { return &pti; }
	PCI *getPCI() { return &pci; }

	void *getDispatcher() { return dispatcher; }
	void *setDispatcher(void *disp) { dispatcher->setDispatcher(disp); }

	PAIEnvironment* getEnvironment() {
		return PAIEnvironment::getEnvironment();
	}

	bool cleanUp() { 
	 //   cout << "PAI: cleaning up" << endl;
		pti.cleanUp(); pci.cleanUp(); }
	
};

#endif // _PAI
