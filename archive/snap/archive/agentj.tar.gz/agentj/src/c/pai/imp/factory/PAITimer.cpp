#include "PAITimer.h"
#include "iostream.h"

PAITimer::PAITimer(double delay, int repeat, PAIDispatcher *eventDispatcher)
: PAIMultipleListener("PAITimer") {
    setDelay(delay);
	setRepeat(repeat);
	edispatcher = eventDispatcher;
}

PAITimer::~PAITimer() { 
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAITimer: destructor" << endl;
	deleteListeners(); // delete all listeners for this timer
	}


PAITimerListener* PAITimer::addListener(PAIOwner *callingClass, CallbackFunc socketListener) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAITimer: adding socket listener" << endl;
	return (PAITimerListener *)PAIMultipleListener::addListener(callingClass, socketListener);
}

bool PAITimer::removeListener(PAITimerListener* listener) {
	return PAIMultipleListener::removeListener(listener);
}


// this gets called when the timer times out
bool PAITimer::TimerTimeOut() {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAITimer: timer timed out" << endl;
	PAIEvent *p = new PAIEvent(this, "Timer Triggered ...");
    return PAIMultipleListener::sendEventsToListeners(p);
}

PAIDispatcher *PAITimer::getEventDispatcher() {
	return edispatcher; 
}

