#ifndef _JNI_BRIDGE
#define _JNI_BRIDGE

#include "PAI.h"
#include <jni.h>
#include "Agentj.h"

class JNIBridge {
	public:
		JNIBridge();
		~JNIBridge() { delete pai; } // should be automatic through the pai class

		/**
		 * @return ID of the listener for this socket
		 */
		int createJavaSocketCallback(int sockID);

		void removeJavaSocketCallback(int sockID, int listenerID);

		int createJavaTimerCallback(int timerID);

		void removeJavaTimerCallback(int timerID, int listenerID);

		PTI *getPTI() { return pti; }
		PCI *getPCI() { return pci; }
		PAI *getPAI() { return pai; }

		void setJVM(JavaVM *jvmref) { jvm=jvmref; }

		LinkedList *getSockets() { return &sockets; }
		LinkedList *getSocketListeners() { return &slisteners; }

		LinkedList *getTimers() { return &timers; }
		LinkedList *getTimerListeners() { return &tlisteners; }

        int schedulerPtr;
        
    private:
		PAI *pai;
		PTI *pti;
		PCI *pci;
		
		Agentj *ns2NodePtr; // DO NOT DESTROY after use !!! this is our NS2 agent.
		
		LinkedList sockets;
		LinkedList slisteners;
		LinkedList timers;
		LinkedList tlisteners;

		// JAVA METHOD ID'S for callback
		jmethodID socketListenerCallbackFuncID;
		jmethodID timerListenerCallbackFuncID;

		jclass cls;
		JNIEnv *env;
		JavaVM *jvm; /* The virtual machine instance */

		bool socketCallbackFunc(PAIEvent *e);
		bool timerCallbackFunc(PAIEvent *e);
};

#endif // _JNI_BRIDGE

