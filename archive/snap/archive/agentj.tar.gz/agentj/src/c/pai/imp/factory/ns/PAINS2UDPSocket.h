#ifndef _PAINS2UDPSocket
#define _PAINS2UDPSocket

#include "PAIDefs.h"
// PROTOLIB_HOME is set in ONE place, in PAIDefs.h
#include PROTOLIB_HOME
#include "nsProtoAgent.h"
#include "ProtoSim.h"

#include "PAISocket.h"

class SockCallback;

/**
 * A PAI Socket: There are different implementations depending on what type of socket
 * we are dealing with i.e. UDP or TCP etc.  One implementation exits - UDPSocket which
 * binds this to the Protolib UDP implementation
 */
 class PAINS2UDPSocket : public PAISocket {
	public:

		PAINS2UDPSocket(PAIEnvironment *penv, PAIDispatcher *eventDispatcher, unsigned int port);

		~PAINS2UDPSocket() { socket.Close();}

		/**
		 * generalized sending routine ....
		 */
		bool send(const PAIInetAddress *address, const char *data, unsigned int length);

		/**
		 * generalized receiving routine ....
		 */
		char *recv(PAIInetAddress **address, unsigned int *length);

		UdpSocket *getSocket() { return &socket; }

		// variable used to make sure that the Win32Init function in the dispatcher
		// is only called once

		/**
		 * Generic callback to the registered socket listener function. The
		 * actual socket reference is passed to this function and this will
		 * be the end implementing protolib class e.g. UdpSocket etc
		 */
		bool socketReceivedData(UdpSocket* theSocket) {
			PAIEvent *p = new PAIEvent(this, "Socket Received Data");
			return PAIMultipleListener::sendEventsToListeners(p);
			}

		/**
		 *
		 * Adds the specified listener to this socket
		 */
		PAISocketListener* addListener(PAIOwner *callingClass, CallbackFunc socketListener);

		/**
		 *
		 * Removes the specified listener from this socket - overrides basic functionality
		 */
		bool removeListener(PAISocketListener* listener);


		/**
		 * Enables multicase support for this socket
		 */
		void setMulticast(bool val);

		/**
		 * Joins the given multicast group
		 */
		void joinGroup(const char* groupAddress);

		/**
		 * leaves the given multicast group
		 */
		void leaveGroup(const char* groupAddress);

		static bool win32Called;

		void setReuseAddress(bool on) {
			socket.SetReuse(on);
		}

		void setSendBufferSize(int size) {
			socket.SetTxBufferSize((unsigned int)size);
		}

		void setReceiveBufferSize(int size) {
			socket.SetRxBufferSize((unsigned int)size);
		}

		void setSoTimeout(int timeout) {
		// NOT implemented in Protolib UDP socket
		}

	private:
		UdpSocket socket;
		SockCallback *sockHelper;
		NsProtoAgent *disp;
}; // end class PCISocket

/**
 * This class is here to help PAINS2UDPSocket with the callback mechanism.  I got a compiler
 * cast error when I put the socketReceivedData in PAINS2UDPSocket. Didn't  found out why exactly
 * but it could be for the following reasons:
 *
 * (1) because PAINS2UDPSocket subclasses other classes
 * (2) because PAIsocket contains virtual functions - this gives the typecast problems
 * because the class is not complete - it can be extended later
 *
 * This is a workaround.
 */
class SockCallback {
	public:
		SockCallback(PAINS2UDPSocket *pais) {
			paisock=pais;
		}

	PAINS2UDPSocket *paisock;

	bool socketReceivedData(UdpSocket* theSocket) {
		return paisock->socketReceivedData(theSocket);
	}
};

#endif // _PAINS2UDPSocket
