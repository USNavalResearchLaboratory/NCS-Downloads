#ifndef _PAINS2Timer
#define _PAINS2Timer

#include "PAIDefs.h"
#include PROTOLIB_HOME

#include "nsProtoAgent.h"

#include "PAITimer.h"

/**
 * A PAI Timer: This catches the timing events for a Protolib Protocol Timer
 * implementation and customizes them for sending back to the PAI application.
 * PAINS2Timers can also have ID's and are a much cimplified version of Protocol
 * timers.  Later, we may add events to PAI
 */
class PAINS2Timer : public PAITimer {
	public:
		/**
		 *
		 */
		PAINS2Timer(double delay, int repeat, PAIDispatcher *eventDispatcher);

		~PAINS2Timer();

		PAITimerListener* addListener(PAIOwner *callingClass, CallbackFunc socketListener);

		bool removeListener(PAITimerListener* listener);

    private:
		ProtocolTimer timer;
		ProtocolTimerMgr timer_mgr;
		NsProtoAgent *disp;
}; // end class PAINS2Timer

#endif // _PAINS2Timer
