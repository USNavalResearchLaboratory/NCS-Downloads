#ifndef _PAIDispatcher
#define _PAIDispatcher

#include <iostream.h>

#ifdef UNIX
#define _REENTRANT
#include <pthread.h>
#endif

// IF we are not running within NS-2 do not include this code - otherwise we will have to include
// all of the NS-2 stuff to compile it which means we'll use the alternate UDP implementation also
// and get a compile error......
#ifndef NETWORK_MODE
#include "protoSim.h"
#endif

#include "PAIDefs.h"
// PROTOLIB_HOME is set in ONE place, in PAIDefs.h
#include PROTOLIB_HOME

typedef UdpSocketInstallFunc SocketInstallFunc;

/**
 * A PAI Dispatcher: Base class doe event dispatchers.  This is just here to
 * abstract our only availabe dispatcher - i.e. the protolib dispatcher.  The
 * PAIFactory creates a dispatcher based on user preferences - they don;t have
 * any choice for now but this makes it easily extendible for adding future
 * dispatchers
 */
class PAIDispatcher {
	public:
		/**
		 * Creates a PAI Dispatcher
		 */
		PAIDispatcher();

		~PAIDispatcher();

		/**
		 * generic mechansim for running any dispatcher subclassed from this class
		 * in a non-blocking fashion
		 */
		void runNonBlock();

		// list of support functions: add more as we require them
		virtual void run()=0;
		virtual void stop(int code)=0;

		void *getDispatcher() { return dispatcher; }
		void setDispatcher(void *disp) { dispatcher=disp; }

		bool isRunning() { return running; }
		void setRunning(bool val) { running=val; }

    private:
		void *dispatcher;
		bool running;
		void runThread();

#ifdef NETWORK_MODE // ONLY THREAD in network mode NOT IN NS2
// Threading for running the disp-atcher thread.  Unfortunately, we have to
// create two different implementations since they no common standard available
// by default to UNIX and Windows
#ifdef WIN32
		static DWORD WINAPI runDispatcherThread(LPVOID); /* Function prototype */
	    HANDLE dispatcherThreadID;
		unsigned long iID;
#endif // WIN32

#ifdef UNIX
		static void *runDispatcherThread(void *objID);
		pthread_t dispatcherThreadID;
#endif // UNIX
#endif // NETWORKED MODE

}; // end class PAIDispatcher

#ifdef NETWORK_MODE
/**
 * An interface to the Protolib Dispatcher with limited functionality. Add more
 * as needed.
 */
 class ProtolibDispatcher : public PAIDispatcher {
	public:
		/**
		 * Creates a PAI Dispatcher
		 */
		ProtolibDispatcher () { setDispatcher(new EventDispatcher()); }

		~ProtolibDispatcher () {}

		/**
		 * Runs the dispatcher and blocks until it finishes
		 */
		void run();

		/**
		 * Stops the dispatcher
		 */
		void stop(int code);

}; // end class PAIDispatcher

#else

/**
 * An interface to the NS agent that replaces a dispatcher's functionality within NS-2
 */
 class NSProtolibDispatcher : public PAIDispatcher {
	public:
		/**
		 * Creates a PAI Dispatcher
		 */
		NSProtolibDispatcher () {
			}

		~NSProtolibDispatcher () {}

		/**
		 * Runs the dispatcher and blocks until it finishes
		 */
		void run();

		/**
		 * Stops the dispatcher
		 */
		void stop(int code);

}; // end class PAIDispatcher

#endif // Not NETWORK MODE i.e. running within NS-2

#endif // _PAIDispatcher
