#ifndef _PAITimer
#define _PAITimer

#include "PAIMultipleListener.h"
#include "PAIDispatcher.h"

/**
 * A PAI Timer: Abstract timer definition for timers. Two subclasses - a default one and one for Ns-2
 */
class PAITimer : public PAIMultipleListener {
	public:
		/**
		 *
		 */
		PAITimer(double delay, int repeat, PAIDispatcher *eventDispatcher);

		~PAITimer();

		virtual PAITimerListener* addListener(PAIOwner *callingClass, CallbackFunc socketListener);

		virtual bool removeListener(PAITimerListener* listener);

		void setDelay(double d) { delay=d; }
		void setRepeat(int r) { repeat=r; }

		double getDelay() { return delay; }
		int setRepeat() { return repeat; }

		PAIOwner *getOwner();
		CallbackFunc getCallbackFunc();
		PAIDispatcher *getEventDispatcher();

    private:
		int repeat;
		double delay;
		PAIOwner *timerListenerClass; // Pointer to class that contains the timer listener function
		CallbackFunc tListener; // Offset pointer to timer action

		// this is the particular event dispatcher you want to use to
		// generate the events.  For the protolib classes, this will be dispatcher
		PAIDispatcher *edispatcher;
    protected:
		// callback routines: for timer timeouts on this timer
		bool TimerTimeOut();

}; // end class PAITimer

#endif // _PAITimer
