#include "PAISocket.h"
#include <stdlib.h>
#include <iostream.h>

PAISocket::PAISocket(PAIEnvironment *penv, PAIDispatcher *eventDispatcher) 
: PAIMultipleListener("PAISocket") {
	env=penv;
	edispatcher = eventDispatcher;
	setSocketBufferLength(env->getSocketBufferLength());
	socketBuffer = new char[getSocketBufferLength()];
	port = 0; 
}

PAISocket::~PAISocket() {
	delete[] socketBuffer;
	deleteListeners(); // delete all listeners for this socket
}

 
PAISocketListener* PAISocket::addListener(PAIOwner *callingClass, CallbackFunc socketListener) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAISocket: adding listener" << endl;
	return (PAISocketListener *)PAIMultipleListener::addListener(callingClass, socketListener);
}

bool PAISocket::removeListener(PAISocketListener* listener) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAISocket: removing socket listener" << endl;

	return PAIMultipleListener::removeListener(listener);
}


PAIDispatcher *PAISocket::getEventDispatcher() { 
	return edispatcher; 
}

unsigned int PAISocket::getPort() { 
	return port; 
}

void PAISocket::setPort(unsigned int portNumber) { 
	port=portNumber; 
}

