#include "PAIDefaultTimer.h"
#include "iostream.h"

PAIDefaultTimer::PAIDefaultTimer(double delay, int repeat, PAIDispatcher *eventDispatcher)
: PAITimer(delay, repeat, eventDispatcher) {
cout << "TIMER: Init" << endl;

	edisp = (EventDispatcher *)eventDispatcher->getDispatcher();
    	timer.Init(delay, repeat,
                 (ProtocolTimerOwner*)this,
                 (ProtocolTimeoutFunc)&PAITimer::TimerTimeOut);
}

PAIDefaultTimer::~PAIDefaultTimer() {
	timer.Deactivate();
}


PAITimerListener* PAIDefaultTimer::addListener(PAIOwner *callingClass, CallbackFunc socketListener) {
cout << "TIMER: Adding timer" << endl;
	edisp->InstallTimer(&timer);
cout << "TIMER: Added timer" << endl;
	return PAITimer::addListener(callingClass, socketListener);
}

bool PAIDefaultTimer::removeListener(PAITimerListener* listener) {
	edisp->RemoveTimer(&timer);
	return PAITimer::removeListener(listener);
}
