#include "PAIEnvironment.h"

PAIEnvironment::PAIEnvironment() {

    setUpLogging();

	socketBufferLength=50000;
	binding=NETWORKING;
	networkProtocol=UDP_SOCKET;
	timerProtocol=DEFAULT_TIMER;
#ifndef NETWORK_MODE
// UGLY, but no way out -we have to use if defs because of the separate UDP implementation for NS2.  If we include
// ANY of the NS2 stuff we end up including all the classes which means that our applicaiton will not compile since
// there exists 2 implementations of the udpSocket class in UdpSocket and ProtoSim
	setBinding(NS_2);
	setDispatcherType(NS2_DISPATCHER);
#else
	dispatcher=DEFAULT_DISPATCHER;
#endif
	}


void PAIEnvironment::setUpLogging() {

	char *debug = getenv ("AGENTJDEBUG");

	cout << "PAIEnvironment::setUpLogging : Logging se to :" << debug << ":" << endl;

	if (strcmp(debug,"ON")==0) {
	    cout << "PAIEnvironment::setUpLogging : Logging Turned on" << endl;
	    verbose=true;
	} else
	    verbose=false;
}

 
