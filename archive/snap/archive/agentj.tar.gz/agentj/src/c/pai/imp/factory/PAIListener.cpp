#include "PAIListener.h"

PAIListener::PAIListener(PAIMultipleListener *theParent, PAIOwner *ownerClass, CallbackFunc callbackFunc) {
	listenerClass=ownerClass;
	sListener = callbackFunc;
	parent=theParent;
	}

bool PAIListener::generateCallback(PAIEvent *event) {
	event->setID((int)this);
	if (sListener!=NULL) {
		(listenerClass->*sListener)(event);
	} else {
		cerr << "PAIListener: No listener attached, cannot make callback....." << endl;
		return false;
	}
	return true;
}
