
// PAI.cpp - Placeholder for including the PAI library

#include "PAI.h"

// Make ONE and only copy of this env class. Define it here so programmers cannot
// multiply define it

PAIEnvironment *PAIEnvironment::env;

PAI::PAI() {
		if (PAIEnvironment::getEnvironment()->isVerbose())
			cout << "PAI: Creating PAI....." << endl;
		PAIEnvironment *env = PAIEnvironment::getEnvironment();
 
		if (PAIEnvironment::getEnvironment()->isVerbose())
			cout << "PAI: Creating Factory....." << endl;

		factory = new PAIFactory(env);
		if (PAIEnvironment::getEnvironment()->isVerbose())
			cout << "PAI: Creating Dispatcher....." << endl;
		try {
			dispatcher = factory->createDispatcher();
		} catch (PAIError *e) { 
			e->printError();
		}
		if (PAIEnvironment::getEnvironment()->isVerbose())
			cout << "PAI: Created dispatcher" << endl;
		theEngine = new PAIEngine(factory, dispatcher);
		if (PAIEnvironment::getEnvironment()->isVerbose())
			cout << "PAI: Created Engine" << endl;
		pci.theEngine = theEngine;
		pti.theEngine = theEngine;
		if (PAIEnvironment::getEnvironment()->isVerbose())
			cout << "PAI: Created PAI" << endl;

#ifdef NETWORK_MODE
		tempDispatcherFudge();
#endif
	}

void PAI::tempDispatcherFudge() {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAI: Setting Timer off for Dispatcher Fudge" << endl;
	PAITimer *timer = pti.addTimer(100.0, -1);
	pti.addListener(timer, (PAIOwner *)this, (CallbackFunc)&PAI::DummyTimeOut);
	pci.runNonBlock();
	}

