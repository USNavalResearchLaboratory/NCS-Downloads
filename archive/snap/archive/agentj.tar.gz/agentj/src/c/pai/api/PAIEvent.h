#ifndef _PAIEvent
#define _PAIEvent

/**
 * Simple class for PAI events.  The events just contain the object that generated
 * the event and the reason why the event was generated e.g. Socket Received Data 
 * or something like that
 */
class PAIEvent {
public:
   /**
	* Constructs a PAIEvent for a particular sending object and with a command
	*/
	PAIEvent(void *obj, const char* com) { object = obj; command=com; }

   /**
	* Sets the ID for this Event - this is set to the PAIlistener which
	* generated the event.  Note also within the PAIListener you have a 
	* reference back to the PAI Socket that generated the event so you
	* can access everything you should need ....
	*/
	void setID(int eventID) { id=eventID; }

   /**
	* @return the ID for this Event i.e. the PAIListener
	*/
	int getID() { return id;}

	/**
	* @return a pointer to the class that generated this event
	*/
	void *getObject() { return object; }

   /**
	* @return the description of the event i.e. reason why it was generated
	*/
	const char *getCommand() { return command; }
private:
	void *object; // Pointer to class that generated this event
	const char* command; // pointer to the command i.e. the reason for this event
	int id;
};

#endif // _PAIEvent
