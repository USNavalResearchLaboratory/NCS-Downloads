#ifndef _PAIInet
#define _PAIInet

#include <string.h>

#include "PAIDefs.h"
// PROTOLIB_HOME is set in ONE place, in PAIDefs.h
#include PROTOLIB_HOME

/**
 * Simple class for interfacing with NetworkAddress and to provide a simple interface
 * for constructing Network Addresses, consisting of a destination IP Address and port,
 * that can be used to send packets using the UDP protocol or represent destination addresses
 * for other protocols
 */
class PAIInetAddress {

friend class PAIUDPSocket;
friend class PAINS2UDPSocket;

public:

  	/**
	 * An empty PAIInetAddress object for receiving address information
	 */
	PAIInetAddress() {}

	/**
	 * There's nothing to delete here because because the address is a const so we cannot
	 * do anything to it anyway (including deleting....) - the deallocation is up to the calling routine
	 */
	~PAIInetAddress() {}

  	/**
	 * An PAIInetAddress object with an IP Address and a port
	 */
	PAIInetAddress(const char *address,  int port) { 
		 if (PAIEnvironment::getEnvironment()->isVerbose())
			cout << "PAIInetAddress: Constructor Address: " << address << endl;
	     address_=new char[strlen(address)+1];
		 // make a copy to ensure the contents do not get changed later down the chain
	     strcpy(address_, address);
         port_=port; 
		 }

	void setPort(int port) {port_=port;}

	/**
	 * Sets the internal address field to the one specified. PAIInetAddress alloactes its own memeory for
	 * the storage of this data so that it can safely delete it upon destruction
	 */
	void setAddress(const char *address) {
		 if (PAIEnvironment::getEnvironment()->isVerbose())
	         cout << "PAIInetAddress: Address: " << address << endl;
	     address_=new char[strlen(address)+1];
	     strcpy(address_, address);
		 }

	int getPort() {return port_;}

	const char *getAddress() {return address_; }

       /**
	* @return a pointer to the class that generated this event
	*/
	static const char *getAddressByName(const char* address) {
		NetworkAddress addr;
		addr.LookupHostAddress(address);
	    DMSG(0, "protoApp:: local EndIdentifier: %0x\n", addr.EndIdentifier());

		return addr.HostAddressString();
		}

	static const char *getLocalHost() {
		NetworkAddress addr;
		//char buffer[255];
		
//		addr.LookupLocalHostAddress(buffer, 128);
		//addr.LookupHostName(buffer, 255);
	    //DMSG(0, "protoApp:: local EndIdentifier: %0x\n", addr.EndIdentifier());

		//return addr.HostAddressString();
		
		return addr.HostAddressString();
	}
	
private:
	char *address_;
	int port_;
};

#endif // _PAIInetAddress
