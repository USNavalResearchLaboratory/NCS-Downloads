#include "PAIEngine.h"

PAIEngine::PAIEngine(PAIFactory *fact, PAIDispatcher *disp) {
	env=PAIEnvironment::getEnvironment();
	factory=fact;

	dispatcher = disp;

	signal(SIGTERM, SignalHandler);
	signal(SIGINT, SignalHandler);
	initializedWIN32=false;
}


bool PAIEngine::runDispatcherNonBlock() { 
	dispatcher->runNonBlock();
	return true;
}

/**
 * Starts the engine to do asynchronous sends and receives. If no timer is installed then
 * Run bacially acts as an event detector that forwards requests onto the 
 * event listeners (for socket receives).  If a timer is installed then the 
 * events for the timer and the sockets are generated.
 *
 * Run starts in a separate thread using CreateThread on Windows or pthread on UNIX so
 * that the event dispatching is performed in the background and the application
 * developers does not have to worry about these mechanims.
 */
bool PAIEngine::runDispatcher() {
    dispatcher->run();
	return true;
}


bool PAIEngine::runWhilstTimerIsActive() {
	runDispatcherNonBlock();

    ProtocolTimer *timer;
	timer = (ProtocolTimer *)timers.getItem(0); // must fix this - only works for 1 timer

	// VERY crude but works ...
	do {
		PAISleep(100); // 1/10th of a second - should be acceptable
    } while(timer->IsActive());
	return true;
}

/**
 * The PAI Sleep function - sleeps for a specified number o milliseconds.
 * This WILL NOT work with NS-2 though .....
 */
bool PAIEngine::PAISleep(long millis) {
#ifdef UNIX
	sleep(millis);
#endif
#ifdef Win32
	Sleep(millis);
#endif
	return true;
}


/**
 * Create a custom timer with a delay between timeouts and the
 * number of repeats (-1 = repeat forever)
 */
PAISocket *PAIEngine::addSocket(unsigned int portNumber) {
	PAISocket *socket;
	ListItem *l;
	int id;

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIEngine: entering addSocket" << endl;

	try {
		socket = factory->createSocket(portNumber);
	} catch (PAIError *e) {
		e->printError();
	}

	l = sockets.addItem(socket);
	id = l->getID();
	socket->setID(id);

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIEngine: leaving addSocket" << endl;

	return socket;
}

PAISocketListener *PAIEngine::addSocketListener(PAISocket *sock, PAIOwner *callingClass, CallbackFunc socketListener) {
    PAISocket *socket;
	PAISocketListener *list;

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIEngine: addSocketListener" << endl;
		
	socket = (PAISocket *)sockets.getItem(sock);

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIEngine: got socket" << endl;

	if (socket==NULL) {
		throw new SocketListenerException();
		cerr << "PAIEngine: SOCKET NOT FOUND..  Has it been created through PAI ?..." << endl;

		return NULL;
	}

	list = socket->addListener(callingClass, socketListener);

	//runDispatcherNonBlock();

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIEngine: leaving addSocketListener"  << endl;

	return list;
}

/**
 * Create a custom timer with a delay between timeouts and the
 * number of repeats (-1 = repeat forever)
 */
PAITimer *PAIEngine::addTimer(double delay, int repeat) {
    PAITimer  *timer;
    ListItem *l;
    PAI_ID id;

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIEngine: entering addTimer"  << endl;

	try {
		timer = factory->createTimer(delay, repeat);
	} catch (PAIError *e) {
		e->printError();
	}

	// add timer to linked list of timers and return the PAI ID for this timer

	l = timers.addItem(timer);
	id = l->getID();
	
	timer->setID(id);

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIEngine: leaving addTimer" << endl;

	return timer;
}  // end PAIEngine::OnStartup()


PAITimerListener *PAIEngine::addTimerListener(PAITimer *timer, PAIOwner *callingClass, CallbackFunc timerListener) {
    PAITimer *t;
	PAITimerListener *list;

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIEngine: entering addTimerListener" << endl;

	t = (PAITimer *)timers.getItem(timer);

	if (t==NULL) {
		throw new TimerListenerException();
		return NULL;
	}

	list = t->addListener(callingClass, timerListener);

	//runDispatcherNonBlock();
	
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIEngine: leaving addTimerListener"  << endl;

	return list; 
}

	
void PAIEngine::removeSocketListener(PAISocket *sock, PAISocketListener *list) {
	sock->removeListener(list);
}

void PAIEngine::removeTimerListener(PAITimer *timer, PAITimerListener *list) {
	timer->removeListener(list);
}

		
void PAIEngine::removeTimer(PAITimer *theTimer) {	
	timers.removeItem(theTimer);
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIEngine: deleting Timer" << endl;
//	delete theTimer;
}

void PAIEngine::removeSocket(PAISocket *theSocket) {
	sockets.removeItem(theSocket);
//	delete theSocket;
}

void PAIEngine::SignalHandler(int sigNum)
{
    switch(sigNum)
    {
        case SIGTERM:
        case SIGINT:
            break;

        default:
            cerr << "PAIEngine: Unexpected signal: " << sigNum << endl;
            break; 
    }  
}  // end PAIEngine::SignalHandler()

/**
 * A demo for now - need to figure this out properly.
 */
void PAIEngine::safeDeleteSockets() {
    ListItem* n;
    ListItem* q;
    PAISocket *obj; // replace with your type of object

    sockets.rewind();

    if (sockets.getCurrentListItem()==NULL)
        cout << "A NULLer" << endl;

    cout << "Deleting Objects" << endl;

    for (n = sockets.getCurrentListItem(); n != NULL; n=sockets.getNextListItem()) {
        obj=(PAISocket *)n->getItem();
        cout << "Deleting " << obj->getID() << endl;
        delete obj;
        }

    sockets.destroy();
}

bool PAIEngine::CleanUp() {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIEngine: CLEANING UP !!!!!!!!!!!!" << endl;
	//timers.destroy();
	//sockets.destroy();
    dispatcher->stop(-1);
	return true;
}  // end PAIEngine::OnShutdown()
