#include "iostream.h"

#ifndef _PAIEnv
#define _PAIEnv

typedef enum PAIEnvType { // For the bindings etc
				NS_2 = 0,			// NS_2 binding identifier
				NETWORKING,         // Network binding identifier
				UDP_SOCKET,    // UDP Socket Type
				TCP_SOCKET,    // TCP Socket Type
				DEFAULT_TIMER,    // TCP Socket Type
				DEFAULT_DISPATCHER,    // TCP Socket Type
				NS2_DISPATCHER    // NS2 Dispatcher
} PAIEnvType;

/**
 * A PAI Environment: Settings for the particular PAI environment being use.  Examples
 * include:
 *
 * 1. Setting which binding you want to use e.g. Network or NS-2
 * 2. Setting the network protocols you want to use e.g. UDP or TCP/IP
 * 3. Environment options such as the buffer size for receiving sockets etc
 *
 */
class PAIEnvironment {
	public:

		/**
		 * Gets the environment - there can be only 1 environment per session
		 */
		static PAIEnvironment* getEnvironment() {
		// ASSERT here is better .......
		if (PAIEnvironment::env==0) {
			cout << "PAIEnvironment: CREATING NEW ENVIRONMENT" <<endl;
			PAIEnvironment::env=new PAIEnvironment();
			}
		return PAIEnvironment::env;
		}

		// this for now - no checks - TODO !!!!
		void setBinding(PAIEnvType bind) { binding=bind; }
		void setSocketType(PAIEnvType type) { networkProtocol=type; }
		void setTimerType(PAIEnvType type) { timerProtocol=type; }
		void setDispatcherType(PAIEnvType type) { dispatcher=type; }

		void setVerbose(bool val) { verbose=val; }
		bool isVerbose() { return verbose; }


		bool isAMac() {
	        char *vendor = getenv ("VENDOR");
	        if (strcmp(vendor, "apple")==0)
	            return true;
	        else
	            return false;
		   }

        void setUpLogging();
        
		PAIEnvType getCommunicationBinding() { return binding;}
		PAIEnvType getSocketType() { return networkProtocol; }
		PAIEnvType getTimerType() { return timerProtocol; }
		PAIEnvType getDispatcherType() { return dispatcher; }

		void setSocketBufferLength(unsigned int length) { socketBufferLength=length; }
		unsigned int getSocketBufferLength() { return socketBufferLength; }

		static PAIEnvironment *env;

    private:
		/**
		 * Sets the length of the receive buffer and allocates the memory
		 */
		PAIEnvironment();

        ~PAIEnvironment() {}

		unsigned int socketBufferLength;
		PAIEnvType binding;
		PAIEnvType networkProtocol;
		PAIEnvType timerProtocol;
		PAIEnvType dispatcher;
		bool verbose;
}; // end class PAIEnvironment

#endif // _PAIEnv

