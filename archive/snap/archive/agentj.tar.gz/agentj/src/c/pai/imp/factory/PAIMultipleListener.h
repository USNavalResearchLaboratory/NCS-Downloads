#ifndef _PAIMultipleListener
#define _PAIMultipleListener

#include "PAIEvent.h"
#include "LinkedList.h"
#include "PAIEnvironment.h"
#include "PAIDefs.h"
#include "PAIListener.h"

/**
 * Base class engine for adding suport for multiple listeners for events.  In 
 * protolib, the PAITimer and PAISocket inherit from this class to add multiple
 * callbacks to the various registered event listeners for each socket.
 */
class PAIMultipleListener {
	public:		
		/**
		 * Sets the length of the receive buffer and allocates the memory
		 */
		PAIMultipleListener(const char *objectString);

        ~PAIMultipleListener();

		PAIListener* addListener(PAIOwner *callingClass, CallbackFunc listenerFunction);

		bool removeListener(PAIListener* listener);

        /**
		 * Deletes all the listeners attached to this object.
		 */
		void deleteListeners();

		void setID(PAI_ID id) { myID = id; }
		
		PAI_ID getID() { return myID; }

		const char *getClassName() { return (const char *)objectName; }

    private:		
		PAI_ID myID;

	protected:
		/**
		 * Call this function from your callback function to send the event to
		 * all registered listeners
		 */
		bool sendEventsToListeners(PAIEvent *event);

		const char *objectName;

		LinkedList listeners;		
}; // end class PCISocket


#endif // _PAIMultipleListener
