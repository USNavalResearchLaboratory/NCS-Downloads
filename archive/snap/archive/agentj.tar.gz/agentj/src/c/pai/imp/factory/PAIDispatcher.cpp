#include "PAIDispatcher.h"
#include "PAIEnvironment.h"
#include <iostream.h>

PAIDispatcher::PAIDispatcher() {
	running=false;
}

PAIDispatcher::~PAIDispatcher() {}

#ifdef NETWORK_MODE
void ProtolibDispatcher::run() {
	EventDispatcher *ed = (EventDispatcher *)PAIDispatcher::getDispatcher();
	ed->Run();
}

void ProtolibDispatcher::stop(int code) {
	EventDispatcher *ed = (EventDispatcher *)PAIDispatcher::getDispatcher();
	ed->Stop(code);
}

#else
void NSProtolibDispatcher::run() {
	// must be overloaded e.g. for NS2, this does nothing - you cannot run an NS-2 dispatcher
}

void NSProtolibDispatcher::stop(int code) {
	// Do nothing - you cannot stop an NS-2 dispatcher
}

#endif // NETWORK_MODE

// Threading section

#ifdef NETWORK_MODE
void PAIDispatcher::runThread() {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "PAIDispatcher: runThread, running dispatcher ..." << endl;
	setRunning(true);
	run();
	setRunning(false);
	if (PAIEnvironment::getEnvironment()->isVerbose()) {
		cout << "PAIDispatcher: WARNING: Dispatcher Thread has exited - Is this user invoked?? " << endl;
		cout << "PAIDispatcher: Finished running dispatcher ..." << endl;
		}
}

/**
 * Kicks the dispatcher engine off in a separate thread: Just calls run but from within a
 * separate thread
 */
#ifdef WIN32
DWORD WINAPI PAIDispatcher::runDispatcherThread(LPVOID obj) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "Starting WINDOWS dispatcher Thread ...." << endl;
#endif
#ifdef UNIX
void *PAIDispatcher::runDispatcherThread(void *obj) {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "Starting UNIX dispatcher Thread ...." << endl;
#endif
	((PAIDispatcher *)obj)->runThread();
return 0;
}

void PAIDispatcher::runNonBlock() {
	if (!isRunning()) {
		if (PAIEnvironment::getEnvironment()->isVerbose())
			cout << "KICKING OFF NEW DISPATCHER THREAD !!!!!!!!.....\n" <<endl;
		#ifdef UNIX
			if (pthread_create(&dispatcherThreadID, NULL,
				runDispatcherThread, (void *)this) > 0) {
					cerr << "Thread could not be created...\n" << endl;
				}
		#endif

		#ifdef WIN32
			dispatcherThreadID = CreateThread(NULL,0,runDispatcherThread,(void *)this,0,&iID);
		#endif

//	do { // just wait until the thread is actually set up.  This returns just before the
		// Run function is entered
//		cout << dispatcherThreadID << endl;
//	} while (!isRunning());
	}
}
#else

void PAIDispatcher::runNonBlock() {
	cerr << "PAIDispatcher: ERROR YOU CANNOT RUN IN A NON BLOCKING MODE WITHIN NS2" << endl;
}

#endif // NETWORK_MODE
