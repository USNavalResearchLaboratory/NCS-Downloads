#ifndef _PAIEngine
#define _PAIEngine

#include "PAISocket.h"
#include "PAITimer.h"
#include "PAIListener.h"
#include "LinkedList.h"
#include "PAIFactory.h"
#include "PAIError.h"

#include <signal.h>  // for SIGTERM/SIGINT handling

#ifdef UNIX
#include <unistd.h>
#endif


class PAIEngine {

public:
	PAIEngine(PAIFactory *fact, PAIDispatcher *disp);

	~PAIEngine() {
		if (PAIEnvironment::getEnvironment()->isVerbose())
			cout << "PAIEngine: destructor called " << endl;
	}

	// for input or output UDP sockets
	PAISocket *addSocket(unsigned int portNumber);
	PAITimer *addTimer(double delay, int repeat);

	/**
	 * Add a socket listener to the given socket which is notified of event
	 * on that socket i.e. data received events. This function
	 * also starts the event dispatcher off if it is not already running
	 */
	PAISocketListener *addSocketListener(PAISocket *sock, PAIOwner *callingClass, CallbackFunc socketListener);

	/**
	 * Add a timer listener to the given timer which is notified of event
	 * on that timer i.e. timer times out. This function
	 * also starts the event dispatcher off if it is not already running
	 */
	PAITimerListener *addTimerListener(PAITimer *timer, PAIOwner *callingClass, CallbackFunc timerListener);

	void removeSocketListener(PAISocket *sock, PAISocketListener *list);
	void removeTimerListener(PAITimer *timer, PAITimerListener *list);

	void removeTimer(PAITimer *theTimer);
	void removeSocket(PAISocket *theSocket);

	void runDispatcherInBackground();
	bool runDispatcherNonBlock();
	bool runDispatcher();

	bool runWhilstTimerIsActive();

	void checkAndRunDispatcher();

	bool CleanUp();

	void safeDeleteSockets();


 private:
	bool PAISleep(long millis);

	static void SignalHandler(int sigNum);
	PAIDispatcher *dispatcher;
	LinkedList sockets;
	LinkedList timers;
	PAIEnvironment *env;
	PAIFactory *factory;
	bool initializedWIN32;
}; // end class PAIEngine

#endif // _PAIEngine
