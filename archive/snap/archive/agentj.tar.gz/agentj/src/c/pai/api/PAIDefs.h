#ifndef _PAIDefs
#define _PAIDefs

#include "PAIEvent.h"

#define PROTOLIB_HOME "protoLib.h"

typedef int PAI_ID;

typedef int PAI_ENV_ID;

/**
 * The following is the signature for the callback function.  For convenience
 * and readability we create a PAIOwner class which is the PAI calling class.
 * This signature is simple i.e. returns a bool and has no arguments
 */
class PAIOwner{};
typedef bool (PAIOwner::*CallbackFunc)(PAIEvent *);

// so that this file only gets include once
#endif // _PAIDefs
