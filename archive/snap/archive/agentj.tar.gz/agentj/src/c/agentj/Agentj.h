
#ifndef _JAVA_AGENT
#define _JAVA_AGENT

#include "nsProtoAgent.h"
#include "C2JBroker.h"

#include <PAI.h>

/**
 * Agentj is an NS2 agent for the PAI library, which can also
 * use the Java bridging interface to allow Java programs to send data
 * between NS2 nodes.
 * This is the central class for the NS2-P2PS integration which ties in
 * a JVM, the PAI interface, Protolib and the P2PS middleware which utlizes
 * all the levels.
 */
 class Agentj : public NsProtoAgent
{
    public:
        Agentj();
        ~Agentj();

        static C2JBroker *cJBroker;

		char *getLocalAddress() {
		    char *buf= new char[50];
		    sprintf(buf, "%li\0", (unsigned long)addr());
			return buf;
			}
			
    protected:
        virtual int command(int argc, const char*const* argv);

    private:
		void initAgent(); // initialise the NS2 node
        void startTimer(double delay, int repeat);
		bool OnTxTimeout();

	    PAI *pai; // for timing functions
	    PTI *pti;
		PAITimer *timer;
		char *myAddress;	

};  // end class


#endif // _JAVA_AGENT
