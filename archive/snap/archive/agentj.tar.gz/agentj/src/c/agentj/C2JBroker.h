/*
 *  C2JBroker.h
 *
 *  Created by Ian Taylor on Fri Mar 26 2004.
 *
 */
 
#include <jni.h>
#ifndef _JVM_REF
#define _JVM_REF

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include "PAIEnvironment.h"
#include "Scheduler.h"

// FOR THE MAC ...

//#ifdef UNIX
//#define _REENTRANT
//#include <pthread.h>
//#endif

// #import <Cocoa/Cocoa.h>

#ifdef _WIN32
#define PATH_SEPARATOR ';'
#else /* UNIX */
#define PATH_SEPARATOR ':'
#endif

#define USER_CLASSPATH "./" /* where our is */

/**
 * This class provides a mechanism for creating and destroying a virtual machine. It
 * also provides a conveneinece method for calling command() functions on Java 
 * objects and it also interacts with a remote container that stores references
 * to the Java objects so the garbage collector doesn't come along and delete them.
 *
 * The is only one instance of C2JBroker class and only one instance of its java
 * counterpart, JavaAgent. The JavaAgent simply registers the Java object
 * with their supplied IDs.  The IDs are the pointers to the NS2 agents
 * that want to invoke Java commands, which makes sure that this reference
 * is unique to the agent itself (this also implies that only ONE Java 
 * object can be manipulated by one agent).
 *
 * We also use the Agent's pointer here so we can reuse this later if
 * the Java object uses the PAI interface to communicate data
 * between NS2 nodes.  
 *
 * The actual Java object that is being invoked implemented the Java 
 * CommandInterface and its command method can be invoked by using the
 * invokeCommand method in this class by supplying the appropriate ID.
 */
class C2JBroker {

	private:
	    JavaVM *jvm; /* The virtual machine instance */
        JNIEnv *env;
        
		/**
		 * Convenience methods for obtaining a method reference to a method in
		 * our JavaAgent class
		 */
		jmethodID getMethodID(jclass cls, char *method, char *sig);
		
		jclass getBrokerClass();

	public:
	    /** 
	     * Create a virtual machine: initialise it with the
	     * CLASSPATH and LD_LIBRARY_PATH variables
	     */
	    C2JBroker();
    	
		/**
	     * Destroy a virtual machine
	     */
	    ~C2JBroker();

		/**
		 * Resgisters an instance of the java class with the given 'className'
		 * with the JavaAgent class.
		 */
        int registerJClass(const char *className, unsigned int id);


        int setNSScheduler();

		/**
		 * Unresgisters java class that is associated with the Agent's ID.
		 */
        int unregisterJClass(unsigned int id);

		/**
		 * Invokes the command with the supplied arguments on the native Java
		 * object which is referenced by the supplied id. 
		 */
        int invokeCommand(unsigned int id, const char *command, const char *args);

        void cleanUp();
};

#endif // _JVM_REF

