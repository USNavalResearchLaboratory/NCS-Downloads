#include "Agentj.h"
#include <iostream.h>

C2JBroker *Agentj::cJBroker=0;
 
static class AgentjExampleClass : public TclClass
{
	public:
		AgentjExampleClass() : TclClass("Agent/Agentj") {}
	 	TclObject *create(int argc, const char*const* argv) {
			return (new Agentj());
			}
} class_protean_example;

Agentj::Agentj() {
    cJBroker=NULL;
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "Agentj: creating ..."  << endl;
} 

void Agentj::initAgent() {
		 cout << "Agentj: My pointer is ..."  << this << endl;
}

void Agentj::startTimer(double delay, int repeat) {
    // cout << "Start Timer with " << delay << repeat << endl;
	
	CallbackFunc timerCallback = (CallbackFunc)&Agentj::OnTxTimeout;
	PAIOwner *owner = (PAIOwner *)this;
    
	timer = pti->addTimer(delay, repeat);
	pti->addListener(timer, owner, timerCallback); // set timer off
}

bool Agentj::OnTxTimeout() {
	if (cJBroker!=0) { // send trigger to java code via a command call...
		cJBroker->invokeCommand((unsigned int)this, "trigger", "none");  // execute command
    }
}

Agentj::~Agentj() {
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "Agentj: destructor ..."  << endl;
	if (cJBroker!=0) // create a virutal machine for our Java broker...
	      cJBroker->cleanUp();
}
 
int Agentj::command(int argc, const char*const* argv) {

	if (!strcmp(argv[1], "agentj")) { // 2 is command, 3 onwards are the arguments
		int i;
		int charsNeeded=0;
		char *args=NULL;

 		// Put ALL arguments back in a String - gives us much more flexibility about how we deal
		// with them on the Java side of things
		
		for (i=3; i< argc; ++i) 
			charsNeeded += strlen(argv[i]) + 1; // 1 for a space
		
		if (charsNeeded != 0) {
			args=new char[charsNeeded];
			char *ptr=args;
			
			for (i=3; i< argc; ++i) {
				if (i==argc-1)
					sprintf(ptr, "%s\0", argv[i]);
				else {
					sprintf(ptr, "%s ", argv[i]);
					ptr += strlen(argv[i]) + 1;
					}
				} 
		    }
		else { // send "NONE" - need to send something ....
		    args=new char[5];
			sprintf(args, "NONE\0");
			}
				
		if (PAIEnvironment::getEnvironment()->isVerbose())
			cout << "Agentj: javaCommand: " << argv[2] << " args: " << args << endl;
    
		if (cJBroker==0) { // No class path set so bomb out...
			cerr << "Agentj.cpp: ERROR no classpath set - use setClass command" << endl;
			return TCL_ERROR;
			}
		cJBroker->invokeCommand((unsigned int)this, argv[2], args);  // execute command
		// this calls calls the invokeCommand in the Agentj.cpp class which in turn
		// invokes the method in the Agentj.java class which routes the
		// call to the appropriate Java object 
		return TCL_OK;
		}

   if (4 == argc) {
        if (!strcmp(argv[1], "startTimer")) { // 2 is delay, 3 is repeat
		   // cout << "Agentj: STARTING TIMER HERE !!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
		    if (pai==NULL) { // only need PAI for timers so create when/if needed
				pai = new PAI();
				pai->setDispatcher(static_cast<ProtoSim*>(this));
				pti = pai->getPTI(); // get the timing library
				}
			double delay = (double)atof(argv[2]);
			int repeat = atoi(argv[3]);
			startTimer(delay,repeat);
			return TCL_OK;
	 	}	 
    }
    else if (3 == argc) {

         if (!strcmp(argv[1], "attach-agentj")) { // 2 is classpath, 3 is classname
	     if (PAIEnvironment::getEnvironment()->isVerbose())
		    cout << "Agentj: Attach-agent " << endl;
             if (cJBroker==NULL) { // create a virutal machine for our Java broker...
        		cout << "Agentj: Creatin JVM" << endl;
                cJBroker=new C2JBroker(); // get classpath from CLASSPATH variable
        		if (PAIEnvironment::getEnvironment()->isVerbose())
                    cout << "Agentj: Created Virtual Machine ---  THIS SHOULD ONLY HAPPEN ONCE !!!!" << endl;
                cJBroker->setNSScheduler();
             }
             cJBroker->registerJClass(argv[2], (unsigned int)this);  // create Java object and use this
        			             // agents pointer as its ID.
        	 return TCL_OK;
        	 }
        else if (!strcmp(argv[1], "setDelimiter")) { // 2 is the delimiter used to divide the instructions
		if (cJBroker==0) { // No class path set so bomb out...
			cout << "Agentj.cpp: ERROR no classpath set - use setClass command" << endl;
			return TCL_ERROR;
			}
		cJBroker->invokeCommand((unsigned int)this, argv[1], argv[2]);  // execute command
		}
		}
	else if (2 == argc) {
		if (!strcmp(argv[1], "initAgent")) { // init is a reserved word so cannot use it ...
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "Agentj: initAgent: " << endl;
			initAgent();
            return TCL_OK; 
        }
		else if (!strcmp(argv[1], "stopTimer")) {
			if (PAIEnvironment::getEnvironment()->isVerbose())
			 	cout << "PAIBroker: Stopping Timer..." << endl;
			if (pti!=NULL)
				pti->removeTimer(timer);
			return TCL_OK;
		}
		else if (!strcmp(argv[1], "cleanUp")) {
			if (PAIEnvironment::getEnvironment()->isVerbose())
				cout << "PAIBroker: PAI Cleaning UP..." << endl;
			if (pti!=NULL)
				pai->cleanUp(); 
			if (pai!=NULL)
				cJBroker->cleanUp();
			delete pai;
			return TCL_OK;
		}
	}

    return NsProtoAgent::command(argc, argv);
}  // end Agentj::command()



