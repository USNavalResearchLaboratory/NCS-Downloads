/*
 *  C2JBroker.cpp
 *  PAI
 *
 *  Created by Ian Taylor on Fri Mar 26 2004.
 *
 */

#include "C2JBroker.h"

#define JAVABROKER_JAVA_CLASS "pai/imp/broker/JavaBroker"
#define DEFAULT_LOG4J_CONFIG "/config/AgentJConfig.xml"
/** 
 * Create a virtual machine 
 */
C2JBroker::C2JBroker() {

	int i;
	jint res;
	char *cpinst;
	char *cp2inst;
	char *cpConfig=NULL;
	jclass cls;

	cout << "initVM: Setting up JVM " << endl;

	char *ld_library_path = getenv ("LD_LIBRARY_PATH");
	char *classpath = getenv ("CLASSPATH");
	char *agentJHome = getenv ("AGENTJ");
	char *agentJConfig = getenv ("AGENTJXMLCONFIG");
	char *agentJDebug = getenv ("AGENTJDEBUG");

	if (ld_library_path==NULL) {
	    cout << "C2JBroker: FATEL!! LD_LIBRARY_PATH is not set, can't continue...." << endl;
		exit(0);
		}

    if (strcmp(agentJDebug, "ON") ==0) { // only if debug is on set someting
	    if (agentJHome!=NULL) { // At least we have a home - let's try and configure log4j
    	    if (agentJConfig !=NULL) { // At least we have a home - let's try and configure
        	    cpConfig= new char[strlen("-Dlog4j.configuration.file=") + strlen(agentJConfig) + 1];
                sprintf(cpConfig, "-Dlog4j.configuration.file=%s \0", agentJConfig);
            }
            else {
        	    cpConfig= new char[strlen("-Dlog4j.configuration.file=") + strlen(agentJHome) + strlen(DEFAULT_LOG4J_CONFIG) + 1];
                sprintf(cpConfig, "-Dlog4j.configuration.file=%s%s \0", agentJConfig, DEFAULT_LOG4J_CONFIG);
            }
        }
	}

    if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "C2JBroker: log4j config file = " << cpConfig << endl;

	JavaVMInitArgs vm_args;
   	JavaVMOption options[3];

	cpinst = new char[strlen("-Djava.library.path=") + strlen(ld_library_path) + 1];
	cp2inst = new char[strlen("-Djava.class.path=") + strlen(classpath) + 1];

    // This sets the LD_LIBRARY_PATH AND the CLASSPATH for the virtual machine

    sprintf(cpinst, "-Djava.library.path=%s \0", ld_library_path);
    sprintf(cp2inst, "-Djava.class.path=%s\0", classpath);

	cout << "Lib path = " << cpinst << endl;
	cout << "Classpath = " << cp2inst << endl;

	options[0].optionString =  cpinst;
	options[1].optionString =  cp2inst;
	if (cpConfig!=NULL)
		options[2].optionString =  cpConfig;

    vm_args.version = 0x00010004;
	vm_args.options = options;
	if (cpConfig!=NULL)
		vm_args.nOptions = 3;
    else
		vm_args.nOptions = 2;

	vm_args.ignoreUnrecognized	= JNI_TRUE;

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "C2JBroker: Creating JVM " << endl;

	/* Create the Java VM */
	res = JNI_CreateJavaVM(&jvm, (void**)&env, &vm_args);
	if (res < 0) {
		fprintf(stderr, "C2JBroker: Fatal, can't create Java VM\n");
		exit(0);
		}

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "C2JBroker: Created JVM "<< endl;
}

/**
 *  Passes the ptr to the schduler instance across to Java
 */
int C2JBroker::setNSScheduler() {
	jint res;
	jmethodID mid;
	jstring applicationArg;
	char *idString;
	jint ret;

	// unsigned int = 32 bits - 0 to 65535 but could be represented as a signed so allocated a couple more
	// to be on the safe side (6 needed, 10 allocated - trim if needed) i.e. -32768 to 32767

    Scheduler *s = &Scheduler::instance();

 	unsigned int id = (unsigned int)s;

	idString = new char[12];
	sprintf(idString, "%u\0", id);

	jclass cls = getBrokerClass();

	mid = getMethodID(cls, "setNSScheduler", "(Ljava/lang/String;)I");

	applicationArg = env->NewStringUTF(idString);

	if (applicationArg == 0) {
		fprintf(stderr, "C2JBroker: Fatal, out of memory\n");
		return -1;
	}

	ret = env->CallStaticIntMethod(cls, mid, applicationArg);

	if (ret==0) {
		fprintf(stderr, "C2JBroker.cpp: Fatal, ERROR in setNSScheduler function\n");
		env->ExceptionDescribe();
		env->ExceptionClear();
		exit(1);
		}

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "C2JBroker: registerJClass: OK Called register method in JavaAgent.java" << endl;

    delete []idString;

	return 1;

}

/**
 * Destroy a virtual machine
 */
C2JBroker::~C2JBroker() {
	jvm->DestroyJavaVM();
	}
		
int C2JBroker::registerJClass(const char *className, unsigned int id) {
	jint res;
	jmethodID mid;
	jstring applicationArg0;
	jstring applicationArg1;
	char *idString;
	jobjectArray args;
	jint ret;
	
	// unsigned int = 32 bits - 0 to 65535 but could be represented as a signed so allocated a couple more
	// to be on the safe side (6 needed, 10 allocated - trim if needed) i.e. -32768 to 32767
	
	idString = new char[10];
	sprintf(idString, "%u\0", id);
	
	jclass cls = getBrokerClass();
	
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "C2JBroker: registerJClass: Creating broker class " << endl;

	mid = getMethodID(cls, "register", "([Ljava/lang/String;)I");
		
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "C2JBroker: registerJClass: Creating method ref " << endl;

//     ARGUMENTS ARE PACKED AS FOLLOWS:
//     arg[0] = the java class name
//     arg[1] is its id (i.e. the pointer to the NS2 agent)

	applicationArg0 = env->NewStringUTF(className);
	applicationArg1 = env->NewStringUTF(idString);

	if ((applicationArg0 == 0) || (applicationArg1 == 0)) {
		fprintf(stderr, "C2JBroker: Fatal, out of memory\n");
		return -1;
	}

	args = env->NewObjectArray(2, env->FindClass("java/lang/String"), NULL);
		
	if (args == 0) {
		fprintf(stderr, "C2JBroker: Fatal, out of memory\n");
		exit(1);
		}

	env->SetObjectArrayElement(args, 0, applicationArg0);
	env->SetObjectArrayElement(args, 1, applicationArg1);
		    
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "C2JBroker: registerJClass: Calling register method in JavaAgent.java" << endl;

	ret = env->CallStaticIntMethod(cls, mid, args);

	if (ret==0) {
		fprintf(stderr, "C2JBroker.cpp: Fatal, ERROR in register function: registering %s\n", className);
		env->ExceptionDescribe();
		env->ExceptionClear();
		exit(1);
		}

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "C2JBroker: registerJClass: OK Called register method in JavaAgent.java" << endl;
   
    delete []idString;
	
	return 1;
}

int C2JBroker::unregisterJClass(unsigned int id) {
	jmethodID mid;
	jclass cls = getBrokerClass();
	jint ret;
	char *idString;
	jstring applicationArg;

	// unsigned int = 32 bits - 0 to 65535 but could be represented as a signed so allocated a couple more
	// to be on the safe side (6 needed, 10 allocated - trim if needed) i.e. -32768 to 32767
	
	idString = new char[10];
	sprintf(idString, "%u\0", id);

	mid = getMethodID(cls, "unregister", "(Ljava/lang/String;)I");

	applicationArg = env->NewStringUTF(idString);

	if (applicationArg == 0) {
		fprintf(stderr, "C2JBroker: Unregistering: Fatal, out of memory\n");
		return -1;
	}

	ret = env->CallStaticIntMethod(cls, mid, applicationArg);

	if (ret==0) {
		fprintf(stderr, "C2JBroker.cpp: WARNING in unregister function. No Such Class\n");
		exit(1);
		}
		
	delete[] idString;

	return 1;
}

int C2JBroker::invokeCommand(unsigned int id, const char *command, const char *progArgs) {
	jmethodID mid;
	jstring applicationArg0;
	jstring applicationArg1;
	jstring applicationArg2;
	char *idString;
	jobjectArray args;
	jstring ret;
	 
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "C2JBroker: invokerCommand: entering" << endl;

	// unsigned int = 32 bits - 0 to 65535 but could be represented as a signed so allocated a couple more
	// to be on the safe side (6 needed, 10 allocated - trim if needed) i.e. -32768 to 32767
	
	idString = new char[10];
	sprintf(idString, "%u\0", id);
	
	jclass cls = getBrokerClass();
	
	mid = getMethodID(cls, "invokeCommand", "([Ljava/lang/String;)Ljava/lang/String;");
		        		
//     ARGUMENTS ARE PACKED AS FOLLOWS: 
//     arg[0] is its id (i.e. the pointer to the NS2 agent)
//     arg[1] the command to send to the java Object
//     arg[0] the arguments for the command 

	applicationArg0 = env->NewStringUTF(idString);
	applicationArg1 = env->NewStringUTF(command);
	applicationArg2 = env->NewStringUTF(progArgs);

	if ((applicationArg0 == 0) || (applicationArg1 == 0) || (applicationArg2 == 0)) {
		fprintf(stderr, "C2JBroker: Fatal, out of memory\n");
		return -1;
	}

	args = env->NewObjectArray(3, env->FindClass("java/lang/String"), NULL);
		
	if (args == 0) {
		fprintf(stderr, "C2JBroker: Fatal, out of memory\n");
		exit(1);
		} 

	env->SetObjectArrayElement(args, 0, applicationArg0);
	env->SetObjectArrayElement(args, 1, applicationArg1);
	env->SetObjectArrayElement(args, 2, applicationArg2);
		    
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "C2JBroker: invokerCommand: calling Java method" << endl;

	ret = (jstring)env->CallStaticObjectMethod(cls, mid, args, id);

	if (ret==0) {
		fprintf(stderr, "C2JBroker.cpp: Fatal, ERROR in executing command: %s\n", command);
		env->ExceptionDescribe();
		env->ExceptionClear();
		exit(1);
		}

     const char *str;
	 
     str = env->GetStringUTFChars(ret, NULL);
     if (str == NULL) {
		 fprintf(stderr, "C2JBroker: Fatal, out of memory\n");
         return -1; 
     }
	 
	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "C2JBroker: invokerCommand: called method in JavaAgent: command sent" << endl;
   
   env->ReleaseStringUTFChars(ret, str);

    delete[] idString;

	return 1;
}
	
void C2JBroker::cleanUp() { 
	jmethodID mid;

	if (PAIEnvironment::getEnvironment()->isVerbose())
		cout << "cleanUP: entering" << endl;

	jclass cls = getBrokerClass();

	mid = getMethodID(cls, "cleanUp", "()V");
		    
	env->CallStaticVoidMethod(cls, mid);

    // this cleans up the objects from the Java side of things
	// we don;t need to call unregisterJClass() individually because
	// we keep no reference here - the unregisterJClass() function
	// is left in this implementation for possible future
	// use and completeness. 
	
	// jvm->DestroyJavaVM();
}

jmethodID C2JBroker::getMethodID(jclass cls, char *method, char *sig) {
	jmethodID mid;
   
	mid = env->GetStaticMethodID(cls, method, sig);
	if (mid == 0) {
		fprintf(stderr, "C2JBroker: Fatal, can't find JavaAgent.register\n");
		return 0;
		}
	return mid;
}

jclass C2JBroker::getBrokerClass() {
	jclass cls;

   	// HA HA Bloody Ha ! two days wasted on this one ... 
	// the stupid classloader doesn't understand Java packages
	// need to tell is by hand - sigh 8^( 

	cls = env->FindClass(JAVABROKER_JAVA_CLASS);
	if (cls == 0) {
		fprintf(stderr, "C2JBroker: Fatal, can't find JavaAgent class\n");
		return 0;
	}
   	 
	return cls;
}
