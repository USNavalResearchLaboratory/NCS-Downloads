
// protApp.cpp - Simple example application using Protean protLib
//               command-line dispatcher, timer, and socket classes

#include "../PAI.h"

#include <stdio.h>   // for stdout/stderr printouts
#include <signal.h>  // for SIGTERM/SIGINT handling

class MultiEveryThing
{
    public:
        MultiEveryThing();

    private:
        bool OnTxTimeout(PAIEvent *e);   
        bool OnTxTimeout2(PAIEvent *e);   
        bool OnSocketRecv(PAIEvent *e);
        bool OnSocketRecv2(PAIEvent *e);

		PAISocket *sock1;
		PAISocketListener *slist;
		PAISocket *sock2;
		PAISocketListener *slist2;
	    PTI *pti;
		PCI *pci;
		PAITimer *timer;
		PAITimerListener *tlist;
		PAITimer *timer2;
		PAITimerListener *tlist2;
		PAI pai;
};


/**
 * The following defintions are made for callback functions and PAI owning classes:
 * 
 * In: PAISocket.h, the following is defined:
 *
 *  class PAIOwner{};
 *  typedef bool (PAIOwner::*CallbackFunc)();
 *
 * which means that a PAIOwner can be cast to any class - note the syntax is merely
 * for convenience here. A PAIOwner is a class that uses te PAI interface, so your
 * class that you are defining.
 * A Callback function has the following type:
 *
 *  bool (PAIOwner::*CallbackFunc) ();
 *
 * i.e. it returns a boolean and belongs to the PAIOwner class and has zero arguments.
 * So something like this would satisfy:
 *
 *    bool MyClass::mycallbackFunction() { // your code}
 */
MultiEveryThing::MultiEveryThing() {
    CallbackFunc timerCallback = (CallbackFunc)&MultiEveryThing::OnTxTimeout;
    CallbackFunc timerCallback2 = (CallbackFunc)&MultiEveryThing::OnTxTimeout2;
    CallbackFunc socketCallback = (CallbackFunc)&MultiEveryThing::OnSocketRecv;
    CallbackFunc socketCallback2 = (CallbackFunc)&MultiEveryThing::OnSocketRecv2;

	PAIOwner *owner = (PAIOwner *)this;

	pti = pai.getPTI(); // get the timing library
	pci = pai.getPCI(); // get the socket library

	printf("Listeners \n");

	timer = pti->addTimer(1.0, -1);	
	sock1 = pci->addSocket(5003);
	slist=pci->addListener(sock1, owner, socketCallback);
	tlist=pti->addListener(timer, owner, timerCallback);

	pci->setMulticast(sock1, true);
	pci->joinGroup(sock1, "232.2.2.2");

//	pci->leaveGroup(sock1, "232.2.2.2");

	cout << "Press any key add timer " << endl;
	getchar();

	timer2 = pti->addTimer(2.0, -1);
	tlist2=pti->addListener(timer2, owner, timerCallback2);

	cout << "Press any key to remove socket listener " << endl;
	getchar();

	pci->removeListener(sock1, slist);

	cout << "Press any key to delete socket and edd a second socket" << endl;
	getchar();

	cout << "Socket" << endl;
	pci->removeSocket(sock1);

	sock2 = pci->addSocket(5002);
	slist2=pci->addListener(sock2, owner, socketCallback2);

	cout << "Press any key to stop timer" << endl;
	getchar();

	pti->removeListener(timer, tlist);
	cout << "Timer" << endl;
	pti->removeTimer(timer);

	pti->cleanUp();
	pci->cleanUp();
	cout << "Finished !!!" << endl;
	getchar();
}


bool MultiEveryThing::OnTxTimeout(PAIEvent *e) {
    char* buffer = "Hello, Proteus";
    unsigned int len = strlen(buffer) + 1;

	cout << "MyID = " << e->getID() << endl;
	try {
		pci->send(sock1, "232.2.2.2", buffer, len);
	} catch (PAISocketSendError *err) {
		cout << err->getError() << endl;
	}

	return true;
}  

bool MultiEveryThing::OnTxTimeout2(PAIEvent *e) {

	cout << "MyID = " << e->getID() << endl;

	    char* buffer = "Hello, Proteus";
    unsigned int len = strlen(buffer) + 1;

	try {
		pci->send(sock2, "127.0.0.1", buffer, len);
	} catch (PAISocketSendError *err) {
		cout << err->getError() << endl;
	}

	return true;
}  

bool MultiEveryThing::OnSocketRecv(PAIEvent *e) {
    char *buffer;
	const char *address;
    unsigned int len=512;

    buffer = pci->recv(sock1, &address, &len);
	cout << "MyID = " << e->getID() << endl;

	delete buffer;
	return true;
}  

bool MultiEveryThing::OnSocketRecv2(PAIEvent *e) {
    char *buffer;
	const char *address;
    unsigned int len=512;

    buffer = pci->recv(sock2, &address, &len);
//	printf(".......... Soicket 2: Received %s from %s\n", buffer, address);
	cout << "MyID = " << e->getID() << endl;

	delete buffer;
	return true;
}  

int main(int argc, char* argv[]) {
	MultiEveryThing theApp; 

	return 1;
}  
