
// protApp.cpp - Simple example application using Protean protLib
//               command-line dispatcher, timer, and socket classes


#include <stdio.h>   // for stdout/stderr printouts
#include <signal.h>  // for SIGTERM/SIGINT handling
#include "../LinkedList.h"
#include "../../../protolib_current/protolib/common/protoLib.h"

class LinkedListTest
{
    public:
        LinkedListTest();        
    private:
};


LinkedListTest::LinkedListTest() {
	LinkedList *ll;
    UdpSocket *socket;
    UdpSocket *toRemove;
	
	ll = new LinkedList();

	for (int i=0; i< 10; ++i) {
		socket = new UdpSocket();
		ll->addItem(socket);
		if (i==5)
			toRemove = socket;
	}

	ll->removeItem(toRemove);

	for (i=0; i< 10; ++i) 
		printf("Item %i = %li\n", i, ll->getItem(i));

	delete ll;
}



int main(int argc, char* argv[]) {
	LinkedListTest theApp; 
	return 1;
}  
