
// protApp.cpp - Simple example application using Protean protLib
//               command-line dispatcher, timer, and socket classes

#include <stdio.h>   // for stdout/stderr printouts
#include <signal.h>  // for SIGTERM/SIGINT handling
#include <iostream.h>

#include "../PAI.h"

class PAI_Example
{
    public:
        PAI_Example();
		int count;

    private:
        bool OnTxTimeout();
        bool OnSocketRecv();
        bool OnSocketRecv2();
        bool OnSocketNotify() { printf("Socket Notified of event\n"); return true; }

		PAISocket *sock1;
		PAISocket *sock2;
	    PTI *pti;
		PCI *pci;
		PAITimer *timer;
		PAI *pai;
};


/**
 * The following defintions are made for callback functions and PAI owning classes:
 *
 * In: PAISocket.h, the following is defined:
 *
 *  class PAIOwner{};
 *  typedef bool (PAIOwner::*CallbackFunc)();
 *
 * which means that a PAIOwner can be cast to any class - note the syntax is merely
 * for convenience here. A PAIOwner is a class that uses te PAI interface, so your
 * class that you are defining.
 * A Callback function has the following type:
 *
 *  bool (PAIOwner::*CallbackFunc) ();
 *
 * i.e. it returns a boolean and belongs to the PAIOwner class and has zero arguments.
 * So something like this would satisfy:
 *
 *    bool MyClass::mycallbackFunction() { // your code}
 */
PAI_Example::PAI_Example() {

        printf("Dynamic PAI \n");

	pai = new PAI();
	count =0;
//	printf("Host teaspoon is %s\n", pci->getAddressByName("teaspoon"));

	pti = pai->getPTI(); // get the timing library
	pci = pai->getPCI(); // get the socket library
	printf("local Host is %s\n", pci->getLocalHost());

	sock1 = pci->addSocket(5004);
	sock2 = pci->addSocket(5005);

        char* buffer = "Hello, Proteus";
        unsigned int len = strlen(buffer) + 1;
	pci->send(sock1, "127.0.0.1", buffer, len);

	char *buffer1;
	const char *address1;
        unsigned int len1=512;

    	buffer = pci->recv(sock1, &address1, &len1);
	printf("#1..........Received %s from %s : %i\n", buffer1, address1, count);

	pti->cleanUp();
	pci->cleanUp();
}


bool PAI_Example::OnTxTimeout() {
    // char* buffer2 = "Hello, Proteus #2";
  //  len = strlen(buffer) + 1;
//	pci->send(sock2, "127.0.0.1", buffer, len);

	return true;
}

bool PAI_Example::OnSocketRecv() {

//	delete buffer;
	return true;
}

bool PAI_Example::OnSocketRecv2() {
    char *buffer;
	const char *address;
    unsigned int len = 512;

    buffer = pci->recv(sock2, &address, &len);
	printf("#2..........Received %s from %s\n", buffer, address);

	delete buffer;
	return true;
}

int main(int argc, char* argv[]) {
	PAI_Example theApp;

	return 1;
}
