This directory contains a number of test code for various
aspects of the Agentj system.  They are not documented
and should be treated as experimental
