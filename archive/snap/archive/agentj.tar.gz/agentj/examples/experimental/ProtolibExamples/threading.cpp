#include <windows.h>  // for CreateThread() stuff


// a pointer to a structure of this type is  
// passed to the Card_X_Thread() function to  
// exchange information between threads
typedef struct {
	void* pOther;
} THREAD_PARAMS;

// This worker thread is used for interfacing   
// with a specific board.  Any number of separate   
// boards may be interfaced using this thread 
// function
DWORD WINAPI Card_X_Thread(LPVOID);

//////////
int main(int argc, char **argv) {
	THREAD_PARAMS*  pCall;
	HANDLE  hThread[2];
	unsigned long tmpthreadid;

	// setup param to pass to worker threads
	pCall = new THREAD_PARAMS[2];
	
	pCall[0].pOther = NULL;
	pCall[1].pOther = NULL;
	
	
	hThread[0] = CreateThread(NULL, 0, 
			Card_X_Thread, &pCall[0], 0, &tmpthreadid);

		return 0;
}


// This worker thread is used for interfacing with
// a specific board. Any number of separate 
// boards may be interfaced using this thread 
// function
DWORD WINAPI Card_X_Thread(LPVOID pVoid) {
	


	return 0;
}