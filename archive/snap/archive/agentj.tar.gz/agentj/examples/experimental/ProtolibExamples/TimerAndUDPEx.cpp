
// SimpleSendAndReceive.cpp - Simple demonstration of how to use Protlib Timers

#include "../../../protolib_current/protolib/common/protoLib.h"
// or whereever you installed protolib 

#include <stdio.h>   // for stdout/stderr printouts
#include <signal.h>  // for SIGTERM/SIGINT handling

class SimpleSendAndReceive
{
    public:
        SimpleSendAndReceive();
		ProtocolTimerMgr getTimerManager() { return manager; }

        bool OnStartup();
		void Stop(int exitCode) {dispatcher.Stop(exitCode);}
		void OnShutdown() { socket.Close(); timer.Deactivate(); }
		int MainLoop() { return dispatcher.Run(); }

    private:
		// Function to implement the timer installer
		static bool TimerInstaller(ProtocolTimerInstallCmd cmd, double theDelay,
                      ProtocolTimerMgr* timerMgr, const void* installData);

        static void SignalHandler(int sigNum);
        EventDispatcher dispatcher;
		bool OnSocketRecv(UdpSocket* theSocket);
        bool OnTimerTimeout();   
        
		ProtocolTimer timer;
		ProtocolTimerMgr manager;
		double delay;
        UdpSocket socket;
        
}; // end class SimpleSendAndReceive

SimpleSendAndReceive::SimpleSendAndReceive() {

    // Init timer for 1.0 second interval, infinite repeats
	timer.Init(1.0, -1, 
                 (ProtocolTimerOwner*)this, 
                 (ProtocolTimeoutFunc)&SimpleSendAndReceive::OnTimerTimeout);  

//	manager.SetInstaller(SimpleSendAndReceive::TimerInstaller, this);
	manager.SetInstaller(EventDispatcher::TimerInstaller, this);
	manager.InstallTimer(&timer);    

    // Init socket, specifying async recv owner/handler, async installer
    socket.Init((UdpSocketOwner*)this, 
             (UdpSocketRecvHandler)&SimpleSendAndReceive::OnSocketRecv, 
                EventDispatcher::SocketInstaller, &dispatcher);
}

bool SimpleSendAndReceive::OnStartup()
{
#ifdef WIN32
    if (!dispatcher.Win32Init())
    {
        fprintf(stderr, "protoApp:: Win32Init() error!\n");
        return false;
    }
#endif // WIN32
    NetworkAddress x;
    x.LookupLocalHostAddress();
    DMSG(0, "protoApp:: local EndIdentifier: %0x\n", x.EndIdentifier());

    // Open a udp socket
    if (UDP_SOCKET_ERROR_NONE != socket.Open(5003))
    {
        fprintf(stderr, "protoApp: Error opening UDP socket!\n");
        return false;
    }    

    // Install our transmit timer

	EventDispatcher::TimerInstaller(PROTOCOL_TIMER_INSTALL, 1.0, &manager, &dispatcher);

    // dispatcher.InstallTimer(&timer);
    
	signal(SIGTERM, SignalHandler);
    signal(SIGINT, SignalHandler);
    return true;
}  // end SimpleSendAndReceive::OnStartup()


bool SimpleSendAndReceive::TimerInstaller(ProtocolTimerInstallCmd cmd, double theDelay,
				ProtocolTimerMgr* timerMgr, const void* installData)
{
printf("Command called ....\n");
	// Note the timeMgr points to the same class as our manager variable here
    switch (cmd)
    {
		// demo code here -> insert whatever you require to keep track 
		// of internal variables, if needed

        case PROTOCOL_TIMER_INSTALL:
        case PROTOCOL_TIMER_MODIFY:
            ((SimpleSendAndReceive*)installData)->delay = theDelay;
            break;
        case PROTOCOL_TIMER_REMOVE:
            ((SimpleSendAndReceive*)installData)->delay = -1.0;
            break;
    }
    return true;
}  

bool SimpleSendAndReceive::OnSocketRecv(UdpSocket* /*theSocket*/) {
    char buffer[512];
    unsigned int len = 512;
    NetworkAddress addr;
	
    socket.RecvFrom(buffer, &len, &addr);

    printf("Received %s on Socket !\n", buffer);

	// fprintf(stderr, "TimerTest:: Received \"%s\" from \"%s\"\n",
    //     buffer, addr.HostAddressString());
    return true;
}  // end TimerTest::OnSocketRecv()


bool SimpleSendAndReceive::OnTimerTimeout() {
    NetworkAddress addr;
	printf("Timer Invoked me !\n");
    addr.LookupHostAddress("127.0.0.1");
    // addr.LookupHostAddress("teaspoon");
    addr.SetPort(5003);
    char* buffer = "Hello, Proteus";
    unsigned int len = strlen(buffer) + 1;
    socket.SendTo(&addr, buffer, len);
    return true;
}       

    SimpleSendAndReceive theApp; 

	// Use "main()" for UNIX and WIN32 console apps, 
// "WinMain()" for non-console WIN32
// (VC++ uses the "_CONSOLE_ macro to indicate build type)

#if defined(WIN32) && !defined(_CONSOLE)
int PASCAL WinMain(HINSTANCE instance, HINSTANCE prevInst, LPSTR cmdline, int cmdshow)
#else
int main(int argc, char* argv[])
#endif
{
#ifdef WIN32
    // Hack to determine if Win32 console application was launched
    // independently or from a pre-existing console window
    bool pauseForUser = false;
    HANDLE hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
    if (INVALID_HANDLE_VALUE != hConsoleOutput)
    {
        CONSOLE_SCREEN_BUFFER_INFO csbi;
        GetConsoleScreenBufferInfo(hConsoleOutput, &csbi);
        pauseForUser = ((csbi.dwCursorPosition.X==0) && (csbi.dwCursorPosition.Y==0));
        if ((csbi.dwSize.X<=0) || (csbi.dwSize.Y <= 0)) pauseForUser = false;
    }
    else
    {
        // We're not a "console" application, so create one
        // This could be commented out or made a command-line option
        OpenDebugWindow();
        pauseForUser = true;
    }
    
    
#endif // WIN32

    int exitCode = 0;
    if (theApp.OnStartup())
    {
    	printf("SimpleSendAndReceive: Starting main Loop....\n");
        exitCode = theApp.MainLoop();
        printf("SimpleSendAndReceive: Ended main Loop....\n");
        theApp.OnShutdown();
        printf("SimpleSendAndReceive: Done.\n");
#ifdef WIN32
        // If Win32 console is going to disappear, pause for user before exiting
        if (pauseForUser)
        {
            printf ("Program Finished - Hit <Enter> to exit");
            getchar();
        }
#endif // WIN32
    }
    else
    {
         fprintf(stderr, "SimpleSendAndReceive: Error initializing application!\n");
         return -1;  
    }      
    return exitCode;  // exitCode contains "signum" causing exit
}  // end main();

void SimpleSendAndReceive::SignalHandler(int sigNum)
{
    switch(sigNum)
    {
        case SIGTERM:
        case SIGINT:
            theApp.Stop(sigNum);  // causes theApp's main loop to exit
            break;
            
        default:
            fprintf(stderr, "SimpleSendAndReceive: Unexpected signal: %d\n", sigNum);
            break; 
    }  
}  // end SimpleSendAndReceive::SignalHandler()

