
//#define _REENTRANT

#include <stdio.h>
// #include <windows.h> /* For the CreateThread prototype */

// SimpleSendAndReceive.cpp - Simple demonstration of how to use Protlib Timers

#include "../../../protolib_current/protolib/common/protoLib.h"
// or whereever you installed protolib 

// on windows, there is a redhat pthread implementation you have to install 
// to run this program:
// http://sources.redhat.com/pthreads-win32/
// need the header file and the pthreadVC.lib file for compilation and then the library
// pthreadVC.dll for run-time - I put this is windows\system32 but I'm sure there's a 
// better way .....

// #include "../../pthread/include/pthread.h"

#include <stdio.h>   // for stdout/stderr printouts
#include <signal.h>  // for SIGTERM/SIGINT handling

class SimpleSendAndReceive
{
    public:
        SimpleSendAndReceive();

        bool OnStartup();
		void Stop(int exitCode) { dispatcher.Stop(exitCode); alive=false; }
		void OnShutdown() { socket.Close(); timer.Deactivate(); }
		bool recv(UdpSocket *s);
        bool send();   		
        bool secondTimer();   		
		int MainLoop(); 
		int count;

    private:
		// Function to implement the timer installer
		static bool TimerInstaller(ProtocolTimerInstallCmd cmd, double theDelay,
                      ProtocolTimerMgr* timerMgr, const void* installData);

        static void SignalHandler(int sigNum);
//		static void *runDataProviderThread(void *objID);

		static DWORD WINAPI runDataProviderThread(LPVOID); /* Function prototype */

        EventDispatcher dispatcher;
        
		ProtocolTimer timer;
		ProtocolTimer disTimer;
		ProtocolTimerMgr manager;
		double delay;
        UdpSocket socket;        
		bool alive;
//		pthread_t dataserverThreadID;
	    HANDLE hThread;
}; // end class SimpleSendAndReceive

SimpleSendAndReceive::SimpleSendAndReceive() {
    count =0;
	timer.Init(5.0, -1, 
                 (ProtocolTimerOwner*)this, 
                 (ProtocolTimeoutFunc)&SimpleSendAndReceive::send);  

	disTimer.Init(3.0, -1, 
                 (ProtocolTimerOwner*)this, 
                 (ProtocolTimeoutFunc)&SimpleSendAndReceive::secondTimer);  


	manager.SetInstaller(SimpleSendAndReceive::TimerInstaller, this);
	manager.InstallTimer(&timer);    
    alive=true;

    // Init socket, specifying async recv owner/handler, async installer
    socket.Init((UdpSocketOwner*)this, 
             (UdpSocketRecvHandler)&SimpleSendAndReceive::recv, 
			 EventDispatcher::SocketInstaller, &dispatcher);
}

					
bool SimpleSendAndReceive::OnStartup()
{
#ifdef WIN32
    if (!dispatcher.Win32Init())
    {
        fprintf(stderr, "protoApp:: Win32Init() error!\n");
        return false;
    }
#endif // WIN32
    
    // Open a udp socket
    if (UDP_SOCKET_ERROR_NONE != socket.Open(5003))
    {
        fprintf(stderr, "protoApp: Error opening UDP socket!\n");
        return false;
    }    

    signal(SIGTERM, SignalHandler);
    signal(SIGINT, SignalHandler);
    return true;
}  // end SimpleSendAndReceive::OnStartup()

int SimpleSendAndReceive::MainLoop() { 
    EventDispatcher::WaitStatus status;

#ifdef UNIX
    if (pthread_create(&dataserverThreadID, NULL, 
		SimpleSendAndReceive::runDataProviderThread, (void *)this) > 0) {
		printf("Thread could not be created...\n");
	}
#endif

#ifdef WIN32
	hThread = CreateThread(NULL,0,runDataProviderThread,(void *)this,0,&iID);
#endif

    while (alive) {	
        printf("End Run...\n");
        if (dispatcher.IsPending()) {
     		printf("Detected an event. Waiting...\n");
	        status = dispatcher.WaitForNextEvent();
            dispatcher.DispatchEvents(status);
		}
	}
	return true;
}


bool SimpleSendAndReceive::secondTimer() {
	printf("2nd Timer Called \n");
	return true;
}

bool SimpleSendAndReceive::send() {

    NetworkAddress addr;
	printf("Timer Invoked me !\n");
    addr.LookupHostAddress("127.0.0.1");
    // addr.LookupHostAddress("teaspoon");
    addr.SetPort(5003);
    char* buffer = "Hello, Proteus";
    unsigned int len = strlen(buffer) + 1;
    socket.SendTo(&addr, buffer, len);
     ++count;
    if (count == 2)
		dispatcher.InstallTimer(&disTimer);

    return true;
}       

bool SimpleSendAndReceive::recv(UdpSocket *s) {
    char buffer[512];
    unsigned int len = 512;
    NetworkAddress addr;
	
    socket.RecvFrom(buffer, &len, &addr);

    printf("Received %s on Socket !\n", buffer);

	// fprintf(stderr, "TimerTest:: Received \"%s\" from \"%s\"\n",
    //     buffer, addr.HostAddressString());
    return true;
}  // end TimerTest::OnSocketRecv()

bool SimpleSendAndReceive::TimerInstaller(ProtocolTimerInstallCmd cmd, double theDelay,
				ProtocolTimerMgr* timerMgr, const void* installData)
{
	// Note the timeMgr points to the same class as our manager variable here
    switch (cmd)
    {
		// demo code here -> insert whatever you require to keep track 
		// of internal variables, if needed

        case PROTOCOL_TIMER_INSTALL:

        case PROTOCOL_TIMER_MODIFY:
            break;
        case PROTOCOL_TIMER_REMOVE:
            break;
    }
    return true;
}  

// thread to send the data using my own timer....
// void *SimpleSendAndReceive::runDataProviderThread(void *objID) {
DWORD WINAPI SimpleSendAndReceive::runDataProviderThread(LPVOID obj) {
	do {
		((SimpleSendAndReceive *)obj)->manager.DoTimers();
	} while (true);
}

SimpleSendAndReceive theApp; 

int main(int argc, char* argv[])
{
    int exitCode=0;

    if (theApp.OnStartup())
    {
    	printf("SimpleSendAndReceive: Starting main Loop....\n");
        exitCode = theApp.MainLoop();
        printf("SimpleSendAndReceive: Ended main Loop....\n");
        theApp.OnShutdown();
        printf("SimpleSendAndReceive: Done.\n");
	}
    return exitCode;  // exitCode contains "signum" causing exit
}  // end main();

void SimpleSendAndReceive::SignalHandler(int sigNum)
{
    switch(sigNum)
    {
        case SIGTERM:
        case SIGINT:
            theApp.Stop(sigNum);  // causes theApp's main loop to exit
            break;
            
        default:
            fprintf(stderr, "SimpleSendAndReceive: Unexpected signal: %d\n", sigNum);
            break; 
    }  
}  // end SimpleSendAndReceive::SignalHandler()

