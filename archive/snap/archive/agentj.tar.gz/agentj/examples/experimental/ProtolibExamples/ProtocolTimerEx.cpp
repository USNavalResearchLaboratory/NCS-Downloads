
// ProtocolTimerEx.cpp - Simple demonstration of how to use Protlib Timers

#include "../../../protolib_current/protolib/common/protoLib.h"

// or whereever you installed protolib 

#include <stdio.h>   // for stdout/stderr printouts

class ProtocolTimerEx
{
    public:
        ProtocolTimerEx();
		ProtocolTimerMgr getTimerManager() { return manager; }

    private:
		// Function to implement the timer installer
		static bool TimerInstaller(ProtocolTimerInstallCmd cmd, double theDelay,
                      ProtocolTimerMgr* timerMgr, const void* installData);

        double delay;
        bool OnTimerTimeout();   
        ProtocolTimer timer;
		ProtocolTimerMgr manager;

}; // end class ProtocolTimerEx

ProtocolTimerEx::ProtocolTimerEx() {

    // Init timer for 1.0 second interval, infinite repeats
	    timer.Init(1.0, -1, 
                 (ProtocolTimerOwner*)this, 
                 (ProtocolTimeoutFunc)&ProtocolTimerEx::OnTimerTimeout);  
    	printf("ProtocolTimerEx: Initialized OK\n");

		manager.SetInstaller(ProtocolTimerEx::TimerInstaller, this);
		manager.InstallTimer(&timer);
}

bool ProtocolTimerEx::TimerInstaller(ProtocolTimerInstallCmd cmd, double theDelay,
				ProtocolTimerMgr* timerMgr, const void* installData)
{
	// Note the timeMgr points to the same class as our manager variable here
    switch (cmd)
    {
		// demo code here -> insert whatever you require to keep track 
		// of internal variables, if needed

        case PROTOCOL_TIMER_INSTALL:
        case PROTOCOL_TIMER_MODIFY:
            ((ProtocolTimerEx*)installData)->delay = theDelay;
            break;
        case PROTOCOL_TIMER_REMOVE:
            ((ProtocolTimerEx*)installData)->delay = -1.0;
            break;
    }
    return true;
}  

bool ProtocolTimerEx::OnTimerTimeout() {
	printf("Timer Finished !!\n");
	return 1;
}       

int main(int argc, char* argv[]) {
    ProtocolTimerEx theApp; 
	int exitCode=0;

		// keep polling the DoTimers method to check if the timer has finished or not
	do {
		theApp.getTimerManager().DoTimers();
	} while (true);

    return exitCode; 
}

