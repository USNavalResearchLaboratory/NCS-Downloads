
// TimerTest.cpp - Simple example application using Protean protLib
//               command-line dispatcher, timer, and socket classes

#include "../../protolib1.0a4/common/protoLib.h"

#include <stdio.h>   // for stdout/stderr printouts
#include <signal.h>  // for SIGTERM/SIGINT handling

class TimerTest
{
    public:
        TimerTest();
        bool OnStartup();
        //int MainLoop() {return dispatcher.Run();}

        int MainLoop() { p.DoTimers(); return 1; }
        
		void Stop(int exitCode) {dispatcher.Stop(exitCode);}
        void OnShutdown();
        
    private:
        bool OnTxTimeout();   
        bool OnSocketRecv(UdpSocket* theSocket);
        static void SignalHandler(int sigNum);
        EventDispatcher dispatcher;
        UdpSocket       socket;
        ProtocolTimerMgr p;
        ProtocolTimer   tx_timer;
}; // end class TimerTest

TimerTest::TimerTest()
{
	printf("TimerTest: Starting....\n");

    // Init tx_timer for 1.0 second interval, infinite repeats
    tx_timer.Init(1.0, -1, 
                 (ProtocolTimerOwner*)this, 
                 (ProtocolTimeoutFunc)&TimerTest::OnTxTimeout);  
    
	p.InstallTimer(&tx_timer);

    // Init socket, specifying async recv owner/handler, async installer
//    socket.Init((UdpSocketOwner*)this, 
  //              (UdpSocketRecvHandler)&TimerTest::OnSocketRecv, 
    //            EventDispatcher::SocketInstaller, 
      //         &dispatcher);
	printf("TimerTest: Initialized OK\n");
}

bool TimerTest::OnStartup()
{
#ifdef WIN32
    if (!dispatcher.Win32Init())
    {
        fprintf(stderr, "TimerTest:: Win32Init() error!\n");
        return false;
    }
#endif // WIN32

    // Open a udp socket
//    if (UDP_SOCKET_ERROR_NONE != socket.Open(5003))
//    {
  //      fprintf(stderr, "TimerTest: Error opening UDP socket!\n");
    //    return false;
  //  }    
    // Install our transmit timer
//    dispatcher.InstallTimer(&tx_timer);
    signal(SIGTERM, SignalHandler);
    signal(SIGINT, SignalHandler);
    return true;
}  // end TimerTest::OnStartup()

void TimerTest::OnShutdown()
{
    // socket.Close();
    tx_timer.Deactivate();
}  // end TimerTest::OnShutdown()

bool TimerTest::OnTxTimeout()
{
    NetworkAddress addr;
	printf("Timer Invoked me !\n");
    addr.LookupHostAddress("127.0.0.1");
    // addr.LookupHostAddress("teaspoon");
    addr.SetPort(5003);
    char* buffer = "Hello, Proteus";
    unsigned int len = strlen(buffer) + 1;
//    socket.SendTo(&addr, buffer, len);
    return true;
}  // end TimerTest::OnTxTimeout()

bool TimerTest::OnSocketRecv(UdpSocket* /*theSocket*/)
{
    char buffer[512];
    unsigned int len = 512;
    NetworkAddress addr;
	
	printf("Received Data on Socket !\n");

    socket.RecvFrom(buffer, &len, &addr);
//    fprintf(stderr, "TimerTest:: Received \"%s\" from \"%s\"\n",
  //          buffer, addr.HostAddressString());
    return true;
}  // end TimerTest::OnSocketRecv()
        
// Out application instance (global for SignalHandler)
TimerTest theApp; 


// Use "main()" for UNIX and WIN32 console apps, 
// "WinMain()" for non-console WIN32
// (VC++ uses the "_CONSOLE_ macro to indicate build type)

#if defined(WIN32) && !defined(_CONSOLE)
int PASCAL WinMain(HINSTANCE instance, HINSTANCE prevInst, LPSTR cmdline, int cmdshow)
#else
int main(int argc, char* argv[])
#endif
{
#ifdef WIN32
    // Hack to determine if Win32 console application was launched
    // independently or from a pre-existing console window
    bool pauseForUser = false;
    HANDLE hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
    if (INVALID_HANDLE_VALUE != hConsoleOutput)
    {
        CONSOLE_SCREEN_BUFFER_INFO csbi;
        GetConsoleScreenBufferInfo(hConsoleOutput, &csbi);
        pauseForUser = ((csbi.dwCursorPosition.X==0) && (csbi.dwCursorPosition.Y==0));
        if ((csbi.dwSize.X<=0) || (csbi.dwSize.Y <= 0)) pauseForUser = false;
    }
    else
    {
        // We're not a "console" application, so create one
        // This could be commented out or made a command-line option
        OpenDebugWindow();
        pauseForUser = true;
    }
    
    
#endif // WIN32

    int exitCode = 0;
    if (theApp.OnStartup())
    {
    	printf("TimerTest: Starting main Loop....\n");
        exitCode = theApp.MainLoop();

        printf("TimerTest: Ended main Loop....\n");
        theApp.OnShutdown();
        fprintf(stderr, "TimerTest: Done.\n");
#ifdef WIN32
        // If Win32 console is going to disappear, pause for user before exiting
        if (pauseForUser)
        {
            printf ("Program Finished - Hit <Enter> to exit");
            getchar();
        }
#endif // WIN32
    }
    else
    {
         fprintf(stderr, "TimerTest: Error initializing application!\n");
         return -1;  
    }      
    return exitCode;  // exitCode contains "signum" causing exit
}  // end main();

void TimerTest::SignalHandler(int sigNum)
{
    switch(sigNum)
    {
        case SIGTERM:
        case SIGINT:
            theApp.Stop(sigNum);  // causes theApp's main loop to exit
            break;
            
        default:
            fprintf(stderr, "TimerTest: Unexpected signal: %d\n", sigNum);
            break; 
    }  
}  // end TimerTest::SignalHandler()
