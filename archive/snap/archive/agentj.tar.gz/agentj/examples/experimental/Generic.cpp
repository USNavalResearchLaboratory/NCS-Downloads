
// protApp.cpp - Simple example application using Protean protLib
//               command-line dispatcher, timer, and socket classes

#include "PAI.h"

#include <stdio.h>   // for stdout/stderr printouts
#include <signal.h>  // for SIGTERM/SIGINT handling
#include "LinkedList.h"
#include "../../protolib_current/protolib/common/protoLib.h"

class PAI_Example
{
    public:
        PAI_Example();
		PAI pai;
        
    private:
        bool OnTxTimeout();   
        bool OnSocketRecv();
};


PAI_Example::PAI_Example() {
//	pai.init(); // runs dispatcher
//	pai.addTimer(1.0, 5, (PAIOwner *)this, (CallbackFunc)&PAI_Example::OnTxTimeout);
//	pai.addSocket(5003, (PAIOwner *)this, (CallbackFunc)&PAI_Example::OnSocketRecv);
	
//	pai.runTimers(); // listen for events indefintely

//	pai.cleanUp();

	LinkedList *ll;
    UdpSocket *socket;
    UdpSocket *toRemove;
	
	ll = new LinkedList();

	for (int i=0; i< 10; ++i) {
		socket = new UdpSocket();
		ll->addItem(socket);
		if (i==5)
			toRemove = socket;
	}

	ll->removeItem(toRemove);

	for (i=0; i< 10; ++i) 
		printf("Item %i = %li\n", i, ll->getItem(i));

	delete ll;
}


bool PAI_Example::OnTxTimeout() {
    char* buffer = "Hello, Proteus";
    unsigned int len = strlen(buffer) + 1;
	printf("Sending Packet ..... \n");
	pai.send("127.0.0.1", 5003, buffer, len);
	return true;
}  

bool PAI_Example::OnSocketRecv() {
    char *buffer;
    unsigned int len = 512;

    buffer = pai.recv("127.0.0.1", 5003, len);
	printf("Received..... %s\n", buffer);

	delete buffer;
	return true;
}  

int main(int argc, char* argv[]) {
	PAI_Example theApp; 
	return 1;
}  
