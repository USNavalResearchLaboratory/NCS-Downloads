

#include <stdio.h>   // for stdout/stderr printouts
#include "ExampleB.h"
// #include "ExampleB.h"
#include "ExampleC.h"

class ExampleApp 
{
    public:
		static int trigger;


        void anotherFunction() { 
			ExampleB b;
			ExampleC c;
			c.cFunction();
			b.bFunction();
			}           
    private:

		int variable1;
		int variable2;
};

int main(int argc, char* argv[]) {
	ExampleApp theApp;
	theApp.anotherFunction();
	printf("Value = %i\n", theApp.trigger);
	return 1;
}  


/*
#include <iostream.h>

class CMyClass {
public:
  static int m_i;
};

int CMyClass::m_i = 0;

void main() {
  CMyClass a,b;
  cout << a.m_i << endl;
  cout << b.m_i << endl;
  // a.m_i = 1;
  CMyClass::m_i = 2;
  cout << a.m_i << endl;
  cout << b.m_i << endl;
}
*/