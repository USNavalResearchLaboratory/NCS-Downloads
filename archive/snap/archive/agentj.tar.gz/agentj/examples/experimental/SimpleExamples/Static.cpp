#include <iostream.h>
#include <stdio.h>   // for stdout/stderr printouts

class Static {
    public:
	    static int trigger;

    private:

		int variable1;
		int variable2;
};

int Static::trigger=0;

int main(int argc, char* argv[]) {
	Static theApp;
	printf("Value = %i\n", theApp.trigger);
	theApp.trigger = 10;
	printf("Value = %i\n", theApp.trigger);
	return 1;
}  
