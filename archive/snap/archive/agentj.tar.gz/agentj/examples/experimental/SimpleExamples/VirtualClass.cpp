

#include <stdio.h>   // for stdout/stderr printouts
#include "ExampleB.h"
#include "ExampleC.h"

class ExampleApp 
{
    public:

        void anotherFunction() { 
			Example *b2;
			ExampleB b;
			ExampleC c;
			
			b2 = new ExampleB();

			c.aFunction();
			b.aFunction();

			b2->aFunction();
			}           
    private:

		int variable1;
		int variable2;
};

int main(int argc, char* argv[]) {
	ExampleApp theApp;
	theApp.anotherFunction();
	return 1;
}  


/*
#include <iostream.h>

class CMyClass {
public:
  static int m_i;
};

int CMyClass::m_i = 0;

void main() {
  CMyClass a,b;
  cout << a.m_i << endl;
  cout << b.m_i << endl;
  // a.m_i = 1;
  CMyClass::m_i = 2;
  cout << a.m_i << endl;
  cout << b.m_i << endl;
}
*/