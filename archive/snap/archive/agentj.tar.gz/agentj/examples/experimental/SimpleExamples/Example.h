#ifndef _EXAMPLE
#define _EXAMPLE

#include <stdio.h>   // for stdout/stderr printouts

class Example {
    public:
        virtual void aFunction() =0;
		// { printf("Example BASE CLASS Called\n"); } 
		
    private:
}; 

#endif // _EXAMPLE
