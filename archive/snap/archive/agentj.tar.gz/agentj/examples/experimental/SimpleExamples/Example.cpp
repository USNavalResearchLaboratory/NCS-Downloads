#include <stdio.h>   // for stdout/stderr printouts
#include "Example.h"

void Example::aFunction() { 
	printf("So What\n"); 

}   
