#include <stdio.h>   // for stdout/stderr printouts
#include "Example.h"

class ExampleC : public Example
{
    public:
        void aFunction() { printf("ExampleC Called\n"); } 
        
    private:
};
