#include <stdio.h>   // for stdout/stderr printouts
#include "Example.h"

class ExampleB : public Example
{
    public:
        void aFunction() { printf("ExampleB Called\n"); } 
        
    private:

		int variableC;
		int variableD;
};
