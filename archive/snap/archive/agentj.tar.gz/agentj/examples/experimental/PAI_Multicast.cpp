
// protApp.cpp - Simple example application using Protean protLib
//               command-line dispatcher, timer, and socket classes

#include "../PAI.h"

#include <stdio.h>   // for stdout/stderr printouts
#include <signal.h>  // for SIGTERM/SIGINT handling

class PAIMulticast
{
    public:
        PAIMulticast();

    private:
        bool OnTxTimeout();   
        bool OnSocketRecv();

		PAISocket *sock1;
		PAISocketListener *slist;
	    PTI *pti;
		PCI *pci;
		PAITimer *timer;
		PAITimerListener *tlist;
		PAI pai;
};


/**
 * The following defintions are made for callback functions and PAI owning classes:
 * 
 * In: PAISocket.h, the following is defined:
 *
 *  class PAIOwner{};
 *  typedef bool (PAIOwner::*CallbackFunc)();
 *
 * which means that a PAIOwner can be cast to any class - note the syntax is merely
 * for convenience here. A PAIOwner is a class that uses te PAI interface, so your
 * class that you are defining.
 * A Callback function has the following type:
 *
 *  bool (PAIOwner::*CallbackFunc) ();
 *
 * i.e. it returns a boolean and belongs to the PAIOwner class and has zero arguments.
 * So something like this would satisfy:
 *
 *    bool MyClass::mycallbackFunction() { // your code}
 */
PAIMulticast::PAIMulticast() {
    CallbackFunc timerCallback = (CallbackFunc)&PAIMulticast::OnTxTimeout;
    CallbackFunc socketCallback = (CallbackFunc)&PAIMulticast::OnSocketRecv;
	PAIOwner *owner = (PAIOwner *)this;

	pti = pai.getPTI(); // get the timing library
	pci = pai.getPCI(); // get the socket library
	
	timer = pti->addTimer(1.0, -1);
	sock1 = pci->addSocket(5003);

	pci->setMulticast(sock1, true);
	pci->joinGroup(sock1, "232.2.2.2");

//	pci->leaveGroup(sock1, "232.2.2.2");

	printf("Listeners \n");

	slist=pci->addListener(sock1, owner, socketCallback);
	tlist=pti->addListener(timer, owner, timerCallback);

	// pci->listen(); // listen for events indefintely

	cout << "Press any key to stop" << endl;
	getchar();

	pci->removeListener(sock1, slist);

	cout << "Press any key to delete socket" << endl;
	getchar();

	cout << "Socket" << endl;
	pci->removeSocket(sock1);

	cout << "Press any key to stop timer" << endl;
	getchar();

	pti->removeListener(timer, tlist);
	cout << "Timer" << endl;
	pti->removeTimer(timer);

	pti->cleanUp();
	pci->cleanUp();
}


bool PAIMulticast::OnTxTimeout() {
    char* buffer = "Hello, Proteus";
    unsigned int len = strlen(buffer) + 1;

	try {
		pci->send(sock1, "232.2.2.2", buffer, len);
	} catch (PAISocketSendError *err) {
		cout << err->getError() << endl;
	}

	printf("..........Sending %s\n", buffer);

	return true;
}  


bool PAIMulticast::OnSocketRecv() {
    char *buffer;
	const char *address;
    unsigned int len=512;

    buffer = pci->recv(sock1, &address, &len);
	printf("..........Received %s from %s\n", buffer, address);

	delete buffer;
	return true;
}  

int main(int argc, char* argv[]) {
	PAIMulticast theApp; 

	return 1;
}  
