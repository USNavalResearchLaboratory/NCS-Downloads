
#include "../LinkedList.h"
#include "../UDP_PAISocket.h"

#include <stdio.h>   // for stdout/stderr printouts
#include <signal.h>  // for SIGTERM/SIGINT handling
#include <string.h>


class PAI_Example
{
    public:
        PAI_Example();
		LinkedList ll;

};


PAI_Example::PAI_Example() {
	UDP_PAISocket *socket;
    ListItem *l;
	int id;
    char* buffer;
	
	buffer = new char[10];
	
	strcpy(buffer, "Hello, You");
	
	socket = new UDP_PAISocket();
	printf("Socket created...\n");
	
	socket->pingString(buffer);
	socket->ping();

	l = ll.addItem(socket);
	printf("Added ...\n");
	id = l->getID();
	printf("ID...\n");
}

int main(int argc, char* argv[]) {
	PAI_Example *theApp = new PAI_Example(); 

	UDP_PAISocket *socket;

	printf("Trying to extract socket......\n");

	socket = (UDP_PAISocket *)theApp->ll.getItem(0);

	socket->ping();

	return 1;
}  
