#include "C_ControlAgent.h"

#include <iostream.h>

static class C_ControlAgentExampleClass : public TclClass
{
	public:
		C_ControlAgentExampleClass() : TclClass("Agent/C_ControlAgent") {}
	 	TclObject *create(int argc, const char*const* argv)
			{return (new C_ControlAgent());}
} class_protean_example;


C_ControlAgent::C_ControlAgent()
{
    char *ad;
    char tclCommand[20];

     tcl = &Tcl::instance();

    udp_socket.Init((UdpSocketOwner*)this,
                    (UdpSocketRecvHandler)&C_ControlAgent::OnReceive,
                    ProtoSimAgent::SocketInstaller,
                    static_cast<ProtoSimAgent*>(this));

    timer_mgr.SetInstaller(ProtoSimAgent::TimerInstaller,
                           static_cast<ProtoSimAgent*>(this));

    tx_timer.Init(10.0, -1, (ProtocolTimerOwner*)this,
                  (ProtocolTimeoutFunc)&C_ControlAgent::OnTxTimeout);


    tcl->evalf("Node allocaddr");
    ad = tcl->result();
 // Convert the group address string to a ProtoAddress
//    grp_addr.LookupHostAddress(ad);

    cout << "Group address allocated is " << ad << endl;
    sprintf(tclCommand, "set group %s", ad);
    tcl->evalf(tclCommand);
    cout << tcl->result() << endl;
}

C_ControlAgent::~C_ControlAgent()
{
}

int C_ControlAgent::command(int argc, const char*const* argv)
{
    if (4 == argc)
    {
        if (!strcmp(argv[1], "send"))
        {
            if (UDP_SOCKET_ERROR_NONE != udp_socket.Open(4444))
            {
                fprintf(stderr, "C_ControlAgent::command(send) socket open error\n");
                return TCL_ERROR;
            }

	    /* old code that takes in address from TCL - we allocate it here in C++ */

	    grp_addr.LookupHostAddress(argv[2]);
            grp_addr.SetPort(atoi(argv[3]));

	    cout << "RAW: Port =  " << argv[3] << " and address is " << argv[2]  << endl;
	    cout << "After Protolib: port " << udp_socket.Port() << " and address is " << grp_addr.HostAddressString() << endl;

	    OnTxTimeout();  // transmit first packet right away
            timer_mgr.InstallTimer(&tx_timer);
            return TCL_OK;
        }
        else if (!strcmp(argv[1], "recv"))  // recv <groupAddr> <port>
        {
            unsigned short recvPort = atoi(argv[3]);
            if (udp_socket.IsOpen())
            {
                if (recvPort != udp_socket.Port())
                {
                    fprintf(stderr, "C_ControlAgent::command(recv <addr> <port>) socket already "
                                    "open on different port\n");
                    return TCL_ERROR;
                }
            }
            else if (UDP_SOCKET_ERROR_NONE != udp_socket.Open(recvPort))
            {
                fprintf(stderr, "C_ControlAgent::command(start) socket open error\n");
                return TCL_ERROR;
            }
            NetworkAddress groupAddr;
            groupAddr.LookupHostAddress(argv[2]);
            if (groupAddr.IsMulticast())
            {
                udp_socket.JoinGroup(&groupAddr);
            }
            else
            {
                fprintf(stderr, "C_ControlAgent::command(recv <addr> <port>) not a multicast address\n");
            }
            return TCL_OK;
        }
    }
    else if (3 == argc)
    {
        if (!strcmp(argv[1], "setID")) {
            myID = atoi(argv[2]);
	    cout << "My ID = " << myID << endl;
            return TCL_OK;
        }
        if (!strcmp(argv[1], "recv"))
        {
            unsigned short recvPort = atoi(argv[2]);
            if (udp_socket.IsOpen())
            {
                if (recvPort != udp_socket.Port())
                {
                    fprintf(stderr, "C_ControlAgent::command(recv <port>) socket already "
                                    "open on different port\n");
                    return TCL_ERROR;
                }
                else
                {
                    return TCL_OK;
                }
            }
            if (UDP_SOCKET_ERROR_NONE != udp_socket.Open(recvPort))
            {
                fprintf(stderr, "C_ControlAgent::command(start) socket open error\n");
                return TCL_ERROR;
            }
            return TCL_OK;
        }
    }
    else if (2 == argc)
    {

	if (!strcmp(argv[1], "start")) {
	    if (myID==2) { // node 2 receives from node 1
		tcl->evalf("$n1 node-addr");
		char* ad = tcl->result();
    		tcl->evalf("$p1 port");
		char *pt = tcl->result();

	        cout << "Node 1: port " << pt << " and address is " << ad << endl;
		}
	    if (myID==1) { // node 1 send to node 2
	        // first get node 2's address
 		tcl->evalf("$n2 node-addr");
		dst_addr.LookupHostAddress(tcl->result());
    		tcl->evalf("$p2 port");
		char *pt = tcl->result();
                dst_addr.SetPort( atoi(pt));

	        cout << "Node 2: port " << dst_addr.Port() << " and address is " << dst_addr.HostAddressString() << endl;

	        SendToNodes(); //send the packet to node 2
		}
            return TCL_OK;
	    }

	if (!strcmp(argv[1], "stop"))
        {
            if (tx_timer.IsActive()) tx_timer.Deactivate();
            udp_socket.Close();
            return TCL_OK;
        }
        else if (!strcmp(argv[1], "recv"))
        {
            if (UDP_SOCKET_ERROR_NONE != udp_socket.Open())
            {
                fprintf(stderr, "C_ControlAgent::command(start) socket open error\n");
                return TCL_ERROR;
            }
            return TCL_OK;
        }
    }
    return NsProtoAgent::command(argc, argv);
}  // end C_ControlAgent::command()

bool C_ControlAgent::OnTxTimeout()
{
    char* buffer = "Hello, Proteus";
    unsigned int len = strlen(buffer) + 1;
    cout << "Sending to: port " << grp_addr.Port() << " and address is " << grp_addr.HostAddressString() << endl;
    udp_socket.SendTo(&grp_addr, buffer, len);
    return true;
}  // end C_ControlAgent::OnTxTimeout()

bool C_ControlAgent::SendToNodes()
{
    char* buffer = "Hello, proteus again";
    unsigned int len = strlen(buffer) + 1;
    cout << "Sending to: port " << dst_addr.Port() << " and address is " << dst_addr.HostAddressString() << endl;
    udp_socket.SendTo(&dst_addr, buffer, len);
    return true;
}  // end C_ControlAgent::OnTxTimeout()

bool C_ControlAgent::OnReceive()
{
    char buffer[512];
    unsigned int buflen = 512;
    NetworkAddress src;
    udp_socket.RecvFrom(buffer, &buflen, &src);
    cout << "MyID = " << myID << ": " << endl;
    fprintf(stderr, "C_ControlAgent::OnReceive() %d.%hu received \"%s\" from %s.%hu\n",
            addr(), udp_socket.Port(), buffer,
            src.HostAddressString(), src.Port());
    return true;
}  // end C_ControlAgent::OnReceive()



