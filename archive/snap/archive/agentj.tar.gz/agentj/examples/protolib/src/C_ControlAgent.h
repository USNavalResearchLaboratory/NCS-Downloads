
#ifndef _PAI_AGENT
#define _PAI_AGENT

#include "nsProtoAgent.h"


class C_ControlAgent : public NsProtoAgent
{
    public:
        C_ControlAgent();
        ~C_ControlAgent();

    protected:
        virtual int command(int argc, const char*const* argv);

    private:
        bool OnTxTimeout();
        bool OnReceive();
	bool SendToNodes();

        ProtocolTimerMgr    timer_mgr;
        ProtocolTimer       tx_timer;
        UdpSocket           udp_socket;
        NetworkAddress      dst_addr;
        NetworkAddress      grp_addr;
	int myID;
        Tcl* tcl;
	
};  // end class


#endif // _PAI_AGENT
