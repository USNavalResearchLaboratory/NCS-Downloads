#include "BasicAgent.h"

#include <iostream.h>

static class BasicAgentExampleClass : public TclClass
{
	public:
		BasicAgentExampleClass() : TclClass("Agent/BasicAgent") {}
	 	TclObject *create(int argc, const char*const* argv)
			{return (new BasicAgent());}
} class_protean_example;


BasicAgent::BasicAgent()
{
    udp_socket.Init((UdpSocketOwner*)this,
                    (UdpSocketRecvHandler)&BasicAgent::OnReceive,
                    ProtoSimAgent::SocketInstaller,
                    static_cast<ProtoSimAgent*>(this));

    timer_mgr.SetInstaller(ProtoSimAgent::TimerInstaller,
                           static_cast<ProtoSimAgent*>(this));

    tx_timer.Init(1.0, -1, (ProtocolTimerOwner*)this,
                  (ProtocolTimeoutFunc)&BasicAgent::OnTxTimeout);
}

BasicAgent::~BasicAgent()
{
}

int BasicAgent::command(int argc, const char*const* argv)
{
    if (4 == argc)
    {
        if (!strcmp(argv[1], "send"))
        {
            if (UDP_SOCKET_ERROR_NONE != udp_socket.Open(7777))
            {
                fprintf(stderr, "BasicAgent::command(send) socket open error\n");
                return TCL_ERROR;
            }

	    cout << "Port =  " << argv[2] << " and address is " << argv[3]  << endl;

	    dst_addr.LookupHostAddress(argv[2]);
            dst_addr.SetPort(atoi(argv[3]));

	    cout << "Socket using port " << udp_socket.Port() << " and address is " << dst_addr.HostAddressString() << endl;

	    OnTxTimeout();  // transmit first packet right away
            timer_mgr.InstallTimer(&tx_timer);
            return TCL_OK;
        }
        else if (!strcmp(argv[1], "recv"))  // recv <groupAddr> <port>
        {
            unsigned short recvPort = atoi(argv[3]);
            if (udp_socket.IsOpen())
            {
                if (recvPort != udp_socket.Port())
                {
                    fprintf(stderr, "BasicAgent::command(recv <addr> <port>) socket already "
                                    "open on different port\n");
                    return TCL_ERROR;
                }
            }
            else if (UDP_SOCKET_ERROR_NONE != udp_socket.Open(recvPort))
            {
                fprintf(stderr, "BasicAgent::command(start) socket open error\n");
                return TCL_ERROR;
            }
            NetworkAddress groupAddr;
            groupAddr.LookupHostAddress(argv[2]);
            if (groupAddr.IsMulticast())
            {
                udp_socket.JoinGroup(&groupAddr);
            }
            else
            {
                fprintf(stderr, "BasicAgent::command(recv <addr> <port>) not a multicast address\n");
            }
            return TCL_OK;
        }
    }
    else if (3 == argc)
    {
        if (!strcmp(argv[1], "recv"))
        {
            unsigned short recvPort = atoi(argv[2]);
            if (udp_socket.IsOpen())
            {
                if (recvPort != udp_socket.Port())
                {
                    fprintf(stderr, "BasicAgent::command(recv <port>) socket already "
                                    "open on different port\n");
                    return TCL_ERROR;
                }
                else
                {
                    return TCL_OK;
                }
            }
            if (UDP_SOCKET_ERROR_NONE != udp_socket.Open(recvPort))
            {
                fprintf(stderr, "BasicAgent::command(start) socket open error\n");
                return TCL_ERROR;
            }
            return TCL_OK;
        }
    }
    else if (2 == argc)
    {
        if (!strcmp(argv[1], "stop"))
        {
            if (tx_timer.IsActive()) tx_timer.Deactivate();
            udp_socket.Close();
            return TCL_OK;
        }
        else if (!strcmp(argv[1], "recv"))
        {
            if (UDP_SOCKET_ERROR_NONE != udp_socket.Open())
            {
                fprintf(stderr, "BasicAgent::command(start) socket open error\n");
                return TCL_ERROR;
            }
            return TCL_OK;
        }
    }
    return NsProtoAgent::command(argc, argv);
}  // end BasicAgent::command()

bool BasicAgent::OnTxTimeout()
{
    char* buffer = "Hello, Proteus";
    unsigned int len = strlen(buffer) + 1;
    udp_socket.SendTo(&dst_addr, buffer, len);
    return true;
}  // end BasicAgent::OnTxTimeout()

bool BasicAgent::OnReceive()
{
    char buffer[512];
    unsigned int buflen = 512;
    NetworkAddress src;
    udp_socket.RecvFrom(buffer, &buflen, &src);
    fprintf(stderr, "BasicAgent::OnReceive() %d.%hu received \"%s\" from %s.%hu\n",
            addr(), udp_socket.Port(), buffer,
            src.HostAddressString(), src.Port());
    return true;
}  // end BasicAgent::OnReceive()



