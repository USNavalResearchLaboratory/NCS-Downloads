
#ifndef _PAI_AGENT
#define _PAI_AGENT

#include "nsProtoAgent.h"


class BasicAgent : public NsProtoAgent
{
    public:
        BasicAgent();
        ~BasicAgent();

    protected:
        virtual int command(int argc, const char*const* argv);

    private:
        bool OnTxTimeout();
        bool OnReceive();

        ProtocolTimerMgr    timer_mgr;
        ProtocolTimer       tx_timer;
        UdpSocket           udp_socket;
        NetworkAddress      dst_addr;

};  // end class


#endif // _PAI_AGENT
