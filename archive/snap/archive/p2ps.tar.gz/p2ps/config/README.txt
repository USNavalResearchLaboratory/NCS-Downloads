To make the log4j use any layout in this directory use the following
syntax:
 
java  -Dlog4j.configuration=$P2PSHOME/config/log4jLayout.xml JavaClass
etc

