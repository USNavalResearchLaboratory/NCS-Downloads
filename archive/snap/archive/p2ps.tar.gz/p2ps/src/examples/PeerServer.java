package examples;

import p2ps.discovery.AdvertisementFactory;
import p2ps.discovery.DiscoveryService;
import p2ps.imp.peer.ConfigFactory;
import p2ps.imp.peer.PeerImp;
import p2ps.peer.Peer;
import p2ps.pipe.*;

import java.io.IOException;


public class PeerServer implements MessageListener {

    private AdvertisementFactory adverts;
    private DiscoveryService discovery;
    private PipeService pipes;


    public PeerServer() throws IOException {
        Peer peer = new PeerImp(ConfigFactory.getConfig(ConfigFactory.CONFIG_WINDOW_ALWAYS));
        peer.init();

        // retrieve services
        adverts = peer.getAdvertisementFactory();
        discovery = peer.getDiscoveryService();
        pipes = peer.getPipeService();

        System.out.println("Server Started");

        // initialise server pipe advertisement
        PipeAdvertisement pipead = (PipeAdvertisement) adverts.newAdvertisement(PipeAdvertisement.PIPE_ADVERTISEMENT_TYPE);
        pipead.setPipeName("serverPipe");

        // create server pipe and attach listener
        InputPipe inpipe = pipes.createInputPipe(pipead);
        inpipe.addPipeListener(this);

        // publish server pipe advertisement
        discovery.publish(pipead);
    }


    public void messageReceived(MessageReceivedEvent event) {
        // display received messages
        System.out.println("\nMessage: " + new String(event.getMessage()));
        System.out.println("(Received on " + event.getInputPipe().getPipeName() + " " + event.getInputPipe().getPipeID() + ")");
    }


    public static void main(String[] args) throws IOException {
        new PeerServer();
    }

}
