/*
 * Copyright (c) 1995 onwards, University of Wales College of Cardiff
 *
 * Permission to use and modify this software and its documentation for
 * any purpose is hereby granted without fee provided a written agreement
 * exists between the recipients and the University.
 *
 * Further conditions of use are that (i) the above copyright notice and
 * this permission notice appear in all copies of the software and
 * related documentation, and (ii) the recipients of the software and
 * documentation undertake not to copy or redistribute the software and
 * documentation to any other party.
 *
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF WALES COLLEGE OF CARDIFF BE LIABLE
 * FOR ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
 * KIND, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON
 * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package examples;

import p2ps.discovery.AdvertisementFactory;
import p2ps.discovery.DiscoveryEvent;
import p2ps.discovery.DiscoveryListener;
import p2ps.discovery.DiscoveryService;
import p2ps.imp.peer.ConfigFactory;
import p2ps.imp.peer.PeerImp;
import p2ps.peer.Peer;
import p2ps.pipe.*;
import p2ps.service.ServiceAdvertisement;
import p2ps.service.ServiceQuery;

import java.io.IOException;
import java.net.SocketException;
import java.util.ArrayList;

/**
 * A p2ps example that links multiple chat clients
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 17th June October 2004
 * @date $Date: 2004/07/16 17:21:14 $ modified by $Author: spxinw $
 */

public class Chat implements DiscoveryListener, PipeConnectionListener, MessageListener {

    public static final String CHAT_SERVICE = "ChatService";
    public static final String CHAT_PIPE = "ChatPipe";

    private AdvertisementFactory adfactory;
    private DiscoveryService discserv;
    private PipeService pipeserv;

    private ChatWindow window;

    // ids of the discovered chat services
    private ArrayList servids = new ArrayList();

    // ouput pipes to the discovered chat services
    private ArrayList outpipes = new ArrayList();


    public Chat(Peer peer) throws IOException {
        // initialise chat window
        this.window = new ChatWindow(this);

        this.adfactory = peer.getAdvertisementFactory();
        this.discserv = peer.getDiscoveryService();
        this.pipeserv = peer.getPipeService();

        // register as a pipe discovery listener
        this.pipeserv.addPipeConnectionListener(this);

        // creates and advertises this chat service
        createChatService();

        // discover other chat service instances
        discoverChatServices();

        // sets the window to visible
        window.setVisible(true);
    }

    /**
     * Create a chat service with a chat pipe and registers this class as a
     * listener for that pipe. Publish an advert for the chat service.
     */
    private void createChatService() throws IOException {
        // create chat service advertisement
        ServiceAdvertisement servad = (ServiceAdvertisement) adfactory.newAdvertisement(ServiceAdvertisement.SERVICE_ADVERTISEMENT_TYPE);
        servad.setServiceName(CHAT_SERVICE);

        // create chat pipe advertisement
        PipeAdvertisement pipead = (PipeAdvertisement) adfactory.newAdvertisement(PipeAdvertisement.PIPE_ADVERTISEMENT_TYPE);
        pipead.setPipeName(CHAT_PIPE);

        // create chat pipe from pipe advertisement
        InputPipe inpipe = pipeserv.createInputPipe(pipead);

        // register this class as a listener to the chat pipe
        inpipe.addPipeListener(this);

        // attach chat pipe for service advertisement
        servad.addPipeAdvertisement(pipead);

        // publish chat service advertisement
        discserv.publish(servad);
    }

    /**
     * Create and publish a query for chat services. Also attach this class as
     * a listener for discovered advertisements
     */
    private void discoverChatServices() throws IOException {
        // listen for discovered advertisements
        discserv.addDiscoveryListener(this);

        // create chat service query
        ServiceQuery query = (ServiceQuery) adfactory.newAdvertisement(ServiceQuery.SERVICE_QUERY_TYPE);
        query.setQueryServiceName(CHAT_SERVICE);

        // publish chat service query
        discserv.publish(query);
    }

    /**
     * Called when the discserv service discovers a new advertisement
     */
    public void advertDiscovered(DiscoveryEvent event) {
        // only interested in chat service advertisements
        if ((event.getAdvertisement() instanceof ServiceAdvertisement) &&
                (((ServiceAdvertisement) event.getAdvertisement()).getServiceName().equals(CHAT_SERVICE))) {
            handleChatServiceAdvertisement((ServiceAdvertisement) event.getAdvertisement());
        }
    }

    /**
     * Connect an output pipe to the chat pipe of the discovered chat service,
     * and sends an introductory message.
     */
    private void handleChatServiceAdvertisement(ServiceAdvertisement advert) {
        try {
            // only interested in new chat service advertisements
            if (!servids.contains(advert.getServiceID())) {
                // add this service to the discovered services list
                servids.add(advert.getServiceID());

                // get the chat pipe from the service advertisement
                PipeAdvertisement pipead = advert.getPipeAdvertisement(CHAT_PIPE);

                if (pipead != null) {
                    // attempt to connect an output pipe to the discovered chat pipe
                    pipeserv.connectOutputPipe(pipead);
                }
            }
        } catch (IOException except) {
            except.printStackTrace();
        }
    }


    /**
     * Called when an output pipe is successfully connected
     */
    public void outpipeConnected(PipeConnectedEvent event) {
        try {
            // only interested in chat pipes
            if (event.getPipeAdvertisement().getPipeName().equals(CHAT_PIPE)) {
                outpipes.add(event.getOutputPipe());

                // send introductory message
                String mess = "# " + window.getChatName() + " is online";
                event.getOutputPipe().send(mess.getBytes());
            }
        } catch (IOException except) {
            except.printStackTrace();
        }
    }

    /**
     * Called when an output pipe is successfully connected
     */
    public void outpipeConnectFailure(PipeConnectFailureEvent event) {
        // only interested in chat pipes
        if (event.getPipeAdvertisement().getPipeName().equals(CHAT_PIPE)) {
            window.print("# Error connection chat pipe to peer " + event.getPipeAdvertisement().getPeerID());

            if (event.getException() != null)
                event.getException().printStackTrace();
        }
    }


    /**
     * Called when a message is received by the chat pipe
     */
    public void messageReceived(MessageReceivedEvent event) {
        // create chat message
        String chatstr = new String(event.getMessage());

        // print message to chat window
        window.print(chatstr);
    }

    /**
     * Called by the chat window when the user sends a message
     */
    public void sendMessage(String mess) {
        try {
            for (int count = 0; count < outpipes.size(); count++) {
                // iterate over the discovered chat pipes
                OutputPipe outpipe = (OutputPipe) outpipes.get(count);

                try {
                    // send message
                    outpipe.send(mess.getBytes());
                } catch (SocketException except) {
                    // remove closed output pipes
                    outpipe.close();
                    outpipes.remove(outpipe);
                    count--;
                }
            }
        } catch (IOException except) {
            except.printStackTrace();
        }
    }

    /**
     * Called by the chat window to close the chat service
     */
    public void stop() {
        // send farewell messages
        sendMessage("# " + window.getChatName() + " is no longer online");

        // close pipes
        for (int count = 0; count < outpipes.size(); count++)
            try {
                ((OutputPipe) outpipes.get(count)).close();
            } catch (IOException except) {
            }

        System.exit(0);
    }


    public static void main(String[] args) throws IOException {
        // create new peer
        Peer peer = new PeerImp(ConfigFactory.getConfig(ConfigFactory.CONFIG_WINDOW_ALWAYS));

        // initialise peer
        peer.init();

        // instantiate chat
        new Chat(peer);
    }

}
