package examples;

import p2ps.discovery.*;
import p2ps.imp.peer.ConfigFactory;
import p2ps.imp.peer.PeerImp;
import p2ps.peer.Peer;
import p2ps.pipe.*;

import java.io.IOException;

public class PeerClient implements DiscoveryListener, PipeConnectionListener {

    public static final String SERVER_PIPE_NAME = "serverPipe";
    
    private AdvertisementFactory adverts;
    private DiscoveryService discovery;
    private PipeService pipes;

    public PeerClient() throws IOException {
        Peer peer = new PeerImp(ConfigFactory.getConfig(ConfigFactory.CONFIG_WINDOW_ALWAYS));
        peer.init();

        // retrieve services
        adverts = peer.getAdvertisementFactory();
        discovery = peer.getDiscoveryService();
        pipes = peer.getPipeService();

        // listen for discovered advertisements
        discovery.addDiscoveryListener(this);
        pipes.addPipeConnectionListener(this);

        System.out.println("Client Started: Locating Server Pipe");

        // create pipe query for server pipe
        PipeQuery pipequery = (PipeQuery) adverts.newAdvertisement(PipeQuery.PIPE_QUERY_TYPE);
        pipequery.setQueryPipeName(SERVER_PIPE_NAME);

        // publish pipe query
        discovery.publish(pipequery);
    }


    public void advertDiscovered(DiscoveryEvent event) {
        try {
            Advertisement advert = event.getAdvertisement();

            // handle discovered server pipe advertisement
            if ((advert instanceof PipeAdvertisement) && ((PipeAdvertisement) advert).getPipeName().equals(SERVER_PIPE_NAME)) {
                System.out.println("\nPipe discovered: " + ((PipeAdvertisement) advert).getPipeName() + " " + ((PipeAdvertisement) advert).getPipeID());

                // connect output pipe to discovered pipe
                pipes.connectOutputPipe((PipeAdvertisement) advert);
            }
        } catch (IOException except) {
            except.printStackTrace();
        }
    }


    /**
     * Called when an output pipe is successfully connected
     */
    public void outpipeConnected(PipeConnectedEvent event) {
        // only interested in server pipes
        if (event.getPipeAdvertisement().getPipeName().equals(SERVER_PIPE_NAME)) {
            try {
                // send test message
                event.getOutputPipe().send("HELLO".getBytes());

                System.out.println("Pipe Connected: 'HELLO' message sent");
            } catch (IOException except) {
            }
        }
    }

    /**
     * Called when an output pipe is successfully connected
     */
    public void outpipeConnectFailure(PipeConnectFailureEvent event) {
        // only interested in server pipes
        if (event.getPipeAdvertisement().getPipeName().equals(SERVER_PIPE_NAME)) {
            System.out.println("Pipe connect failure!");

            if (event.getException() != null)
                event.getException().printStackTrace();
        }
    }


    public static void main(String[] args) throws IOException {
        new PeerClient();
    }

}
