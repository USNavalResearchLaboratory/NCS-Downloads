package p2ps.peer;

import org.jdom.Element;

import java.io.IOException;

/**
 * The config for an advert/endpoint address instantiator
 *
 * @author      Ian Wang
 * @created     1st July 2004
 * @version     $Revision: 1.1 $
 * @date        $Date: 2004/07/02 11:21:02 $ modified by $Author: spxinw $
 * @todo
 */

public interface InstantiatorConfig {

    public static final String INSTANTIATOR_CONFIG_TAG = "instantiatorConfig";
    public static final String CLASS_NAME_TAG = "instantiatorClassName";
    public static final String TYPE_TAG = "type";


    /**
     * @return the name of the instantiator's Java class
     */
    public String getInstantiatorClass();

    /**
     * @return the name of the type instantiated by this instantiator
     */
    public String getInstantiatorType();

    /**
     * Outputs the InstantiatorConfig as an XML Element
     */
    public Element getXMLElement() throws IOException;

}
