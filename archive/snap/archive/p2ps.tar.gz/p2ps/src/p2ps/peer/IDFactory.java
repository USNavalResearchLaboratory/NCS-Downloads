package p2ps.peer;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * A factory class for generating peer, pipe and advertisement ids
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 18th March 2003
 * @date $Date: 2004/07/02 13:40:52 $ modified by $Author: spxinw $
 * @todo
 */

public class IDFactory {

    public static IDFactoryInterface factory;


    public static final String newPeerID() {
        return factory.newPeerID();
    }

    public static final String newAdvertID() {
        return factory.newAdvertID();
    }

    public static final String newPipeID() {
        return factory.newPipeID();
    }

    public static final String newServiceID() {
        return factory.newServiceID();
    }


}
