package p2ps.peer;

import p2ps.discovery.AdvertisementFactory;
import p2ps.discovery.DiscoveryService;
import p2ps.pipe.PipeService;
import p2ps.rendezvous.RendezvousService;
import p2ps.endpoint.EndpointAddressFactory;

import java.io.IOException;


/**
 * A peer
 *
 * @author Ian Wang
 * @version $Revision: 1.3 $
 * @created 20th March 2003
 * @date $Date: 2004/07/02 11:21:02 $ modified by $Author: spxinw $
 * @todo
 */

public interface Peer {

    /**
     * Initialises the peer
     */
    public void init() throws IOException;


    /**
     * @return the unique id for this peer
     */
    public String getPeerID();


    /**
     * @return the advertisement factory
     */
    public AdvertisementFactory getAdvertisementFactory();

    /**
     * @return the endpoint address factory
     */
    public EndpointAddressFactory getEndpointAddressFactory();


    /**
     * @return the discovery service
     */
    public DiscoveryService getDiscoveryService();

    /**
     * @return the rendezvous service (null if not rendezvous)
     */
    public RendezvousService getRendezvousService();

    /**
     * @return the pipe service
     */
    public PipeService getPipeService();

}
