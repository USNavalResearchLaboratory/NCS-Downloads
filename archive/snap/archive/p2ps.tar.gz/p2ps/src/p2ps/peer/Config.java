/*
 * The University of Wales, Cardiff Triana Project Software License (Based
 * on the Apache Software License Version 1.1)
 *
 * Copyright (c) 2003 University of Wales, Cardiff. All rights reserved.
 *
 * Redistribution and use of the software in source and binary forms, with
 * or without modification, are permitted provided that the following
 * conditions are met:
 *
 * 1.  Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 * 2.  Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * 3. The end-user documentation included with the redistribution, if any,
 *    must include the following acknowledgment: "This product includes
 *    software developed by the University of Wales, Cardiff for the Triana
 *    Project (http://www.trianacode.org)." Alternately, this
 *    acknowledgment may appear in the software itself, if and wherever
 *    such third-party acknowledgments normally appear.
 *
 * 4. The names "Triana" and "University of Wales, Cardiff" must not be
 *    used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact triana@trianacode.org.
 *
 * 5. Products derived from this software may not be called "Triana," nor
 *    may Triana appear in their name, without prior written permission of
 *    the University of Wales, Cardiff.
 *
 * 6. This software may not be sold, used or incorporated into any product
 *    for sale to third parties.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 * NO EVENT SHALL UNIVERSITY OF WALES, CARDIFF OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Triana Project. For more information on the
 * Triana Project, please see. http://www.trianacode.org.
 *
 * This license is based on the BSD license as adopted by the Apache
 * Foundation and is governed by the laws of England and Wales.
 */

package p2ps.peer;

import p2ps.endpoint.EndpointAddress;

import java.io.IOException;

/**
 * The configuration for a p2ps peer.
 *
 * @author Ian Wang
 * @version $Revision: 1.3 $
 * @created 7th July 2003
 * @date $Date: 2004/07/02 11:21:01 $ modified by $Author: spxinw $
 * @todo
 */

public interface Config {

    public static final int DEFAULT_MIN_PORT = 2223;
    public static final int DEFAULT_MAX_PORT = 2333;

    public static final String PROPERTIES_FILE = "p2ps.properties";

    // XML Tag Names
    public static final String P2PS_CONFIG_TAG = "p2psConfig";
    public static final String DISCOVERY_SERVICE_CLASS_TAG = "discoveryServiceClass";
    public static final String PIPE_SERVICE_CLASS_TAG = "pipeServiceClass";
    public static final String RENDEZVOUS_SERVICE_CLASS_TAG = "rendezvousServiceClass";
    public static final String ID_FACTORY_CLASS_TAG = "idFactoryClass";
    public static final String ADVERT_INSTANTIATORS_TAG = "advertInstantiators";
    public static final String ENDPOINT_ADDRESS_INSTANTIATORS_TAG = "endpointAddressInstantiators";
    public static final String RENDEZVOUS_TAG = "isRendezvous";
    public static final String PORT_MIN_TAG = "portRangeMin";
    public static final String PORT_MAX_TAG = "portTangeMax";
    public static final String LOCAL_END_TAG = "localEndPoints";
    public static final String REMOTE_END_TAG = "remoteEndPoints";


    /**
     * @return the class of the discovery service
     */
    public String getDiscoveryServiceClass();

    /**
     * @return the class of the pipe service
     */
    public String getPipeServiceClass();

    /**
     * @return the class of the rendezvous service
     */
    public String getRendezvousServiceClass();

    /**
     * @return the class of the id factory
     */
    public String getIDFactoryClass();


    /**
     * @return an array of configs for the advertisement instantiators
     */
    public InstantiatorConfig[] getAdvertInstantiatorConfigs();

    /**
     * @return an array of configs for the endpoint address instantiators
     */
    public InstantiatorConfig[] getEndpointAddressInstantiatorConfigs();


    /**
     * @return true if the peer is a rendezvous peer
     */
    public boolean isRendezvousPeer();


    /**
     * @return an array of the local rendezvous endpoints
     */
    public EndpointAddress[] getLocalRendezvousEndpoints();

    /**
     * @return an array of the remote rendezvous endpoints that the rendezvous
     *         service should connect to.
     */
    public EndpointAddress[] getRemoteRendezvousEndpoints();


    /**
     * @return an array of resolver configurations
     */
    public ResolverConfig[] getResolverConfigs();


    /**
     * @return the range of minimum available port number
     */
    public int getMinPort();

    /**
     * @return the range of maximum available port number
     */
    public int getMaxPort();

    /**
     * Write a configuration to a file
     */
    public void writeConfig() throws IOException;

    /**
     * @return the resolver config for the specified protocol
     */
    public ResolverConfig getResolverConfig(String protocol);

}
