package p2ps.discovery;

import p2ps.peer.Peer;

import java.io.IOException;

/**
 * The interface responsible for discovering and publishing advertisements
 *
 * @author Ian Wang
 * @version $Revision: 1.3 $
 * @created 20th March 2003
 * @date $Date: 2004/07/02 11:20:48 $ modified by $Author: spxinw $
 * @todo
 */

public interface DiscoveryService {

    public static final String DISCOVERY_SERVICE = "DiscoveryService";

    /**
     * Initialises the discovery service
     */
    public void init() throws IOException;

    /**
     * Adds a listener to be notified when an advert is discovered
     */
    public void addDiscoveryListener(DiscoveryListener listener);

    /**
     * Removes a listener from being notified when an advert is discovered
     */
    public void removeDiscoveryListener(DiscoveryListener listener);

    /**
     * Publishes an advert using the discovery pipe. Any messages published
     * before init is called should just be added to the local cache.
     */
    public void publish(Advertisement advert) throws IOException;

}
