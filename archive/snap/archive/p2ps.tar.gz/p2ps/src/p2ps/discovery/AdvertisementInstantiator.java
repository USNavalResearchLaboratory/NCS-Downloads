package p2ps.discovery;

import org.jdom.Element;

import java.io.IOException;

import p2ps.endpoint.EndpointAddressFactory;
import p2ps.peer.Peer;

/**
 * An interface implemented by classes that turn xml input into advertisement
 * classes. Each advertisement type should have one advertisement instantiator
 * registered with the Advertisement Factory
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 18th March 2003
 * @date $Date: 2004/07/02 11:20:48 $ modified by $Author: spxinw $
 * @todo
 */

public interface AdvertisementInstantiator {

    /**
     * @return a new advertisement instance
     */
    public p2ps.discovery.Advertisement newAdvertisement(String peerid, String advertid) throws IOException;

    /**
     * @return a advertisement generated from the specified document
     */
    public p2ps.discovery.Advertisement createAdvertisement(Element envelope, Peer peer) throws IOException;

}
