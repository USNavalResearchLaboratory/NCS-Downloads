package p2ps.discovery;

import p2ps.endpoint.EndpointAddress;
import p2ps.pipe.PipeAdvertisement;

/**
 * The base class for all queries
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 18th March 2003
 * @date $Date: 2004/07/02 11:20:48 $ modified by $Author: spxinw $
 * @todo
 */
public interface Query extends Advertisement {

    public static final String QUERY_TAG = "query";

    public static final String REPLY_PIPE_ADVERTISEMENT_TAG = "replyPipeAdvertisement";
    public static final String REPLY_ENDPOINT_ADDRESS_TAG = "replyEndpointAddress";


    /**
     * @return the type of advertisement this query is interested in (e.g.
     *         PipeAdvertisement)
     */
    public String getQueryType();


    /**
     * @return optional pipe for the query reply.
     */
    public PipeAdvertisement getReplyPipeAdvertisement();

    /**
     * Ssets the optional endpoint address for the query reply.
     */
    public void setReplyPipeAdvertisement(PipeAdvertisement pipead);


    /**
     * @return optional endpoint address for the query reply.
     */
    public EndpointAddress getReplyEndpointAddress();

    /**
     * Ssets the optional endpoint address for the query reply.
     */
    public void setReplyEndpointAddress(EndpointAddress replyaddr);

}
