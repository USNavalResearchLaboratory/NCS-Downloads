package p2ps.discovery;

import org.jdom.Element;

import java.io.IOException;
import java.io.Serializable;

/**
 * The base class for all advertisements
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 18th March 2003
 * @date $Date: 2004/07/02 11:20:47 $ modified by $Author: spxinw $
 * @todo
 */

public interface Advertisement extends Serializable {

    public static final String ADVERT_ID_TAG = "advertId";
    public static final String PEER_ID_TAG = "peerId";


    /**
     * @return the type for this advertisement
     */
    public String getType();

    /**
     * @return the unique id for this advertisement
     */
    public String getAdvertID();

    /**
     * @return the id of the peer that created this advertisement
     */
    public String getPeerID();


    /**
     * @return an XML element for advert
     */
    public Element getXMLAdvert() throws IOException;

    /**
     * @return an XML element for the full enveloped advert (returns the same
     *         as getXMLAdvert if no envelope)
     */
    public Element getXMLEnvelope() throws IOException;

}
