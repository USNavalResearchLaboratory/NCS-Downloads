package p2ps.discovery;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import p2ps.imp.discovery.AdvertisementUtils;
import p2ps.peer.IDFactory;
import p2ps.peer.Peer;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.Hashtable;

/**
 * A factory for creating new Adevrtisement instances (also Query instances as
 * Query is a sub-class of Advertisement). For each advertisement type an
 * advertisement instantiator must be registered.
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 18th March 2003
 * @date $Date: 2004/07/02 11:20:47 $ modified by $Author: spxinw $
 * @todo
 */

public class AdvertisementFactory {

    /**
     * the main peer class
     */
    private Peer peer;

    /**
     * the default advertisement instantiator of unknown advertisement types
     */
    private AdvertisementInstantiator defaultinst;

    /**
     * a hashtable of the instantiators for each advertisement type
     */
    private Hashtable insttable = new Hashtable();

    /**
     * the xml parser
     */
    private SAXBuilder xmlbuilder = new SAXBuilder();


    /**
     * Creates a new advertisement factory.
     *
     * @param peer        the main peer class
     * @param defaultinst the default advertisement instantiator for unknown advert types
     */
    public AdvertisementFactory(Peer peer, AdvertisementInstantiator defaultinst) {
        this.peer = peer;
        this.defaultinst = defaultinst;
    }


    /**
     * Register an instantiator to generate advertisement classes from an xml
     * advert
     */
    public void register(String type, AdvertisementInstantiator inst) {
        insttable.put(type, inst);
    }

    /**
     * Unregister the instantiator for an advertisement type
     */
    public void unregister(String type) {
        insttable.remove(type);
    }


    /**
     * @return a new advert of the specified type
     */
    public Advertisement newAdvertisement(String type) throws IOException {
        if (!insttable.containsKey(type))
            throw (new IOException("Advertisement type not registered: " + type));
        else {
            return ((AdvertisementInstantiator) insttable.get(type)).newAdvertisement(peer.getPeerID(), IDFactory.newAdvertID());
        }
    }

    /**
     * @return an advert generated from the specified input stream (null if
     *         not an advert)
     */
    public Advertisement createAdvertisement(InputStream in) throws IOException {
        try {
            Document xmlDoc = xmlbuilder.build(in);
            return createAdvertisement(xmlDoc.getRootElement());
        } catch (org.jdom.JDOMException except) {
            throw (new IOException(except.getMessage()));
        }
    }

    /**
     * @return an advert generated from the specified reader (null if not an
     *         advert)
     */
    public Advertisement createAdvertisement(Reader in) throws IOException {
        try {
            Document xmlDoc = xmlbuilder.build(in);
            return createAdvertisement(xmlDoc.getRootElement());
        } catch (org.jdom.JDOMException except) {
            throw (new IOException(except.getMessage()));
        }
    }

    /**
     * @return an advert generated from the specified document element (null if
     *         not an advert)
     */
    public Advertisement createAdvertisement(Element root) throws IOException {
        if (AdvertisementUtils.isXMLEnvelope(root)) {
            String type = AdvertisementUtils.getXMLAdvert(root).getName();

            if (insttable.containsKey(type))
                return ((AdvertisementInstantiator) insttable.get(type)).createAdvertisement(root, peer);
            else
                return defaultinst.createAdvertisement(root, peer);
        } else
            return null;
    }

    /**
     * @return an advert generated from the specified byte array (null if
     *         not an advert)
     */
    public Advertisement createAdvertisement(byte[] data) throws IOException {
        return createAdvertisement(new ByteArrayInputStream(data));
    }


}
