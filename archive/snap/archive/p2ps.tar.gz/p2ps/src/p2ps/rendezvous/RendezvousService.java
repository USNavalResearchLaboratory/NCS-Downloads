package p2ps.rendezvous;

import p2ps.endpoint.EndpointAddress;
import p2ps.discovery.DiscoveryServiceInterface;
import p2ps.peer.Peer;

import java.io.IOException;

/**
 * A service for caching and forwarding messages
 *
 * @author Ian Wang
 * @version $Revision: 1.3 $
 * @created 7th July 2003
 * @date $Date: 2004/07/02 11:21:03 $ modified by $Author: spxinw $
 * @todo
 */
public interface RendezvousService {

    /**
     * Initialises the rendezvous service
     */
    public void init(EndpointAddress[] addresses) throws IOException;

    
    /**
     * Connects this rendezvous service to a remote rendezvous endpoint
     */
    public void connectToRendezvous(EndpointAddress addr) throws IOException;

    /**
     * @return the local endpoint addresses of this rendezvous service
     */
    public EndpointAddress[] getLocalRendezvousAddresses() throws IOException;

    /**
     * @return the remote endpoint addresses this rendezvous service is
     *         connected to
     */
    public EndpointAddress[] getRemoteRendezvousAddresses() throws IOException;

}
