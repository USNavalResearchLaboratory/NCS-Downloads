package p2ps.pipe;

/**
 * A pipe with both input and output components
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 4th July 2003
 * @date $Date: 2004/07/02 11:21:02 $ modified by $Author: spxinw $
 * @todo
 */

public interface BidirectionalPipe extends InputPipe, OutputPipe {

}
