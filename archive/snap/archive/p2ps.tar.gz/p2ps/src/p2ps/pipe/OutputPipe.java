package p2ps.pipe;

import java.io.IOException;

/**
 * An interface to an input pipe.
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 19th March 2003
 * @date $Date: 2004/07/02 11:21:02 $ modified by $Author: spxinw $
 * @todo
 */

public interface OutputPipe {

    /**
     * @return the id of the pipe
     */
    public String getPipeID();

    /**
     * @return the name of the pipe
     */
    public String getPipeName();

    /**
     * Sends a message from the pipe
     */
    public void send(byte[] message) throws IOException;

    /**
     * Closes the pipe
     */
    public void close() throws IOException;

    /**
     * @return true if the pipe is closed
     */
    public boolean isClosed();

}
