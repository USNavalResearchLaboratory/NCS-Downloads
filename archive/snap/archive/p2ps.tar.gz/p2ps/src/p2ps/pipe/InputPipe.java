package p2ps.pipe;

import java.io.IOException;


/**
 * An interface to an input pipe.
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 19th March 2003
 * @date $Date: 2004/07/02 11:21:02 $ modified by $Author: spxinw $
 * @todo
 */

public interface InputPipe {

    /**
     * Adds a listener to be notified when messages are received
     */
    public void addPipeListener(MessageListener listener);

    /**
     * Removes a listener from being notified when messages are received
     */
    public void removePipeListener(MessageListener listener);

    /**
     * @return the id of the pipe
     */
    public String getPipeID();

    /**
     * @return the name of the pipe
     */
    public String getPipeName();

    /**
     * Closes the pipe
     */
    public void close() throws IOException;

    /**
     * @return true if the pipe is closed
     */
    public boolean isClosed();

}
