package p2ps.pipe;

/**
 * Implemented by classes that want to be notified when a message is received
 * by an input pipe
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 19th March 2003
 * @date $Date: 2004/07/02 11:21:02 $ modified by $Author: spxinw $
 * @todo
 */

public interface MessageListener {

    /**
     * Called when a message is received by the pipe
     */
    public void messageReceived(MessageReceivedEvent event);

}
