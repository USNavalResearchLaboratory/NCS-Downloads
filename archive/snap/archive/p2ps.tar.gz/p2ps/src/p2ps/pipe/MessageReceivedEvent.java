package p2ps.pipe;

import java.util.EventObject;

/**
 * The event that is generated when a message is received
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 19th March 2003
 * @date $Date: 2004/07/02 11:21:02 $ modified by $Author: spxinw $
 * @todo
 */

public class MessageReceivedEvent extends EventObject {

    private byte[] message;
    private InputPipe inpipe;
    private OutputPipe replypipe;


    /**
     * Construct an message received event
     */
    public MessageReceivedEvent(InputPipe pipe, byte[] message) {
        super(pipe);

        this.inpipe = pipe;
        this.message = message;
    }

    /**
     * Construct an message received event with a specified reply pipe
     */
    public MessageReceivedEvent(InputPipe pipe, OutputPipe replypipe, byte[] message) {
        super(pipe);

        this.inpipe = pipe;
        this.replypipe = replypipe;
        this.message = message;
    }


    /**
     * @return the input pipe the message was received on
     */
    public InputPipe getInputPipe() {
        return inpipe;
    }

    /**
     * @return the output pipe the direct responses to this message should be
     *         sent via (null if no reply pipe).
     */
    public OutputPipe getReplyPipe() {
        return replypipe;
    }

    /**
     * @return the message
     */
    public byte[] getMessage() {
        return message;
    }

}
