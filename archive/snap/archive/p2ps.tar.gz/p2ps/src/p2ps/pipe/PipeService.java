/*
 * Copyright (c) 1995 onwards, University of Wales College of Cardiff
 *
 * Permission to use and modify this software and its documentation for
 * any purpose is hereby granted without fee provided a written agreement
 * exists between the recipients and the University.
 *
 * Further conditions of use are that (i) the above copyright notice and
 * this permission notice appear in all copies of the software and
 * related documentation, and (ii) the recipients of the software and
 * documentation undertake not to copy or redistribute the software and
 * documentation to any other party.
 *
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF WALES COLLEGE OF CARDIFF BE LIABLE
 * FOR ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
 * KIND, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON
 * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package p2ps.pipe;

import p2ps.endpoint.EndpointResolver;
import p2ps.peer.Peer;

import java.io.IOException;

/**
 * The service for constructing pipes between peers.
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 30th March 2003
 * @date $Date: 2004/07/16 17:21:15 $ modified by $Author: spxinw $
 * @todo
 */

public interface PipeService {

    /**
     * Initialises the pipe service
     */
    public void init() throws IOException;


    /**
     * Adds a pipe connection listener to the pipe service
     */
    public void addPipeConnectionListener(PipeConnectionListener listener);

    /**
     * Removes a pipe connection listener from the pipe service
     */
    public void removePipeConnectionListener(PipeConnectionListener listener);


    /**
     * Creates an input pipe using the specified advert
     */
    public InputPipe createInputPipe(PipeAdvertisement pipead) throws IOException;

    /**
     * Attempts to connect an output pipe to the pipe specified in the advert.
     * PipeConnectionListeners are notified when connection is achieved/fails.
     */
    public void connectOutputPipe(PipeAdvertisement pipead) throws IOException;


    /**
     * Register a pipe resolver to create pipes for a particular protocol
     */
    public void register(EndpointResolver resolver) throws IOException;

    /**
     * Unregister a pipe resolver
     */
    public void unregister(EndpointResolver resolver);


    /**
     * @return the endpoint protocols currently supported by the service
     */
    public String[] getEndpointProtocols();

    /**
     * @return the registered pipe resolvers for this peer
     */
    public EndpointResolver[] getPipeResolvers();

    /**
     * @return the registered pipe resolvers for thie specified pipe type
     */
    public EndpointResolver[] getPipeResolvers(String type);

    /**
     * @return a pipe resolver for the specified protocol
     */
    public EndpointResolver getPipeResolver(String protocol);

}
