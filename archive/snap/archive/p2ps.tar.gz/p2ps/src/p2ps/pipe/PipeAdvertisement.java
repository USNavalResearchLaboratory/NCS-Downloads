/*
 * Copyright (c) 1995 onwards, University of Wales College of Cardiff
 *
 * Permission to use and modify this software and its documentation for
 * any purpose is hereby granted without fee provided a written agreement
 * exists between the recipients and the University.
 *
 * Further conditions of use are that (i) the above copyright notice and
 * this permission notice appear in all copies of the software and
 * related documentation, and (ii) the recipients of the software and
 * documentation undertake not to copy or redistribute the software and
 * documentation to any other party.
 *
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF WALES COLLEGE OF CARDIFF BE LIABLE
 * FOR ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
 * KIND, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON
 * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package p2ps.pipe;

import p2ps.discovery.Advertisement;

/**
 * An interface implemented by advertisements for input pipes.
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 18th March 2003
 * @date $Date: 2004/07/02 11:21:02 $ modified by $Author: spxinw $
 * @todo
 */

public interface PipeAdvertisement extends Advertisement {

    public static final String PIPE_ADVERTISEMENT_TYPE = "PipeAdvertisement";

    public static final String PIPE_ID_TAG = "pipeId";
    public static final String PIPE_NAME_TAG = "pipeName";
    public static final String PIPE_TYPE_TAG = "pipeType";

    /**
     * @return the id of the pipe
     */
    public String getPipeID();

    /**
     * @return the name of the pipe
     */
    public String getPipeName();

    /**
     * Sets the name of the pipe
     */
    public void setPipeName(String name);

    /**
     * @return the type of the pipe (e.g. STANDARD, BIDIRECTIONAL, DISCOVERY)
     */
    public String getPipeType();

    /**
     * Sets the type of the pipe (e.g. STANDARD, BIDIRECTIONAL, DISCOVERY)
     */
    public void setPipeType(String type);

}
