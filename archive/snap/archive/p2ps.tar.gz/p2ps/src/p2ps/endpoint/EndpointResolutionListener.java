package p2ps.endpoint;


/**
 * A listener that is notified when an output pipe is resolved
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 20th March 2003
 * @date $Date: 2004/07/02 11:20:49 $ modified by $Author: spxinw $
 * @todo
 */

public interface EndpointResolutionListener {

    public void pipeResolved(EndpointResolutionEvent event);

}
