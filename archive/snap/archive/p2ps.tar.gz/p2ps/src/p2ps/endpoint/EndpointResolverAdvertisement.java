/*
 * Copyright (c) 1995 onwards, University of Wales College of Cardiff
 *
 * Permission to use and modify this software and its documentation for
 * any purpose is hereby granted without fee provided a written agreement
 * exists between the recipients and the University.
 *
 * Further conditions of use are that (i) the above copyright notice and
 * this permission notice appear in all copies of the software and
 * related documentation, and (ii) the recipients of the software and
 * documentation undertake not to copy or redistribute the software and
 * documentation to any other party.
 *
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF WALES COLLEGE OF CARDIFF BE LIABLE
 * FOR ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
 * KIND, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON
 * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package p2ps.endpoint;

import p2ps.discovery.Advertisement;

/**
 * An advert for a pipe resolver. A pipe resolver provides an endpoint that
 * pipe endpoint queries can be sent to be resolved into endpoint addresses.
 * <p/>
 * <pre>
 * &lt;?xml version="1.0"?&gt;
 * &lt;EndpointResolverAdvertisement;&gt;
 *  &lt;advertId&gt; ID of advertisement &lt;/advertId&gt;
 *  &lt;peerID&gt; ID of resolver peer &lt;/peerId&gt;
 *  &lt;endpointAddress&gt;
 *   &lt;address&gt; Endpoint address of resolver &lt;/address&gt;
 *   &lt;transportProtocol&gt; Endpoint protocol of resolver &lt;/transportProtocol&gt;
 *  &lt;/endpointAddress&gt;
 *  &lt;resolverForPeerID&gt; ID a peers that the reolver resolvers endpoints for&lt;/resolverForPeerID&gt;
 *  &lt;resolverForPeerID&gt; Optional additional peer ids&lt;/resolverForPeerID&gt;
 *  &lt;transportProtocol&gt; Transport protocols that can be resolved &lt;/tansportProtocol&gt;
 *  &lt;transportProtocol&gt; Optional additional protocols &lt;/tansportProtocol&gt;
 * &lt;/EndpointResolverAdvertisement;&gt;
 * </pre>
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 18th March 2003
 * @date $Date: 2004/07/02 11:20:50 $ modified by $Author: spxinw $
 * @todo
 */

public interface EndpointResolverAdvertisement extends Advertisement {

    public static final String ENDPOINT_RESOLVER_ADVERTISEMENT_TYPE = "EndpointResolverAdvertisement";

    public static final String RESOLVER_ENDPOINT_TAG = "resolverEndpoint";
    public static final String RESOLVER_PIPE_TYPE_TAG = "resolverPipeType";
    public static final String RESOLVER_FOR_PEER_ID_TAG = "resolverForPeerID";
    public static final String TRANSPORT_PROTOCOL_TAG = "transportProtocol";


    /**
     * @return the endpoint address of the resolver
     */
    public EndpointAddress getEndpointAddress();

    /**
     * Sets the endpoint address for this resolver
     */
    public void setEndpointAddress(EndpointAddress address);


    /**
     * @return the pipe types handled by the resolver
     */
    public String[] getPipeTypes();

    /**
     * Sets the pipe types for this advert
     */
    public void setPipeTypes(String[] types);


    /**
     * @return the peer ids of the peers handled by the resolver
     */
    public String[] getResolverForPeerIDs();

    /**
     * Sets the transport protocol for this advert
     */
    public void setResolverForPeerIDs(String[] peerids);


    /**
     * @return the endpoint transport protocols handled by the resolver
     */
    public String[] getTransportProtocols();

    /**
     * Sets the transport protocol for this advert
     */
    public void setTransportProtocols(String[] protocol);

}
