package p2ps.endpoint;



/**
 * The event generated when a message is fully received by an endpoint
 *
 * @author Ian Wang
 * @version $Revision: 1.3 $
 * @created 17th March
 * @date $Date: 2004/07/02 11:20:48 $ modified by $Author: spxinw $
 * @todo
 */

public class DataMessageEvent {

    private DataMessage message;

    private Endpoint endpoint;
    private Endpoint replyendpoint;


    /**
     * Constructs a data message event.
     *
     * @param endpoint the endpoint the data message was received on
     * @param message  the message received
     */
    public DataMessageEvent(Endpoint endpoint, DataMessage message) {
        this.endpoint = endpoint;
        this.message = message;
    }

    /**
     * Constructs a data message event.
     *
     * @param endpoint      the endpoint the data message was received on
     * @param replyendpoint the endpoint replies through which replies should be sent
     * @param message       the message received
     */
    public DataMessageEvent(Endpoint endpoint, Endpoint replyendpoint, DataMessage message) {
        this.endpoint = endpoint;
        this.replyendpoint = replyendpoint;
        this.message = message;
    }


    /**
     * @return the socket the message was received on
     */
    public Endpoint getEndpoint() {
        return endpoint;
    }

    /**
     * @return the endpoint via which replies to this message should be sent
     */
    public Endpoint getReplyEndpoint() {
        return replyendpoint;
    }

    /**
     * @return the message received
     */
    public DataMessage getDataMessage() {
        return message;
    }

}
