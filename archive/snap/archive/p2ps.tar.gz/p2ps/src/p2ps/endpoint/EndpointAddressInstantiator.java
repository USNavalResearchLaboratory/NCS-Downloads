package p2ps.endpoint;

import org.jdom.Element;

/**
 * An instantiator for creating new endpoint address instances.
 *
 * @author Ian Wang
 * @version $Revision: 1.1 $
 * @created 28th June 2004
 * @date $Date: 2004/07/02 11:20:49 $ modified by $Author: spxinw $
 * @todo
 */

public interface EndpointAddressInstantiator {

    /**
     * Creates a new endpoint address
     */
    public EndpointAddress newEndpointAddress(String protocol, String address, String type);

    /**
     * Creates a new endpoint address from a document element
     */
    public EndpointAddress createEndpointAddress(Element root);

}
