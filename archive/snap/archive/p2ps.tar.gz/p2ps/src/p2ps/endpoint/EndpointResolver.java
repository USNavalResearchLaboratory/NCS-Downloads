/*
 * Copyright (c) 1995 onwards, University of Wales College of Cardiff
 *
 * Permission to use and modify this software and its documentation for
 * any purpose is hereby granted without fee provided a written agreement
 * exists between the recipients and the University.
 *
 * Further conditions of use are that (i) the above copyright notice and
 * this permission notice appear in all copies of the software and
 * related documentation, and (ii) the recipients of the software and
 * documentation undertake not to copy or redistribute the software and
 * documentation to any other party.
 *
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF WALES COLLEGE OF CARDIFF BE LIABLE
 * FOR ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
 * KIND, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON
 * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package p2ps.endpoint;

import p2ps.peer.Config;
import p2ps.peer.Peer;

import java.io.IOException;

/**
 * The service for creating input/output socket for a particulat transport
 * protocol, and for resolving the addresses of socket on remote peers.
 *
 * @author Ian Wang
 * @version $Revision: 1.6 $
 * @created 30th March 2003
 * @date $Date: 2004/07/02 11:20:50 $ modified by $Author: spxinw $
 * @todo
 */

public interface EndpointResolver {

    /**
     * Initialises the endpoint resolver
     */
    public void init(Peer peer, Config config) throws IOException;


    /**
     * @return true if input pipes of the specified type are enabled with this
     *         resolver
     */
    public boolean isInputPipesEnabled(String endpointtype);

    /**
     * Sets whether input pipes of the specified type are enabled with this
     * resolver
     */
    public void setInputPipesEnabled(String endpointtype, boolean state);

    /**
     * @return true if output pipes of the specified type are enabled with this
     *         resolver
     */
    public boolean isOutputPipesEnabled(String endpointtype);

    /**
     * Sets whether output pipes of the specified type are enabled with this
     * resolver
     */
    public void setOutputPipesEnabled(String endpointtype, boolean state);


    /**
     * @return the resolver endpoint
     */
    public Endpoint getResolverEndpoint();

    /**
     * @return the address of the resolver endpoint
     */
    public EndpointAddress getResolverEndpointAddress() throws IOException;


    /**
     * @return an array of the pipe types handled by this resolver
     */
    public String[] getPipeTypes();

    /**
     * @return the ids of the peers this resolver handles enpoint resolution for
     */
    public String[] getResolverForPeerIDs();

    /**
     * @return the endpoint protocols this resolver handles
     */
    public String[] getEndpointProtocols();

    /**
     * @return a pipe resolver advert for this resolver
     */
    public EndpointResolverAdvertisement getAdvertisement() throws IOException;


    /**
     * Add a listener to be notified when a pipe is resolved
     */
    public void addEndpointResolutionListener(EndpointResolutionListener listener);

    /**
     * Removes a pipe resolution listener
     */
    public void removeEndpointResolutionListener(EndpointResolutionListener listener);


    /**
     * Create a endpoint for the specified input pipe
     */
    public Endpoint createInputEndpoint(String pipeid, String pipetype) throws IOException;

    /**
     * Create a endpoint for the specified input pipe bound the specified endpoint
     * address
     */
    public Endpoint createInputEndpoint(String pipeid, EndpointAddress address) throws IOException;

    /**
     * Connects an endpoint to output to the specified address
     */
    public Endpoint connectOutputEndpoint(String pipeid, EndpointAddress address) throws IOException;


    /**
     * Sends an endpoint query for the specified pipe id to the specified
     * endpoint address using the resolver's socket. Responses are notified to
     * endpoint resolution listeneers
     */
    public void resolveEndpoint(String pipeid, EndpointAddress resolveraddr) throws IOException;

}
