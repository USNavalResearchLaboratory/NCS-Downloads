package p2ps.endpoint;

/**
 * A message containing byte array data.
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 2nd July 2003
 * @date $Date: 2004/07/02 11:20:48 $ modified by $Author: spxinw $
 * @todo
 */

public interface DataMessage {

    /**
     * @return the data in this message
     */

    public byte[] getData();

}
