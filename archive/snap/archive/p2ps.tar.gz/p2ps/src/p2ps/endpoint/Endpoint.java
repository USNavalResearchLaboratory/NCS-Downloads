package p2ps.endpoint;

import java.io.IOException;

/**
 * The interface implemented by all endpoint classes
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 17th March 2003
 * @date $Date: 2004/07/02 11:20:49 $ modified by $Author: spxinw $
 * @todo
 */

public interface Endpoint {

    /**
     * @return the address of this endpoint
     */
    public EndpointAddress getEndpointAddress();

    /**
     * @return an EndpointAdvertisement for this endpoint
     */
    public EndpointAdvertisement getAdvertisement();


    /**
     * @return true if this endpoint is input enabled
     */
    public boolean isInputEndpoint();

    /**
     * @return true if this endpoint is output enabled
     */
    public boolean isOutputEndpoint();


    /**
     * Adds a listener to receive data from this endpoint
     */
    public void addEndpointMessageListener(EndpointMessageListener listener);

    /**
     * Removes a listener from this endpoint
     */
    public void removeEndpointMessageListener(EndpointMessageListener listener);

    /**
     * Sends a message from the endpoint to the address the endpoint is bound to
     */
    public void send(byte[] message) throws IOException;


    /**
     * Closes the endpoint
     */
    public void close() throws IOException;

    /**
     * @return true if the endpoint is closed
     */
    public boolean isClosed();

}
