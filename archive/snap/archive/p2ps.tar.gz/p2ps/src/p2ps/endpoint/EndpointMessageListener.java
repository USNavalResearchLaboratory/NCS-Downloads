package p2ps.endpoint;

/**
 * An interface implemented by classes that receive data messages
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 17th March
 * @date $Date: 2004/07/02 11:20:49 $ modified by $Author: spxinw $
 * @todo
 */

public interface EndpointMessageListener {

    /**
     * Called when the endpoint receives a data message
     */
    public void dataMessageReceived(DataMessageEvent event);

}
