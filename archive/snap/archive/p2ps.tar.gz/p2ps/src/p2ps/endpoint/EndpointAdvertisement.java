package p2ps.endpoint;

import p2ps.discovery.Advertisement;

/**
 * An advertisement for a pipe endpoint. Note that the protocol tag is required
 * for endpoint querying.
 * <p/>
 * <pre>
 * &lt;?xml version="1.0"?&gt;
 * &lt;EndpointAdvertisement;&gt;
 *  &lt;advertId&gt; ID of advertisement &lt;/advertId&gt;
 *  &lt;peerID&gt; ID of resolver peer &lt;/peerId&gt;
 *  &lt;endpointAddress&gt;
 *   &lt;address&gt; The endpoint address &lt;/address&gt;
 *   &lt;transportProtocol&gt; The endpoint protocol &lt;/transportProtocol&gt;
 *  &lt;/endpointAddress&gt;
 *  &lt;pipeID&gt; Optional pipe id &lt;/pipeId&gt;
 *  &lt;pipeID&gt; The endpoint protocol &lt;/pipeId&gt;
 * &lt;/EndpointAdvertisement;&gt;
 * </pre>
 *
 * @author Ian Wang
 * @version $Revision: 1.3 $
 * @created 3rd July 2003
 * @date $Date: 2004/07/02 11:20:49 $ modified by $Author: spxinw $
 * @todo
 */

public interface EndpointAdvertisement extends Advertisement {

    public static final String ENDPOINT_ADVERTISEMENT_TYPE = "EndpointAdvertisement";

    public static final String PROTOCOL_TAG = "protocol";
    public static final String PIPE_ID_TAG = "pipeId";
    public static final String ENDPOINT_ADDRESS_TAG = "endpointAddress";


    /**
     * @return the address of the endpoint
     */
    public EndpointAddress getEndpointAddress();

    /**
     * Sets the address of the endpoint
     */
    public void setEndpointAddress(EndpointAddress address);


    /**
     * @return the id of the pipe (optional)
     */
    public String getPipeID();

    /**
     * Sets the id of the pipe (optional)
     */
    public void setPipeID(String pipeid);


}
