/*
 * The University of Wales, Cardiff Triana Project Software License (Based
 * on the Apache Software License Version 1.1)
 *
 * Copyright (c) 2003 University of Wales, Cardiff. All rights reserved.
 *
 * Redistribution and use of the software in source and binary forms, with
 * or without modification, are permitted provided that the following
 * conditions are met:
 *
 * 1.  Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 * 2.  Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * 3. The end-user documentation included with the redistribution, if any,
 *    must include the following acknowledgment: "This product includes
 *    software developed by the University of Wales, Cardiff for the Triana
 *    Project (http://www.trianacode.org)." Alternately, this
 *    acknowledgment may appear in the software itself, if and wherever
 *    such third-party acknowledgments normally appear.
 *
 * 4. The names "Triana" and "University of Wales, Cardiff" must not be
 *    used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact triana@trianacode.org.
 *
 * 5. Products derived from this software may not be called "Triana," nor
 *    may Triana appear in their name, without prior written permission of
 *    the University of Wales, Cardiff.
 *
 * 6. This software may not be sold, used or incorporated into any product
 *    for sale to third parties.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 * NO EVENT SHALL UNIVERSITY OF WALES, CARDIFF OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Triana Project. For more information on the
 * Triana Project, please see. http://www.trianacode.org.
 *
 * This license is based on the BSD license as adopted by the Apache
 * Foundation and is governed by the laws of England and Wales.
 */

package p2ps.imp.peer.config;

import p2ps.endpoint.*;
import p2ps.peer.Config;
import p2ps.peer.ResolverConfig;
import p2ps.peer.InstantiatorConfig;
import p2ps.pipe.PipeTypes;
import p2ps.pipe.PipeAdvertisement;
import p2ps.pipe.PipeQuery;
import p2ps.imp.endpoint.UDP.UDPResolver;
import p2ps.imp.endpoint.TCP.TCPResolver;
import p2ps.service.ServiceAdvertisement;
import p2ps.service.ServiceQuery;
import p2ps.rendezvous.RendezvousAdvertisement;

import java.io.IOException;

/**
 * The default configuration for a p2ps peer.
 *
 * @author Ian Wang
 * @version $Revision: 1.9 $
 * @created 7th July 2003
 * @date $Date: 2004/07/16 16:13:13 $ modified by $Author: ian $
 * @todo
 */

public class DefaultConfig implements Config {

    public static final String DISCOVERY_SERVICE_CLASS = "p2ps.imp.discovery.DiscoveryServiceImp";
    public static final String PIPE_SERVICE_CLASS = "p2ps.imp.pipe.PipeServiceImp";
    public static final String RENDEZVOUS_SERVICE_CLASS = "p2ps.imp.rendezvous.ReplyRendezvousService";
    public static final String ID_FACTORY_CLASS = "p2ps.imp.peer.DefaultIDFactory";


    private ResolverConfig[] resconfigs;

    public static final InstantiatorConfig[] getDefaultAdvertInstantiatorConfigs() {
        return new InstantiatorConfig[] {
            new InstantiatorConfigImp(PipeAdvertisement.PIPE_ADVERTISEMENT_TYPE, "p2ps.imp.pipe.PipeAdvertisementInstantiator"),
            new InstantiatorConfigImp(PipeQuery.PIPE_QUERY_TYPE, "p2ps.imp.pipe.PipeQueryInstantiator"),
            new InstantiatorConfigImp(ServiceAdvertisement.SERVICE_ADVERTISEMENT_TYPE, "p2ps.imp.service.ServiceAdvertisementInstantiator"),
            new InstantiatorConfigImp(ServiceQuery.SERVICE_QUERY_TYPE, "p2ps.imp.service.ServiceQueryInstantiator"),
            new InstantiatorConfigImp(EndpointAdvertisement.ENDPOINT_ADVERTISEMENT_TYPE, "p2ps.imp.endpoint.EndpointAdvertisementInstantiator"),
            new InstantiatorConfigImp(EndpointQuery.ENDPOINT_QUERY_TYPE, "p2ps.imp.endpoint.EndpointQueryInstantiator"),
            new InstantiatorConfigImp(EndpointResolverAdvertisement.ENDPOINT_RESOLVER_ADVERTISEMENT_TYPE, "p2ps.imp.endpoint.EndpointResolverAdvertisementInstantiator"),
            new InstantiatorConfigImp(EndpointResolverQuery.ENDPOINT_RESOLVER_QUERY_TYPE, "p2ps.imp.endpoint.EndpointResolverQueryInstantiator"),
            new InstantiatorConfigImp(RendezvousAdvertisement.RENDEZVOUS_ADVERTISEMENT_TYPE, "p2ps.imp.rendezvous.RendezvousAdvertisementInstantiator")
        };
    }

    public static InstantiatorConfig[] getDefaultEndpointAddressInstantiatorConfigs() {
        return new InstantiatorConfig[] {
            new InstantiatorConfigImp(TCPResolver.TCP_PROTOCOL, "p2ps.imp.endpoint.EndpointAddressInstantiatorImp"),
            new InstantiatorConfigImp(UDPResolver.UDP_PROTOCOL, "p2ps.imp.endpoint.EndpointAddressInstantiatorImp")
        };
    }


    public DefaultConfig() {
        ResolverConfigImp tcpconfig =
                new ResolverConfigImp("p2ps.imp.endpoint.TCP.TCPResolver", TCPResolver.TCP_PROTOCOL, true, true);
        ResolverConfigImp udpconfig =
                new ResolverConfigImp("p2ps.imp.endpoint.UDP.UDPResolver", UDPResolver.UDP_PROTOCOL, false, false);

        udpconfig.setInputPipesEnabled(PipeTypes.DISCOVERY, true);
        udpconfig.setOutputPipesEnabled(PipeTypes.DISCOVERY, true);

        tcpconfig.setInputPipesEnabled(PipeTypes.STANDARD, true);
        tcpconfig.setOutputPipesEnabled(PipeTypes.STANDARD, true);

        resconfigs = new ResolverConfig[]{tcpconfig, udpconfig};
    }

    public void setResolverConfig(ResolverConfig[] resconfigs) {
        this.resconfigs=resconfigs;
    }

    /**
     * @return the class of the discovery service
     */
    public String getDiscoveryServiceClass() {
        return DISCOVERY_SERVICE_CLASS;
    }

    /**
     * @return the class of the pipe service
     */
    public String getPipeServiceClass() {
        return PIPE_SERVICE_CLASS;
    }

    /**
     * @return the class of the rendezvous service
     */
    public String getRendezvousServiceClass() {
        return RENDEZVOUS_SERVICE_CLASS;
    }

    /**
     * @return the class of the id factory
     */
    public String getIDFactoryClass() {
        return ID_FACTORY_CLASS;
    }


    /**
     * @return an array of configs for the advertisement instantiators
     */
    public InstantiatorConfig[] getAdvertInstantiatorConfigs() {
        return getDefaultAdvertInstantiatorConfigs();
    }

    /**
     * @return an array of configs for the advertisement instantiators
     */
    public InstantiatorConfig[] getEndpointAddressInstantiatorConfigs() {
        return getDefaultEndpointAddressInstantiatorConfigs();
    }


    /**
     * @return true if the peer is a rendezvous peer
     */
    public boolean isRendezvousPeer() {
        return false;
    }

    /**
     * @return an array of the local rendezvous endpoints
     */
    public EndpointAddress[] getLocalRendezvousEndpoints() {
        return new EndpointAddress[0];
    }

    /**
     * @return an array of the remote rendezvous endpoints that the rendezvous
     *         service should connect to.
     */
    public EndpointAddress[] getRemoteRendezvousEndpoints() {
        return new EndpointAddress[0];
    }

    /**
     * @return a configuration using a UDP resolver for input, output and
     *         discovery pipes
     */
    public ResolverConfig[] getResolverConfigs() {
        return resconfigs;
    }

    /**
     * @return the resolver config for the specified protocol
     */
    public ResolverConfig getResolverConfig(String protocol) {
        ResolverConfig config = null;

        for (int count = 0; (count < resconfigs.length) && (config == null); count++)
            if (resconfigs[count].getResolverProtocol().equals(protocol))
                config = resconfigs[count];

        return config;
    }


    /**
     * @return the minimum available port number
     */
    public int getMinPort() {
        return DEFAULT_MIN_PORT;
    }

    /**
     * Read a saved configuration from a file
     */
    public void readConfig() throws IOException {
        //no-op no point in saving a default
    }

    /**
     * Write a configuration to a file
     */
    public void writeConfig() throws IOException {
        //no-op no point in saving a default
    }

    /**
     * @return the maximum available port number
     */
    public int getMaxPort() {
        return DEFAULT_MAX_PORT;
    }

}
