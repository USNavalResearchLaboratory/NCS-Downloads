package p2ps.imp.pipe;

import p2ps.endpoint.Endpoint;
import p2ps.pipe.*;

import java.io.IOException;

/**
 * A bidirectional pipe based on an underlying input pipe and output pipe
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 4th July 2003
 * @date $Date: 2004/07/02 11:20:58 $ modified by $Author: spxinw $
 * @todo
 */
public class DiscoveryPipeImp implements BidirectionalPipe {

    private InputPipe inpipe;
    private OutputPipe[] outpipes;


    public DiscoveryPipeImp(PipeAdvertisement pipead, Endpoint[] inpoints, Endpoint[] outpoints) {
        this.inpipe = new InputPipeImp(pipead, inpoints);

        outpipes = new OutputPipeImp[outpoints.length];

        for (int count = 0; count < outpoints.length; count++)
            this.outpipes[count] = new OutputPipeImp(pipead, outpoints[count]);
    }


    /**
     * @return the id of the pipe
     */
    public String getPipeID() {
        return inpipe.getPipeID();
    }

    /**
     * @return the name of the pipe
     */
    public String getPipeName() {
        return inpipe.getPipeName();
    }


    /**
     * Adds a listener to be notified when messages are received
     */
    public void addPipeListener(MessageListener listener) {
        inpipe.addPipeListener(listener);
    }

    /**
     * Removes a listener from being notified when messages are received
     */
    public void removePipeListener(MessageListener listener) {
        inpipe.removePipeListener(listener);
    }


    /**
     * Sends a message from the pipe
     */
    public void send(byte[] message) throws IOException {
        for (int count = 0; count < outpipes.length; count++)
            outpipes[count].send(message);
    }


    /**
     * Closes the pipe
     */
    public void close() throws IOException {
        inpipe.close();

        for (int count = 0; count < outpipes.length; count++)
            outpipes[count].close();
    }

    /**
     * @return true if the pipe is closed
     */
    public boolean isClosed() {
        if (inpipe.isClosed())
            return true;

        for (int count = 0; count < outpipes.length; count++)
            if (outpipes[count].isClosed())
                return true;

        return false;
    }

}
