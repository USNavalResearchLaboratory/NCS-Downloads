package p2ps.imp.endpoint.TCP;

import org.jdom.Document;
import org.jdom.output.XMLOutputter;
import org.apache.log4j.Logger;
import p2ps.endpoint.DataMessage;
import p2ps.endpoint.Endpoint;
import p2ps.imp.endpoint.PortFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;

/**
 * A generic TCP socket class
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 11th May 2004
 * @date $Date: 2004/07/16 16:13:13 $ modified by $Author: ian $
 * @todo
 */

public abstract class TCPSocket implements Endpoint, SocketHandler {

    static Logger logger = Logger.getLogger(TCPSocket.class);

    public static int RECEIVE_BUFFER_SIZE = 32000;
    public static int SEND_BUFFER_SIZE = 32000;


    /**
     * The underlying java socket
     */
    private Socket socket;

    /**
     * the message handler for this socket
     */
    private SocketHandler handler;


    /**
     * Creates a TCP socket with the specified socket handler
     */
    public TCPSocket(Socket socket, SocketHandler handler) {
        logger.info("entering");

        this.socket = socket;
        this.handler = handler;
        logger.info("exiting");
    }

    /**
     * Creates a TCP socket with the specified socket handler
     */
    public TCPSocket(SocketHandler handler) throws IOException {
        logger.info("entering");
        this.handler = handler;

        initSocket();
        logger.info("exiting");
    }

    /**
     * Creates a TCP socket as its own socket handler.
     */
    public TCPSocket() throws IOException {
        logger.info("entering");
        this.handler = this;

        initSocket();
        logger.info("exiting");
    }


    private void initSocket() throws IOException {
        logger.info("entering");
        Object key = PortFactory.getNewFactoryKey();
        boolean success = false;
        int port;

        while (!success) {
            port = PortFactory.getNextPort(key);

            try {
                socket = new Socket();
                socket.bind(new InetSocketAddress(InetAddress.getLocalHost(), port));

                success = true;
            } catch (IOException except) {
            }
        }
        logger.info("exiting");
    }


    /**
     * @return true if this endpoint is input enabled
     */
    public boolean isInputEndpoint() {
        return true;
    }

    /**
     * @return true if this endpoint is output enabled
     */
    public boolean isOutputEndpoint() {
        return true;
    }


    /**
     * Connects the socket to a specified address and port
     */
    void connect(String address, int port, String socketid) throws IOException {
        logger.info("entering");
        if (socket.isConnected())
            throw (new IOException("Socket already connected"));

        socket.connect(new InetSocketAddress(address, port));
        socket.setReuseAddress(true);
        socket.setSendBufferSize(SEND_BUFFER_SIZE);

        TCPInputHandler.getDefaultTCPSocketHandler().addSocket(this);

        TCPInitMessage initmess = new TCPInitMessage(socketid);
        XMLOutputter xmlout = new XMLOutputter();
        ByteArrayOutputStream byteout = new ByteArrayOutputStream();

        xmlout.output(new Document(initmess.getXMLElement()), byteout);

        send(byteout.toByteArray());
        logger.info("exiting");
    }


    protected Socket getSocket() {
        return socket;
    }

    protected void handleMessage(DataMessage mess) {
        handler.receiveMessage(mess, this);
    }


    /**
     * Send a message from the socket
     */
    public void send(byte[] message) throws IOException {
        logger.info("entering");
        if (!socket.isConnected())
            throw (new IOException("TCP Send Error: Socket not connected"));

        // write message length and then the message
        writeInt(message.length, socket.getOutputStream());
        writeMessage(message, socket.getOutputStream());
        logger.info("exiting");
    }

    /**
     * Read into the specified byte array, return true if successful
     */
    public boolean readInto(InputStream instream, byte[] bytearray) throws IOException {
        int retval = 0;
        int ptr = 0;

        while ((retval >= 0) && (ptr < bytearray.length)) {
            retval = instream.read(bytearray, ptr, bytearray.length - ptr);
            ptr += retval;
        }

        return (retval > 0);
    }

    /**
     * Reads an integer from the underlying input stream
     */
    private void writeInt(int v, OutputStream outstream) throws IOException {
        outstream.write((byte) (0xff & (v >> 24)));
        outstream.write((byte) (0xff & (v >> 16)));
        outstream.write((byte) (0xff & (v >> 8)));
        outstream.write((byte) (0xff & v));
        outstream.flush();
    }

    /**
     * Reads an integer from the underlying input stream
     */
    private void writeMessage(byte[] message, OutputStream outstream) throws IOException {
        outstream.write(message);
        outstream.flush();
    }


    /**
     * notifies the socket handler that it will handle  messaege for the
     * specified socket
     */
    public void handleSocket(TCPSocket socket) {
    }

    /**
     * handle the specified Data Message received on the specified socket
     */
    public void receiveMessage(DataMessage mess, TCPSocket socket) {
    }


    /**
     * Closes the socket
     */
    public void close() throws IOException {
        TCPInputHandler.getDefaultTCPSocketHandler().removeSocket(this);

        if (!socket.isClosed())
            socket.close();

        handler = null;
    }

    /**
     * @return true is the socket is closed
     */
    public boolean isClosed() {
        return socket.isClosed();
    }

}

