package p2ps.imp.rendezvous;

import org.jdom.Element;
import p2ps.endpoint.EndpointAddress;
import p2ps.endpoint.EndpointAddressFactory;
import p2ps.rendezvous.RendezvousAdvertisement;

import java.io.IOException;
import java.util.List;

/**
 * An implementation of the Pipe Advertisement interface
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 18th March 2003
 * @date $Date: 2004/07/02 11:21:00 $ modified by $Author: spxinw $
 * @todo
 */

public class RendezvousAdvertisementImp implements RendezvousAdvertisement {

    private String advertid;
    private String peerid;

    private EndpointAddress[] addresses;


    public RendezvousAdvertisementImp(String advertid, String peerid) {
        this.advertid = advertid;
        this.peerid = peerid;
    }

    public RendezvousAdvertisementImp(Element root, EndpointAddressFactory endfactory) throws IOException {
        Element elem = root.getChild(ADVERT_ID_TAG);
        if (elem != null)
            advertid = elem.getText();

        elem = root.getChild(PEER_ID_TAG);
        if (elem != null)
            peerid = elem.getText();

        elem = root.getChild(RENDEZVOUS_ADDRESS_TAG);
        if (elem != null) {
            List list = elem.getChildren();
            addresses = new EndpointAddress[list.size()];

            for (int count = 0; count < list.size(); count++)
                addresses[count] = endfactory.createEndpointAddress((Element) list.get(count));
        }
    }


    /**
     * @return the type for this advertisement
     */
    public String getType() {
        return RENDEZVOUS_ADVERTISEMENT_TYPE;
    }

    /**
     * @return the unique id for this advertisement
     */
    public String getAdvertID() {
        return advertid;
    }

    /**
     * @return the id of the peer that created this advertisement
     */
    public String getPeerID() {
        return peerid;
    }


    /**
     * @return the name of the service
     */
    public EndpointAddress[] getEndpointAddresses() {
        return addresses;
    }

    /**
     * Sets the name for this service
     */
    public void setEndpointAddresses(EndpointAddress[] addresses) {
        this.addresses = addresses;
    }

    /**
     * Output the advert as an xml document
     */
    public Element getXMLAdvert() throws IOException {
        Element root = new Element(RENDEZVOUS_ADVERTISEMENT_TYPE);

        Element elem = new Element(ADVERT_ID_TAG);
        elem.addContent(advertid);
        root.addContent(elem);

        elem = new Element(PEER_ID_TAG);
        elem.addContent(peerid);
        root.addContent(elem);

        elem = new Element(RENDEZVOUS_ADDRESS_TAG);

        for (int count = 0; count < addresses.length; count++)
            elem.addContent(addresses[count].getXMLElement());

        root.addContent(elem);

        return root;
    }

    /**
     * @return an XML element for the full enveloped advert (returns the same
     *         as getXMLAdvert if no envelope)
     */
    public Element getXMLEnvelope() throws IOException {
        return getXMLAdvert();
    }

}
