package p2ps.imp.pipe;

import org.apache.log4j.Logger;
import p2ps.discovery.Advertisement;
import p2ps.discovery.DiscoveryEvent;
import p2ps.discovery.DiscoveryListener;
import p2ps.endpoint.*;
import p2ps.imp.discovery.DiscoveryCache;
import p2ps.peer.Peer;
import p2ps.pipe.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;

/**
 * A class that handles the resolving and connecting of output pipes, including
 * the searching for appropriate resolvers.
 *
 * @author Ian Wang
 * @version $Revision: 1.10 $
 * @created 24th March 2003
 * @date $Date: 2004/07/16 17:21:15 $ modified by $Author: spxinw $
 * @todo
 */

public class PipeConnectHandler
        implements EndpointResolutionListener, DiscoveryListener, MessageListener {

    static Logger logger = Logger.getLogger(PipeConnectHandler.class);

    /**
     * an input pipe used to receive replies to resolver queries
     */
    private InputPipeImp inpipe;

    /**
     * a hashtable of the unresolved pipe advertisements, keyed by pipe id
     */
    private Hashtable pipeads = new Hashtable();

    /**
     * a cache of the discovered endpoint resolver adverts
     */
    private DiscoveryCache cache = new DiscoveryCache();

    /**
     * the main peer class
     */
    private Peer peer;

    /**
     * a list of the pipe connection listeners.
     */
    private ArrayList listeners = new ArrayList();


    /**
     * Connects an output pipe to the specified pipe
     */
    public PipeConnectHandler(Peer peer) {
        logger.info("entering");
        this.peer = peer;
        logger.info("exiting");
    }


    public void init() throws IOException {
        logger.info("entering");
        if (peer.getDiscoveryService() == null)
            throw(new RuntimeException("Error instantiating pipe service: Discovery service not registered for peer"));

        peer.getDiscoveryService().addDiscoveryListener(this);

        createReplyEndpoints();
//        publishResolverQuery(peer.getPeerID());
        logger.info("exiting");
    }

    /**
     * Creates an input pipe from the resolver endpoints that is used to
     * receieve the replies from the endpoint resolver queries.
     */
    private void createReplyEndpoints() throws IOException {
        logger.info("entering");
        EndpointResolver[] resolvers = peer.getPipeService().getPipeResolvers();
        PipeAdvertisement pipead = (PipeAdvertisement) peer.getAdvertisementFactory().newAdvertisement(PipeAdvertisement.PIPE_ADVERTISEMENT_TYPE);
        ArrayList inlist = new ArrayList();

        for (int count = 0; count < resolvers.length; count++)
            inlist.add(resolvers[count].getResolverEndpoint());

        inpipe = new InputPipeImp(pipead, (Endpoint[]) inlist.toArray(new Endpoint[inlist.size()]));
        inpipe.addPipeListener(this);
        logger.info("exiting");
    }


    /**
     * Adds a pipe connection listener to the pipe service
     */
    public void addPipeConnectionListener(PipeConnectionListener listener) {
        if (!listeners.contains(listener))
            listeners.add(listener);
    }


    /**
     * Removes a pipe connection listener from the pipe service
     */
    public void removePipeConnectionListener(PipeConnectionListener listener) {
        listeners.remove(listener);
    }


    /**
     * Tries to create a new output pipe, notifies registered PipeConnectionListeners.
     */
    public void connectOutputPipe(PipeAdvertisement pipead) throws IOException {
        logger.info("entering");

        pipeads.put(pipead.getPipeID(), pipead);
        queryCachedResolvers(pipead);
        logger.info("exiting");
    }


    /**
     * Query the local cache for suitable resolvers
     */
    private void queryCachedResolvers(PipeAdvertisement pipead) throws IOException {
        logger.info("entering");
        EndpointResolverQuery query = (EndpointResolverQuery) peer.getAdvertisementFactory().newAdvertisement(EndpointResolverQuery.ENDPOINT_RESOLVER_QUERY_TYPE);
        query.setQueryResolverForPeerID(pipead.getPeerID());

        Advertisement[] adverts = cache.getAdvertisements(query);

        for (int count = 0; count < adverts.length; count++)
            if (adverts[count] instanceof EndpointResolverAdvertisement)
                queryResolver((EndpointResolverAdvertisement) adverts[count], pipead);

        if (adverts.length == 0)
            publishResolverQuery(pipead.getPeerID());
        logger.info("exiting");
    }

    /**
     * Attempts to locate endpoints resolvers for the specified peer
     */
    private void publishResolverQuery(String peerid) throws IOException {
        logger.info("entering");
        Endpoint[] endpoints = inpipe.getSockets();
        EndpointResolverQuery query;

        for (int count = 0; count < endpoints.length; count++) {
            query = (EndpointResolverQuery) peer.getAdvertisementFactory().newAdvertisement(EndpointResolverQuery.ENDPOINT_RESOLVER_QUERY_TYPE);
            query.setQueryResolverForPeerID(peerid);
            query.setReplyEndpointAddress(endpoints[count].getEndpointAddress());

            peer.getDiscoveryService().publish(query);
        }
        logger.info("exiting");
    }


    private void handleEndpointResolverAdvertisement(EndpointResolverAdvertisement advert) {
        logger.info("entering");
        if (cache.contains(advert.getAdvertID()))
            return;

        cache.add(advert);

        Enumeration enum = pipeads.elements();

        while (enum.hasMoreElements()) {
            try {
                queryResolver(advert, (PipeAdvertisement) enum.nextElement());
            } catch (IOException except) {
            }
        }
        logger.info("exiting");
    }

    private void queryResolver(EndpointResolverAdvertisement advert, PipeAdvertisement pipead) throws IOException {
        logger.info("entering");
        String[] peerids = advert.getResolverForPeerIDs();
        boolean match = false;

        for (int peercount = 0; (peercount < peerids.length) && (!match); peercount++)
            match = pipead.getPeerID().equals(peerids[peercount]);

        if (match) {
            String[] protocols = advert.getTransportProtocols();

            for (int protcount = 0; protcount < protocols.length; protcount++) {
                EndpointResolver resolver = peer.getPipeService().getPipeResolver(protocols[protcount]);

                if ((resolver != null) && (resolver.isOutputPipesEnabled(pipead.getPipeType()))) {
                    resolver.addEndpointResolutionListener(this);
                    resolver.resolveEndpoint(pipead.getPipeID(), advert.getEndpointAddress());
                }
            }
        }
        logger.info("exiting");
    }


    /**
     * Called when a message is received by the pipe
     */
    public void messageReceived(MessageReceivedEvent event) {
        logger.info("entering");
        try {
            Advertisement advert = peer.getAdvertisementFactory().createAdvertisement(new ByteArrayInputStream(event.getMessage()));

            if (advert instanceof EndpointResolverAdvertisement)
                handleEndpointResolverAdvertisement((EndpointResolverAdvertisement) advert);
        } catch (IOException except) {
            throw (new RuntimeException("Pipe connect error: " + except.getMessage(), except));
        }
        logger.info("exiting");
    }


    public void advertDiscovered(DiscoveryEvent event) {
        logger.info("entering");
        if (event.getAdvertisement() instanceof EndpointResolverAdvertisement)
            handleEndpointResolverAdvertisement((EndpointResolverAdvertisement) event.getAdvertisement());
        logger.info("exiting");
    }


    /**
     * Called by the pipe service when a pipe is resolved
     */
    public void pipeResolved(EndpointResolutionEvent event) {
        logger.info("entering");
        if (pipeads.containsKey(event.getPipeId())) {
            PipeAdvertisement pipead = (PipeAdvertisement) pipeads.remove(event.getPipeId());

            try {
                OutputPipe pipe = createOutputPipe(pipead, event.getResolver(), event.getEndpointAddress());
                notifyPipeConnection(pipe, pipead);
            } catch (IOException except) {
                notifyPipeConnectFailure(pipead, except);
            }
        }

        logger.info("exiting");
    }

    /**
     * Creates an output pipe from a resolved endpoint
     */
    private OutputPipe createOutputPipe(PipeAdvertisement pipead, EndpointResolver resolver, EndpointAddress endpointAddress) throws IOException {
        Endpoint outpoint = resolver.connectOutputEndpoint(pipead.getPipeID(), endpointAddress);

        if (((Endpoint) outpoint).isInputEndpoint())
            return new BidirectionalPipeImp(pipead, new Endpoint[]{(Endpoint) outpoint});
        else
            return new OutputPipeImp(pipead, (Endpoint) outpoint);
    }


    private void notifyPipeConnection(OutputPipe pipe, PipeAdvertisement pipead) {
        PipeConnectionListener[] copy = (PipeConnectionListener[]) listeners.toArray(new PipeConnectionListener[listeners.size()]);
        PipeConnectedEvent event = new PipeConnectedEvent(peer.getPipeService(), pipe, pipead);

        for (int count = 0; count < copy.length; count++)
            copy[count].outpipeConnected(event);
    }

    private void notifyPipeConnectFailure(PipeAdvertisement pipead, IOException except) {
        PipeConnectionListener[] copy = (PipeConnectionListener[]) listeners.toArray(new PipeConnectionListener[listeners.size()]);
        PipeConnectFailureEvent event = new PipeConnectFailureEvent(peer.getPipeService(), pipead, except);

        for (int count = 0; count < copy.length; count++)
            copy[count].outpipeConnectFailure(event);
    }

}
