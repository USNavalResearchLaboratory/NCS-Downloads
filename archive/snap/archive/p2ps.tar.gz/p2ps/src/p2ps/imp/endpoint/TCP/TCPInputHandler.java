/*
 * The University of Wales, Cardiff Triana Project Software License (Based
 * on the Apache Software License Version 1.1)
 *
 * Copyright (c) 2003 University of Wales, Cardiff. All rights reserved.
 *
 * Redistribution and use of the software in source and binary forms, with
 * or without modification, are permitted provided that the following
 * conditions are met:
 *
 * 1.  Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 * 2.  Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * 3. The end-user documentation included with the redistribution, if any,
 *    must include the following acknowledgment: "This product includes
 *    software developed by the University of Wales, Cardiff for the Triana
 *    Project (http://www.trianacode.org)." Alternately, this
 *    acknowledgment may appear in the software itself, if and wherever
 *    such third-party acknowledgments normally appear.
 *
 * 4. The names "Triana" and "University of Wales, Cardiff" must not be
 *    used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact triana@trianacode.org.
 *
 * 5. Products derived from this software may not be called "Triana," nor
 *    may Triana appear in their name, without prior written permission of
 *    the University of Wales, Cardiff.
 *
 * 6. This software may not be sold, used or incorporated into any product
 *    for sale to third parties.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 * NO EVENT SHALL UNIVERSITY OF WALES, CARDIFF OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Triana Project. For more information on the
 * Triana Project, please see. http://www.trianacode.org.
 *
 * This license is based on the BSD license as adopted by the Apache
 * Foundation and is governed by the laws of England and Wales.
 */

package p2ps.imp.endpoint.TCP;

import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import p2ps.endpoint.DataMessage;
import p2ps.imp.endpoint.PortFactory;
import p2ps.imp.endpoint.ThreadPool;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.*;
import java.util.Hashtable;
import java.util.Vector;

/**
 * A thread that monitors each socket server for incoming connections.
 *
 * @author Ian Wang
 * @version $Revision: 1.3 $
 * @created 29th July 2003
 * @date $Date: 2004/07/02 11:20:52 $ modified by $Author: spxinw $
 * @todo
 */


public class TCPInputHandler extends Thread {

    public static int MONITOR_SLEEP_TIME = 100;
    public static int SEND_BUFFER_SIZE = 32000;


    /**
     * the default socket handler
     */
    private static TCPInputHandler defhandler;

    /**
     * a hashtable of tcp socket handlers keyed by port
     */
    private static Hashtable handlers = new Hashtable();


    /**
     * the server socket
     */
    private TCPServerSocketThread servthread;

    /**
     * a pool of threads used to handle messages
     */
    private ThreadPool threads = new ThreadPool("TCPSocketThread");

    /**
     * a hashtable of message handlers for each id
     */
    private Hashtable idtable = new Hashtable();

    /**
     * a hashtable tcp sockets for each Java socket
     */
    private Hashtable tcptable = new Hashtable();

    /**
     * a list all the sockets currently being input from
     */
    private Vector sockets = new Vector();


    private TCPInputHandler() throws IOException {
        Object key = PortFactory.getNewFactoryKey();
        ServerSocket ssocket = null;
        boolean success = false;
        int port;

        while (!success) {
            port = PortFactory.getNextPort(key);

            try {
                ssocket = new ServerSocket(port);
                success = true;
            } catch (IOException except) {
            }
        }

        if (ssocket != null) {
            setName("TCPInputHandler:" + ssocket.getLocalPort());
            initSocket(ssocket);
        } else
            throw(new IOException("Error constructing TCP Socket Handler: Unable to assign unbound port"));
    }

    private TCPInputHandler(int port) throws IOException {
        ServerSocket ssocket = new ServerSocket(port);

        setName("TCPInputHandler:" + ssocket.getLocalPort());
        initSocket(ssocket);
    }


    /**
     * @return a default socket handler
     */
    public static TCPInputHandler getDefaultTCPSocketHandler() throws IOException {
        if (defhandler == null) {
            defhandler = new TCPInputHandler();
            defhandler.start();

            handlers.put(new Integer(defhandler.getPort()), defhandler);
        }

        return defhandler;
    }

    /**
     * @return a default socket handler
     */
    public static TCPInputHandler getTCPSocketHandler(int port) throws IOException {
        if (!handlers.containsKey(new Integer(port))) {
            TCPInputHandler handler = new TCPInputHandler(port);
            handler.start();

            handlers.put(new Integer(port), handler);
        }

        return (TCPInputHandler) handlers.get(new Integer(port));
    }


    /**
     * Initialises the buffer size on the socket
     */
    private void initSocket(ServerSocket ssocket) throws IOException {
        servthread = new TCPServerSocketThread(ssocket);
        servthread.start();
    }


    /**
     * @return the port for this socket handler
     */
    public int getPort() {
        if (servthread == null)
            return -1;
        else
            return servthread.getPort();
    }

    /**
     * @return the inet address of this socket handler
     */
    public InetAddress getInetAddress() {
        if (servthread == null)
            return null;
        else
            return servthread.getInetAddress();
    }

    /**
     * Adds tcp input socket and its associated pipe id
     */
    public void registerMessageHandler(String id, SocketHandler handler) throws IOException {
        idtable.put(id, handler);
    }

    /**
     * Removes a server socket from being monitored
     */
    public void unregisterMessageHandler(String id) {
        idtable.remove(id);
    }

    /**
     * @return true if there is a message handler for the specified pipe id
     */
    public boolean isMessageHandler(String id) {
        return idtable.containsKey(id);
    }


    /**
     * Adds a socket to the socket list
     */
    public void addSocket(TCPSocket tcpsocket) throws IOException {
        addSocket(tcpsocket.getSocket());
        tcptable.put(tcpsocket.getSocket(), tcpsocket);
    }

    /**
     * Removes a socket from the socket list
     */
    public void removeSocket(TCPSocket tcpsocket) {
        tcptable.remove(tcpsocket.getSocket());
    }


    /**
     * Adds a socket to the socket list
     */
    private void addSocket(Socket socket) throws IOException {
        if (!sockets.contains(socket)) {
            socket.setReuseAddress(true);
            socket.setReceiveBufferSize(TCPInputSocket.RECEIVE_BUFFER_SIZE);

            sockets.add(socket);
        }
    }

    /**
     * Removes a socket from the socket list
     */
    private void removeSocket(Socket socket) {
        try {
            if (!socket.isClosed())
                socket.close();
        } catch (IOException except) {
        }

        sockets.remove(socket);
    }


    /**
     * Closes the socket handler and all associated sockets
     */
    public void close() {
        Socket[] socks = (Socket[]) sockets.toArray(new Socket[sockets.size()]);

        for (int count = 0; count < socks.length; count++)
            removeSocket(socks[count]);

        servthread.stopThread();
        idtable.clear();
        threads.dispose();

        servthread = null;
        idtable = null;
    }


    public void run() {
        Socket socket;

        while (true) {
            for (int count = 0; count < sockets.size(); count++) {
                socket = (Socket) sockets.get(count);

                try {
                    if (socket.getInputStream().available() > 0) {
                        sockets.remove(socket);
                        threads.addTask(new HandleMessage(socket));
                    }
                } catch (IOException except) {
                    removeSocket(socket);
                }
            }

            try {
                Thread.sleep(MONITOR_SLEEP_TIME);
            } catch (InterruptedException except) {
            }
        }
    }


    private class HandleMessage implements Runnable {

        private Socket socket;


        public HandleMessage(Socket socket) {
            this.socket = socket;
        }

        public void run() {
            try {
                DataMessage message = readMessage();

                if (message != null)
                    handleMessage(message);
                else
                    removeSocket(socket);
            } catch (IOException except) {
                except.printStackTrace();
            }
        }

        /**
         * Called by a single input socket when a message is received. The input
         * socket notifies all the data message listeners
         */
        private void handleMessage(DataMessage message) throws IOException {
            if (tcptable.containsKey(socket)) {
                sockets.add(socket);
                ((TCPSocket) tcptable.get(socket)).handleMessage(message);
            } else {
                handleInitMessage(message);
                sockets.add(socket);
            }
        }

        /**
         * Handles the init message which associates a pipe name with the
         * socket
         */
        private void handleInitMessage(DataMessage message) throws IOException {
            try {
                SAXBuilder xmlbuild = new SAXBuilder();
                Document doc = xmlbuild.build(new ByteArrayInputStream(message.getData()));
                TCPInitMessage init = new TCPInitMessage(doc.getRootElement());

                if (idtable.containsKey(init.getPipeID())) {
                    SocketHandler handler = (SocketHandler) idtable.get(init.getPipeID());
                    TCPSocket tcpsocket = new TCPSocketImp(socket, handler);
                    handler.handleSocket(tcpsocket);

                    tcptable.put(socket, tcpsocket);
                } else
                    throw (new IOException("Message handler not registered for pipe id: " + init.getPipeID()));
            } catch (JDOMException except) {
                throw(new IOException(except.getMessage()));
            }
        }


        /**
         * handles a partial message either by creating a new message
         */
        private DataMessage readMessage() throws IOException {
            try {
                // read message length
                int length = readInt(socket.getInputStream());

                // read message
                byte[] message = new byte[length];
                readInto(socket.getInputStream(), message);

                return new DataMessageImp(message);
            } catch (SocketException except) {
                return null;
            }
        }

        /**
         * Reads an integer from the underlying input stream
         */
        private int readInt(InputStream instream) throws IOException {
            byte[] bytes = new byte[4];
            readInto(instream, bytes);

            return (((bytes[0] & 0xff) << 24) | ((bytes[1] & 0xff) << 16) | ((bytes[2] & 0xff) << 8) | (bytes[3] & 0xff));
        }

        /**
         * Read into the specified byte array, return true if successful
         */
        public boolean readInto(InputStream instream, byte[] bytearray) throws IOException {
            int retval = 0;
            int ptr = 0;

            while ((retval >= 0) && (ptr < bytearray.length)) {
                retval = instream.read(bytearray, ptr, bytearray.length - ptr);
                ptr += retval;

                Thread.yield();
            }

            return (retval > 0);
        }

    }


    public class TCPServerSocketThread extends Thread {

        private ServerSocket servsocket;
        private boolean stopped = false;

        public TCPServerSocketThread(ServerSocket servsocket) throws SocketException {
            this.servsocket = servsocket;
            this.servsocket.setSoTimeout(10000);
            this.servsocket.setReuseAddress(true);

            setName("TCPServerSocket:" + servsocket.getLocalPort());
        }


        public int getPort() {
            return servsocket.getLocalPort();
        }

        public InetAddress getInetAddress() {
            return servsocket.getInetAddress();
        }


        public void stopThread() {
            stopped = true;
        }

        public void run() {
            try {
                while (!stopped) {
                    try {
                        addSocket(servsocket.accept());
                    } catch (SocketTimeoutException except) {
                    }
                }
            } catch (IOException except) {
                except.printStackTrace();
            }
        }

    }

}
