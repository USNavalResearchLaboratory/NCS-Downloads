package p2ps.imp.endpoint;

import org.jdom.Element;
import p2ps.endpoint.EndpointAddress;
import p2ps.endpoint.EndpointResolverAdvertisement;
import p2ps.endpoint.EndpointAddressFactory;

import java.io.IOException;
import java.util.List;

/**
 * An implementation of the Pipe Advertisement interface
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 18th March 2003
 * @date $Date: 2004/07/02 11:20:55 $ modified by $Author: spxinw $
 * @todo
 */

public class EndpointResolverAdvertisementImp implements EndpointResolverAdvertisement {

    private String advertid;
    private String peerid;

    private EndpointAddress address;

    private String[] pipetypes;
    private String[] peerids;
    private String[] protocols;


    public EndpointResolverAdvertisementImp(String advertid, String peerid) {
        this.advertid = advertid;
        this.peerid = peerid;
    }


    public EndpointResolverAdvertisementImp(Element root, EndpointAddressFactory endfactory) throws IOException {
        Element elem = root.getChild(ADVERT_ID_TAG);
        if (elem != null)
            advertid = elem.getText();

        elem = root.getChild(PEER_ID_TAG);
        if (elem != null)
            peerid = elem.getText();

        elem = root.getChild(RESOLVER_ENDPOINT_TAG);
        if (elem != null) {
            List children = elem.getChildren();
            if (children.size() > 0)
                address = endfactory.createEndpointAddress((Element) children.get(0));
        }

        List list = root.getChildren(RESOLVER_PIPE_TYPE_TAG);
        Element[] elems = (Element[]) list.toArray(new Element[list.size()]);
        pipetypes = new String[elems.length];

        for (int count = 0; count < elems.length; count++)
            pipetypes[count] = elems[count].getText();

        list = root.getChildren(RESOLVER_FOR_PEER_ID_TAG);
        elems = (Element[]) list.toArray(new Element[list.size()]);
        peerids = new String[elems.length];

        for (int count = 0; count < elems.length; count++)
            peerids[count] = elems[count].getText();

        list = root.getChildren(TRANSPORT_PROTOCOL_TAG);
        elems = (Element[]) list.toArray(new Element[list.size()]);
        protocols = new String[elems.length];

        for (int count = 0; count < elems.length; count++)
            protocols[count] = elems[count].getText();
    }


    /**
     * @return the type for this advertisement
     */
    public String getType() {
        return ENDPOINT_RESOLVER_ADVERTISEMENT_TYPE;
    }

    /**
     * @return the unique id for this advertisement
     */
    public String getAdvertID() {
        return advertid;
    }

    /**
     * @return the id of the peer that created this advertisement
     */
    public String getPeerID() {
        return peerid;
    }

    /**
     * @return the address of the resolver in terms of the specified transport
     *         protocol
     */
    public EndpointAddress getEndpointAddress() {
        return address;
    }

    /**
     * Sets the address for this resolver
     */
    public void setEndpointAddress(EndpointAddress address) {
        this.address = address;
    }


    /**
     * @return the pipe types handled by the resolver
     */
    public String[] getPipeTypes() {
        return pipetypes;
    }

    /**
     * Sets the pipe types for this advert
     */
    public void setPipeTypes(String[] types) {
        this.pipetypes = types;
    }

    /**
     * @return the peer ids of the peers handled by the resolver
     */
    public String[] getResolverForPeerIDs() {
        return peerids;
    }

    /**
     * Sets the transport protocol for this advert
     */
    public void setResolverForPeerIDs(String[] peerids) {
        this.peerids = peerids;
    }

    /**
     * @return the transport protocol used by this resolver
     */
    public String[] getTransportProtocols() {
        return protocols;
    }

    /**
     * Sets the transport protocol for this advert
     */
    public void setTransportProtocols(String[] protocols) {
        this.protocols = protocols;
    }


    /**
     * Output the advert as an xml document
     */
    public Element getXMLAdvert() throws IOException {
        Element root = new Element(ENDPOINT_RESOLVER_ADVERTISEMENT_TYPE);

        Element elem = new Element(ADVERT_ID_TAG);
        elem.addContent(advertid);
        root.addContent(elem);

        elem = new Element(PEER_ID_TAG);
        elem.addContent(peerid);
        root.addContent(elem);

        elem = new Element(RESOLVER_ENDPOINT_TAG);
        elem.addContent(address.getXMLElement());
        root.addContent(elem);

        for (int count = 0; (pipetypes != null) && (count < pipetypes.length); count++) {
            elem = new Element(RESOLVER_PIPE_TYPE_TAG);
            elem.addContent(pipetypes[count]);
            root.addContent(elem);
        }

        for (int count = 0; (peerids != null) && (count < peerids.length); count++) {
            elem = new Element(RESOLVER_FOR_PEER_ID_TAG);
            elem.addContent(peerids[count]);
            root.addContent(elem);
        }

        for (int count = 0; (protocols != null) && (count < protocols.length); count++) {
            elem = new Element(TRANSPORT_PROTOCOL_TAG);
            elem.addContent(protocols[count]);
            root.addContent(elem);
        }

        return root;
    }

    /**
     * @return an XML element for the full enveloped advert (returns the same
     *         as getXMLAdvert if no envelope)
     */
    public Element getXMLEnvelope() throws IOException {
        return getXMLAdvert();
    }

}
