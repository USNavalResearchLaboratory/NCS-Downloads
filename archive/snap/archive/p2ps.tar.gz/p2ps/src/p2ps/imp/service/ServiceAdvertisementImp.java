package p2ps.imp.service;

import org.jdom.Element;
import p2ps.discovery.AdvertisementFactory;
import p2ps.pipe.PipeAdvertisement;
import p2ps.service.ServiceAdvertisement;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * An implementation of the Pipe Advertisement interface
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 18th March 2003
 * @date $Date: 2004/07/02 11:21:00 $ modified by $Author: spxinw $
 * @todo
 */

public class ServiceAdvertisementImp implements ServiceAdvertisement {

    private String advertid;
    private String peerid;

    private String name;
    private String servid;
    private ArrayList controls = new ArrayList();


    public ServiceAdvertisementImp(String advertid, String peerid, String servid) {
        this.advertid = advertid;
        this.peerid = peerid;
        this.servid = servid;
    }

    public ServiceAdvertisementImp(Element root, AdvertisementFactory adfactory) throws IOException {
        Element elem = root.getChild(ADVERT_ID_TAG);
        if (elem != null)
            advertid = elem.getText();

        elem = root.getChild(PEER_ID_TAG);
        if (elem != null)
            peerid = elem.getText();

        elem = root.getChild(SERVICE_NAME_TAG);
        if (elem != null)
            name = elem.getText();

        elem = root.getChild(SERVICE_ID_TAG);
        if (elem != null)
            servid = elem.getText();

        elem = root.getChild(CONTROL_PIPES_TAG);
        if (elem != null) {
            List pipeads = elem.getChildren(p2ps.pipe.PipeAdvertisement.PIPE_ADVERTISEMENT_TYPE);

            for (Iterator iter = pipeads.iterator(); iter.hasNext();)
                controls.add(adfactory.createAdvertisement((Element) iter.next()));
        }
    }


    /**
     * @return the type for this advertisement
     */
    public String getType() {
        return SERVICE_ADVERTISEMENT_TYPE;
    }

    /**
     * @return the unique id for this advertisement
     */
    public String getAdvertID() {
        return advertid;
    }

    /**
     * @return the id of the peer that created this advertisement
     */
    public String getPeerID() {
        return peerid;
    }


    /**
     * @return the name of the service
     */
    public String getServiceName() {
        return name;
    }

    /**
     * Sets the name for this service
     */
    public void setServiceName(String name) {
        this.name = name;
    }

    /**
     * @return the id of the service
     */
    public String getServiceID() {
        return servid;
    }

    /**
     * Sets the name for this service
     */
    public void setServiceID(String id) {
        this.servid = id;
    }

    /**
     * @return the advertisements for the services control pipes
     */
    public PipeAdvertisement[] getPipeAdvertisements() {
        return (PipeAdvertisement[]) controls.toArray(new PipeAdvertisement[controls.size()]);
    }

    /**
     * @return the pipe advertisement for the control pipe with the specified
     *         name
     */
    public PipeAdvertisement getPipeAdvertisement(String pipename) {
        PipeAdvertisement pipead;
        for (Iterator iter = controls.iterator(); iter.hasNext();) {
            pipead = (PipeAdvertisement) iter.next();

            if (pipename.equals(pipead.getPipeName()))
                return pipead;
        }

        return null;
    }

    /**
     * Sets the advertisement for this services control pipes
     */
    public void addPipeAdvertisement(PipeAdvertisement advert) {
        if (!controls.contains(advert))
            controls.add(advert);
    }

    /**
     * Sets the advertisement for this services control pipes
     */
    public void removePipeAdvertisement(PipeAdvertisement advert) {
        controls.remove(advert);
    }


    /**
     * Output the advert as an xml document
     */
    public Element getXMLAdvert() throws IOException {
        Element root = new Element(SERVICE_ADVERTISEMENT_TYPE);

        Element elem = new Element(ADVERT_ID_TAG);
        elem.addContent(advertid);
        root.addContent(elem);

        elem = new Element(PEER_ID_TAG);
        elem.addContent(peerid);
        root.addContent(elem);

        elem = new Element(SERVICE_NAME_TAG);
        elem.addContent(name);
        root.addContent(elem);

        elem = new Element(SERVICE_ID_TAG);
        elem.addContent(servid);
        root.addContent(elem);

        elem = new Element(CONTROL_PIPES_TAG);

        for (Iterator iter = controls.iterator(); iter.hasNext();)
            elem.addContent(((PipeAdvertisement) iter.next()).getXMLAdvert());

        root.addContent(elem);

        return root;
    }

    /**
     * @return an XML element for the full enveloped advert (returns the same
     *         as getXMLAdvert if no envelope)
     */
    public Element getXMLEnvelope() throws IOException {
        return getXMLAdvert();
    }

}
