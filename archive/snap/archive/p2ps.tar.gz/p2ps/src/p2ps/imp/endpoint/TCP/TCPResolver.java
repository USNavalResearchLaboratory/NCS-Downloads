package p2ps.imp.endpoint.TCP;

import org.jdom.Document;
import org.jdom.output.XMLOutputter;
import p2ps.discovery.Advertisement;
import p2ps.endpoint.*;
import p2ps.imp.discovery.DiscoveryCache;
import p2ps.imp.endpoint.EndpointAddressImp;
import p2ps.peer.Config;
import p2ps.peer.IDFactory;
import p2ps.peer.Peer;
import p2ps.pipe.PipeTypes;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * The resolver for socket using UDP
 *
 * @author Ian Wang
 * @version $Revision: 1.10 $
 * @created 18th March 2002
 * @date $Date: 2004/07/02 14:11:57 $ modified by $Author: spxinw $
 * @todo
 */

public class TCPResolver implements EndpointResolver, EndpointMessageListener, PipeTypes, TCPEndpointTypes {

    public static final String TCP_PROTOCOL = "TCP";
    public static final String DEFAULT_RENDEZVOUS_SOCKET_ID = "rendezvous";
    public static final String DEFAULT_RESOLVER_SOCKET_ID = "resolver";

    /**
     * the resolver socker
     */
    private TCPInputSocket ressocket;

    /**
     * the main peer
     */
    private Peer peer;

    /**
     * the protocol this resolver is using (TCP_PROTOCOL by default)
     */
    private String protocol = TCP_PROTOCOL;

    /**
     * the advertisement type used to advertise this resolver
     */
    private String adverttype = EndpointResolverAdvertisement.ENDPOINT_RESOLVER_ADVERTISEMENT_TYPE;

    /**
     * the query type used to query for other resolvers
     */
    private String querytype = EndpointQuery.ENDPOINT_QUERY_TYPE;

    /**
     * the advert for the resolver
     */
    private EndpointResolverAdvertisement advert;

    /**
     * a list of all the input sockets
     */
    private ArrayList sockets = new ArrayList();

    /**
     * an array list of the listeners that are notified when a pipe is resolved
     */
    private ArrayList listeners = new ArrayList();

    /**
     * a flag indicating whether input pipes are enabled
     */
    private boolean inpipes = true;

    /**
     * a flag indicating whether output pipes are enabled
     */
    private boolean outpipes = true;

    /**
     * a flag indicating whether bidirectional input pipes are enabled
     */
    private boolean biinpipes;

    /**
     * a flag indicating whether bidirectional output pipes are enabled
     */
    private boolean bioutpipes;


    /**
     * Create a TCPResolver that uses the standard TCP_PROTOCOL
     */
    public TCPResolver() {
        this(TCP_PROTOCOL);
    }

    /**
     * Create a TCPResolver the uses a custom protocol but uses the default
     * endpoint resolver advertisement and query types
     */
    protected TCPResolver(String protocol) {
        this.protocol = protocol;
    }

    /**
     * Create a TCPResolver the uses a custom protocol, endpoint resolver advert
     * type and endpoint query type
     */
    protected TCPResolver(String protocol, String adverttype, String querytype) {
        this.protocol = protocol;
        this.adverttype = adverttype;
        this.querytype = querytype;
    }


    /**
     * Initialises the endpoint resolver
     */
    public void init(Peer peer, Config config) throws IOException {
        this.peer = peer;

        EndpointAddress resaddr = getResolverEndpoint(config);

        if (resaddr != null)
            ressocket = new TCPInputSocket(resaddr, IDFactory.newPipeID(), protocol, peer);
        else
            ressocket = new TCPInputSocket(IDFactory.newPipeID(), protocol, peer);

        ressocket.addEndpointMessageListener(this);

        if (peer.getAdvertisementFactory() == null)
            throw(new RuntimeException("Error instantiating UDP resolver: Advertisement factory not registered on peer"));

        advert = (EndpointResolverAdvertisement) peer.getAdvertisementFactory().newAdvertisement(adverttype);
        advert.setEndpointAddress(getResolverEndpointAddress());
        advert.setPipeTypes(new String[]{STANDARD, BIDIRECTIONAL});
        advert.setResolverForPeerIDs(new String[]{peer.getPeerID()});
        advert.setTransportProtocols(new String[]{protocol});
    }

    /**
     * @return the endpoint address for the resolver socket, based on the
     *         endpoint specified in the config for the local rendezvous socket (or
     *         null if no tcp local rendezvous socket
     */
    private EndpointAddress getResolverEndpoint(Config config) throws IOException {
        EndpointAddress[] rendaddr = config.getLocalRendezvousEndpoints();
        EndpointAddress resaddr = null;

        for (int count = 0; (count < rendaddr.length) && (resaddr == null); count++) {
            if (rendaddr[count].getProtocol().equals(protocol)) {
                String address = getHostAddress(rendaddr[count]) + ":" + getPort(rendaddr[count]) + ":" + DEFAULT_RESOLVER_SOCKET_ID;
                resaddr = peer.getEndpointAddressFactory().newEndpointAddress(protocol, address, TCPEndpointTypes.TCP_UNICAST);
            }
        }

        return resaddr;
    }


    /**
     * @return true if input pipes of the specified type are enabled with this
     *         resolver
     */
    public boolean isInputPipesEnabled(String endpointtype) {
        if (endpointtype.equals(TCP_UNICAST) || endpointtype.equals(STANDARD))
            return inpipes;
        else if (endpointtype.equals(TCP_UNICAST) || endpointtype.equals(BIDIRECTIONAL))
            return biinpipes;
        else
            return false;
    }

    /**
     * Sets whether input pipes of the specified type are enabled with this
     * resolver
     */
    public void setInputPipesEnabled(String endpointtype, boolean state) {
        if (endpointtype.equals(STANDARD))
            this.inpipes = state;
        else if (endpointtype.equals(BIDIRECTIONAL))
            this.biinpipes = state;
    }

    /**
     * @return true if output pipes of the specified type are enabled with this
     *         resolver
     */
    public boolean isOutputPipesEnabled(String endpointtype) {
        if (endpointtype.equals(TCP_UNICAST) || endpointtype.equals(STANDARD))
            return outpipes;
        else if (endpointtype.equals(TCP_UNICAST) || endpointtype.equals(BIDIRECTIONAL))
            return bioutpipes;
        else
            return false;
    }

    /**
     * Sets whether output pipes of the specified type are enabled with this
     * resolver
     */
    public void setOutputPipesEnabled(String endpointtype, boolean state) {
        if (endpointtype.equals(STANDARD))
            this.outpipes = state;
        else if (endpointtype.equals(BIDIRECTIONAL))
            this.bioutpipes = state;
    }


    /**
     * @return the resolver endpoint
     */
    public Endpoint getResolverEndpoint() {
        return ressocket;
    }

    /**
     * @return the address of the resolver socket
     */
    public EndpointAddress getResolverEndpointAddress() throws IOException {
        return ressocket.getEndpointAddress();
    }


    /**
     * @return an array of the pipe types handled by this resolver
     */
    public String[] getPipeTypes() {
        return advert.getPipeTypes();
    }

    /**
     * @return the ids of the peers this resolver handles enpoint resolution for
     */
    public String[] getResolverForPeerIDs() {
        return advert.getResolverForPeerIDs();
    }

    /**
     * @return the endpoint protocol used by this socket
     */
    public String[] getEndpointProtocols() {
        return advert.getTransportProtocols();
    }

    /**
     * @return a pipe resolver advert for this resolver
     */
    public EndpointResolverAdvertisement getAdvertisement() throws IOException {
        return advert;
    }


    /**
     * Add a listener to be notified when a pipe is resolved
     */
    public void addEndpointResolutionListener(EndpointResolutionListener listener) {
        if (!listeners.contains(listener))
            listeners.add(listener);
    }

    /**
     * Removes a pipe resolution listener
     */
    public void removeEndpointResolutionListener(EndpointResolutionListener listener) {
        listeners.remove(listener);
    }


    /**
     * Create a endpoint for the specified input pipe
     */
    public Endpoint createInputEndpoint(String pipeid, String type) throws IOException {
        if ((!type.equals(STANDARD)) && (!type.equals(BIDIRECTIONAL)))
            throw(new RuntimeException("TCP Resolver Error: Cannot create input endpoint for " + type + " pipes"));

        Endpoint socket = new TCPInputSocket(pipeid, protocol, peer);
        sockets.add(socket);
        return socket;
    }

    /**
     * Create a endpoint for the specified input pipe bound the specified endpoint
     * address
     */
    public Endpoint createInputEndpoint(String pipeid, EndpointAddress address) throws IOException {
        String protocol = address.getProtocol();
        Endpoint socket;

        if (!address.getEndpointType().equals(TCP_UNICAST))
            throw(new RuntimeException("TCP Resolver Error: Cannot create input endpoint for non-unicast pipe"));

        if (!protocol.equals(this.protocol))
            throw(new RuntimeException("TCP Resolver Error: Cannot create input endpoint for non-TCP address"));

        socket = new TCPInputSocket(address, pipeid, protocol, peer);

        sockets.add(socket);
        return socket;
    }

    /**
     * Connects an endpoint to output to the specified address
     */
    public Endpoint connectOutputEndpoint(String pipeid, EndpointAddress address) throws IOException {
        String protocol = address.getProtocol();

        if (!address.getEndpointType().equals(TCP_UNICAST))
            throw(new RuntimeException("TCP Resolver Error: Cannot create output endpoint for non-unicast pipe"));

        if (!protocol.equals(this.protocol))
            throw(new RuntimeException("TCP Resolver Error: Cannot create output endpoint for non-TCP address"));

        TCPOutputSocket socket = new TCPOutputSocket(pipeid, protocol, peer);
        socket.connect(getHostAddress(address), getPort(address), getSocketID(address));

        return socket;
    }


    /**
     * Sends out a pipe resolution query for the specified pipe to the specified
     * pipe resolver address.
     *
     * @param pipeid     the id of the pipe being resolved
     * @param resaddress the address of the endpoint resolver
     */
    public void resolveEndpoint(String pipeid, EndpointAddress resaddress) throws IOException {
        EndpointQuery query = (EndpointQuery) peer.getAdvertisementFactory().newAdvertisement(querytype);
        query.setQueryPipeID(pipeid);
        query.setQueryTransportProtocol(this.protocol);
        query.setReplyEndpointAddress(getResolverEndpointAddress());

        XMLOutputter xmlout = new XMLOutputter("    ", true);
        ByteArrayOutputStream outstream = new ByteArrayOutputStream();
        xmlout.output(new Document(query.getXMLEnvelope()), outstream);

        TCPOutputSocket outsocket = new TCPOutputSocket("reply", protocol, peer);
        outsocket.connect(getHostAddress(resaddress), getPort(resaddress), getSocketID(resaddress));
        outsocket.send(outstream.toByteArray());
    }


    public void dataMessageReceived(DataMessageEvent event) {
        try {
            Advertisement advert = peer.getAdvertisementFactory().createAdvertisement(event.getDataMessage().getData());

            if (advert instanceof EndpointQuery)
                handleEndpointQuery((EndpointQuery) advert);
            else if (advert instanceof EndpointAdvertisement)
                handleEndpointAdvertisement((EndpointAdvertisement) advert);
        } catch (IOException except) {
            except.printStackTrace();
        }
    }

    /**
     * Replies to a resolver query (if the pipe is known to this resolver)
     */
    public void handleEndpointQuery(EndpointQuery query) throws IOException {
        Endpoint[] endpoints = (Endpoint[]) sockets.toArray(new Endpoint[sockets.size()]);
        ArrayList matches = new ArrayList();

        for (int count = 0; count < endpoints.length; count++) {
            if (endpoints[count].isClosed())
                sockets.remove(endpoints[count]);
            else {
                if (DiscoveryCache.isMatch(query, endpoints[count].getAdvertisement()))
                    matches.add(endpoints[count].getAdvertisement());
            }
        }

        if (matches.size() > 0)
            notifyMatches(query.getReplyEndpointAddress(), matches);
    }

    /**
     * Sends matching adverts to either the reply address, or publishes them
     * if no reply address
     */
    private void notifyMatches(EndpointAddress replyaddr, ArrayList matches) throws IOException {
        Iterator iter = matches.iterator();
        Endpoint outsocket = null;

        if (replyaddr != null) {
            try {
                EndpointResolver resolver = peer.getPipeService().getPipeResolver(replyaddr.getProtocol());
                outsocket = resolver.connectOutputEndpoint(IDFactory.newPipeID(), replyaddr);
            } catch (ConnectException except) {
            }
        }

        while (iter.hasNext()) {
            Advertisement advert = (Advertisement) iter.next();

            if (outsocket == null)
                peer.getDiscoveryService().publish(advert);
            else {
                XMLOutputter xmlout = new XMLOutputter("    ", true);
                ByteArrayOutputStream outstream = new ByteArrayOutputStream();
                xmlout.output(new Document(advert.getXMLEnvelope()), outstream);
                outsocket.send(outstream.toByteArray());
            }
        }
    }


    private void handleEndpointAdvertisement(EndpointAdvertisement advert) {
        EndpointResolutionEvent event = new EndpointResolutionEvent(advert.getPipeID(), advert.getEndpointAddress(), this);
        EndpointResolutionListener[] copy = (EndpointResolutionListener[]) listeners.toArray(new EndpointResolutionListener[listeners.size()]);

        for (int count = 0; count < copy.length; count++)
            copy[count].pipeResolved(event);
    }

    /**
     * @return an host specified in the full address
     */
    public static final String getHostAddress(EndpointAddress address) {
        if (address.getAddress().indexOf(':') == address.getAddress().lastIndexOf(':'))
            throw (new RuntimeException("Invalid TCP address: " + address.getAddress()));

        return address.getAddress().substring(0, address.getAddress().indexOf(':'));
    }

    /**
     * @return the port specified in the address address
     */
    public static final int getPort(EndpointAddress address) {
        if (address.getAddress().indexOf(':') == address.getAddress().lastIndexOf(':'))
            throw (new RuntimeException("Invalid TCP address: " + address.getAddress()));

        return Integer.parseInt(address.getAddress().substring(address.getAddress().indexOf(':') + 1, address.getAddress().lastIndexOf(':')));
    }

    /**
     * @return the socket id specified in the full address
     */
    public static final String getSocketID(EndpointAddress address) {
        if (address.getAddress().indexOf(':') == address.getAddress().lastIndexOf(':'))
            throw (new RuntimeException("Invalid TCP address: " + address.getAddress()));

        return address.getAddress().substring(address.getAddress().lastIndexOf(':') + 1);
    }
}
