package p2ps.imp.endpoint;

import org.jdom.Element;
import p2ps.discovery.AdvertisementFactory;
import p2ps.endpoint.EndpointAddress;
import p2ps.endpoint.EndpointResolverAdvertisement;
import p2ps.endpoint.EndpointResolverQuery;
import p2ps.endpoint.EndpointAddressFactory;
import p2ps.pipe.PipeAdvertisement;

import java.io.IOException;
import java.util.List;

/**
 * An implementation of the Pipe Resolver Query interface
 *
 * @author Ian Wang
 * @version $Revision: 1.5 $
 * @created 18th March 2003
 * @date $Date: 2004/07/02 11:20:56 $ modified by $Author: spxinw $
 * @todo
 */

public class EndpointResolverQueryImp implements EndpointResolverQuery {

    private String advertid;
    private String peerid;

    private String querypipetype;
    private String querypeerid;
    private String queryprotocol;

    private PipeAdvertisement pipead;
    private EndpointAddress replyaddr;


    public EndpointResolverQueryImp(String advertid, String peerid) {
        this.advertid = advertid;
        this.peerid = peerid;
    }

    public EndpointResolverQueryImp(Element root, AdvertisementFactory adfactory, EndpointAddressFactory endfactory) throws IOException {
        Element elem = root.getChild(ADVERT_ID_TAG);
        if (elem != null)
            advertid = elem.getText();

        elem = root.getChild(PEER_ID_TAG);
        if (elem != null)
            peerid = elem.getText();

        elem = root.getChild(QUERY_PIPE_TYPE);
        if (elem != null)
            querypipetype = elem.getText();

        elem = root.getChild(QUERY_PEER_ID_TAG);
        if (elem != null)
            querypeerid = elem.getText();

        elem = root.getChild(QUERY_PROTOCOL_TAG);
        if (elem != null)
            queryprotocol = elem.getText();

        elem = root.getChild(REPLY_PIPE_ADVERTISEMENT_TAG);
        if (elem != null) {
            List children = elem.getChildren();
            if (children.size() > 0)
                pipead = (PipeAdvertisement) adfactory.createAdvertisement((Element) children.get(0));
        }

        elem = root.getChild(REPLY_ENDPOINT_ADDRESS_TAG);
        if (elem != null) {
            List children = elem.getChildren();
            if (children.size() > 0)
                replyaddr = endfactory.createEndpointAddress((Element) children.get(0));
        }
    }


    /**
     * @return the type for this advertisement
     */
    public String getType() {
        return ENDPOINT_RESOLVER_QUERY_TYPE;
    }

    /**
     * @return the type of advertisement this query is interested in (e.g.
     *         PipeAdvertisement)
     */
    public String getQueryType() {
        return EndpointResolverAdvertisement.ENDPOINT_RESOLVER_ADVERTISEMENT_TYPE;
    }

    /**
     * @return the unique id for this advertisement
     */
    public String getAdvertID() {
        return advertid;
    }

    /**
     * @return the id of the peer that created this advertisement
     */
    public String getPeerID() {
        return peerid;
    }


    /**
     * @return the pipe type this query is interested in (null if any)
     */
    public String getQueryPipeType() {
        return querypipetype;
    }

    /**
     * Sets the pipe type this query is interested in (null if any)
     */
    public void setQueryPipeType(String type) {
        this.querypipetype = type;
    }

    /**
     * @return the id of the peer this query is interested in (null if any)
     */
    public String getQueryResolverForPeerID() {
        return querypeerid;
    }

    /**
     * Sets the id of the peer this query is interested in (null if any)
     */
    public void setQueryResolverForPeerID(String id) {
        querypeerid = id;
    }

    /**
     * @return the id of the transport protocol this query is interested in (null if any)
     */
    public String getQueryTransportProtocol() {
        return queryprotocol;
    }

    /**
     * Sets the id of the transport protocol this query is interested in (null if any)
     */
    public void setQueryTransportProtocol(String protocol) {
        this.queryprotocol = protocol;
    }


    /**
     * @return optional pipe for the query reply.
     */
    public PipeAdvertisement getReplyPipeAdvertisement() {
        return pipead;
    }

    /**
     * Ssets the optional endpoint address for the query reply.
     */
    public void setReplyPipeAdvertisement(PipeAdvertisement pipead) {
        this.pipead = pipead;
    }


    /**
     * @return optional endpoint address for the query reply. If not specified
     *         the query matches should be (re)published.
     */
    public EndpointAddress getReplyEndpointAddress() {
        return replyaddr;
    }

    /**
     * Ssets the optional endpoint address for the query reply. If not specified
     * the query matches should be (re)published.
     */
    public void setReplyEndpointAddress(EndpointAddress replyaddr) {
        this.replyaddr = replyaddr;
    }


    /**
     * Output the advert as an xml document
     */
    public Element getXMLAdvert() throws IOException {
        Element root = new Element(ENDPOINT_RESOLVER_QUERY_TYPE);

        Element elem = new Element(QUERY_TAG);
        elem.addContent(EndpointResolverAdvertisement.ENDPOINT_RESOLVER_ADVERTISEMENT_TYPE);
        root.addContent(elem);

        elem = new Element(ADVERT_ID_TAG);
        elem.addContent(advertid);
        root.addContent(elem);

        elem = new Element(PEER_ID_TAG);
        elem.addContent(peerid);
        root.addContent(elem);

        if (querypipetype != null) {
            elem = new Element(QUERY_PIPE_TYPE);
            elem.addContent(querypipetype);
            root.addContent(elem);
        }

        if (querypeerid != null) {
            elem = new Element(QUERY_PEER_ID_TAG);
            elem.addContent(querypeerid);
            root.addContent(elem);
        }

        if (queryprotocol != null) {
            elem = new Element(QUERY_PROTOCOL_TAG);
            elem.addContent(queryprotocol);
            root.addContent(elem);
        }

        if (pipead != null) {
            elem = new Element(REPLY_PIPE_ADVERTISEMENT_TAG);
            elem.addContent(pipead.getXMLAdvert());
            root.addContent(elem);
        }

        if (replyaddr != null) {
            elem = new Element(REPLY_ENDPOINT_ADDRESS_TAG);
            elem.addContent(replyaddr.getXMLElement());
            root.addContent(elem);
        }

        return root;
    }

    /**
     * @return an XML element for the full enveloped advert (returns the same
     *         as getXMLAdvert if no envelope)
     */
    public Element getXMLEnvelope() throws IOException {
        return getXMLAdvert();
    }

}
