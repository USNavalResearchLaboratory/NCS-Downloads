package p2ps.imp.peer.config;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;
import p2ps.endpoint.EndpointAddress;
import p2ps.endpoint.EndpointAddressFactory;
import p2ps.endpoint.EndpointAddressInstantiator;
import p2ps.peer.Config;
import p2ps.peer.ResolverConfig;
import p2ps.peer.InstantiatorConfig;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Hashtable;

/**
 * The configuration for a p2ps peer
 *
 * @author Ian Wang
 * @version $Revision: 1.8 $
 * @created 7th July 2003
 * @date $Date: 2004/07/02 13:40:52 $ modified by $Author: spxinw $
 * @todo
 */

public class ConfigImp implements Config {

    static String DOC_INDENT_ = "   ";
    static boolean DOC_NEW_LINE_ = true;
    static String TAB = "    ";
    static String NEWLINE = "\n";

    private String discclass;
    private String pipeclass;
    private String rendezclass;
    private String idclass;

    private ArrayList advertinstants = new ArrayList();
    private ArrayList endpointinstants = new ArrayList();

    private boolean rendezvous;

    private ArrayList localendpoints = new ArrayList();
    private ArrayList remoteendpoints = new ArrayList();

    private Hashtable resconfigs = new Hashtable();

    private int minport = DEFAULT_MIN_PORT;
    private int maxport = DEFAULT_MAX_PORT;


    /**
     * Constructs an empty ConfigImp
     */
    private ConfigImp() {
    }

    /**
     * Constructs a ConfigImp from the specfied config
     */
    public ConfigImp(Config config) {
        discclass = config.getDiscoveryServiceClass();
        pipeclass = config.getPipeServiceClass();
        rendezclass = config.getRendezvousServiceClass();
        idclass = config.getIDFactoryClass();

        InstantiatorConfig[] instconfigs = config.getAdvertInstantiatorConfigs();
        for (int count = 0; count < instconfigs.length; count++)
            addAdvertInstantiatorConfig(instconfigs[count]);

        instconfigs = config.getEndpointAddressInstantiatorConfigs();
        for (int count = 0; count < instconfigs.length; count++)
            addEndpointAddressInstantiatorConfig(instconfigs[count]);

        rendezvous = config.isRendezvousPeer();

        EndpointAddress[] addrs = config.getLocalRendezvousEndpoints();
        for (int count = 0; count < addrs.length; count++)
            addLocalRendezvousEndpoint(addrs[count]);

        addrs = config.getRemoteRendezvousEndpoints();
        for (int count = 0; count < addrs.length; count++)
            addRemoteRendezvousEndpoint(addrs[count]);

        ResolverConfig[] resconfigs = config.getResolverConfigs();
        for (int count = 0; count < resconfigs.length; count++)
            setResolverConfigs(resconfigs[count]);

        minport = config.getMinPort();
        maxport = config.getMaxPort();
    }


    /**
     * @return the class of the discovery service
     */
    public String getDiscoveryServiceClass() {
        return discclass;
    }

    public void setDiscoveryServiceClass(String discclass) {
        this.discclass = discclass;
    }

    /**
     * @return the class of the pipe service
     */
    public String getPipeServiceClass() {
        return pipeclass;
    }

    public void setPipeServiceClass(String pipeclass) {
        this.pipeclass = pipeclass;
    }

    /**
     * @return the class of the rendezvous service
     */
    public String getRendezvousServiceClass() {
        return rendezclass;
    }

    public void setRendezvousServiceClass(String rendezclass) {
        this.rendezclass = rendezclass;
    }


    /**
     * @return the class of the id factory
     */
    public String getIDFactoryClass() {
        return idclass;
    }

    public void setIDFactoryClass(String idclass) {
        this.idclass = idclass;
    }


    /**
     * @return an array of the advert instantiator configs
     */
    public InstantiatorConfig[] getAdvertInstantiatorConfigs() {
        return (InstantiatorConfig[]) advertinstants.toArray(new InstantiatorConfig[advertinstants.size()]);
    }

    /**
     * Add an advert instantiator config
     */
    public void addAdvertInstantiatorConfig(InstantiatorConfig config) {
        advertinstants.add(config);
    }


    /**
     * @return an array of the endpoint address instantiator configs
     */
    public InstantiatorConfig[] getEndpointAddressInstantiatorConfigs() {
        return (InstantiatorConfig[]) endpointinstants.toArray(new InstantiatorConfig[endpointinstants.size()]);
    }

    /**
     * Add an endpoint address instantiator config
     */
    public void addEndpointAddressInstantiatorConfig(InstantiatorConfig config) {
        endpointinstants.add(config);
    }


    /**
     * @return true if the peer is a rendezvous peer
     */
    public boolean isRendezvousPeer() {
        return rendezvous;
    }

    /**
     * Sets the peer as a rendezvous peer
     */
    public void setRendezvousPeer(boolean rendezvous) {
        this.rendezvous = rendezvous;
    }


    /**
     * @return an array of the local rendezvous endpoints
     */
    public EndpointAddress[] getLocalRendezvousEndpoints() {
        return (EndpointAddress[])
                localendpoints.toArray(new EndpointAddress[localendpoints.size()]);
    }

    /**
     * Add a local rendezvous endpoint
     */
    public void addLocalRendezvousEndpoint(EndpointAddress endpoint) {
        localendpoints.add(endpoint);
    }

    /**
     * Removes all remote rendezvous endpoints
     */
    public void clearLocalRendezvousEndpoints() {
        localendpoints.clear();
    }


    /**
     * @return an array of the remote rendezvous endpoints that the rendezvous
     *         service should connect to.
     */
    public EndpointAddress[] getRemoteRendezvousEndpoints() {
        return (EndpointAddress[])
                remoteendpoints.toArray(new EndpointAddress[remoteendpoints.size()]);
    }

    /**
     * Add a remote rendezvous endpoint
     */
    public void addRemoteRendezvousEndpoint(EndpointAddress endpoint) {
        remoteendpoints.add(endpoint);
    }

    /**
     * Removes all remote rendezvous endpoints
     */
    public void clearRemoteRendezvousEndpoints() {
        remoteendpoints.clear();
    }


    /**
     * @return an array of resolver configurations
     */
    public ResolverConfig[] getResolverConfigs() {
        return (ResolverConfig[]) resconfigs.values().toArray(new ResolverConfig[resconfigs.values().size()]);
    }

    /**
     * @return the resolver config for the specified protocol
     */
    public ResolverConfig getResolverConfig(String protocol) {
        return (ResolverConfig) resconfigs.get(protocol);
    }

    /**
     * Adds a resolver configuration to configuration
     */
    public void setResolverConfigs(ResolverConfig resconfig) {
        if (!resconfigs.containsKey(resconfig.getResolverProtocol()))
            resconfigs.put(resconfig.getResolverProtocol(), resconfig);
    }

    /**
     * Adds a resolver configuration to configuration
     */
    public void removeResolverConfigs(String protocol) {
        resconfigs.remove(protocol);
    }

    /**
     * Removes all the resolver configs
     */
    public void clearResolverConfigs() {
        resconfigs.clear();
    }


    /**
     * @return the minimum available port number
     */
    public int getMinPort() {
        return minport;
    }


    /**
     * @return the maximum available port number
     */
    public int getMaxPort() {
        return maxport;
    }

    /**
     * Sets the mininum available port
     */
    public void setPortRange(int minport, int maxport) {
        this.minport = minport;
        this.maxport = maxport;
    }

    /**
     * Write a configuration to a file
     */
    public void writeConfig() throws IOException {
        Element root = new Element(P2PS_CONFIG_TAG);

        Element elem = new Element(DISCOVERY_SERVICE_CLASS_TAG);
        elem.setText(getDiscoveryServiceClass());
        root.addContent(elem);

        elem = new Element(PIPE_SERVICE_CLASS_TAG);
        elem.setText(getPipeServiceClass());
        root.addContent(elem);

        elem = new Element(RENDEZVOUS_SERVICE_CLASS_TAG);
        elem.setText(getRendezvousServiceClass());
        root.addContent(elem);

        elem = new Element(ID_FACTORY_CLASS_TAG);
        elem.setText(getIDFactoryClass());
        root.addContent(elem);

        elem = new Element(ADVERT_INSTANTIATORS_TAG);
        InstantiatorConfig[] configs = getAdvertInstantiatorConfigs();
        for (int count = 0; count < configs.length; count++)
            elem.addContent(configs[count].getXMLElement());
        root.addContent(elem);

        elem = new Element(ENDPOINT_ADDRESS_INSTANTIATORS_TAG);
        configs = getEndpointAddressInstantiatorConfigs();
        for (int count = 0; count < configs.length; count++)
            elem.addContent(configs[count].getXMLElement());
        root.addContent(elem);

        elem = new Element(RENDEZVOUS_TAG);
        elem.addContent(String.valueOf(isRendezvousPeer()));
        root.addContent(elem);

        EndpointAddress[] endpoints = getLocalRendezvousEndpoints();
        if (endpoints.length > 0) {
            elem = new Element(LOCAL_END_TAG);
            root.addContent(elem);
            for (int i = 0; i < endpoints.length; i++) {
                EndpointAddress endpoint = endpoints[i];
                elem.addContent(endpoint.getXMLElement());
            }
        }

        endpoints = getRemoteRendezvousEndpoints();
        if (endpoints.length > 0) {
            elem = new Element(REMOTE_END_TAG);
            root.addContent(elem);
            for (int i = 0; i < endpoints.length; i++) {
                EndpointAddress endpoint = endpoints[i];
                elem.addContent(endpoint.getXMLElement());
            }
        }

        ResolverConfig[] resolverConfigs = getResolverConfigs();
        for (int i = 0; i < resolverConfigs.length; i++) {
            ResolverConfig resolverConfig = resolverConfigs[i];
            root.addContent(resolverConfig.getXMLElement());
        }

        elem = new Element(PORT_MIN_TAG);
        elem.addContent(String.valueOf(getMinPort()));
        root.addContent(elem);
        elem = new Element(PORT_MAX_TAG);
        elem.addContent(String.valueOf(getMaxPort()));
        root.addContent(elem);

        XMLOutputter xmlOut = new XMLOutputter(DOC_INDENT_, DOC_NEW_LINE_);
        xmlOut.setIndent(TAB);
        xmlOut.setNewlines(true);
        xmlOut.setTextNormalize(true);
        Document doc = new Document(root);
        BufferedWriter writer = new BufferedWriter(new FileWriter(PROPERTIES_FILE));
        xmlOut.output(doc, writer);
        writer.close();
    }

    /**
     * Static constructor and loader for P2PS Config
     *
     * @return A successfuly loaded Config or null if there is a problem
     */
    public static final Config loadConfig() {
        ConfigImp result = new ConfigImp();
        try {
            boolean success = result.readConfig();

            if (success)
                return result;
            else
                return null;
        } catch (IOException e) {
            System.err.println("Error reading config");
            e.printStackTrace();

            return null;
        } catch (JDOMException e) {
            System.err.println("Error reading config");
            e.printStackTrace();

            return null;
        }
    }

    /**
     * Read a saved configuration from a file
     */
    private boolean readConfig() throws IOException, JDOMException {
        String infile = PROPERTIES_FILE;
        if (!(new File(PROPERTIES_FILE)).exists()) {
            infile = System.getProperty("user.home");
            if (!infile.endsWith(File.separator))
                infile += File.separator;
            infile += PROPERTIES_FILE;
        }

        if (!new File(infile).exists())
            return false;

        FileReader in = new FileReader(infile);
        BufferedReader reader = new BufferedReader(in);
        Document doc;
        doc = new SAXBuilder().build(reader);
        reader.close();
        Element root = doc.getRootElement();

        Element child = root.getChild(DISCOVERY_SERVICE_CLASS_TAG);
        if (child == null)
            setDiscoveryServiceClass(DefaultConfig.DISCOVERY_SERVICE_CLASS);
        else
            setDiscoveryServiceClass(child.getText());

        child = root.getChild(PIPE_SERVICE_CLASS_TAG);
        if (child == null)
            setPipeServiceClass(DefaultConfig.PIPE_SERVICE_CLASS);
        else
            setPipeServiceClass(child.getText());

        child = root.getChild(RENDEZVOUS_SERVICE_CLASS_TAG);
        if (child == null)
            setRendezvousServiceClass(DefaultConfig.RENDEZVOUS_SERVICE_CLASS);
        else
            setRendezvousServiceClass(child.getText());

        child = root.getChild(ID_FACTORY_CLASS_TAG);
        if (child == null)
            setIDFactoryClass(DefaultConfig.ID_FACTORY_CLASS);
        else
            setIDFactoryClass(child.getText());

        child = root.getChild(ADVERT_INSTANTIATORS_TAG);
        if (child == null) {
            InstantiatorConfig[] configs = DefaultConfig.getDefaultAdvertInstantiatorConfigs();
            for (int count = 0; count < configs.length; count++)
                this.addAdvertInstantiatorConfig(configs[count]);
        } else {
            List children = child.getChildren();
            Iterator iterator = children.iterator();

            while (iterator.hasNext()) {
                this.addAdvertInstantiatorConfig(new InstantiatorConfigImp((Element) iterator.next()));
            }
        }

        child = root.getChild(ENDPOINT_ADDRESS_INSTANTIATORS_TAG);
        if (child == null) {
            InstantiatorConfig[] configs = DefaultConfig.getDefaultEndpointAddressInstantiatorConfigs();
            for (int count = 0; count < configs.length; count++)
                this.addEndpointAddressInstantiatorConfig(configs[count]);
        } else {
            List children = child.getChildren();
            Iterator iterator = children.iterator();

            while (iterator.hasNext()) {
                this.addEndpointAddressInstantiatorConfig(new InstantiatorConfigImp((Element) iterator.next()));
            }
        }

        EndpointAddressFactory endfactory = createEndpointAddressFactory(this);

        child = root.getChild(RENDEZVOUS_TAG);
        if (child != null)
            this.setRendezvousPeer(new Boolean(child.getText()).booleanValue());

        child = root.getChild(LOCAL_END_TAG);
        if (child != null) {
            List children = child.getChildren();
            Iterator iterator = children.iterator();
            while (iterator.hasNext()) {
                this.addLocalRendezvousEndpoint(endfactory.createEndpointAddress((Element) iterator.next()));
            }
        }

        child = root.getChild(REMOTE_END_TAG);
        if (child != null) {
            List children = child.getChildren();
            Iterator iterator = children.iterator();
            while (iterator.hasNext()) {
                this.addRemoteRendezvousEndpoint(endfactory.createEndpointAddress((Element) iterator.next()));
            }
        }

        List children = root.getChildren(ResolverConfig.RESOLVER_CONFIG_TAG);
        Iterator iterator = children.iterator();
        ResolverConfigImp resconfig;
        while (iterator.hasNext()) {
            resconfig = new ResolverConfigImp((Element) iterator.next());

            // handle legacy configs
            if (resconfig.getResolverProtocol() == null) {
                if (resconfig.getResolverClassName().indexOf("UDP") >= 0)
                    resconfig.setResolverProtocol("UDP");
                else
                    resconfig.setResolverProtocol("TCP");
            }

            this.setResolverConfigs(resconfig);
        }

        child = root.getChild(PORT_MIN_TAG);
        int min = Integer.parseInt(child.getText());
        child = root.getChild(PORT_MAX_TAG);
        int max = Integer.parseInt(child.getText());
        this.setPortRange(min, max);

        return true;
    }


    public static EndpointAddressFactory createEndpointAddressFactory(Config config) {
        EndpointAddressFactory endfactory = new EndpointAddressFactory();

        InstantiatorConfig[] instconfigs = config.getEndpointAddressInstantiatorConfigs();
        EndpointAddressInstantiator inst;
        Class instclass;

        for (int count = 0; count < instconfigs.length; count++) {
            try {
                instclass = Class.forName(instconfigs[count].getInstantiatorClass());

                inst = (EndpointAddressInstantiator) instclass.newInstance();
                endfactory.register(instconfigs[count].getInstantiatorType(), inst);
            } catch (ClassNotFoundException except) {
                System.err.println("Endpoint Address Instantiator Class Not Found: " + instconfigs[count].getInstantiatorClass());
                except.printStackTrace();
            } catch (InstantiationException except) {
                System.err.println("Cannot Instantiate Endpoint Address Instantiator: " + instconfigs[count].getInstantiatorClass());
                except.printStackTrace();
            } catch (IllegalAccessException except) {
                except.printStackTrace();
            }

        }

        return endfactory;
    }
}
