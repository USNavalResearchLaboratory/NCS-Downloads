package p2ps.imp.endpoint.TCP;

import p2ps.endpoint.*;
import p2ps.imp.endpoint.EndpointAddressImp;
import p2ps.peer.Peer;

import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;

/**
 * A class that sends and receives message bytes to/from a Datagram Socket. If
 * the message bytes exceed the packet size the message is split into multiple
 * packets.
 *
 * @author Ian Wang
 * @version $Revision: 1.7 $
 * @created 17th March 2003
 * @date $Date: 2004/07/02 13:01:04 $ modified by $Author: spxinw $
 * @todo
 */

public class TCPOutputSocket extends TCPSocket implements Endpoint, TCPEndpointTypes {

    /**
     * an advert for this endpoint
     */
    private EndpointAdvertisement advert;

    /**
     * an array list of input message listeners (applies to bidirectional only)
     */
    private ArrayList listeners = new ArrayList();


    /**
     * Creates a TCP output socket connected to the specified address
     */
    public TCPOutputSocket(String pipeid, String protocol, Peer peer) throws IOException {
        super();

        initAdvert(pipeid, protocol, peer);
    }

    /**
     * Initialises the advert for this socket
     */
    private void initAdvert(String pipeid, String protocol, Peer peer) throws IOException {
        String address = InetAddress.getLocalHost().getHostAddress() + ":" + getSocket().getLocalPort();

        advert = (EndpointAdvertisement) peer.getAdvertisementFactory().newAdvertisement(EndpointAdvertisement.ENDPOINT_ADVERTISEMENT_TYPE);
        advert.setPipeID(pipeid);
        advert.setEndpointAddress(peer.getEndpointAddressFactory().newEndpointAddress(protocol, address, TCP_UNICAST));
    }


    /**
     * Adds a listener to receive data from this socket
     */
    public void addEndpointMessageListener(EndpointMessageListener listener) {
        if (!listeners.contains(listener))
            listeners.add(listener);
    }

    /**
     * Removes a listener from this socket
     */
    public void removeEndpointMessageListener(EndpointMessageListener listener) {
        listeners.remove(listener);
    }


    /**
     * @return an EndpointAdvertisement for this endpoint
     */
    public EndpointAdvertisement getAdvertisement() {
        return advert;
    }

    /**
     * @return the transport protocol for this socket
     */
    public EndpointAddress getEndpointAddress() {
        return advert.getEndpointAddress();
    }


    /**
     * notifies the socket handler that it will handle  messaege for the
     * specified socket
     */
    public void handleSocket(TCPSocket socket) {
    }

    /**
     * handle the specified Data Message received on the specified socket
     */
    public void receiveMessage(DataMessage mess, TCPSocket socket) {
        EndpointMessageListener[] copy = (EndpointMessageListener[]) listeners.toArray(new EndpointMessageListener[listeners.size()]);
        DataMessageEvent event = new DataMessageEvent(this, socket, mess);

        for (int count = 0; count < copy.length; count++)
            copy[count].dataMessageReceived(event);
    }

}