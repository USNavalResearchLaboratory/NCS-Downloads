package p2ps.imp.pipe;

import org.jdom.Element;
import p2ps.pipe.PipeAdvertisement;
import p2ps.pipe.PipeTypes;

import java.io.IOException;

/**
 * An implementation of the Pipe Advertisement interface
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 18th March 2003
 * @date $Date: 2004/07/02 11:20:58 $ modified by $Author: spxinw $
 * @todo
 */

public class PipeAdvertisementImp implements PipeAdvertisement, PipeTypes {

    private String advertid;
    private String peerid;

    private String pipeid;
    private String pipename;
    private String pipetype = STANDARD;


    public PipeAdvertisementImp(String advertid, String peerid, String pipeid) {
        this.advertid = advertid;
        this.peerid = peerid;
        this.pipeid = pipeid;
    }

    public PipeAdvertisementImp(Element root) {
        Element elem = root.getChild(ADVERT_ID_TAG);
        if (elem != null)
            advertid = elem.getText();

        elem = root.getChild(PEER_ID_TAG);
        if (elem != null)
            peerid = elem.getText();

        elem = root.getChild(PIPE_ID_TAG);
        if (elem != null)
            pipeid = elem.getText();

        elem = root.getChild(PIPE_NAME_TAG);
        if (elem != null)
            pipename = elem.getText();

        elem = root.getChild(PIPE_TYPE_TAG);
        if (elem != null)
            pipetype = elem.getText();
    }


    /**
     * @return the type for this advertisement
     */
    public String getType() {
        return PIPE_ADVERTISEMENT_TYPE;
    }

    /**
     * @return the unique id for this advertisement
     */
    public String getAdvertID() {
        return advertid;
    }

    /**
     * @return the id of the peer that created this advertisement
     */
    public String getPeerID() {
        return peerid;
    }


    /**
     * @return the id of the pipe
     */
    public String getPipeID() {
        return pipeid;
    }


    /**
     * @return the name of the pipe
     */
    public String getPipeName() {
        return pipename;
    }

    /**
     * Sets the name of the pipe
     */
    public void setPipeName(String name) {
        pipename = name;
    }


    /**
     * @return the type of the pipe (e.g. STANDARD, BIDIRECTIONAL, MULTICAST)
     */
    public String getPipeType() {
        return pipetype;
    }

    /**
     * Sets the type of the pipe (e.g. STANDARD, BIDIRECTIONAL, MULTICAST)
     */
    public void setPipeType(String type) {
        this.pipetype = type;
    }


    /**
     * Output the advert as an xml document
     */
    public Element getXMLAdvert() throws IOException {
        Element root = new Element(PIPE_ADVERTISEMENT_TYPE);

        Element elem = new Element(ADVERT_ID_TAG);
        elem.addContent(advertid);
        root.addContent(elem);

        elem = new Element(PEER_ID_TAG);
        elem.addContent(peerid);
        root.addContent(elem);

        elem = new Element(PIPE_ID_TAG);
        elem.addContent(pipeid);
        root.addContent(elem);

        if (pipename != null) {
            elem = new Element(PIPE_NAME_TAG);
            elem.addContent(pipename);
            root.addContent(elem);
        }

        if (pipetype != null) {
            elem = new Element(PIPE_TYPE_TAG);
            elem.addContent(pipetype);
            root.addContent(elem);
        }

        return root;
    }

    /**
     * @return an XML element for the full enveloped advert (returns the same
     *         as getXMLAdvert if no envelope)
     */
    public Element getXMLEnvelope() throws IOException {
        return getXMLAdvert();
    }

}
