package p2ps.imp.pipe;

import p2ps.endpoint.DataMessageEvent;
import p2ps.endpoint.Endpoint;
import p2ps.endpoint.EndpointMessageListener;
import p2ps.pipe.*;

import java.io.IOException;
import java.util.ArrayList;

/**
 * A bidirectional pipe based on an underlying input pipe and output pipe
 *
 * @author Ian Wang
 * @version $Revision: 1.3 $
 * @created 4th July 2003
 * @date $Date: 2004/07/02 11:20:57 $ modified by $Author: spxinw $
 * @todo
 */
public class BidirectionalPipeImp implements BidirectionalPipe, EndpointMessageListener {

    /**
     * the id and name of this pipe
     */
    private String pipeid;
    private String pipename;

    /**
     * a list of the socket this pipe sends and receives from
     */
    private Endpoint[] endpoints;

    /**
     * a list of the message listeners attached to this pipe
     */
    private ArrayList listeners = new ArrayList();

    /**
     * a flag indicating whether this pipe is closed
     */
    private boolean closed = false;


    public BidirectionalPipeImp(PipeAdvertisement pipead, Endpoint[] endpoints) {
        pipeid = pipead.getPipeID();
        pipename = pipead.getPipeName();

        this.endpoints = new Endpoint[endpoints.length];

        for (int count = 0; count < endpoints.length; count++) {
            if ((!endpoints[count].isInputEndpoint()) || (!endpoints[count].isOutputEndpoint()))
                throw (new RuntimeException("Cannot create bidirectional pipe from non-bidirectional endpoints"));

            this.endpoints[count] = endpoints[count];
            this.endpoints[count].addEndpointMessageListener(this);
        }
    }


    /**
     * Adds a listener to be notified when messages are received
     */
    public void addPipeListener(MessageListener listener) {
        if (!listeners.contains(listener))
            listeners.add(listener);
    }

    /**
     * Removes a listener from being notified when messages are received
     */
    public void removePipeListener(MessageListener listener) {
        listeners.remove(listener);
    }


    /**
     * @return the id of the pipe
     */
    public String getPipeID() {
        return pipeid;
    }

    /**
     * @return the name of the pipe
     */
    public String getPipeName() {
        return pipename;
    }


    /**
     * @return an array of the socket for this pipe (open and closed)
     */
    public Endpoint[] getEndpoints() {
        return endpoints;
    }


    /**
     * Sends a message from the pipe
     */
    public void send(byte[] message) throws IOException {
        for (int count = 0; count < endpoints.length; count++)
            endpoints[count].send(message);
    }


    public void dataMessageReceived(DataMessageEvent event) {
        MessageReceivedEvent recevent = new MessageReceivedEvent(this, new ReplyPipe(this, event.getReplyEndpoint()), event.getDataMessage().getData());
        MessageListener[] copy = (MessageListener[]) listeners.toArray(new MessageListener[listeners.size()]);

        for (int count = 0; count < copy.length; count++)
            copy[count].messageReceived(recevent);
    }


    public void close() throws IOException {
        for (int count = 0; count < endpoints.length; count++) {
            endpoints[count].close();
            endpoints[count].removeEndpointMessageListener(this);
        }

        endpoints = null;
        closed = true;
    }

    /**
     * @return true if the pipe is closed (i.e. all its underlying socket are
     *         closed)
     */
    public boolean isClosed() {
        return closed;
    }


    private class ReplyPipe implements OutputPipe {

        private BidirectionalPipe parent;
        private Endpoint outpoint;

        public ReplyPipe(BidirectionalPipe parent, Endpoint outpoint) {
            this.parent = parent;
            this.outpoint = outpoint;
        }

        /**
         * @return the id of the pipe
         */
        public String getPipeID() {
            return parent.getPipeID();
        }

        /**
         * @return the name of the pipe
         */
        public String getPipeName() {
            return parent.getPipeName();
        }

        /**
         * Sends a message from the pipe
         */
        public void send(byte[] message) throws IOException {
            outpoint.send(message);
        }

        /**
         * Closes the pipe
         */
        public void close() throws IOException {
        }

        /**
         * @return true if the pipe is closed
         */
        public boolean isClosed() {
            return parent.isClosed();
        }

    }
}
