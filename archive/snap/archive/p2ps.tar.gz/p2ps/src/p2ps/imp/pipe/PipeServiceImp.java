package p2ps.imp.pipe;

import p2ps.endpoint.Endpoint;
import p2ps.endpoint.EndpointResolver;
import p2ps.peer.Peer;
import p2ps.pipe.*;

import java.io.IOException;
import java.util.ArrayList;

/**
 * The service for creating input pipes and connecting output pipes.
 *
 * @author Ian Wang
 * @version $Revision: 1.7 $
 * @created 18th March 2003
 * @date $Date: 2004/07/20 10:39:12 $ modified by $Author: spxmss $
 * @todo
 */

public class PipeServiceImp implements PipeService {

    /**
     * the main peer class
     */
    private Peer peer;

    /**
     * a list of the resolvers for this peer
     */
    private ArrayList resolvers = new ArrayList();

    /**
     * a cache of the discovered endpoint resolver adverts
     */
    private PipeConnectHandler connect;


    public PipeServiceImp(Peer peer) {
        this.peer = peer;
        this.connect = new PipeConnectHandler(peer);
    }


    /**
     * Initialises the pipe service
     */
    public void init() throws IOException {
        connect.init();
    }


    /**
     * Adds a pipe connection listener to the pipe service
     */
    public void addPipeConnectionListener(PipeConnectionListener listener) {
        connect.addPipeConnectionListener(listener);
    }

    /**
     * Removes a pipe connection listener from the pipe service
     */
    public void removePipeConnectionListener(PipeConnectionListener listener) {
        connect.removePipeConnectionListener(listener);
    }


    /**
     * Register a pipe resolver to create pipes for a particular protocol
     */
    public void register(EndpointResolver resolver) throws IOException {
        checkProtocolConflict(resolver);

        resolvers.add(resolver);

        if ((peer != null) && (peer.getDiscoveryService() != null))
            peer.getDiscoveryService().publish(resolver.getAdvertisement());
    }

    /**
     * Unregister the pipe resolver
     */
    public void unregister(EndpointResolver resolver) {
        resolvers.remove(resolver);
    }

    /**
     * Checks if there is the protocols of a newly registered resolver conflict
     * with those already registerd, and throws an exception if there is.
     */
    private void checkProtocolConflict(EndpointResolver resolver) throws IOException {
        String[] protocols = getEndpointProtocols();
        String[] newprotocols = resolver.getEndpointProtocols();

        for (int count1 = 0; count1 < newprotocols.length; count1++)
            for (int count2 = 0; count2 < protocols.length; count2++)
                if (newprotocols[count1].equals(protocols[count2]))
                    throw (new IOException("Error Registering Resolver: Resolver already registered for " + protocols[count2]));
    }


    /**
     * @return the endpoint protocols currently supported by the service
     */
    public String[] getEndpointProtocols() {
        EndpointResolver[] resolves = (EndpointResolver[]) resolvers.toArray(new EndpointResolver[resolvers.size()]);
        ArrayList protocollist = new ArrayList();
        String[] protocols;

        for (int rcount = 0; rcount < resolves.length; rcount++) {
            protocols = resolves[rcount].getEndpointProtocols();

            for (int pcount = 0; pcount < protocols.length; pcount++)
                if (!protocollist.contains(protocols[pcount]))
                    protocollist.add(protocols[pcount]);
        }

        return (String[]) protocollist.toArray(new String[protocollist.size()]);
    }


    /**
     * @return the registered pipe resolvers for this peer
     */
    public EndpointResolver[] getPipeResolvers() {
        return (EndpointResolver[]) resolvers.toArray(new EndpointResolver[resolvers.size()]);
    }

    /**
     * @return the registered pipe resolvers for thie specified pipe type
     */
    public EndpointResolver[] getPipeResolvers(String type) {
        EndpointResolver[] resolves = (EndpointResolver[]) resolvers.toArray(new EndpointResolver[resolvers.size()]);
        ArrayList typeres = new ArrayList();

        for (int count = 0; count < resolves.length; count++) {
            if (resolves[count].isInputPipesEnabled(type))
                typeres.add(resolves[count]);
        }

        return (EndpointResolver[]) typeres.toArray(new EndpointResolver[typeres.size()]);
    }

    /**
     * @return a pipe resolver for the specified protocol
     */
    public EndpointResolver getPipeResolver(String protocol) {
        EndpointResolver[] resolves = (EndpointResolver[]) resolvers.toArray(new EndpointResolver[resolvers.size()]);
        EndpointResolver resolver = null;
        String[] protocols;

        for (int rcount = 0; (resolver == null) && (rcount < resolves.length); rcount++) {
            protocols = resolves[rcount].getEndpointProtocols();

            for (int pcount = 0; (resolver == null) && (pcount < protocols.length); pcount++)
                if (protocols[pcount].equals(protocol))
                    resolver = resolves[rcount];
        }

        return resolver;
    }


    /**
     * Creates an input pipe using the specified advert
     */
    public InputPipe createInputPipe(PipeAdvertisement pipead) throws IOException {
        if (!pipead.getPeerID().equals(peer.getPeerID()))
            throw (new RuntimeException("Error creating input pipe: Invalid Peer ID"));

        Endpoint[] sockets = getSockets(pipead.getPipeID(), pipead.getPipeType());
        boolean bidirectional = true;

        for (int count = 0; (count < sockets.length) && bidirectional; count++)
            bidirectional = bidirectional && sockets[count].isOutputEndpoint();

        if (bidirectional)
            return new BidirectionalPipeImp(pipead, sockets);
        else
            return new InputPipeImp(pipead, sockets);
    }

    /**
     * Attempts to connect an output pipe to the pipe specified in the advert.
     * PipeConnectionListeners are notified when connection is achieved/fails.
     */
    public void connectOutputPipe(PipeAdvertisement pipead) throws IOException {
        connect.connectOutputPipe(pipead);
    }


    /**
     * @return an array of socket for an input pipe
     */
    private Endpoint[] getSockets(String pipeid, String type) throws IOException {
        EndpointResolver[] resolves = (EndpointResolver[]) resolvers.toArray(new EndpointResolver[resolvers.size()]);
        ArrayList sockets = new ArrayList();

        for (int count = 0; count < resolves.length; count++) {
            if (resolves[count].isInputPipesEnabled(type))
                sockets.add(resolves[count].createInputEndpoint(pipeid, type));
        }

        if (sockets.size() == 0)
            throw (new IOException("Pipe Service Error: No valid resolvers for " + type + " pipes."));

        return (Endpoint[]) sockets.toArray(new Endpoint[sockets.size()]);
    }

}
