package p2ps.imp.endpoint.TCP;

import p2ps.endpoint.DataMessage;

/**
 * An interface implemented by classes that handle the messages received by
 * TCP Sockets
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 11th May 2004
 * @date $Date: 2004/07/02 11:20:52 $ modified by $Author: spxinw $
 * @todo
 */

public interface SocketHandler {

    /**
     * notifies the socket handler that it will handle  messaege for the
     * specified socket
     */
    public void handleSocket(TCPSocket socket);

    /**
     * handle the specified Data Message received on the specified socket
     */
    public void receiveMessage(DataMessage mess, TCPSocket socket);

}
