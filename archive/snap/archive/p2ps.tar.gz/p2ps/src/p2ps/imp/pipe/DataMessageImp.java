/*
 * Copyright (c) 1995 onwards, University of Wales College of Cardiff
 *
 * Permission to use and modify this software and its documentation for
 * any purpose is hereby granted without fee provided a written agreement
 * exists between the recipients and the University.
 *
 * Further conditions of use are that (i) the above copyright notice and
 * this permission notice appear in all copies of the software and
 * related documentation, and (ii) the recipients of the software and
 * documentation undertake not to copy or redistribute the software and
 * documentation to any other party.
 *
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF WALES COLLEGE OF CARDIFF BE LIABLE
 * FOR ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
 * KIND, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON
 * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package p2ps.imp.pipe;

import p2ps.endpoint.DataMessage;

/**
 * A class for passing data between peers. In addition to the data, header
 * information concerning the message id, source id, routing information and
 * packet information is sent.
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 19th March 2002
 * @date $Date: 2004/07/02 11:20:57 $ modified by $Author: spxinw $
 * @todo
 */

public class DataMessageImp implements DataMessage {

    public static final int PACKET_SIZE = 50000;
    public static final int BASE_HEADER_SIZE = 20;

    private static final long BYTE_SIZE = (long) (Math.pow(2.0, 8) - 1);

    /**
     * the message data array
     */
    private byte[] messdata;

    /**
     * an byte array of the header infromation
     */
    private byte[] header = null;

    /**
     * the id of the message
     */
    private String messid;

    /**
     * the number of packets received
     */
    private int packreceived = 0;

    /**
     * the total number of packets in the message
     */
    private int packtotal = 0;


    /**
     * a counter used for generating message ids
     */
    private static int idcount = 0;

    /**
     * Construct a new message for sending data
     */
    public DataMessageImp(byte[] data) {
        this.messid = String.valueOf(idcount++);

        messdata = data;

        packreceived = packtotal;

        generateHeader();
    }

    /**
     * Reconstruct a message from received packets
     */
    public DataMessageImp() {
    }


    /**
     * Generates a header for the current field information
     */
    private void generateHeader() {
        byte[] messidbytes = messid.getBytes();

        header = new byte[BASE_HEADER_SIZE + 2 + messidbytes.length];
        packtotal = (messdata.length - 1) / (PACKET_SIZE - header.length) + 1;

        for (int count = 0; count < 4; count++)
            header[count] = 100;

        intIntoBytes(header.length, header, 4);
        intIntoBytes(packtotal, header, 12);
        intIntoBytes(messdata.length, header, 16);

        int ptr = BASE_HEADER_SIZE;
        shortIntoBytes(messidbytes.length, header, ptr);
        System.arraycopy(messidbytes, 0, header, ptr + 2, messidbytes.length);
    }

    /**
     * Turns the header bytes into field information
     */
    private void parseHeader() {
        packtotal = intFromBytes(header, 12);
        messdata = new byte[intFromBytes(header, 16)];

        int ptr = BASE_HEADER_SIZE;

        int messidlen = shortFromBytes(header, ptr);
        messid = new String(header, ptr + 2, messidlen);
    }


    /**
     * @return the data in this message (use isMessageComplete to check if the
     *         data has been fully received)
     */

    public byte[] getData() {
        return messdata;
    }


    /**
     * Add a received packet to the message, returns true if the packet was
     * valid and successfully added
     */
    public boolean addPacket(byte[] packet) {
        if (!isValid(packet))
            return false;

        if (header == null) {
            int headerlen = intFromBytes(packet, 4);
            header = new byte[headerlen];
            System.arraycopy(packet, 0, header, 0, headerlen);

            parseHeader();
        }

        int packindex = intFromBytes(packet, 8);
        int packlen = Math.min(PACKET_SIZE - header.length, messdata.length - ((PACKET_SIZE - header.length) * packindex));

        System.arraycopy(packet, header.length, messdata, (PACKET_SIZE - header.length) * packindex, packlen);
        packreceived++;

        return true;
    }

    /**
     * @return the message packet for the specified index
     */
    public byte[] getPacket(int index) {
        int maxdatalen = PACKET_SIZE - header.length;
        int datalen = Math.min(maxdatalen, messdata.length - (maxdatalen * index));

        byte[] packet = new byte[header.length + datalen];
        System.arraycopy(header, 0, packet, 0, header.length);
        System.arraycopy(messdata, maxdatalen * index, packet, header.length, datalen);

        intIntoBytes(index, packet, 8);

        return packet;
    }


    /**
     * @return the number of packets received so far
     */
    public int getPacketReceivedCount() {
        return packreceived;
    }

    /**
     * @return the totol number for packets in this message
     */
    public int getPacketCount() {
        return packtotal;
    }

    /**
     * @return true if the message has been fully received
     */
    public boolean isComplete() {
        return (packreceived >= packtotal);
    }


    /**
     * @return the id for this message
     */
    public String getMessageId() {
        return messid;
    }

    /**
     * @return true if the packet is a valid data message
     */
    public static boolean isValid(byte[] packet) {
        if (packet.length < BASE_HEADER_SIZE)
            return false;

        return (packet[0] == 100) && (packet[1] == 100) && (packet[2] == 100) && (packet[3] == 100);
    }

    /**
     * @return the message id for a packet (null if the packet is invalid)
     */
    public static String getMessageID(byte[] packet) {
        if (!isValid(packet))
            return null;

        try {
            int messidlen = shortFromBytes(packet, BASE_HEADER_SIZE);
            return new String(packet, BASE_HEADER_SIZE + 2, messidlen);
        } catch (StringIndexOutOfBoundsException except) {
            return null;
        }
    }


    /**
     * Stores the given int into the byte array at the given offset
     */
    static final void intIntoBytes(int val, byte[] bytes, int offset) {
        for (int ptr = 0; ptr <= 3; ptr++) {
            bytes[offset + ptr] = (byte) (val & BYTE_SIZE);
            val = val >> 8;
        }
    }

    /**
     * Converts the int bytes at the given offset into a int
     */
    static int intFromBytes(byte[] bytes, int offset) {
        return ((bytes[offset + 3] & 0xFF) << 24) |
                ((bytes[offset + 2] & 0xFF) << 16) |
                ((bytes[offset + 1] & 0xFF) << 8) |
                ((bytes[offset + 0] & 0xFF));
    }


    /**
     * Stores the given int into the byte array at the given offset
     */
    static final void shortIntoBytes(int val, byte[] bytes, int offset) {
        for (int ptr = 0; ptr <= 1; ptr++) {
            bytes[offset + ptr] = (byte) (val & BYTE_SIZE);
            val = val >> 8;
        }
    }

    /**
     * Converts the int bytes at the given offset into a int
     */
    static int shortFromBytes(byte[] bytes, int offset) {
        return ((bytes[offset + 1] & 0xFF) << 8) |
                ((bytes[offset + 0] & 0xFF));
    }

}

