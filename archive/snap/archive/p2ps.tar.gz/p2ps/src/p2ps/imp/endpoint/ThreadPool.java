/*
 * The University of Wales, Cardiff Triana Project Software License (Based
 * on the Apache Software License Version 1.1)
 *
 * Copyright (c) 2003 University of Wales, Cardiff. All rights reserved.
 *
 * Redistribution and use of the software in source and binary forms, with
 * or without modification, are permitted provided that the following
 * conditions are met:
 *
 * 1.  Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 * 2.  Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * 3. The end-user documentation included with the redistribution, if any,
 *    must include the following acknowledgment: "This product includes
 *    software developed by the University of Wales, Cardiff for the Triana
 *    Project (http://www.trianacode.org)." Alternately, this
 *    acknowledgment may appear in the software itself, if and wherever
 *    such third-party acknowledgments normally appear.
 *
 * 4. The names "Triana" and "University of Wales, Cardiff" must not be
 *    used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact triana@trianacode.org.
 *
 * 5. Products derived from this software may not be called "Triana," nor
 *    may Triana appear in their name, without prior written permission of
 *    the University of Wales, Cardiff.
 *
 * 6. This software may not be sold, used or incorporated into any product
 *    for sale to third parties.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 * NO EVENT SHALL UNIVERSITY OF WALES, CARDIFF OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Triana Project. For more information on the
 * Triana Project, please see. http://www.trianacode.org.
 *
 * This license is based on the BSD license as adopted by the Apache
 * Foundation and is governed by the laws of England and Wales.
 */

package p2ps.imp.endpoint;

import java.util.ArrayList;

/**
 * A utility thread pool.
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 29th July 2003
 * @date $Date: 2004/07/02 11:20:56 $ modified by $Author: spxinw $
 * @todo
 */

public class ThreadPool {

    public static int DEFAULT_MINIMUM_THREADS = 2;
    public static int DEFAULT_MAXIMUM_THREADS = 5;
    public static int DEFAULT_IDLE_TIME_MILLIS = 10000;


    private int min;
    private int max;
    private int idle;

    /**
     * a list of the idle threads awaiting jobs
     */
    private ArrayList threads = new ArrayList();

    /**
     * a list of the tasks awaiting threads
     */
    private ArrayList tasks = new ArrayList();

    /**
     * the name given to this thread pool and its threads
     */
    private String name;

    /**
     * a count of the total number of threads
     */
    private int threadcount = 0;

    /**
     * a count used to uniquely identify each thread
     */
    private int idcount = 0;


    /**
     * Constructs a thread pool with default min and max threads and idle time
     */
    public ThreadPool(String name) {
        this(name, DEFAULT_MINIMUM_THREADS, DEFAULT_MAXIMUM_THREADS, DEFAULT_IDLE_TIME_MILLIS);
    }

    /**
     * Constructs a thread pool with specified min and max threads and idle time
     *
     * @param name the name of the thread pool
     * @param min  the minimum number of threads that is maintained by the pool
     * @param max  the maximum number of threads that is maintained by the pool
     * @param idle the time a thread is idle before it is disposed
     */
    public ThreadPool(String name, int min, int max, int idle) {
        if (max == 0)
            throw(new RuntimeException("Thread Pool Error: Maximum threads must be > 0"));

        if (max < min)
            throw(new RuntimeException("Thread Pool Error: Maximum threads must be > Minimum threads"));

        this.name = name;
        this.min = min;
        this.max = max;
        this.idle = idle;
    }


    public void addTask(Runnable task) {
        synchronized (tasks) {
            tasks.add(task);
        }
        wakeThread();
    }

    /**
     * Wakes a idle thread, or creates a new thread if the maximum has not been
     * reached
     */
    private void wakeThread() {
        if (!threads.isEmpty())
            ((Thread) threads.get(0)).interrupt();
        else if (threadcount < max) {
            threadcount++;
            newThread();
        }
    }

    /**
     * Constructs and starts a new pool thread
     */
    private void newThread() {
        new PoolThread().start();
    }

    /**
     * @return the next task in the queue (which is also removed from the queue)
     */
    private Runnable getNextTask() {
        synchronized (tasks) {
            if (tasks.isEmpty())
                return null;
            else {
                Runnable task = (Runnable) tasks.get(0);
                tasks.remove(task);
                return task;
            }
        }
    }

    /**
     * Adds a thread to the idle thread list
     */
    private void addIdleThread(Thread thread) {
        if (!threads.contains(thread))
            threads.add(0, thread);
    }

    /**
     * Removes a thread from the idle thread list
     */
    private void removeIdleThread(Thread thread) {
        threads.remove(thread);
    }

    /**
     * @return a count of the number of idle threads
     */
    private int getIdleThreadCount() {
        return threads.size();
    }


    /**
     * Notifies the pool when a thread finishes running
     */
    private void threadFinished() {
        threadcount--;
    }

    public void dispose() {
        PoolThread[] thds = (PoolThread[]) threads.toArray(new PoolThread[threads.size()]);

        for (int count = 0; count < thds.length; count++)
            thds[count].stopThread();

        threads.clear();
        tasks.clear();

        threads = null;
        tasks = null;
    }


    private class PoolThread extends Thread {

        private boolean stopped = false;
        private boolean idlethread = false;


        public PoolThread() {
            setName(name + "_" + ++idcount);
        }


        public void stopThread() {
            stopped = true;
            interrupt();
        }

        public void run() {
            Runnable task;

            while ((!stopped) || (getIdleThreadCount() < min)) {
                stopped = false;
                task = getNextTask();

                if (task != null) {
                    if (idlethread) {
                        idlethread = false;
                        removeIdleThread(this);
                    }

                    task.run();
                } else {
                    if (!idlethread) {
                        idlethread = true;
                        addIdleThread(this);
                    }

                    try {
                        sleep(idle);

                        idlethread = false;
                        removeIdleThread(this);
                        stopped = true;
                    } catch (InterruptedException except) {
                    }
                }
            }

            threadFinished();
        }

    }

}