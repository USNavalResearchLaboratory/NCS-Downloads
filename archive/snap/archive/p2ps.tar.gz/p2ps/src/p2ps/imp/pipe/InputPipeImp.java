package p2ps.imp.pipe;

import org.apache.log4j.Logger;
import p2ps.endpoint.DataMessageEvent;
import p2ps.endpoint.Endpoint;
import p2ps.endpoint.EndpointMessageListener;
import p2ps.pipe.InputPipe;
import p2ps.pipe.MessageListener;
import p2ps.pipe.MessageReceivedEvent;
import p2ps.pipe.PipeAdvertisement;

import java.io.IOException;
import java.util.ArrayList;

/**
 * The implementation of a pipe for broadcasting and receiving discovery
 * adverts
 *
 * @author Ian Wang
 * @version $Revision: 1.6 $
 * @created 24th March 2003
 * @date $Date: 2004/07/02 11:20:58 $ modified by $Author: spxinw $
 * @todo
 */

public class InputPipeImp implements InputPipe, EndpointMessageListener {

    static Logger logger = Logger.getLogger(InputPipeImp.class);

    /**
     * the id and name of this pipe
     */
    private String pipeid;
    private String pipename;

    /**
     * a list of the socket this pipe sends and receives from
     */
    private ArrayList sockets = new ArrayList();

    /**
     * a list of the message listeners attached to this pipe
     */
    private ArrayList listeners = new ArrayList();

    /**
     * a flag indicating whether this pipe is closed
     */
    private boolean closed = false;


    public InputPipeImp(PipeAdvertisement pipead, Endpoint[] sockets) {
        logger.info("entering");
        pipeid = pipead.getPipeID();
        pipename = pipead.getPipeName();

        for (int count = 0; count < sockets.length; count++) {
            this.sockets.add(sockets[count]);
            sockets[count].addEndpointMessageListener(this);
        }
        logger.info("exiting");
    }


    /**
     * Adds a listener to be notified when messages are received
     */
    public void addPipeListener(MessageListener listener) {
        logger.info("entering");
        if (!listeners.contains(listener))
            listeners.add(listener);
        logger.info("exiting");
    }

    /**
     * Removes a listener from being notified when messages are received
     */
    public void removePipeListener(MessageListener listener) {
        listeners.remove(listener);
    }


    /**
     * @return the id of the pipe
     */
    public String getPipeID() {
        return pipeid;
    }

    /**
     * @return the name of the pipe
     */
    public String getPipeName() {
        return pipename;
    }


    /**
     * @return an array of the socket for this pipe (open and closed)
     */
    public Endpoint[] getSockets() {
        return (Endpoint[]) sockets.toArray(new Endpoint[sockets.size()]);
    }


    public void dataMessageReceived(DataMessageEvent event) {
        logger.info("entering");
        MessageReceivedEvent recevent = new MessageReceivedEvent(this, event.getDataMessage().getData());
        MessageListener[] copy = (MessageListener[]) listeners.toArray(new MessageListener[listeners.size()]);

        for (int count = 0; count < copy.length; count++)
            copy[count].messageReceived(recevent);
        logger.info("exiting");
    }


    public void close() throws IOException {
        logger.info("entering");
        Endpoint[] endpoints = (Endpoint[]) sockets.toArray(new Endpoint[sockets.size()]);

        for (int count = 0; count < endpoints.length; count++) {
            endpoints[count].close();
            endpoints[count].removeEndpointMessageListener(this);
        }

        sockets.clear();
        closed = true;
        logger.info("exiting");
    }

    /**
     * @return true if the pipe is closed (i.e. all its underlying socket are
     *         closed)
     */
    public boolean isClosed() {
        return closed;
    }

}
