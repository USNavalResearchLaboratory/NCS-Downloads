/*
 * The University of Wales, Cardiff Triana Project Software License (Based
 * on the Apache Software License Version 1.1)
 *
 * Copyright (c) 2003 University of Wales, Cardiff. All rights reserved.
 *
 * Redistribution and use of the software in source and binary forms, with
 * or without modification, are permitted provided that the following
 * conditions are met:
 *
 * 1.  Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 * 2.  Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * 3. The end-user documentation included with the redistribution, if any,
 *    must include the following acknowledgment: "This product includes
 *    software developed by the University of Wales, Cardiff for the Triana
 *    Project (http://www.trianacode.org)." Alternately, this
 *    acknowledgment may appear in the software itself, if and wherever
 *    such third-party acknowledgments normally appear.
 *
 * 4. The names "Triana" and "University of Wales, Cardiff" must not be
 *    used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact triana@trianacode.org.
 *
 * 5. Products derived from this software may not be called "Triana," nor
 *    may Triana appear in their name, without prior written permission of
 *    the University of Wales, Cardiff.
 *
 * 6. This software may not be sold, used or incorporated into any product
 *    for sale to third parties.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 * NO EVENT SHALL UNIVERSITY OF WALES, CARDIFF OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Triana Project. For more information on the
 * Triana Project, please see. http://www.trianacode.org.
 *
 * This license is based on the BSD license as adopted by the Apache
 * Foundation and is governed by the laws of England and Wales.
 */

package p2ps.imp.rendezvous;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;
import p2ps.discovery.Advertisement;
import p2ps.discovery.DiscoveryServiceInterface;
import p2ps.discovery.Query;
import p2ps.endpoint.*;
import p2ps.imp.discovery.AdvertisementUtils;
import p2ps.imp.discovery.DiscoveryCache;
import p2ps.imp.pipe.BidirectionalPipeImp;
import p2ps.peer.IDFactory;
import p2ps.peer.Peer;
import p2ps.pipe.*;
import p2ps.rendezvous.RendezvousAdvertisement;
import p2ps.rendezvous.RendezvousService;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.util.ArrayList;


/**
 * An rendezvous service either acts without a discovery service, or sits
 * on top of a discovery service.
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 7th July 2003
 * @date $Date: 2004/07/16 17:21:15 $ modified by $Author: spxinw $
 * @todo
 */

public abstract class AbstractRendezvousService implements RendezvousService,
        MessageListener, EndpointMessageListener {

    protected Peer peer;


    /**
     * the discovery pipe used to receive adverts/queries
     */
    protected DiscoveryServiceInterface disc;

    /**
     * the addresses of the input endpoints for this service
     */
    private EndpointAddress[] localaddresses;

    /**
     * the rendezvous endpoints that advertisements are recevived on
     */
    protected Endpoint[] inpoints = new Endpoint[0];

    /**
     * the addresses of the remote endpoints this service is connected to
     */
    private ArrayList remoteaddresses = new ArrayList();

    /**
     * the rendezvous endpoints that advertisements are sent on
     */
    protected ArrayList outpoints = new ArrayList();

    /**
     * the cache of queries/queries
     */
    protected DiscoveryCache cache = new DiscoveryCache();

    /**
     * the rendezvous advert for this rendezvous service
     */
    private RendezvousAdvertisement advert;

    /**
     * the SAX XML builder
     */
    private SAXBuilder xmlbuilder = new SAXBuilder();


    public AbstractRendezvousService(Peer peer) {
        this.peer = peer;
    }

    /**
     * Initialises the rendezvous service
     */
    public void init(EndpointAddress[] addresses) throws IOException {
        this.localaddresses = addresses;
        this.inpoints = new Endpoint[addresses.length];

        if (peer.getDiscoveryService() instanceof DiscoveryServiceInterface)
            this.disc = (DiscoveryServiceInterface) peer.getDiscoveryService();
        else
            this.disc = new DummyDiscoveryService();

        this.disc.addDiscoveryPipeListener(this);

        for (int count = 0; count < localaddresses.length; count++) {
            try {
                inpoints[count] = createInputEndpoint(localaddresses[count]);
                inpoints[count].addEndpointMessageListener(this);
            } catch (IOException except) {
                except.printStackTrace();
            }
        }

        advert = (RendezvousAdvertisement) peer.getAdvertisementFactory().newAdvertisement(RendezvousAdvertisement.RENDEZVOUS_ADVERTISEMENT_TYPE);
        advert.setEndpointAddresses(localaddresses);

        peer.getDiscoveryService().publish(advert);
    }


    /**
     * @return an input endpoint for the specified address
     */
    private Endpoint createInputEndpoint(EndpointAddress addr) throws IOException {
        if (addr != null) {
            EndpointResolver resolver = peer.getPipeService().getPipeResolver(addr.getProtocol());

            if ((resolver != null) && (resolver.isInputPipesEnabled(addr.getEndpointType())))
                return resolver.createInputEndpoint(IDFactory.newPipeID(), addr);
        }

        throw(new IOException("Rendezvous Error: No resolver for input endpoint " + addr));
    }

    /**
     * Connects this rendezvous service to a remote rendezvous endpoint
     */
    public void connectToRendezvous(EndpointAddress addr) throws IOException {
        EndpointResolver resolver = peer.getPipeService().getPipeResolver(addr.getProtocol());
        boolean outputPipesEnabled = resolver.isOutputPipesEnabled(addr.getEndpointType());

        if ((resolver != null) && outputPipesEnabled) {
            try {
                Endpoint outpoint = resolver.connectOutputEndpoint(IDFactory.newPipeID(), addr);

                remoteaddresses.add(addr);
                outpoints.add(outpoint);

                sendRendezvousAdvert(outpoint);
                sendQueries(outpoint);
            } catch (ConnectException except) {
                System.err.println("Cannot connect to rendezvous: " + addr);
            }
        } else
            new IOException("Rendezvous Error: No resolver for output endpoint " + addr).printStackTrace();
    }

    /**
     * Sends an advert for this rendezvous service to the specified endpoint
     */
    private void sendRendezvousAdvert(Endpoint endpoint) throws IOException {
        endpoint.send(advertToByteArray(advert.getXMLEnvelope()));
    }

    /**
     * Sends an advert for this rendezvous service to the specified endpoint
     */
    private void sendQueries(Endpoint endpoint) throws IOException {
        Query[] queries = cache.getQueries();

        for (int count = 0; count < queries.length; count++)
            endpoint.send(advertToByteArray(queries[count].getXMLEnvelope()));
    }

    /**
     * @return the advert as a byte array
     */
    protected byte[] advertToByteArray(Element advert) throws IOException {
        XMLOutputter xmlout = new XMLOutputter("    ", true);
        ByteArrayOutputStream outstream = new ByteArrayOutputStream();
        xmlout.output(new Document(advert), outstream);

        return outstream.toByteArray();
    }


    /**
     * @return the endpoint addresses of this rendezvous service
     */
    public EndpointAddress[] getLocalRendezvousAddresses() throws IOException {
        return localaddresses;
    }

    /**
     * @return the remote endpoint addresses this rendezvous service is
     *         connected to
     */
    public EndpointAddress[] getRemoteRendezvousAddresses() throws IOException {
        return (EndpointAddress[]) remoteaddresses.toArray(new EndpointAddress[remoteaddresses.size()]);
    }


    /**
     * Forwards the advert to all known rendezvous peers
     */
    protected void forward(Advertisement advert) throws IOException {
        byte[] mess = advertToByteArray(advert.getXMLEnvelope());

        for (int count = 0; count < outpoints.size(); count++)
            ((Endpoint) outpoints.get(count)).send(mess);
    }


    /**
     * Handles a received advert for a non-rendezvous peer
     */
    protected void handleAdvert(Advertisement advert) throws IOException {
        Advertisement matches[];

        boolean newad = !cache.contains(advert.getAdvertID());
        cache.add(advert);

        if (newad) {
            if (advert instanceof RendezvousAdvertisement)
                handleRendezvousAdvert((RendezvousAdvertisement) advert);

            // find any matching queries/adverts
            if (cache.isQuery(advert) && newad) {
                matches = cache.getAdvertisements((Query) advert);

                handleMatch(matches, (Query) advert);

                forward(advert);
            } else if (!cache.isQuery(advert)) {
                matches = cache.getQueries(advert);

                for (int count = 0; count < matches.length; count++)
                    handleMatch(new Advertisement[] {advert}, (Query) matches[count]);
            }
        }
    }

    /**
     * Called when a match between adverts and a query is found. Implementations
     * of this method are responsible replying to the query with the discovered
     * advert.
     */
    protected abstract void handleMatch(Advertisement[] adverts, Query query) throws IOException;


    /**
     * Handles a rendezvous advert by connecting to that service and forwarding
     * all known queries
     */
    private void handleRendezvousAdvert(RendezvousAdvertisement advert) throws IOException {
        EndpointAddress[] addresses = advert.getEndpointAddresses();

        for (int count = 0; count < addresses.length; count++) {
            if ((!isLocalEndpoint(addresses[count])) && (!remoteaddresses.contains(addresses[count])))
                connectToRendezvous(addresses[count]);
        }
    }

    private boolean isLocalEndpoint(EndpointAddress address) {
        for (int count = 0; count < localaddresses.length; count++)
            if (localaddresses[count].equals(address))
                return true;

        return false;
    }


    private void handleData(byte[] data) {
        try {
            Document xmlDoc = xmlbuilder.build(new ByteArrayInputStream(data));

            if (AdvertisementUtils.isXMLEnvelope(xmlDoc.getRootElement())) {
                Advertisement advert = peer.getAdvertisementFactory().createAdvertisement(xmlDoc.getRootElement());
                handleAdvert(advert);
            }
        } catch (IOException except) {
            throw (new RuntimeException("Rendezvous error: " + except.getMessage(), except));
        } catch (JDOMException except) {
            throw (new RuntimeException("Rendezvous error: " + except.getMessage(), except));
        }
    }

    /**
     * Called when the endpoint receives a data message
     */
    public void dataMessageReceived(DataMessageEvent event) {
        handleData(event.getDataMessage().getData());
    }

    /**
     * Called when a message is received by the pipe
     */
    public void messageReceived(MessageReceivedEvent event) {
        handleData(event.getMessage());
    }


    /**
     * A dummy discovery services interface that is not actually linked to
     * the actual discovery service.
     */
    private class DummyDiscoveryService implements DiscoveryServiceInterface {

        public static final String DUMMY_DISCOVERY_SERVICE = "DummyDiscoveryService";

        private BidirectionalPipe discpipe;


        public DummyDiscoveryService() throws IOException {
            discpipe = createDiscoveryPipe();
        }


        /**
         * Creates the bidirectional discovery pipe
         */
        private BidirectionalPipe createDiscoveryPipe() throws IOException {
            PipeAdvertisement discad = (PipeAdvertisement) peer.getAdvertisementFactory().newAdvertisement(PipeAdvertisement.PIPE_ADVERTISEMENT_TYPE);
            discad.setPipeName(DUMMY_DISCOVERY_SERVICE);
            discad.setPipeType(PipeTypes.DISCOVERY);

            if (peer.getPipeService().getPipeResolvers(PipeTypes.DISCOVERY).length == 0)
                return new BidirectionalPipeImp(discad, new Endpoint[0]);
            else {
                InputPipe pipe = peer.getPipeService().createInputPipe(discad);

                if (pipe instanceof BidirectionalPipe)
                    return (BidirectionalPipe) pipe;
                else
                    throw(new IOException("Error: Discovery pipe not bidirectional"));
            }
        }


        /**
         * Adds the specified message listener to the discovery pipe
         *
         * @param listener
         */
        public void addDiscoveryPipeListener(MessageListener listener) {
            discpipe.addPipeListener(listener);
        }

        /**
         * Removes the specified message listener from the discovery pipe
         *
         * @param listener
         */
        public void removeDiscoveryPipeListener(MessageListener listener) {
            discpipe.removePipeListener(listener);
        }

        /**
         * Sends the specified advert via the discovery pipe
         */
        public void send(Advertisement advert) throws IOException {
            discpipe.send(advertToByteArray(advert));

        }

        /**
         * @return the advert as a byte array
         */
        protected byte[] advertToByteArray(Advertisement advert) throws IOException {
            XMLOutputter xmlout = new XMLOutputter("    ", true);
            ByteArrayOutputStream outstream = new ByteArrayOutputStream();
            xmlout.output(new Document(advert.getXMLEnvelope()), outstream);

            return outstream.toByteArray();
        }

    }

}
