/*
 * The University of Wales, Cardiff Triana Project Software License (Based
 * on the Apache Software License Version 1.1)
 *
 * Copyright (c) 2003 University of Wales, Cardiff. All rights reserved.
 *
 * Redistribution and use of the software in source and binary forms, with
 * or without modification, are permitted provided that the following
 * conditions are met:
 *
 * 1.  Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 * 2.  Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * 3. The end-user documentation included with the redistribution, if any,
 *    must include the following acknowledgment: "This product includes
 *    software developed by the University of Wales, Cardiff for the Triana
 *    Project (http://www.trianacode.org)." Alternately, this
 *    acknowledgment may appear in the software itself, if and wherever
 *    such third-party acknowledgments normally appear.
 *
 * 4. The names "Triana" and "University of Wales, Cardiff" must not be
 *    used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact triana@trianacode.org.
 *
 * 5. Products derived from this software may not be called "Triana," nor
 *    may Triana appear in their name, without prior written permission of
 *    the University of Wales, Cardiff.
 *
 * 6. This software may not be sold, used or incorporated into any product
 *    for sale to third parties.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 * NO EVENT SHALL UNIVERSITY OF WALES, CARDIFF OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Triana Project. For more information on the
 * Triana Project, please see. http://www.trianacode.org.
 *
 * This license is based on the BSD license as adopted by the Apache
 * Foundation and is governed by the laws of England and Wales.
 */

package p2ps.imp.peer.config;

import p2ps.endpoint.EndpointAddress;
import p2ps.endpoint.EndpointAddressFactory;
import p2ps.imp.endpoint.TCP.TCPResolver;
import p2ps.imp.endpoint.UDP.UDPResolver;
import p2ps.peer.Config;
import p2ps.peer.ResolverConfig;
import p2ps.pipe.PipeTypes;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.IOException;
import java.net.InetAddress;
import java.util.Enumeration;

/**
 * The default config window for a P2PS peer.
 *
 * @author Ian Wang
 * @version $Revision: 1.9 $
 * @created 7th July 2003
 * @date $Date: 2004/07/02 11:20:56 $ modified by $Author: spxinw $
 * @todo
 */

public class ConfigWindow extends JDialog implements ActionListener, ItemListener {

    public static String DEFAULT_RENDEZVOUS_PORT = "2222";
    public static String DEFAULT_RENDEZVOUS_ENDPOINT = DEFAULT_RENDEZVOUS_PORT + ":" + TCPResolver.DEFAULT_RENDEZVOUS_SOCKET_ID;
    public static String DEFAULT_RENDEZVOUS_PROTOCOL = TCPResolver.TCP_PROTOCOL;
    public static String DEFAULT_RENDEZVOUS_ENDPOINT_TYPE = TCPResolver.TCP_UNICAST;

    public static String[] PROTOCOLS = {TCPResolver.TCP_PROTOCOL, UDPResolver.UDP_PROTOCOL};
    public static String[] ENDPOINT_TYPES = {TCPResolver.TCP_UNICAST, UDPResolver.UDP_UNICAST};

    private Config initconfig;

    private JCheckBox udpmulticast = new JCheckBox("Enable UDP Multicast Discovery");
    private JCheckBox rendezvous = new JCheckBox("Enable as Rendezvous Peer");

    private JList portlist = new JList(new DefaultListModel());
    private JLabel portlabel = new JLabel("Local Rendezvous Ports");
    private JButton portadd = new JButton("Add");
    private JButton portremove = new JButton("Remove");

    private JList rendezvouslist = new JList(new DefaultListModel());
    private JLabel rendezvouslabel = new JLabel("Rendezvous Addresses");
    private JButton rendezvousadd = new JButton("Add");
    private JButton rendezvousremove = new JButton("Remove");

    private JCheckBox tcpinput = new JCheckBox("Enable TCP Input Pipes");
    private JCheckBox tcpoutput = new JCheckBox("Enable TCP Output Pipes");
    private JCheckBox udpinput = new JCheckBox("Enable UDP Input Pipes");
    private JCheckBox udpoutput = new JCheckBox("Enable UDP Output Pipes");
    private JCheckBox disableother = new JCheckBox("Disable Other Pipe Types");

    private JTextField minport = new JTextField(5);
    private JTextField maxport = new JTextField(5);

    private JButton restoredefault = new JButton("Restore Defaults");
    private JButton ok = new JButton("OK");

    public ConfigWindow(Config config) {
        super((Frame) null, "Peer Configuration", true);

        initLayout();
        setConfiguration(config);
        pack();

        Dimension screen = getToolkit().getScreenSize();
        Dimension size = getSize();
        setLocation((screen.width / 2) - (size.width / 2), (screen.height / 2) - (size.height / 2));

        show();
    }

    /**
     * Initialises the window layout
     */
    private void initLayout() {
        Container main = getContentPane();
        main.setLayout(new BorderLayout());

        JPanel discoverypanel = getDiscoveryPanel();
        JPanel pipespanel = getPipesPanel();

        JTabbedPane tabpanel = new JTabbedPane();
        tabpanel.setBorder(new javax.swing.border.EmptyBorder(3, 3, 3, 3));
        tabpanel.setName("Peer Configuration");
        tabpanel.setAutoscrolls(true);
        tabpanel.addTab("Pipes", null, pipespanel, "Set Pipe Service Configuration");
        tabpanel.addTab("Discovery", null, discoverypanel, "Set Discovery/Rendezvous Service Configuration");

        main.add(tabpanel, BorderLayout.CENTER);

        JPanel buttonpanel = new JPanel(new BorderLayout());
        JPanel buttonpanel2 = new JPanel();
        buttonpanel2.add(ok);
        buttonpanel.add(buttonpanel2, BorderLayout.EAST);
        ok.addActionListener(this);

        main.add(buttonpanel, BorderLayout.SOUTH);
    }

    /**
     * @return the panel for setting the discovery service configuration
     */
    private JPanel getDiscoveryPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel checkpanel = new JPanel(new GridLayout(2, 1));
        checkpanel.add(udpmulticast);
        checkpanel.add(rendezvous);
        rendezvous.addItemListener(this);

        panel.add(checkpanel, BorderLayout.NORTH);

        JPanel subpanel = new JPanel(new BorderLayout());
        subpanel.add(getLocalRendezvousPortPanel(), BorderLayout.NORTH);
        subpanel.add(getRendezvousAddressPanel(), BorderLayout.CENTER);

        panel.add(subpanel, BorderLayout.CENTER);
        return panel;
    }

    private JPanel getLocalRendezvousPortPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        panel.add(portlabel, BorderLayout.NORTH);

        JPanel buttonpanel = new JPanel(new GridLayout(2, 1));
        buttonpanel.add(portadd);
        buttonpanel.add(portremove);
        portadd.addActionListener(this);
        portremove.addActionListener(this);
        portadd.setMargin(new Insets(2, 2, 2, 2));
        portremove.setMargin(new Insets(2, 2, 2, 2));

        JPanel buttoncont = new JPanel(new BorderLayout());
        buttoncont.add(buttonpanel, BorderLayout.SOUTH);
        panel.add(buttoncont, BorderLayout.EAST);

        JScrollPane scroll = new JScrollPane(portlist, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        portlist.setPrototypeCellValue("12345678901234567890123456789012345");
        portlist.setVisibleRowCount(3);
        panel.add(scroll, BorderLayout.CENTER);

        portlabel.setEnabled(rendezvous.isSelected());
        portlist.setEnabled(rendezvous.isSelected());
        portadd.setEnabled(rendezvous.isSelected());
        portremove.setEnabled(rendezvous.isSelected());

        return panel;
    }

    private JPanel getRendezvousAddressPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(rendezvouslabel, BorderLayout.NORTH);

        JPanel buttonpanel = new JPanel(new GridLayout(2, 1));
        buttonpanel.add(rendezvousadd);
        buttonpanel.add(rendezvousremove);
        rendezvousadd.addActionListener(this);
        rendezvousremove.addActionListener(this);
        rendezvousadd.setMargin(new Insets(2, 2, 2, 2));
        rendezvousremove.setMargin(new Insets(2, 2, 2, 2));

        JPanel buttoncont = new JPanel(new BorderLayout());
        buttoncont.add(buttonpanel, BorderLayout.SOUTH);
        panel.add(buttoncont, BorderLayout.EAST);

        JScrollPane scroll = new JScrollPane(rendezvouslist, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        rendezvouslist.setPrototypeCellValue("12345678901234567890123456789012345");
        rendezvouslist.setVisibleRowCount(5);
        panel.add(scroll, BorderLayout.CENTER);

        rendezvouslabel.setEnabled(rendezvous.isSelected());
        rendezvouslist.setEnabled(rendezvous.isSelected());
        rendezvousadd.setEnabled(rendezvous.isSelected());
        rendezvousremove.setEnabled(rendezvous.isSelected());

        return panel;
    }

    /**
     * @return the panel for setting the discovery service configuration
     */
    private JPanel getPipesPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel checkpanel = new JPanel(new GridLayout(5, 1));
        checkpanel.add(tcpinput);
        checkpanel.add(tcpoutput);
        checkpanel.add(udpinput);
        checkpanel.add(udpoutput);
        checkpanel.add(disableother);

        JPanel rangepanel = new JPanel();
        rangepanel.add(new JLabel("Port Range:"), BorderLayout.NORTH);
        rangepanel.add(minport);
        rangepanel.add(new JLabel("to"));
        rangepanel.add(maxport);

        JPanel portpanel = new JPanel(new BorderLayout());
        portpanel.add(rangepanel, BorderLayout.WEST);

        JPanel portcont = new JPanel(new BorderLayout());
        portcont.add(portpanel, BorderLayout.NORTH);

        JPanel buttonpanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonpanel.add(restoredefault);
        restoredefault.addActionListener(this);

        panel.add(checkpanel, BorderLayout.NORTH);
        panel.add(portcont, BorderLayout.CENTER);
        panel.add(buttonpanel, BorderLayout.SOUTH);

        return panel;
    }



    /**
     * @return an address item for the default local rendezvous port
     */
    private AddressItem getDefaultLocalRendezvousPort() {
        try {
            return new AddressItem(InetAddress.getLocalHost().getHostAddress() + ":" + DEFAULT_RENDEZVOUS_ENDPOINT, DEFAULT_RENDEZVOUS_PROTOCOL, DEFAULT_RENDEZVOUS_ENDPOINT_TYPE);
        } catch (IOException except) {
            except.printStackTrace();
            return new AddressItem("InetAddress Error", "", "");
        }
    }


    /**
     * Sets the configuration in the window
     */
    public void setConfiguration(Config config) {
        this.initconfig = config;

        rendezvous.setSelected(config.isRendezvousPeer());

        EndpointAddress[] addrs = config.getLocalRendezvousEndpoints();
        DefaultListModel model = (DefaultListModel) portlist.getModel();
        model.removeAllElements();
        for (int count = 0; count < addrs.length; count++)
            model.addElement(new AddressItem(addrs[count]));

        if (addrs.length == 0)
            ((DefaultListModel) portlist.getModel()).addElement(getDefaultLocalRendezvousPort());

        addrs = config.getRemoteRendezvousEndpoints();
        model = (DefaultListModel) rendezvouslist.getModel();
        model.removeAllElements();
        for (int count = 0; count < addrs.length; count++)
            model.addElement(new AddressItem(addrs[count]));


        ResolverConfig tcpconfig = config.getResolverConfig("TCP");
        if (tcpconfig != null) {
            tcpinput.setSelected(tcpconfig.isInputPipesEnabled(PipeTypes.STANDARD));
            tcpoutput.setSelected(tcpconfig.isOutputPipesEnabled(PipeTypes.STANDARD));
        }

        ResolverConfig udpconfig = config.getResolverConfig("UDP");
        if (udpconfig != null) {
            udpinput.setSelected(udpconfig.isInputPipesEnabled(PipeTypes.STANDARD));
            udpoutput.setSelected(udpconfig.isOutputPipesEnabled(PipeTypes.STANDARD));
            udpmulticast.setSelected(udpconfig.isInputPipesEnabled(PipeTypes.DISCOVERY) && udpconfig.isOutputPipesEnabled(PipeTypes.DISCOVERY));
        }

        minport.setText(String.valueOf(config.getMinPort()));
        maxport.setText(String.valueOf(config.getMaxPort()));
    }


    /**
     * @return the config generated using this window
     */
    public Config getConfiguration() {
        ConfigImp config = new ConfigImp(initconfig);

        EndpointAddressFactory endfactory = ConfigImp.createEndpointAddressFactory(config);

        config.setRendezvousPeer(rendezvous.isSelected());
        config.clearLocalRendezvousEndpoints();
        config.clearRemoteRendezvousEndpoints();

        if (rendezvous.isSelected()) {
            Enumeration enum = ((DefaultListModel) portlist.getModel()).elements();

            while (enum.hasMoreElements()) {
                try {
                    config.addLocalRendezvousEndpoint(((AddressItem) enum.nextElement()).getEndpointAddress(endfactory));
                } catch (IOException except) {
                    except.printStackTrace();
                }
            }

            enum = ((DefaultListModel) rendezvouslist.getModel()).elements();

            while (enum.hasMoreElements()) {
                try {
                    config.addRemoteRendezvousEndpoint(((AddressItem) enum.nextElement()).getEndpointAddress(endfactory));
                } catch (IOException except) {
                    except.printStackTrace();
                }
            }
        }

        if (disableother.isSelected()) {
            ResolverConfig[] configs = config.getResolverConfigs();
            String[] entypes;

            for (int count = 0; count < configs.length; count++) {
                entypes = configs[count].getEnabledInputTypes();
                for (int count2 = 0; count2 < entypes.length; count2++)
                    configs[count].setInputPipesEnabled(entypes[count2], false);

                entypes = configs[count].getEnabledOutputTypes();
                for (int count2 = 0; count2 < entypes.length; count2++)
                    configs[count].setOutputPipesEnabled(entypes[count2], false);

                config.setResolverConfigs(configs[count]);
            }
        }

        ResolverConfig udpconfig = config.getResolverConfig("UDP");
        ResolverConfig tcpconfig = config.getResolverConfig("TCP");

        if (udpconfig == null)
            udpconfig = new ResolverConfigImp("p2ps.imp.endpoint.UDP.UDPResolver", "UDP");

        if (tcpconfig == null)
            tcpconfig = new ResolverConfigImp("p2ps.imp.endpoint.TCP.TCPResolver", "TCP");

        udpconfig.setInputPipesEnabled(PipeTypes.STANDARD, udpinput.isSelected());
        udpconfig.setOutputPipesEnabled(PipeTypes.STANDARD, udpoutput.isSelected());
        udpconfig.setInputPipesEnabled(PipeTypes.DISCOVERY, udpmulticast.isSelected());
        udpconfig.setOutputPipesEnabled(PipeTypes.DISCOVERY, udpmulticast.isSelected());
        config.setResolverConfigs(udpconfig);

        tcpconfig.setInputPipesEnabled(PipeTypes.STANDARD, tcpinput.isSelected());
        tcpconfig.setOutputPipesEnabled(PipeTypes.STANDARD, tcpoutput.isSelected());
        config.setResolverConfigs(tcpconfig);

        try {
            int min = Integer.parseInt(minport.getText());
            int max = Integer.parseInt(maxport.getText());

            config.setPortRange(min, max);
        } catch (NumberFormatException except) {
            new Exception("Port Range Invalid: Using range " + Config.DEFAULT_MIN_PORT + " to " + Config.DEFAULT_MAX_PORT);
        }

        return config;
    }


    /**
     * Adds a rendezvous address
     */
    private void addLocalRendezvousPort() {
        AddPortDialog dialog = new AddPortDialog(this);

        if (dialog.isAccepted())
            ((DefaultListModel) portlist.getModel()).addElement(new AddressItem(dialog.getAddress(), dialog.getProtocol(), getEndpointType(dialog.getProtocol())));
    }

    /**
     * Removes a rendezvous address
     */
    private void removeLocalRendezvousPort() {
        Object[] selected = portlist.getSelectedValues();

        for (int count = 0; count < selected.length; count++)
            ((DefaultListModel) portlist.getModel()).removeElement(selected[count]);
    }

    /**
     * Adds a rendezvous address
     */
    private void addRendezvousAddress() {
        AddRendezvousDialog dialog = new AddRendezvousDialog(this);

        if (dialog.isAccepted())
            ((DefaultListModel) rendezvouslist.getModel()).addElement(new AddressItem(dialog.getAddress(), dialog.getProtocol(), getEndpointType(dialog.getProtocol())));
    }

    /**
     * @return the endpoint type for the specified protocol
     */
    private String getEndpointType(String protocol) {
        String type = null;

        for (int count = 0; (count < PROTOCOLS.length) && (type == null); count++)
            if (PROTOCOLS[count].equals(protocol))
                type = ENDPOINT_TYPES[count];

        return type;
    }

    /**
     * Removes a rendezvous address
     */
    private void removeRendezvousAddress() {
        Object[] selected = rendezvouslist.getSelectedValues();

        for (int count = 0; count < selected.length; count++)
            ((DefaultListModel) rendezvouslist.getModel()).removeElement(selected[count]);
    }


    public void actionPerformed(ActionEvent event) {
        if (event.getSource() == ok) {
            setVisible(false);
        } else if (event.getSource() == portadd) {
            addLocalRendezvousPort();
        } else if (event.getSource() == portremove) {
            removeLocalRendezvousPort();
        } else if (event.getSource() == rendezvousadd) {
            addRendezvousAddress();
        } else if (event.getSource() == rendezvousremove) {
            removeRendezvousAddress();
        } else if (event.getSource() == restoredefault) {
            setConfiguration(new DefaultConfig());
        }
    }

    public void itemStateChanged(ItemEvent event) {
        portlabel.setEnabled(rendezvous.isSelected());
        portlist.setEnabled(rendezvous.isSelected());
        portadd.setEnabled(rendezvous.isSelected());
        portremove.setEnabled(rendezvous.isSelected());

        rendezvouslabel.setEnabled(rendezvous.isSelected());
        rendezvouslist.setEnabled(rendezvous.isSelected());
        rendezvousadd.setEnabled(rendezvous.isSelected());
        rendezvousremove.setEnabled(rendezvous.isSelected());
    }

    private class AddressItem {

        private String address;
        private String protocol;
        private String type;
        private EndpointAddress addr;


        public AddressItem(String address, String protocol, String type) {
            this.address = address;
            this.protocol = protocol;
            this.type = type;
        }

        public AddressItem(EndpointAddress addr) {
            this.addr = addr;

            this.address = addr.getAddress();
            this.protocol = addr.getProtocol();
            this.type = addr.getEndpointType();
        }


        public String getAddress() {
            return address;
        }

        public String getProtocol() {
            return protocol;
        }


        public EndpointAddress getEndpointAddress(EndpointAddressFactory factory) throws IOException {
            if (addr == null)
                return factory.newEndpointAddress(protocol, address, type);
            else
                return addr;
        }


        public String toString() {
            if (protocol.equals(TCPResolver.TCP_PROTOCOL))
                return address.substring(0, address.lastIndexOf(':')) + " [" + protocol + "]";
            else
                return address + " [" + protocol + "]";
        }

    }

    private class AddPortDialog extends JDialog implements ActionListener {

        private JTextField port = new JTextField(6);
        private JComboBox protocol = new JComboBox(new DefaultComboBoxModel());

        private JButton ok = new JButton("OK");
        private JButton cancel = new JButton("Cancel");

        private boolean accepted = false;

        public AddPortDialog(JDialog parent) {
            super(parent, "Add Local Rendezvous Port", true);

            initLayout();

            setLocation(parent.getLocation().x + 100, parent.getLocation().y + 100);
            pack();
            show();
        }

        private void initLayout() {
            Container main = getContentPane();
            main.setLayout(new BorderLayout());

            JPanel panel = new JPanel(new BorderLayout());
            panel.setBorder(new EmptyBorder(3, 3, 3, 3));
            main.add(panel, BorderLayout.CENTER);


            JPanel formpanel = new JPanel(new FormLayout(1, 1));

            JPanel subpanel = new JPanel(new BorderLayout());
            subpanel.add(port, BorderLayout.WEST);
            formpanel.add(new Label("Port"));
            formpanel.add(subpanel);

            subpanel = new JPanel(new BorderLayout());
            subpanel.add(protocol, BorderLayout.WEST);
            formpanel.add(new Label("Protocol"));
            formpanel.add(subpanel);

            for (int count = 0; count < PROTOCOLS.length; count++)
                ((DefaultComboBoxModel) protocol.getModel()).addElement(PROTOCOLS[count]);

            protocol.getModel().setSelectedItem(PROTOCOLS[0]);

            JPanel buttonpanel = new JPanel();
            buttonpanel.add(ok);
            buttonpanel.add(cancel);
            ok.addActionListener(this);
            cancel.addActionListener(this);

            JPanel buttoncont = new JPanel(new BorderLayout());
            buttoncont.add(buttonpanel, BorderLayout.EAST);

            panel.add(formpanel, BorderLayout.CENTER);
            panel.add(buttoncont, BorderLayout.SOUTH);
        }


        public boolean isAccepted() {
            return accepted;
        }

        public String getAddress() {
            try {
                if (protocol.getSelectedItem().equals(TCPResolver.TCP_PROTOCOL))
                    return InetAddress.getLocalHost().getHostAddress() + ":" + port.getText() + ":" + TCPResolver.DEFAULT_RENDEZVOUS_SOCKET_ID;
                else
                    return InetAddress.getLocalHost().getHostAddress() + ":" + port.getText();
            } catch (IOException except) {
                except.printStackTrace();
                return "InetAddress Error";
            }
        }

        public String getProtocol() {
            return (String) protocol.getSelectedItem();
        }


        public void actionPerformed(ActionEvent event) {
            if (event.getSource() == ok) {
                accepted = true;
                hide();
            } else {
                accepted = false;
                hide();
            }
        }
    }

    private class AddRendezvousDialog extends JDialog implements ActionListener {

        private JTextField address = new JTextField(15);
        private JTextField port = new JTextField(6);
        private JComboBox protocol = new JComboBox(new DefaultComboBoxModel());

        private JButton ok = new JButton("OK");
        private JButton cancel = new JButton("Cancel");

        private boolean accepted = false;

        public AddRendezvousDialog(JDialog parent) {
            super(parent, "Add Rendezvous Address", true);

            initLayout();

            setLocation(parent.getLocation().x + 100, parent.getLocation().y + 100);
            pack();
            show();
        }

        private void initLayout() {
            Container main = getContentPane();
            main.setLayout(new BorderLayout());

            JPanel panel = new JPanel(new BorderLayout());
            panel.setBorder(new EmptyBorder(3, 3, 3, 3));
            main.add(panel, BorderLayout.CENTER);

            JPanel formpanel = new JPanel(new FormLayout(1, 1));

            JPanel subpanel = new JPanel(new BorderLayout());
            subpanel.add(address, BorderLayout.WEST);
            formpanel.add(new Label("Address"));
            formpanel.add(subpanel);

            subpanel = new JPanel(new BorderLayout());
            subpanel.add(port, BorderLayout.WEST);
            formpanel.add(new Label("Port"));
            formpanel.add(subpanel);
            port.setText(String.valueOf(DEFAULT_RENDEZVOUS_PORT));

            subpanel = new JPanel(new BorderLayout());
            subpanel.add(protocol, BorderLayout.WEST);
            formpanel.add(new Label("Protocol"));
            formpanel.add(subpanel);

            for (int count = 0; count < PROTOCOLS.length; count++)
                ((DefaultComboBoxModel) protocol.getModel()).addElement(PROTOCOLS[count]);

            protocol.getModel().setSelectedItem(PROTOCOLS[0]);

            JPanel buttonpanel = new JPanel();
            buttonpanel.add(ok);
            buttonpanel.add(cancel);
            ok.addActionListener(this);
            cancel.addActionListener(this);

            JPanel buttoncont = new JPanel(new BorderLayout());
            buttoncont.add(buttonpanel, BorderLayout.EAST);

            panel.add(formpanel, BorderLayout.CENTER);
            panel.add(buttoncont, BorderLayout.SOUTH);
        }


        public boolean isAccepted() {
            return accepted;
        }

        public String getAddress() {
            if (protocol.getSelectedItem().equals(TCPResolver.TCP_PROTOCOL))
                return address.getText() + ":" + port.getText() + ":" + TCPResolver.DEFAULT_RENDEZVOUS_SOCKET_ID;
            else
                return address.getText() + ":" + port.getText();
        }

        public String getProtocol() {
            return (String) protocol.getSelectedItem();
        }


        public void actionPerformed(ActionEvent event) {
            if (event.getSource() == ok) {
                accepted = true;
                hide();
            } else {
                accepted = false;
                hide();
            }
        }
    }

}
