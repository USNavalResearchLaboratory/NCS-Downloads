package p2ps.imp.endpoint;

import org.apache.log4j.Logger;
import org.jdom.Element;
import p2ps.endpoint.EndpointAddress;
import p2ps.endpoint.EndpointAdvertisement;
import p2ps.endpoint.EndpointAddressFactory;

import java.io.IOException;
import java.util.List;

/**
 * An advertisement for a pipe endpoint
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 20th March 2003
 * @date $Date: 2004/07/02 11:20:54 $ modified by $Author: spxinw $
 * @todo
 */
public class EndpointAdvertisementImp implements EndpointAdvertisement {

    static Logger logger = Logger.getLogger(EndpointAdvertisementImp.class);

    /**
     * the id of the advert
     */
    private String advertid;

    /**
     * the id of the resolver peer
     */
    private String peerid;

    /**
     * the id of the pipe
     */
    private String pipeid;

    /**
     * the endpoint address for the pipe
     */
    private EndpointAddress address;


    /**
     * Construct a failed pipe resolution event
     */
    public EndpointAdvertisementImp(String peerid, String adverid) {
        logger.info("entering");
        this.peerid = peerid;
        this.advertid = adverid;
        logger.info("exiting");
    }


    public EndpointAdvertisementImp(Element root, EndpointAddressFactory endfactory) throws IOException {
        logger.info("entering");
        Element elem = root.getChild(ADVERT_ID_TAG);
        if (elem != null)
            advertid = elem.getText();

        elem = root.getChild(PEER_ID_TAG);
        if (elem != null)
            peerid = elem.getText();

        elem = root.getChild(PIPE_ID_TAG);
        if (elem != null)
            pipeid = elem.getText();

        elem = root.getChild(ENDPOINT_ADDRESS_TAG);
        if (elem != null) {
            List list = elem.getChildren();
            if (list.size() > 0)
                address = endfactory.createEndpointAddress((Element) list.get(0));
        }

        logger.info("exiting");
    }


    /**
     * @return the type for this advertisement
     */
    public String getType() {
        return ENDPOINT_ADVERTISEMENT_TYPE;
    }

    /**
     * @return the unique id for this advertisement
     */
    public String getAdvertID() {
        return advertid;
    }

    /**
     * @return the id of the peer that created this advertisement
     */
    public String getPeerID() {
        return peerid;
    }


    /**
     * @return the address of the endpoint
     */
    public EndpointAddress getEndpointAddress() {
        return address;
    }

    /**
     * Sets the address of the endpoint
     */
    public void setEndpointAddress(EndpointAddress address) {
        this.address = address;
    }


    /**
     * @return the id of the pipe
     */
    public String getPipeID() {
        return pipeid;
    }

    /**
     * Sets the id of the pipe
     */
    public void setPipeID(String pipeid) {
        this.pipeid = pipeid;
    }


    /**
     * Output the advert as an XML document
     */
    public Element getXMLAdvert() throws IOException {
        logger.info("entering");
        Element root = new Element(ENDPOINT_ADVERTISEMENT_TYPE);

        Element elem = new Element(ADVERT_ID_TAG);
        elem.addContent(advertid);
        root.addContent(elem);

        elem = new Element(PEER_ID_TAG);
        elem.addContent(peerid);
        root.addContent(elem);

        elem = new Element(PIPE_ID_TAG);
        elem.addContent(pipeid);
        root.addContent(elem);

        elem = new Element(PROTOCOL_TAG);
        elem.addContent(address.getProtocol());
        root.addContent(elem);

        elem = new Element(ENDPOINT_ADDRESS_TAG);
        elem.addContent(address.getXMLElement());
        root.addContent(elem);

        return root;
    }

    /**
     * @return an XML element for the full enveloped advert (returns the same
     *         as getXMLAdvert if no envelope)
     */
    public Element getXMLEnvelope() throws IOException {
        return getXMLAdvert();
    }

}
