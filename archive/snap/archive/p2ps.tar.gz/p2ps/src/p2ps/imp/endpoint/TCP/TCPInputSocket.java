/*
 * The University of Wales, Cardiff Triana Project Software License (Based
 * on the Apache Software License Version 1.1)
 *
 * Copyright (c) 2003 University of Wales, Cardiff. All rights reserved.
 *
 * Redistribution and use of the software in source and binary forms, with
 * or without modification, are permitted provided that the following
 * conditions are met:
 *
 * 1.  Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 * 2.  Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * 3. The end-user documentation included with the redistribution, if any,
 *    must include the following acknowledgment: "This product includes
 *    software developed by the University of Wales, Cardiff for the Triana
 *    Project (http://www.trianacode.org)." Alternately, this
 *    acknowledgment may appear in the software itself, if and wherever
 *    such third-party acknowledgments normally appear.
 *
 * 4. The names "Triana" and "University of Wales, Cardiff" must not be
 *    used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact triana@trianacode.org.
 *
 * 5. Products derived from this software may not be called "Triana," nor
 *    may Triana appear in their name, without prior written permission of
 *    the University of Wales, Cardiff.
 *
 * 6. This software may not be sold, used or incorporated into any product
 *    for sale to third parties.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 * NO EVENT SHALL UNIVERSITY OF WALES, CARDIFF OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Triana Project. For more information on the
 * Triana Project, please see. http://www.trianacode.org.
 *
 * This license is based on the BSD license as adopted by the Apache
 * Foundation and is governed by the laws of England and Wales.
 */

package p2ps.imp.endpoint.TCP;

import p2ps.endpoint.*;
import p2ps.imp.endpoint.EndpointAddressImp;
import p2ps.peer.Peer;

import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;

/**
 * A class that acts as a wrapper for multiple TCP input socket.
 *
 * @author Ian Wang
 * @version $Revision: 1.8 $
 * @created 24th June 2003
 * @date $Date: 2004/07/02 13:01:04 $ modified by $Author: spxinw $
 * @todo
 */

public class TCPInputSocket implements SocketHandler, Endpoint, TCPEndpointTypes {

    public static int RECEIVE_BUFFER_SIZE = 32000;


    /**
     * the socket handler for this input socket (either the default socket
     * handler or a custom one attached to a specified port)
     */
    private TCPInputHandler sockethandler;

    /**
     * an advert for this endpoint
     */
    private EndpointAdvertisement advert;

    /**
     * a list of the TCPSockets this input socket handles
     */
    private ArrayList sockets = new ArrayList();

    /**
     * a hashtable of lists of listeners for each pipe, keyed by pipeid
     */
    private ArrayList listeners = new ArrayList();

    /**
     * the unique address of the input socket
     */
    private String address;

    /**
     * the unique id of this input socket
     */
    private String id;

    /**
     * a counter used to give unique addresses to each input socket
     */
    private static int idcount = 0;

    /**
     * a flag indicating whether the socket is closed
     */
    private boolean closed = false;

    /**
     * Creates a standard UDP socket for an available port
     */
    public TCPInputSocket(String pipeid, String protocol, Peer peer) throws IOException {
        id = String.valueOf(idcount++);

        sockethandler = TCPInputHandler.getDefaultTCPSocketHandler();
        sockethandler.registerMessageHandler(id, this);

        initAdvert(pipeid, protocol, peer);
    }


    /**
     * Creates a standard UDP socket for the specified port
     */
    public TCPInputSocket(EndpointAddress address, String pipeid, String protocol, Peer peer) throws IOException {
        id = TCPResolver.getSocketID(address);
        int port = TCPResolver.getPort(address);

        sockethandler = TCPInputHandler.getTCPSocketHandler(port);
        sockethandler.registerMessageHandler(id, this);

        initAdvert(pipeid, protocol, peer);
    }


    /**
     * Initialises the advert for this socket
     */
    private void initAdvert(String pipeid, String protocol, Peer peer) throws IOException {
        address = InetAddress.getLocalHost().getHostAddress() + ":" + sockethandler.getPort() + ":" + id;

        advert = (EndpointAdvertisement) peer.getAdvertisementFactory().newAdvertisement(EndpointAdvertisement.ENDPOINT_ADVERTISEMENT_TYPE);
        advert.setPipeID(pipeid);
        advert.setEndpointAddress(peer.getEndpointAddressFactory().newEndpointAddress(protocol, address, TCP_UNICAST));
    }


    /**
     * @return the id of this socket
     */
    public String getSocketID() {
        return id;
    }


    /**
     * Adds a data message listener to the specified pipe
     */
    public void addEndpointMessageListener(EndpointMessageListener listener) {
        if (!listeners.contains(listener))
            listeners.add(listener);
    }

    /**
     * Removes the specified data message listener from the pipe
     */
    public void removeEndpointMessageListener(EndpointMessageListener listener) {
        listeners.remove(listener);
    }

    /**
     * @return an array of the listeners to this socket
     */
    EndpointMessageListener[] getEndpointMessageListeners() {
        return (EndpointMessageListener[]) listeners.toArray(new EndpointMessageListener[listeners.size()]);
    }


    /**
     * @return the transport protocol for this socket
     */
    public EndpointAddress getEndpointAddress() {
        return advert.getEndpointAddress();
    }

    /**
     * @return an EndpointAdvertisement for this endpoint
     */
    public EndpointAdvertisement getAdvertisement() {
        return advert;
    }


    /**
     * @return true if this endpoint is input enabled
     */
    public boolean isInputEndpoint() {
        return true;
    }

    /**
     * @return true if this endpoint is output enabled
     */
    public boolean isOutputEndpoint() {
        return true;
    }


    /**
     * Send a message from the socket
     */
    public void send(byte[] message) throws IOException {
        TCPSocket[] socks = (TCPSocket[]) sockets.toArray(new TCPSocket[sockets.size()]);

        for (int count = 0; count < socks.length; count++)
            socks[count].send(message);
    }

    /**
     * Sends a message from the socket to the specified address
     */
    public void send(byte[] message, EndpointAddress address) throws IOException {
        TCPSocket[] socks = (TCPSocket[]) sockets.toArray(new TCPSocket[sockets.size()]);

        for (int count = 0; count < socks.length; count++)
            socks[count].send(message);
    }


    /**
     * notifies the socket handler that it will handle  messaege for the
     * specified socket
     */
    public void handleSocket(TCPSocket socket) {
        if (!sockets.contains(socket))
            sockets.add(socket);
    }

    /**
     * handle the specified Data Message received on the specified socket
     */
    public void receiveMessage(DataMessage mess, TCPSocket socket) {
        EndpointMessageListener[] copy = (EndpointMessageListener[]) listeners.toArray(new EndpointMessageListener[listeners.size()]);
        DataMessageEvent event = new DataMessageEvent(this, socket, mess);

        for (int count = 0; count < copy.length; count++)
            copy[count].dataMessageReceived(event);
    }


    /**
     * Closes the socket
     */
    public void close() throws IOException {
        TCPSocket[] socks = (TCPSocket[]) sockets.toArray(new TCPSocket[sockets.size()]);

        for (int count = 0; count < socks.length; count++) {
            socks[count].close();
            socks[count] = null;
        }

        closed = true;
    }

    /**
     * @return true is the socket is closed
     */
    public boolean isClosed() {
        return closed;
    }

}

