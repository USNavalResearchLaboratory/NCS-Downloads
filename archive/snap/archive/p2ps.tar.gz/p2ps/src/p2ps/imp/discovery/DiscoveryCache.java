package p2ps.imp.discovery;

import p2ps.discovery.Advertisement;
import p2ps.discovery.Query;

import java.util.*;
import java.io.IOException;

import org.jdom.Element;

/**
 * A cache of advertisements and queries. Methods are provided to query the
 * cached advertisements and queries.
 *
 * @author      Ian Wang
 * @created     21st March 2003
 * @version     $Revision: 1.5 $
 * @date        $Date: 2004/07/16 17:21:14 $ modified by $Author: spxinw $
 * @todo
 */
public class DiscoveryCache {

    /**
     * a hashtable of the cached queries keyed by query-id
     */
    private Hashtable queries = new Hashtable();

    /**
     * a hashtable of the cached adverts keyed by advert-id
     */
    private Hashtable adverts = new Hashtable();


    /**
     * @return true if the specified advert is a query
     */
    public boolean isQuery(Advertisement advert) {
        return (advert instanceof Query);
    }


    /**
     * Adds an advertisement/query to the cache
     */
    public void add(Advertisement advert) {
        adverts.put(advert.getAdvertID(), advert);

        if (isQuery(advert))
            queries.put(advert.getAdvertID(), advert);
        else
            queries.remove(advert.getAdvertID());
    }

    /**
     * Removes an advertisement/query from the cache
     */
    public void remove(String advertid) {
        adverts.remove(advertid);
        queries.remove(advertid);
    }

    /**
     * @return the advertisement/query with the specified id
     */
    public Advertisement get(String advertid) {
        if (adverts.containsKey(advertid))
            return (Advertisement) adverts.get(advertid);
        else
            return null;
    }

    /**
     * @return true if the cache contains an advert with the specified id
     */
    public boolean contains(String advertid) {
        return adverts.containsKey(advertid);
    }


    /**
     * @return an array of the all advertisement ids (including queries) in the
     *  cahce
     */
    public Advertisement[] getAdvertisementIds() {
        return (Advertisement[]) adverts.keySet().toArray(new Advertisement[adverts.keySet().size()]);
    }

    /**
     * @return an array of the all advertisements (including queries) in the cache
     */
    public Advertisement[] getAdvertisements() {
        return (Advertisement[]) adverts.values().toArray(new Advertisement[adverts.values().size()]);
    }

    /**
     * @return the number of advertisements in the cache
     */
    public int getAdvertisementCount() {
        return adverts.size();
    }


    /**
     * @return an array of the query ids in the cache
     */
    public Query[] getQueryIds() {
        return (Query[]) queries.keySet().toArray(new Query[queries.keySet().size()]);
    }

    /**
     * @return an array of the queries in the cache
     */
    public Query[] getQueries() {
        return (Query[]) queries.values().toArray(new Query[queries.values().size()]);
    }

    /**
     * @return an array of the advertisements that match the specified query
     */
    public Advertisement[] getAdvertisements(Query query) {
        Enumeration enum = adverts.elements();
        ArrayList match = new ArrayList();
        p2ps.discovery.Advertisement advert;

        while (enum.hasMoreElements()) {
            advert = (p2ps.discovery.Advertisement) enum.nextElement();

            if (isMatch(query, advert))
                match.add(advert);
        }

        return (p2ps.discovery.Advertisement[]) match.toArray(new p2ps.discovery.Advertisement[match.size()]);
    }

    /**
     * @return an array of the queries that would match the specified
     * advertisement
     */
    public Query[] getQueries(Advertisement advert) {
        Enumeration enum = queries.elements();
        ArrayList match = new ArrayList();
        Query query;

        while (enum.hasMoreElements()) {
            query = (Query) enum.nextElement();

            if (isMatch(query, advert))
                match.add(query);
        }

        return (Query[]) match.toArray(new Query[match.size()]);
    }

    /**
     * @return the number of queries in the cache
     */
    public int getQueryCount() {
        return queries.size();
    }


    /**
     * @return true if the advert matches the query according to the P2PS
     * query naming conventions.
     */
    public static boolean isMatch(Query query, Advertisement advert) {
        if (!isTypeMatch(query, advert))
            return false;

        try {
            List children = query.getXMLAdvert().getChildren();
            Element advertxml = advert.getXMLAdvert();
            ArrayList matches = new ArrayList();
            ArrayList failures = new ArrayList();

            for (Iterator iter = children.iterator(); iter.hasNext();) {
                Element elem = (Element) iter.next();
                String elemname = elem.getName();

                if (elemname.startsWith("query") && (elemname.length() != 5)) {
                    boolean match = isElementMatch(elem, advertxml);

                    if (match) {
                        matches.add(elem.getName());
                        failures.remove(elem.getName());
                    } else if ((!matches.contains(elem.getName())) && (!failures.contains(elem.getName())))
                        failures.add(elem.getName());
                }
            }            

            return failures.isEmpty();
        } catch (IOException except) {
            return false;
        }
    }

    /**
     * @return true if the query type matches the advert type
     */
    private static boolean isTypeMatch(Query query, Advertisement advert) {
        return query.getQueryType().equals(advert.getType());
    }

    /**
     * @return true if there is a match for the specified query element in the
     * specified advert XML.
     */
    private static boolean isElementMatch(Element elem, Element advertxml) {
        String name = elem.getName().substring(5);
        //name = Character.toLowerCase(name.charAt(0)) + name.substring(1);
        List children = advertxml.getChildren();
        for (Iterator iter = children.iterator(); iter.hasNext();) {
            Element child = (Element) iter.next();

            if (child.getName().equalsIgnoreCase(name) && child.getText().equals(elem.getText()))
                return true;
        }

        return false;
    }

}
