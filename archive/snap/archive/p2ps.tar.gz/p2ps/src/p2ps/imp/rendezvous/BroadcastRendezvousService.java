package p2ps.imp.rendezvous;

import p2ps.discovery.Advertisement;
import p2ps.discovery.Query;
import p2ps.endpoint.EndpointAddress;
import p2ps.peer.Peer;

import java.io.IOException;

/**
 * A rendezvous service implementation that broadcast matching queries using
 * its discovery pipe. It is then up to the peers that created the advertisement
 * originally to reply directly to the query.
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 30th June 2004
 * @date $Date: 2004/07/16 17:21:15 $ modified by $Author: spxinw $
 * @todo
 */

public class BroadcastRendezvousService extends AbstractRendezvousService {

    public BroadcastRendezvousService(Peer peer) {
        super(peer);
    }

    /**
     * Called when a match between an advert and a query is found. Implementations
     * of this method are responsible replying to the query with the discovered
     * advert.
     */
    protected void handleMatch(Advertisement[] adverts, Query query) throws IOException {
        for (int count = 0; count < adverts.length; count++) 
            disc.send(adverts[count]);
    }

}
