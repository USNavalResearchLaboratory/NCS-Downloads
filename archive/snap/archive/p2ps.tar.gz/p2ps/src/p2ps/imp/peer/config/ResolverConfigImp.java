/*
 * The University of Wales, Cardiff Triana Project Software License (Based
 * on the Apache Software License Version 1.1)
 *
 * Copyright (c) 2003 University of Wales, Cardiff. All rights reserved.
 *
 * Redistribution and use of the software in source and binary forms, with
 * or without modification, are permitted provided that the following
 * conditions are met:
 *
 * 1.  Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 * 2.  Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * 3. The end-user documentation included with the redistribution, if any,
 *    must include the following acknowledgment: "This product includes
 *    software developed by the University of Wales, Cardiff for the Triana
 *    Project (http://www.trianacode.org)." Alternately, this
 *    acknowledgment may appear in the software itself, if and wherever
 *    such third-party acknowledgments normally appear.
 *
 * 4. The names "Triana" and "University of Wales, Cardiff" must not be
 *    used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact triana@trianacode.org.
 *
 * 5. Products derived from this software may not be called "Triana," nor
 *    may Triana appear in their name, without prior written permission of
 *    the University of Wales, Cardiff.
 *
 * 6. This software may not be sold, used or incorporated into any product
 *    for sale to third parties.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 * NO EVENT SHALL UNIVERSITY OF WALES, CARDIFF OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Triana Project. For more information on the
 * Triana Project, please see. http://www.trianacode.org.
 *
 * This license is based on the BSD license as adopted by the Apache
 * Foundation and is governed by the laws of England and Wales.
 */

package p2ps.imp.peer.config;

import org.jdom.Element;
import p2ps.peer.ResolverConfig;
import p2ps.pipe.PipeTypes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Information about a resolver configuration
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 9th July 2003
 * @date $Date: 2004/07/02 11:20:57 $ modified by $Author: spxinw $
 * @todo
 */
public class ResolverConfigImp implements ResolverConfig, PipeTypes {

    private String classname;
    private String protocol;

    private ArrayList inpipes = new ArrayList();
    private ArrayList outpipes = new ArrayList();


    /**
     * Creates a configuration for the resolver with the specified classname;
     * input, output and discovery pipes are all enabled
     */
    public ResolverConfigImp(String classname, String protocol) {
        this.classname = classname;
        this.protocol = protocol;
    }

    /**
     * Creates a configuration for the resolver with the specified classname
     *
     * @param classname the name of the resolver class
     * @param inpipes   a flag indicating whether standard input pipes are enabled
     * @param outpipes  a flag indicating whether standard output pipes are enabled
     */
    public ResolverConfigImp(String classname, String protocol, boolean inpipes, boolean outpipes) {
        this.classname = classname;
        this.protocol = protocol;

        if (inpipes)
            this.inpipes.add(STANDARD);

        if (outpipes)
            this.outpipes.add(STANDARD);
    }

    public ResolverConfigImp(Element elem) {
        Element child = elem.getChild(CLASS_NAME_TAG);
        classname = child.getText();

        child = elem.getChild(PROTOCOL_TAG);
        if (child != null)
            protocol = child.getText();

        List children = elem.getChildren(INPUT_PIPE_TAG);
        Iterator iterator = children.iterator();
        while (iterator.hasNext()) {
            Element element = (Element) iterator.next();
            String pipeType = element.getAttributeValue(PIPE_TYPE_TAG);
            boolean pipeEnabled = new Boolean(element.getAttributeValue(PIPE_ENABLED_TAG)).booleanValue();
            setInputPipesEnabled(pipeType, pipeEnabled);
        }
        children = elem.getChildren(OUTPUT_PIPE_TAG);
        iterator = children.iterator();
        while (iterator.hasNext()) {
            Element element = (Element) iterator.next();
            String pipeType = element.getAttributeValue(PIPE_TYPE_TAG);
            boolean pipeEnabled = new Boolean(element.getAttributeValue(PIPE_ENABLED_TAG)).booleanValue();
            setOutputPipesEnabled(pipeType, pipeEnabled);
        }
    }


    /**
     * @return the class name of the resolver
     */
    public String getResolverClassName() {
        return classname;
    }

    /**
     * @return the class name of the resolver
     */
    public String getResolverProtocol() {
        return protocol;
    }

    /**
     * Sets the class name of the resolver
     */
    public void setResolverProtocol(String protocol) {
        this.protocol = protocol;
    }


    /**
     * @return true if input pipes are enabled for this resolver
     */
    public boolean isInputPipesEnabled(String type) {
        return inpipes.contains(type);
    }

    /**
     * Sets input pipes of the specified type as enabled/disabled
     */
    public void setInputPipesEnabled(String type, boolean enabled) {
        if ((enabled) && (!inpipes.contains(type)))
            inpipes.add(type);

        if ((!enabled) && (inpipes.contains(type)))
            inpipes.remove(type);
    }

    /**
     * @return true if output pipes are enabled for this resolver
     */
    public boolean isOutputPipesEnabled(String type) {
        return outpipes.contains(type);
    }

    /**
     * Sets input pipes of the specified type as enabled/disabled
     */
    public void setOutputPipesEnabled(String type, boolean enabled) {
        if ((enabled) && (!outpipes.contains(type)))
            outpipes.add(type);

        if ((!enabled) && (outpipes.contains(type)))
            outpipes.remove(type);
    }

    /**
     * @return an array of the enabled input types
     */
    public String[] getEnabledInputTypes() {
        return (String[]) inpipes.toArray(new String[inpipes.size()]);
    }

    /**
     * Outputs the ResolverConfig as an XML Element
     */
    public Element getXMLElement() throws IOException {
        Element root = new Element(RESOLVER_CONFIG_TAG);

        Element elem = new Element(CLASS_NAME_TAG);
        elem.addContent(this.getResolverClassName());
        root.addContent(elem);

        Iterator iterator = inpipes.iterator();
        while (iterator.hasNext()) {
            String s = (String) iterator.next();
            elem = new Element(INPUT_PIPE_TAG);
            elem.setAttribute(PIPE_TYPE_TAG, s);
            elem.setAttribute(PIPE_ENABLED_TAG, "true");
            root.addContent(elem);
        }

        iterator = outpipes.iterator();
        while (iterator.hasNext()) {
            String s = (String) iterator.next();
            elem = new Element(OUTPUT_PIPE_TAG);
            elem.setAttribute(PIPE_TYPE_TAG, s);
            elem.setAttribute(PIPE_ENABLED_TAG, "true");
            root.addContent(elem);
        }
        return root;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ResolverConfigImp)) return false;

        final ResolverConfigImp resolverConfigImp = (ResolverConfigImp) o;

        if (!classname.equals(resolverConfigImp.classname)) return false;
        if (!inpipes.equals(resolverConfigImp.inpipes)) return false;
        if (!outpipes.equals(resolverConfigImp.outpipes)) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = classname.hashCode();
        result = 29 * result + inpipes.hashCode();
        result = 29 * result + outpipes.hashCode();
        return result;
    }

    /**
     * @return an array of the enabled output types
     */
    public String[] getEnabledOutputTypes() {
        return (String[]) outpipes.toArray(new String[outpipes.size()]);
    }
}
