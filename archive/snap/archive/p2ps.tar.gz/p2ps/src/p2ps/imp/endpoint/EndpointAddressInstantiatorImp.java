package p2ps.imp.endpoint;

import org.jdom.Element;
import p2ps.endpoint.EndpointAddress;
import p2ps.endpoint.EndpointAddressInstantiator;

/**
 * An instantiator for EndpointAddressImp instances
 *
 * @author Ian Wang
 * @version $Revision: 1.1 $
 * @created 28th June 2004
 * @date $Date: 2004/07/02 11:20:54 $ modified by $Author: spxinw $
 * @todo
 */

public class EndpointAddressInstantiatorImp implements EndpointAddressInstantiator {

    public EndpointAddress newEndpointAddress(String protocol, String address, String type) {
        return new EndpointAddressImp(protocol, address, type);
    }


    public EndpointAddress createEndpointAddress(Element root) {
        return new EndpointAddressImp(root);
    }

}
