/*
 * Copyright (c) 1995 onwards, University of Wales College of Cardiff
 *
 * Permission to use and modify this software and its documentation for
 * any purpose is hereby granted without fee provided a written agreement
 * exists between the recipients and the University.
 *
 * Further conditions of use are that (i) the above copyright notice and
 * this permission notice appear in all copies of the software and
 * related documentation, and (ii) the recipients of the software and
 * documentation undertake not to copy or redistribute the software and
 * documentation to any other party.
 *
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF WALES COLLEGE OF CARDIFF BE LIABLE
 * FOR ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
 * KIND, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON
 * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package p2ps.imp.endpoint.UDP;

import org.jdom.Document;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;
import org.apache.log4j.Logger;
import p2ps.endpoint.DataMessage;

import java.io.*;

/**
 * A class for passing data between peers. In addition to the data, header
 * information concerning the message id, source id, routing information and
 * packet information is sent.
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 19th March 2002
 * @date $Date: 2004/07/16 17:21:14 $ modified by $Author: spxinw $
 * @todo
 */

public class DataMessageImp implements DataMessage {

    static Logger logger = Logger.getLogger(DataMessageImp.class);


    /**
     * the XML header
     */
    private UDPHeader header;

    /**
     * the message data array
     */
    private byte[] messdata;

    /**
     * the number of packets received
     */
    private int packreceived = 0;


    /**
     * a counter used for generating message ids
     */
    private static int idcount = 0;


    /**
     * Construct a new message for sending data
     */
    public DataMessageImp(byte[] data) {
        logger.info("Entering");
        this.header = new UDPHeader(String.valueOf(idcount++), data.length, 0);
        this.messdata = data;
        logger.info("Exiting");
    }

    /**
     * Reconstruct a message from received packets
     */
    public DataMessageImp(UDPHeader header) {
        logger.info("Entering");
        this.header = header;
        this.messdata = new byte[header.getMessageLength()];
        logger.info("Exiting");
    }


    /**
     * the space available for data in the message
     */
    private int getDataSize() {
        return UDPSocket.PACKET_SIZE - UDPSocket.HEADER_SIZE;
    }

    /**
     * @return the data in this message (use isMessageComplete to check if the
     *         data has been fully received)
     */

    public byte[] getData() {
        return messdata;
    }


    /**
     * Add a received packet to the message, returns true if the packet was
     * valid and successfully added
     */
    public boolean addPacket(byte[] packet) {

        logger.info("Entering");
        UDPHeader header = getHeader(packet);

        if (header == null)
            return false;

        int packlen = Math.min(getDataSize(), messdata.length - (getDataSize() * header.getPacketIndex()));
        System.arraycopy(packet, UDPSocket.HEADER_SIZE, messdata, header.getPacketIndex() * getDataSize(), packlen);

        packreceived++;

        logger.info("Exiting");

        return true;
    }

    /**
     * @return the message packet for the specified index
     */
    public byte[] getPacket(int index) throws IOException {
        logger.info("Entering");

        int maxlen = UDPSocket.PACKET_SIZE - UDPSocket.HEADER_SIZE;
        int datalen = Math.min(maxlen, messdata.length - (maxlen * index));

        byte[] packet = new byte[UDPSocket.HEADER_SIZE + datalen];

        UDPHeader head = new UDPHeader(header.getMessageID(), header.getMessageLength(), index);
        XMLOutputter xmlout = new XMLOutputter();
        ByteArrayOutputStream byteout = new ByteArrayOutputStream();
        xmlout.output(head.getXMLElement(), byteout);

        byte[] headerbytes = byteout.toByteArray();

        System.arraycopy(headerbytes, 0, packet, 0, headerbytes.length);
        System.arraycopy(messdata, maxlen * index, packet, UDPSocket.HEADER_SIZE, datalen);

        logger.info("Exiting");
        return packet;
    }


    /**
     * @return the number of packets received so far
     */
    public int getPacketReceivedCount() {
        return packreceived;
    }

    /**
     * @return the totol number for packets in this message
     */
    public int getPacketCount() {
        return (header.getMessageLength() - 1) / getDataSize() + 1;
    }

    /**
     * @return true if the message has been fully received
     */
    public boolean isComplete() {
        return (packreceived >= getPacketCount());
    }


    /**
     * @return the id for this message
     */
    public String getMessageId() {
        return header.getMessageID();
    }

    /**
     * @return the header from a packet
     */
    public static UDPHeader getHeader(byte[] packet) {
        logger.info("Entering");

        try {
            String headstr = new String(packet, 0, UDPSocket.HEADER_SIZE);
            headstr = headstr.substring(0, headstr.lastIndexOf('>') + 1);

            SAXBuilder xmlbuild = new SAXBuilder();
            Document doc = xmlbuild.build(new StringReader(headstr));
            UDPHeader header = new UDPHeader(doc.getRootElement());

            logger.info("Exiting");
            return header;
        } catch (Exception except) {
            return null;
        }
    }

}

