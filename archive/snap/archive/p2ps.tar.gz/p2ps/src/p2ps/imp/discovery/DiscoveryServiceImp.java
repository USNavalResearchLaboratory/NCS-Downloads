package p2ps.imp.discovery;

import org.apache.log4j.Logger;
import org.jdom.Document;
import org.jdom.output.XMLOutputter;
import p2ps.discovery.*;
import p2ps.endpoint.Endpoint;
import p2ps.endpoint.EndpointAddress;
import p2ps.endpoint.EndpointResolver;
import p2ps.peer.IDFactory;
import p2ps.peer.Peer;
import p2ps.pipe.*;
import p2ps.rendezvous.RendezvousAdvertisement;
import p2ps.service.ServiceAdvertisement;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;

/**
 * The main class that publishes adverts/queries to other peers and listens for
 * adverts/queries from other peers. In non-rendezvous mode adverts/queries are
 * just multi-cast to other peers in the local network. In rendezvous mode
 * queries are also sent to other known rendezvous peer, and a cache of queries
 * is also kept so that adverts can be forwarded to interested peers.
 *
 * @author Ian Wang
 * @version $Revision: 1.8 $
 * @created 17th March 2003
 * @date $Date: 2004/07/16 17:21:14 $ modified by $Author: spxinw $
 * @todo
 */

public class DiscoveryServiceImp implements DiscoveryService, DiscoveryServiceInterface,
        MessageListener, PipeConnectionListener {

    static Logger logger = Logger.getLogger(DiscoveryServiceImp.class);

    /**
     * the main peer class
     */
    private Peer peer;

    /**
     * the bidirectional pipes used to send/receive adverts
     */
    private BidirectionalPipe discpipe;

    /**
     * the input pipe used to receive query replies
     */
    private InputPipe inpipe;

    /**
     * the advertisement for the input pipe used to directly receive adverts
     */
    private PipeAdvertisement pipead;

    /**
     * a cache of the adverts published by this discovery service
     */
    private DiscoveryCache localcache = new DiscoveryCache();

    /**
     * a list of all the discovery listeners
     */
    private ArrayList listeners = new ArrayList();

    /**
     * a list of all the rendezvous listening to the discovery pipe
     */
    private ArrayList discpipelisteners = new ArrayList();

    /**
     * a hashtable of adverts destined for reply pipes that are currently being
     * connected
     */
    private Hashtable replyads = new Hashtable();


    /**
     * Constructs a new discovery service for the specified peer.
     */
    public DiscoveryServiceImp(Peer peer) {
        logger.info("entering");
        this.peer = peer;
    }


    /**
     * Initialises the discovery service
     */
    public void init() throws IOException {
        logger.info("entering");

        if (peer.getPipeService() == null)
            throw(new RuntimeException("Error instantiating discovery service: Pipe service not registered for peer"));

        if (peer.getAdvertisementFactory() == null)
            throw(new RuntimeException("Error instantiating discovery service: Advertisement factory service not registered for peer"));

        peer.getPipeService().addPipeConnectionListener(this);

        discpipe = createDiscoveryPipe();
        discpipe.addPipeListener(this);

        inpipe = createInputPipe();
        inpipe.addPipeListener(this);

        ServiceAdvertisement servad = (ServiceAdvertisement) peer.getAdvertisementFactory().newAdvertisement(ServiceAdvertisement.SERVICE_ADVERTISEMENT_TYPE);
        servad.setServiceName(DISCOVERY_SERVICE);
        servad.setServiceID(IDFactory.newServiceID());
        servad.addPipeAdvertisement(pipead);

        // advertise discovery service
        publish(servad);

        // advertise pipe resolvers
        publishResolvers();
        logger.info("exiting");
    }


    /**
     * Creates the bidirectional discovery pipe
     */
    private BidirectionalPipe createDiscoveryPipe() throws IOException {
        logger.info("entering");

        PipeAdvertisement discad = (PipeAdvertisement) peer.getAdvertisementFactory().newAdvertisement(PipeAdvertisement.PIPE_ADVERTISEMENT_TYPE);
        discad.setPipeName(DISCOVERY_SERVICE);
        discad.setPipeType(PipeTypes.DISCOVERY);

        if (peer.getPipeService().getPipeResolvers(PipeTypes.DISCOVERY).length == 0)
            return new BounceBackPipe();
        else {
            InputPipe pipe = peer.getPipeService().createInputPipe(discad);

            if (pipe instanceof BidirectionalPipe)
                return (BidirectionalPipe) pipe;
            else
                throw(new IOException("Error: Discovery pipe not bidirectional"));
        }
    }

    /**
     * Creates the direct input pipe
     */
    private InputPipe createInputPipe() throws IOException {
        logger.info("entering");
        pipead = (PipeAdvertisement) peer.getAdvertisementFactory().newAdvertisement(PipeAdvertisement.PIPE_ADVERTISEMENT_TYPE);
        pipead.setPipeName(DISCOVERY_SERVICE);
        return peer.getPipeService().createInputPipe(pipead);
    }


    /**
     * Publishes an advert for each endpoint resolver
     */
    private void publishResolvers() throws IOException {
        logger.info("entering");
        EndpointResolver[] resolvers = peer.getPipeService().getPipeResolvers();

        for (int count = 0; count < resolvers.length; count++)
            publish(resolvers[count].getAdvertisement());
        logger.info("exiting");
    }


    /**
     * Adds a listener to be notified when an advert is discovered/published
     */
    public void addDiscoveryListener(DiscoveryListener listener) {
        logger.info("entering");
        if (!listeners.contains(listener))
            listeners.add(listener);
        logger.info("exiting");
    }

    /**
     * Removes a listener from being notified when an advert is discovered/published
     */
    public void removeDiscoveryListener(DiscoveryListener listener) {
        logger.info("entering");
        listeners.remove(listener);
        logger.info("exiting");
    }


    /**
     * Adds the specified message listener to the discovery pipe
     */
    public void addDiscoveryPipeListener(MessageListener listener) {
        if (!discpipelisteners.contains(listener))
            discpipelisteners.add(listener);

        Advertisement[] adverts = localcache.getAdvertisements();

        for (int count = 0; count < adverts.length; count++)
            try {
                listener.messageReceived(new MessageReceivedEvent(discpipe, advertToByteArray(adverts[count])));
            } catch (IOException except) {
                except.printStackTrace();
            }
    }

    /**
     * Removes the specified message listener from the discovery pipe
     */
    public void removeDiscoveryPipeListener(MessageListener listener) {
        discpipelisteners.remove(listener);
    }


    /**
     * Sends the specified advert via the discovery pipe
     */
    public void send(Advertisement advert) throws IOException {
        logger.info("entering");
        discpipe.send(advertToByteArray(advert));
        logger.info("entering");
    }


    /**
     * Publishes an advert using the discovery pipe. Any messages published
     * before init is called should just be added to the local cache.
     */
    public void publish(Advertisement advert) throws IOException {
        logger.info("entering");

        if (localcache.isQuery(advert)) {
            Query query = (Query) advert;

            if ((query.getReplyPipeAdvertisement() == null) && (query.getReplyEndpointAddress() == null))
                query.setReplyPipeAdvertisement(pipead);
        }

        localcache.add(advert);

        if (discpipe != null)
            discpipe.send(advertToByteArray(advert));

        logger.info("entering");
    }


    /**
     * @return the advert as a byte array
     */
    protected byte[] advertToByteArray(Advertisement advert) throws IOException {
        logger.info("entering");
        XMLOutputter xmlout = new XMLOutputter("    ", true);
        ByteArrayOutputStream outstream = new ByteArrayOutputStream();
        xmlout.output(new Document(advert.getXMLEnvelope()), outstream);

        return outstream.toByteArray();
    }

    /**
     * Handles a broadcast advert or a query reply
     */
    public void messageReceived(MessageReceivedEvent event) {
        logger.info("entering");
        try {
            Advertisement advert = peer.getAdvertisementFactory().createAdvertisement(new ByteArrayInputStream(event.getMessage()));

            if (advert != null) {
                if (event.getInputPipe() == inpipe) {
                    notifyListeners(advert);
                } else {
                    notifyDiscoveryPipeListeners(event);
                    handleAdvert(advert);
                }
            }
        } catch (IOException except) {
            System.err.println("Discovery error: " + except.getMessage());
            except.printStackTrace();
        }
        logger.info("exiting");
    }


    /**
     * Handles a received advert for a peer
     */
    protected void handleAdvert(Advertisement advert) throws IOException {
        logger.info("entering");

        if (advert instanceof RendezvousAdvertisement)
            handleRendezvousAdvertisement((RendezvousAdvertisement) advert);

        // respond to queries
        if (advert instanceof Query)
            handleQuery((Query) advert);

        notifyListeners(advert);
        logger.info("exiting");
    }

    /**
     * When a new rendezvous is discovered, all adevts/queries in the local
     * cache are forwarded to the rendezvous in order that its cache is
     * complete.
     */
    private void handleRendezvousAdvertisement(RendezvousAdvertisement advert) throws IOException {
        EndpointAddress[] addrs = advert.getEndpointAddresses();
        Endpoint outpoint = null;

        for (int count = 0; (count < addrs.length) && (outpoint == null); count++)
            outpoint = getEndpoint(addrs[count]);

        if (outpoint != null) {
            Advertisement[] adverts = localcache.getAdvertisements();

            for (int count = 0; count < adverts.length; count++)
                outpoint.send(advertToByteArray(adverts[count]));
        }
    }


    /**
     * Searches the cache for adverts that match the specified query. Any matches
     * are sent to the query reply address, or republished if no reply address
     * specified.
     *
     * @param query the query advertisement
     */
    private void handleQuery(Query query) throws IOException {
        logger.info("entering");
        Advertisement[] adverts = localcache.getAdvertisements(query);
        PipeAdvertisement replypipead = query.getReplyPipeAdvertisement();

        if (adverts.length == 0)
            return;
        else if ((replypipead != null) && replypipead.getPipeID().equals(pipead.getPipeID()))
            answerLocalQuery(adverts);
        else {
            Endpoint outpoint = getEndpoint(query.getReplyEndpointAddress());

            if (outpoint != null)
                answerQueryWithEndpoint(outpoint, adverts);
            else if (replypipead != null)
                handleQueryWithPipe(replypipead, adverts);
            else
                answerQueryWithNoReply(adverts);
        }
    }

    private void answerLocalQuery(Advertisement[] adverts) {
        for (int count = 0; count < adverts.length; count++)
            notifyListeners(adverts[count]);
    }

    private void answerQueryWithEndpoint(Endpoint outpoint, Advertisement[] adverts) throws IOException {
        for (int count = 0; count < adverts.length; count++)
            outpoint.send(advertToByteArray(adverts[count]));

        outpoint.close();
    }

    private synchronized void handleQueryWithPipe(PipeAdvertisement pipead, Advertisement[] adverts) throws IOException {
        if (replyads.containsKey(pipead.getPipeID())) {
            Advertisement[] curadverts = (Advertisement[]) replyads.get(pipead.getPipeID());
            Advertisement[] merge = new Advertisement[curadverts.length + adverts.length];
            System.arraycopy(curadverts, 0, merge, 0, curadverts.length);
            System.arraycopy(adverts, 0, merge, curadverts.length, adverts.length);
            replyads.put(pipead.getPipeID(), adverts);
        } else {
            replyads.put(pipead.getPipeID(), adverts);
            peer.getPipeService().connectOutputPipe(pipead);
        }
    }

    private synchronized void answerQueryWithPipe(OutputPipe outpipe, Advertisement[] adverts) throws IOException {
        for (int count = 0; count < adverts.length; count++)
            outpipe.send(advertToByteArray(adverts[count]));

        outpipe.close();
    }

    private void answerQueryWithNoReply(Advertisement[] adverts) throws IOException {
        for (int count = 0; count < adverts.length; count++)
            discpipe.send(advertToByteArray(adverts[count]));
    }


    /**
     * @return an endpoint connected to the specified addr (or null if unresolved)
     */
    private Endpoint getEndpoint(EndpointAddress addr) throws IOException {
        logger.info("entering");
        if (addr != null) {
            EndpointResolver resolver = peer.getPipeService().getPipeResolver(addr.getProtocol());

            if (resolver != null)
                return resolver.connectOutputEndpoint(IDFactory.newPipeID(), addr);
        }

        return null;
    }


    /**
     * Called when an output pipe is successfully connected
     */
    public void outpipeConnected(PipeConnectedEvent event) {
        try {
            if (replyads.containsKey(event.getPipeAdvertisement().getPipeID())) {
                Advertisement[] adverts = (Advertisement[]) replyads.remove(event.getPipeAdvertisement().getPipeID());
                try {
                    answerQueryWithPipe(event.getOutputPipe(), adverts);
                } catch (IOException except) {
                    answerQueryWithNoReply(adverts);
                }
            }
        } catch (IOException except) {
            System.err.println("Discover pipe error: " + except.getMessage());
            except.printStackTrace();
        }
    }

    /**
     * Called when an output pipe is successfully connected
     */
    public void outpipeConnectFailure(PipeConnectFailureEvent event) {
        try {
            if (replyads.containsKey(event.getPipeAdvertisement().getPipeID())) {
                Advertisement[] adverts = (Advertisement[]) replyads.remove(event.getPipeAdvertisement().getPipeID());
                answerQueryWithNoReply(adverts);
            }
        } catch (IOException except) {
            System.err.println("Discover pipe error: " + except.getMessage());
            except.printStackTrace();
        }
    }

    /**
     * Notify all the discovery listeners that an advert has been discovered
     */
    private void notifyListeners(Advertisement advert) {
        logger.info("entering");
        DiscoveryEvent event = new DiscoveryEvent(advert);
        DiscoveryListener[] copy = (DiscoveryListener[]) listeners.toArray(new DiscoveryListener[listeners.size()]);

        for (int count = 0; count < copy.length; count++)
            copy[count].advertDiscovered(event);
        logger.info("exiting");
    }

    /**
     * Notify all the rendezvous discovery listeners that an advert has been discovered
     */
    private void notifyDiscoveryPipeListeners(MessageReceivedEvent event) {
        logger.info("entering");
        MessageListener[] copy = (MessageListener[]) discpipelisteners.toArray(new MessageListener[discpipelisteners.size()]);

        for (int count = 0; count < copy.length; count++)
            copy[count].messageReceived(event);
        logger.info("exiting");
    }


    private class BounceBackPipe implements BidirectionalPipe {

        public static final String BOUNCE_BACK_PIPE = "BounceBackPipe";

        private ArrayList listeners = new ArrayList();

        private String id = IDFactory.newPipeID();
        private boolean closed = false;


        /**
         * Adds a listener to be notified when messages are received
         */
        public void addPipeListener(MessageListener listener) {
            if (!listeners.contains(listener))
                listeners.add(listener);
        }

        /**
         * Removes a listener from being notified when messages are received
         */
        public void removePipeListener(MessageListener listener) {
            listeners.remove(listener);
        }

        /**
         * @return the id of the pipe
         */
        public String getPipeID() {
            return id;
        }

        /**
         * @return the name of the pipe
         */
        public String getPipeName() {
            return BOUNCE_BACK_PIPE;
        }

        /**
         * Sends a message from the pipe
         */
        public void send(byte[] message) throws IOException {
            notifyListeners(message);
        }


        /**
         * Closes the pipe
         */
        public void close() throws IOException {
            closed = true;
        }

        /**
         * @return true if the pipe is closed
         */
        public boolean isClosed() {
            return closed;
        }

        private void notifyListeners(byte[] message) {
            MessageListener[] copy = (MessageListener[]) listeners.toArray(new MessageListener[listeners.size()]);
            MessageReceivedEvent event = new MessageReceivedEvent(this, message);

            for (int count = 0; count < copy.length; count++)
                copy[count].messageReceived(event);
        }

    }
}
