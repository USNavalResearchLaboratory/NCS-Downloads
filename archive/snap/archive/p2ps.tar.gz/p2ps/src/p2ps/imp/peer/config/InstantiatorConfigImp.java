package p2ps.imp.peer.config;

import p2ps.peer.InstantiatorConfig;
import org.jdom.Element;

import java.util.List;
import java.util.Iterator;
import java.io.IOException;

/**
 * An implementation of the Instantiator Config interface
 *
 * @author      Ian Wang
 * @created     1st July 2004
 * @version     $Revision: 1.1 $
 * @date        $Date: 2004/07/02 11:20:57 $ modified by $Author: spxinw $
 * @todo
 */

public class InstantiatorConfigImp implements InstantiatorConfig {

    private String type;
    private String classname;


    public InstantiatorConfigImp(String type, String classname) {
        this.type = type;
        this.classname = classname;
    }

    public InstantiatorConfigImp(Element elem) {
        Element child = elem.getChild(CLASS_NAME_TAG);
        classname = child.getText();

        child = elem.getChild(TYPE_TAG);
        type = child.getText();
    }


    /**
     * @return the name of the type instantiated by this instantiator
     */
    public String getInstantiatorType() {
        return type;
    }

    /**
     * @return the name of the instantiator's Java class
     */
    public String getInstantiatorClass() {
        return classname;
    }


    /**
     * Outputs the InstantiatorConfig as an XML Element
     */
    public Element getXMLElement() throws IOException {
        Element root = new Element(INSTANTIATOR_CONFIG_TAG);

        Element elem = new Element(CLASS_NAME_TAG);
        elem.addContent(this.getInstantiatorClass());
        root.addContent(elem);

        elem = new Element(TYPE_TAG);
        elem.addContent(this.getInstantiatorType());
        root.addContent(elem);

        return root;
    }

}
