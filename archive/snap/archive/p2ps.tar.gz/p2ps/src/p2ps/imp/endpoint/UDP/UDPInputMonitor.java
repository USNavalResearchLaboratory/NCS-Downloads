package p2ps.imp.endpoint.UDP;

import p2ps.endpoint.DataMessage;
import p2ps.endpoint.DataMessageEvent;
import p2ps.endpoint.EndpointMessageListener;
import p2ps.imp.endpoint.ThreadPool;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Hashtable;

/**
 * A monitor thread that listens to all tcp input sockets and handles messages
 * received.
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 29th July 2003
 * @date $Date: 2004/07/02 11:20:53 $ modified by $Author: spxinw $
 * @todo
 */

public class UDPInputMonitor extends Thread {

    public static int UDP_SOCKET_TIMEOUT = 10;
    public static int MONITOR_SLEEP_TIME = 100;

    /**
     * a pool of threads used to handle messages
     */
    private static ThreadPool threads = new ThreadPool("UDPSocketThread");

    /**
     * a hashtable of the half built messages
     */
    private static Hashtable messages = new Hashtable();

    private ArrayList sockets = new ArrayList();

    public UDPInputMonitor() {
        setName("UDPInputMonitor");
        start();
    }


    public void monitorSocket(UDPSocket udpsocket) throws IOException {
        if (!sockets.contains(udpsocket)) {
            sockets.add(udpsocket);
            udpsocket.getSocket().setSoTimeout(UDP_SOCKET_TIMEOUT);
        }
    }

    public void unmonitorSocket(UDPSocket socket) {
        sockets.remove(socket);
    }


    public void run() {
        UDPSocket udpsocket;
        DatagramPacket packet;

        while (true) {
            for (int count = 0; count < sockets.size(); count++) {
                udpsocket = (UDPSocket) sockets.get(count);

                packet = new DatagramPacket(new byte[UDPSocket.PACKET_SIZE], UDPSocket.PACKET_SIZE);

                try {
                    udpsocket.getSocket().receive(packet);

                    UDPHeader header = DataMessageImp.getHeader(packet.getData());

                    if (header != null)
                        threads.addTask(new HandleMessage(header, packet, udpsocket));
                } catch (SocketTimeoutException except) {
                } catch (SocketException except) {
                    unmonitorSocket(udpsocket);
                } catch (IOException except) {
                    except.printStackTrace();
                    unmonitorSocket(udpsocket);
                }
            }

            try {
                Thread.sleep(MONITOR_SLEEP_TIME);
            } catch (InterruptedException except) {
            }
        }
    }


    private class HandleMessage implements Runnable {

        private UDPHeader header;
        private DatagramPacket packet;
        private UDPSocket socket;


        public HandleMessage(UDPHeader header, DatagramPacket packet, UDPSocket socket) {
            this.header = header;
            this.packet = packet;
            this.socket = socket;
        }

        public void run() {
            DataMessage message = buildMessage();

            if (message != null)
                handleMessage(message);
        }

        /**
         * handles a partial message either by creating a new message
         */
        private DataMessage buildMessage() {
            String key = packet.getAddress().toString() + "&" + header.getMessageID();
            DataMessageImp message;

            if (!messages.containsKey(key)) {
                synchronized(messages) {
                    message = new DataMessageImp(header);
                    messages.put(key, message);
                }
            } else
                message = (DataMessageImp) messages.get(key);

            message.addPacket(packet.getData());

            if (message.isComplete()) {
                messages.remove(key);
                return message;
            } else
                return null;
        }

        /**
         * Called by a single input socket when a message is received. The input
         * socket notifies all the data message listeners
         */
        private void handleMessage(DataMessage message) {
            DataMessageEvent event = new DataMessageEvent(socket, message);
            EndpointMessageListener[] copy = socket.getEndpointMessageListeners();

            for (int count = 0; count < copy.length; count++) {
                copy[count].dataMessageReceived(event);
                Thread.yield();
            }
        }
    }

}
