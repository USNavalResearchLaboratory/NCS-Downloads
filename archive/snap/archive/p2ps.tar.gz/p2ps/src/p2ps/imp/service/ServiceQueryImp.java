package p2ps.imp.service;

import org.jdom.Element;
import p2ps.discovery.AdvertisementFactory;
import p2ps.endpoint.EndpointAddress;
import p2ps.endpoint.EndpointAddressFactory;
import p2ps.imp.endpoint.EndpointAddressImp;
import p2ps.pipe.PipeAdvertisement;
import p2ps.service.ServiceAdvertisement;
import p2ps.service.ServiceQuery;

import java.io.IOException;
import java.util.List;

/**
 * An implementation of the Service Query interface
 *
 * @author Ian Wang
 * @version $Revision: 1.4 $
 * @created 18th March 2003
 * @date $Date: 2004/07/02 11:21:01 $ modified by $Author: spxinw $
 * @todo
 */

public class ServiceQueryImp implements ServiceQuery {

    private String advertid;
    private String peerid;

    private String querypeerid;
    private String servicename;

    private PipeAdvertisement pipead;
    private EndpointAddress replyaddr;


    public ServiceQueryImp(String advertid, String peerid) {
        this.advertid = advertid;
        this.peerid = peerid;
    }

    public ServiceQueryImp(Element root, AdvertisementFactory adfactory, EndpointAddressFactory endfactory) throws IOException {
        Element elem = root.getChild(ADVERT_ID_TAG);
        if (elem != null)
            advertid = elem.getText();

        elem = root.getChild(PEER_ID_TAG);
        if (elem != null)
            peerid = elem.getText();

        elem = root.getChild(QUERY_PEER_ID_TAG);
        if (elem != null)
            querypeerid = elem.getText();

        elem = root.getChild(QUERY_SERVICE_NAME_TAG);
        if (elem != null)
            servicename = elem.getText();

        elem = root.getChild(REPLY_PIPE_ADVERTISEMENT_TAG);
        if (elem != null) {
            List children = elem.getChildren();
            if (children.size() > 0)
                pipead = (PipeAdvertisement) adfactory.createAdvertisement((Element) children.get(0));
        }

        elem = root.getChild(REPLY_ENDPOINT_ADDRESS_TAG);
        if (elem != null) {
            List children = elem.getChildren();
            if (children.size() > 0)
                replyaddr = endfactory.createEndpointAddress((Element) children.get(0));
        }
    }


    /**
     * @return the type for this advertisement
     */
    public String getType() {
        return SERVICE_QUERY_TYPE;
    }

    /**
     * @return the type of advertisement this query is interested in (e.g.
     *         PipeAdvertisement)
     */
    public String getQueryType() {
        return ServiceAdvertisement.SERVICE_ADVERTISEMENT_TYPE;
    }

    /**
     * @return the unique id for this advertisement
     */
    public String getAdvertID() {
        return advertid;
    }

    /**
     * @return the id of the peer that created this advertisement
     */
    public String getPeerID() {
        return peerid;
    }


    /**
     * @return the id of the peer this query is interested in (null if any)
     */
    public String getQueryPeerID() {
        return querypeerid;
    }

    /**
     * Sets the id of the peer this query is interested in (null if any)
     */
    public void setQueryPeerID(String id) {
        querypeerid = id;
    }

    /**
     * @return the name of the service this query is interested in (null if any)
     */
    public String getQueryServiceName() {
        return servicename;
    }

    /**
     * Sets the name of the service this query is interested in (null if any)
     */
    public void setQueryServiceName(String name) {
        servicename = name;
    }


    /**
     * @return optional pipe for the query reply.
     */
    public PipeAdvertisement getReplyPipeAdvertisement() {
        return pipead;
    }

    /**
     * Ssets the optional endpoint address for the query reply.
     */
    public void setReplyPipeAdvertisement(PipeAdvertisement pipead) {
        this.pipead = pipead;
    }


    /**
     * @return optional endpoint address for the query reply. If not specified
     *         the query matches should be (re)published.
     */
    public EndpointAddress getReplyEndpointAddress() {
        return replyaddr;
    }

    /**
     * Ssets the optional endpoint address for the query reply. If not specified
     * the query matches should be (re)published.
     */
    public void setReplyEndpointAddress(EndpointAddress replyaddr) {
        this.replyaddr = replyaddr;
    }


    /**
     * Output the advert as an xml document
     */
    public Element getXMLAdvert() throws IOException {
        Element root = new Element(SERVICE_QUERY_TYPE);

        Element elem = new Element(QUERY_TAG);
        elem.addContent(ServiceAdvertisement.SERVICE_ADVERTISEMENT_TYPE);
        root.addContent(elem);

        elem = new Element(ADVERT_ID_TAG);
        elem.addContent(advertid);
        root.addContent(elem);

        elem = new Element(PEER_ID_TAG);
        elem.addContent(peerid);
        root.addContent(elem);

        if (querypeerid != null) {
            elem = new Element(QUERY_PEER_ID_TAG);
            elem.addContent(querypeerid);
            root.addContent(elem);
        }

        if (servicename != null) {
            elem = new Element(QUERY_SERVICE_NAME_TAG);
            elem.addContent(servicename);
            root.addContent(elem);
        }

        if (pipead != null) {
            elem = new Element(REPLY_PIPE_ADVERTISEMENT_TAG);
            elem.addContent(pipead.getXMLAdvert());
            root.addContent(elem);
        }

        if (replyaddr != null) {
            elem = new Element(REPLY_ENDPOINT_ADDRESS_TAG);
            elem.addContent(replyaddr.getXMLElement());
            root.addContent(elem);
        }

        return root;
    }

    /**
     * @return an XML element for the full enveloped advert (returns the same
     *         as getXMLAdvert if no envelope)
     */
    public Element getXMLEnvelope() throws IOException {
        return getXMLAdvert();
    }

}
