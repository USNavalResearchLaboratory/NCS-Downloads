/*
 * Copyright (c) 1995 onwards, University of Wales College of Cardiff
 *
 * Permission to use and modify this software and its documentation for
 * any purpose is hereby granted without fee provided a written agreement
 * exists between the recipients and the University.
 *
 * Further conditions of use are that (i) the above copyright notice and
 * this permission notice appear in all copies of the software and
 * related documentation, and (ii) the recipients of the software and
 * documentation undertake not to copy or redistribute the software and
 * documentation to any other party.
 *
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT SHALL THE UNIVERSITY OF WALES COLLEGE OF CARDIFF BE LIABLE
 * FOR ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY
 * KIND, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON
 * ANY THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package p2ps.imp.endpoint;

import org.jdom.Element;
import p2ps.discovery.Advertisement;
import p2ps.discovery.AdvertisementFactory;
import p2ps.discovery.AdvertisementInstantiator;
import p2ps.peer.Peer;

import java.io.IOException;

/**
 * A class for instantiating pipe resolver query queries
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 19th March 2003
 * @date $Date: 2004/07/02 11:20:56 $ modified by $Author: spxinw $
 * @todo
 */

public class EndpointResolverQueryInstantiator implements AdvertisementInstantiator {

    /**
     * @return a advertisement generated from the specified document
     */
    public Advertisement createAdvertisement(Element envelope, Peer peer) throws IOException {
        return new EndpointResolverQueryImp(envelope, peer.getAdvertisementFactory(), peer.getEndpointAddressFactory());
    }

    /**
     * @return a new advertisement instance
     */
    public Advertisement newAdvertisement(String peerid, String advertid) throws IOException {
        return new EndpointResolverQueryImp(advertid, peerid);
    }

}
