package p2ps.imp.peer;

import p2ps.imp.peer.config.ConfigImp;
import p2ps.imp.peer.config.ConfigWindow;
import p2ps.imp.peer.config.DefaultConfig;
import p2ps.peer.Config;

import java.io.IOException;

/**
 * A factory constructor for creating P2PS Peers.
 *
 * @author Matthew Shields
 * @version $Revision: 1.2 $
 * @created Feb 25, 2004: 3:34:24 PM
 * @date $Date: 2004/07/16 17:21:14 $ modified by $Author: spxinw $
 */
public class ConfigFactory {

    public static final int CONFIG_WINDOW_NEVER = 0;
    public static final int CONFIG_WINDOW_ALWAYS = 1;
    public static final int CONFIG_WINDOW_IF_REQUIRED = 2;


    public static final Config getConfig(int configwindow) {
        Config config = ConfigImp.loadConfig();
        try {
            if ((configwindow == CONFIG_WINDOW_ALWAYS) || ((config == null) && (configwindow == CONFIG_WINDOW_IF_REQUIRED))) {
                if (config == null)
                    config = new DefaultConfig();

                ConfigWindow confwindow = new ConfigWindow(config);
                config = confwindow.getConfiguration();
                try {
                    config.writeConfig();
                } catch (IOException e) {
                    System.err.println("Error writing config file");
                }
            }
        } catch (Throwable throwable) {
            System.err.println("Unable to launch the graphical configurator");
        }
        if (config == null) {
            System.err.println("No p2ps.properties file found");
            System.err.println("Not able to configure this Peer, loading defaults");
            config = new DefaultConfig();
        }

        return config;
    }
}
