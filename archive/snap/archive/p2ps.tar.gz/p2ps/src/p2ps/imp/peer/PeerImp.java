package p2ps.imp.peer;

import autolog.DefaultLogConfig;
import org.apache.log4j.Logger;
import p2ps.discovery.AdvertisementFactory;
import p2ps.discovery.AdvertisementInstantiator;
import p2ps.discovery.DiscoveryService;
import p2ps.endpoint.EndpointAddress;
import p2ps.endpoint.EndpointAddressFactory;
import p2ps.endpoint.EndpointAddressInstantiator;
import p2ps.endpoint.EndpointResolver;
import p2ps.imp.discovery.DefaultAdvertisementInstantiator;
import p2ps.imp.endpoint.PortFactory;
import p2ps.peer.*;
import p2ps.pipe.PipeService;
import p2ps.rendezvous.RendezvousService;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * The main peer class that groups all the services together.
 *
 * @author Ian Wang
 * @version $Revision: 1.14 $
 * @created 18th March 2003
 * @date $Date: 2004/07/16 16:13:13 $ modified by $Author: ian $
 * @todo
 */

public class PeerImp implements Peer {

    static Logger logger = Logger.getLogger(PeerImp.class);

    /**
     * the unique id of this peer
     */
    String peerid;

    /**
     * the advertisement factory
     */
    AdvertisementFactory adverts;

    /**
     * the advertisement factory
     */
    EndpointAddressFactory endfactory;


    /**
     * the discovery service
     */
    DiscoveryService discovery;

    /**
     * the advertisement factory
     */
    RendezvousService rendezvous;

    /**
     * the pipe service
     */
    PipeService pipes;

    /**
     * the configuration of this peer
     */
    Config config;


    /**
     * Constructs a peer with no configuration. Use configPeer(Config) to
     * configure, then init() to initialise)
     */
    protected PeerImp() {
        initLogging();
        logger.info("Init");
    }

    /**
     * Constructs but does not initialise a peer (call init() to initialise).
     */
    public PeerImp(Config config) throws IOException {
        initLogging();
        logger.info("Init");

        configPeer(config);
    }


    /**
     * Calles
     */
    protected void configPeer(Config config) throws IOException {
        logger.info("Entering");

        this.config = config;

        initIDFactory();
        this.peerid = IDFactory.newPeerID();

        initAdvertisementFactory();
        initEndpointAddressFactory();
        initDiscoveryService();
        initPipeService();
        initRendezvousService();
        logger.info("Exiting");
    }


    /**
     * Kicks off the autoconfiguration of the default logging within the
     * autolog package.
     */
    void initLogging() {
        DefaultLogConfig.setup();
    }

    /**
     * Initialises the advertisement factory.
     */
    void initAdvertisementFactory() {
        logger.info("Entering");
        adverts = new AdvertisementFactory(this, new DefaultAdvertisementInstantiator());

        InstantiatorConfig[] instconfigs = config.getAdvertInstantiatorConfigs();
        AdvertisementInstantiator inst;
        Class instclass;

        for (int count = 0; count < instconfigs.length; count++) {
            try {
                instclass = Class.forName(instconfigs[count].getInstantiatorClass());

                inst = (AdvertisementInstantiator) instclass.newInstance();
                adverts.register(instconfigs[count].getInstantiatorType(), inst);
            } catch (ClassNotFoundException except) {
                System.err.println("Advert Instantiator Class Not Found: " + instconfigs[count].getInstantiatorClass());
                except.printStackTrace();
            } catch (InstantiationException except) {
                System.err.println("Cannot Instantiate Advert Instantiator: " + instconfigs[count].getInstantiatorClass());
                except.printStackTrace();
            } catch (IllegalAccessException except) {
                except.printStackTrace();
            }

        }
        logger.info("Exiting");
    }

    /**
     * Initialises the endpoint address factory.
     */
    void initEndpointAddressFactory() {
        logger.info("Entering");
        endfactory = new EndpointAddressFactory();

        InstantiatorConfig[] instconfigs = config.getEndpointAddressInstantiatorConfigs();
        EndpointAddressInstantiator inst;
        Class instclass;

        for (int count = 0; count < instconfigs.length; count++) {
            try {
                instclass = Class.forName(instconfigs[count].getInstantiatorClass());
                inst = (EndpointAddressInstantiator) instclass.newInstance();
                endfactory.register(instconfigs[count].getInstantiatorType(), inst);

                logger.debug("Instantiator Class: " +  instclass.getName() + " for endpoint ID "
                            + instconfigs[count].getInstantiatorType());
            } catch (ClassNotFoundException except) {
                System.err.println("Endpoint Address Instantiator Class Not Found: " + instconfigs[count].getInstantiatorClass());
                except.printStackTrace();
            } catch (InstantiationException except) {
                System.err.println("Cannot Instantiate Endpoint Address Instantiator: " + instconfigs[count].getInstantiatorClass());
                except.printStackTrace();
            } catch (IllegalAccessException except) {
                except.printStackTrace();
            }
        }
        logger.info("Exiting");
    }


    /**
     * Initializes the id factory
     */
    void initIDFactory() {
        try {
            Class cls = Class.forName(config.getIDFactoryClass());
            IDFactory.factory = (IDFactoryInterface) cls.newInstance();
        } catch (ClassCastException except) {
            System.err.println("ID Factory Class not instance of IDFactoryInterface");
            except.printStackTrace();
        } catch (ClassNotFoundException except) {
            System.err.println("ID Factory Class Not Found: " + config.getIDFactoryClass());
            except.printStackTrace();
        } catch (InstantiationException except) {
            System.err.println("Cannot Instantiate ID Factoryr: " + config.getIDFactoryClass());
            except.printStackTrace();
        } catch (IllegalAccessException except) {
            except.printStackTrace();
        }
    }


    /**
     * Initialises the pipe service
     */
    void initPipeService() throws IOException {
        logger.info("Entering");
        PortFactory.setPortRange(config.getMinPort(), config.getMaxPort());

        pipes = (PipeService) initService(config.getPipeServiceClass());

        ResolverConfig[] resconfigs = config.getResolverConfigs();
        EndpointResolver resolver;
        String[] types;
        Class resclass;

        for (int rescount = 0; rescount < resconfigs.length; rescount++) {
            try {
                resclass = Class.forName(resconfigs[rescount].getResolverClassName());

                resolver = (EndpointResolver) resclass.newInstance();
                resolver.init(this, config);

                types = resolver.getPipeTypes();

                for (int typecount = 0; typecount < types.length; typecount++) {
                    resolver.setInputPipesEnabled(types[typecount], resconfigs[rescount].isInputPipesEnabled(types[typecount]));
                    resolver.setOutputPipesEnabled(types[typecount], resconfigs[rescount].isOutputPipesEnabled(types[typecount]));
                }

                pipes.register(resolver);
            } catch (ClassNotFoundException except) {
                System.err.println("Pipe Resolver Class Not Found: " + resconfigs[rescount].getResolverClassName());
                except.printStackTrace();
            } catch (InstantiationException except) {
                System.err.println("Cannot Instantiate Pipe Resolver: " + resconfigs[rescount].getResolverClassName());
                except.printStackTrace();
            } catch (IllegalAccessException except) {
                except.printStackTrace();
            }
        }
        logger.info("Exiting");
    }

    /**
     * Initialises the discovery service
     */
    void initDiscoveryService() throws IOException {
        logger.info("Entering");

        discovery = (DiscoveryService) initService(config.getDiscoveryServiceClass());

        logger.info("Exiting");
    }

    /**
     * Initialises the rendezvous service (if a rendezvous peer)
     */
    void initRendezvousService() throws IOException {
        logger.info("Entering");

        if (config.isRendezvousPeer())
            rendezvous = (RendezvousService) initService(config.getRendezvousServiceClass());

        logger.info("Exiting");
    }

    private Object initService(String clsname) {
        try {
            Class cls = Class.forName(clsname);
            Constructor construct = cls.getConstructor(new Class[]{Peer.class});
            return construct.newInstance(new Object[]{this});
        } catch (NoSuchMethodException except) {
            System.err.println("Invalid constructor in " + clsname + ": Peer argument expected");
            except.printStackTrace();
        } catch (ClassNotFoundException except) {
            System.err.println("Class Not Found: " + clsname);
            except.printStackTrace();
        } catch (InstantiationException except) {
            System.err.println("Cannot Instantiate: " + clsname);
            except.printStackTrace();
        } catch (IllegalAccessException except) {
            except.printStackTrace();
        } catch (InvocationTargetException except) {
            except.printStackTrace();
        }

        return null;
    }


    /**
     * Initialises the peer
     */
    public void init() throws IOException {
        logger.info("Entering");
        discovery.init();
        pipes.init();

        if (config.isRendezvousPeer()) {
            rendezvous.init(config.getLocalRendezvousEndpoints());

            EndpointAddress[] resaddr = config.getRemoteRendezvousEndpoints();
            for (int count = 0; count < resaddr.length; count++)
                ((RendezvousService) rendezvous).connectToRendezvous(resaddr[count]);
        }

        logger.info("Exiting");
    }


    /**
     * @return the unique id for this peer
     */
    public String getPeerID() {
        return peerid;
    }


    /**
     * @return the advertisement factory
     */
    public AdvertisementFactory getAdvertisementFactory() {
        return adverts;
    }

    /**
     * @return the endpoint address factory
     */
    public EndpointAddressFactory getEndpointAddressFactory() {
        return endfactory;
    }


    /**
     * @return the discovery service
     */
    public DiscoveryService getDiscoveryService() {
        return discovery;
    }

    /**
     * @return the rendezvous service (null if not rendezvous)
     */
    public RendezvousService getRendezvousService() {
        return rendezvous;
    }

    /**
     * @return the pipe service
     */
    public PipeService getPipeService() {
        return pipes;
    }

}
