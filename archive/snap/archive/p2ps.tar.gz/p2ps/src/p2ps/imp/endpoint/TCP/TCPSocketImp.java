package p2ps.imp.endpoint.TCP;

import p2ps.endpoint.*;

import java.net.Socket;
import java.util.ArrayList;

/**
 * A class that sends and receives message bytes to/from a Datagram Socket. If
 * the message bytes exceed the packet size the message is split into multiple
 * packets.
 *
 * @author Ian Wang
 * @version $Revision: 1.3 $
 * @created 17th March 2003
 * @date $Date: 2004/07/02 11:20:53 $ modified by $Author: spxinw $
 * @todo
 */

public class TCPSocketImp extends TCPSocket implements Endpoint, TCPEndpointTypes {

    /**
     * an array list of input message listeners (applies to bidirectional only)
     */
    private ArrayList listeners = new ArrayList();


    /**
     * Creates a TCP output socket connected to the specified address
     */
    public TCPSocketImp(Socket socket, SocketHandler handler) {
        super(socket, handler);
    }


    /**
     * Adds a listener to receive data from this socket
     */
    public void addEndpointMessageListener(EndpointMessageListener listener) {
        if (!listeners.contains(listener))
            listeners.add(listener);
    }

    /**
     * Removes a listener from this socket
     */
    public void removeEndpointMessageListener(EndpointMessageListener listener) {
        listeners.remove(listener);
    }


    /**
     * @return an EndpointAdvertisement for this endpoint
     */
    public EndpointAdvertisement getAdvertisement() {
        return null;
    }

    /**
     * @return the transport protocol for this socket
     */
    public EndpointAddress getEndpointAddress() {
        return null;
    }


    /**
     * notifies the socket handler that it will handle  messaege for the
     * specified socket
     */
    public void handleSocket(TCPSocket socket) {
    }

    /**
     * handle the specified Data Message received on the specified socket
     */
    public void receiveMessage(DataMessage mess, TCPSocket socket) {
        EndpointMessageListener[] copy = (EndpointMessageListener[]) listeners.toArray(new EndpointMessageListener[listeners.size()]);
        DataMessageEvent event = new DataMessageEvent(this, socket, mess);

        for (int count = 0; count < copy.length; count++)
            copy[count].dataMessageReceived(event);
    }

}