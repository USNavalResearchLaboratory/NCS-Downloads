/*
 * The University of Wales, Cardiff Triana Project Software License (Based
 * on the Apache Software License Version 1.1)
 *
 * Copyright (c) 2003 University of Wales, Cardiff. All rights reserved.
 *
 * Redistribution and use of the software in source and binary forms, with
 * or without modification, are permitted provided that the following
 * conditions are met:
 *
 * 1.  Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 * 2.  Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 * 3. The end-user documentation included with the redistribution, if any,
 *    must include the following acknowledgment: "This product includes
 *    software developed by the University of Wales, Cardiff for the Triana
 *    Project (http://www.trianacode.org)." Alternately, this
 *    acknowledgment may appear in the software itself, if and wherever
 *    such third-party acknowledgments normally appear.
 *
 * 4. The names "Triana" and "University of Wales, Cardiff" must not be
 *    used to endorse or promote products derived from this software
 *    without prior written permission. For written permission, please
 *    contact triana@trianacode.org.
 *
 * 5. Products derived from this software may not be called "Triana," nor
 *    may Triana appear in their name, without prior written permission of
 *    the University of Wales, Cardiff.
 *
 * 6. This software may not be sold, used or incorporated into any product
 *    for sale to third parties.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 * NO EVENT SHALL UNIVERSITY OF WALES, CARDIFF OR ITS CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Triana Project. For more information on the
 * Triana Project, please see. http://www.trianacode.org.
 *
 * This license is based on the BSD license as adopted by the Apache
 * Foundation and is governed by the laws of England and Wales.
 */

package p2ps.imp.rendezvous;

import p2ps.discovery.Advertisement;
import p2ps.discovery.Query;
import p2ps.endpoint.Endpoint;
import p2ps.endpoint.EndpointAddress;
import p2ps.endpoint.EndpointResolver;
import p2ps.peer.IDFactory;
import p2ps.peer.Peer;
import p2ps.pipe.*;

import java.io.IOException;
import java.util.Hashtable;

/**
 * A rendezvous service implementation that replies directly to queries it
 * receives.
 *
 * @author Ian Wang
 * @version $Revision: 1.3 $
 * @created 30th June 2004
 * @date $Date: 2004/07/16 17:26:19 $ modified by $Author: spxinw $
 * @todo
 */

public class ReplyRendezvousService extends AbstractRendezvousService implements PipeConnectionListener {

    /**
     * a hashtable of adverts destined for reply pipes that are currently being
     * connected
     */
    private Hashtable replyads = new Hashtable();

    public ReplyRendezvousService(Peer peer) {
        super(peer);
    }

    /**
     * Initialises the rendezvous service
     */
    public void init(EndpointAddress[] addresses) throws IOException {
        peer.getPipeService().addPipeConnectionListener(this);
        super.init(addresses);
    }


    /**
     * Called when a match between an advert and a query is found. Implementations
     * of this method are responsible replying to the query with the discovered
     * advert.
     */
    protected void handleMatch(Advertisement[] adverts, Query query) throws IOException {
        PipeAdvertisement replypipead = query.getReplyPipeAdvertisement();

        Endpoint outpoint = getEndpoint(query.getReplyEndpointAddress());

        if (outpoint != null)
            answerQueryWithEndpoint(outpoint, adverts);
        else if (replypipead != null)
            handleQueryWithPipe(replypipead, adverts);
        else
            answerQueryWithNoReply(adverts);
    }

    private void answerQueryWithEndpoint(Endpoint outpoint, Advertisement[] adverts) throws IOException {
        for (int count = 0; count < adverts.length; count++)
            outpoint.send(advertToByteArray(adverts[count].getXMLEnvelope()));

        outpoint.close();
    }

    private synchronized void handleQueryWithPipe(PipeAdvertisement pipead, Advertisement[] adverts) throws IOException {
        if (replyads.containsKey(pipead.getPipeID())) {
            Advertisement[] curadverts = (Advertisement[]) replyads.get(pipead.getPipeID());
            Advertisement[] merge = new Advertisement[curadverts.length + adverts.length];
            System.arraycopy(curadverts, 0, merge, 0, curadverts.length);
            System.arraycopy(adverts, 0, merge, curadverts.length, adverts.length);
            replyads.put(pipead.getPipeID(), adverts);
        } else {
            replyads.put(pipead.getPipeID(), adverts);
            peer.getPipeService().connectOutputPipe(pipead);
        }
    }

    private synchronized void answerQueryWithPipe(OutputPipe outpipe, Advertisement[] adverts) throws IOException {
        for (int count = 0; count < adverts.length; count++)
            outpipe.send(advertToByteArray(adverts[count].getXMLEnvelope()));

        outpipe.close();
    }

    private void answerQueryWithNoReply(Advertisement[] adverts) throws IOException {
        for (int count = 0; count < adverts.length; count++)
            disc.send(adverts[count]);
    }


    /**
     * @return an endpoint connected to the specified addr (or null if unresolved)
     */
    private Endpoint getEndpoint(EndpointAddress addr) throws IOException {
        if (addr != null) {
            EndpointResolver resolver = peer.getPipeService().getPipeResolver(addr.getProtocol());

            if (resolver != null)
                return resolver.connectOutputEndpoint(IDFactory.newPipeID(), addr);
        }

        return null;
    }


    /**
     * Called when an output pipe is successfully connected
     */
    public void outpipeConnected(PipeConnectedEvent event) {
        try {
            if (replyads.containsKey(event.getPipeAdvertisement().getPipeID())) {
                Advertisement[] adverts = (Advertisement[]) replyads.remove(event.getPipeAdvertisement().getPipeID());
                answerQueryWithPipe(event.getOutputPipe(), adverts);
            }
        } catch (IOException except) {
        }
    }

    /**
     * Called when an output pipe is successfully connected
     */
    public void outpipeConnectFailure(PipeConnectFailureEvent event) {
        if (replyads.containsKey(event.getPipeAdvertisement().getPipeID()))
            replyads.remove(event.getPipeAdvertisement().getPipeID());
    }

}
