package p2ps.imp.endpoint;

import java.net.SocketException;

/**
 * A static class that maintains the range of ports available through a firewall
 * and suggests the next port that should be used
 *
 * @author Ian Wang
 * @version $Revision: 1.2 $
 * @created 24th July 2003
 * @date $Date: 2004/07/02 11:20:56 $ modified by $Author: spxinw $
 * @todo
 */
public class PortFactory {

    private static int min = 1025;
    private static int max = 65535;

    private static int last;

    /**
     * Sets the range of available ports through the firewall
     */
    public static void setPortRange(int minport, int maxport) {
        if (min > max)
            throw (new RuntimeException("Port Factory Exception: Minimum port greater than maximum"));

        min = minport;
        max = maxport;
        last = max;
    }

    /**
     * @return the minimum available port
     */
    public static int getMinPort() {
        return min;
    }

    /**
     * @return the maximum available port
     */
    public static int getMaxPort() {
        return max;
    }


    /**
     * @return a key used to access getNextPort(). A new key should be
     *         generated each time a port is created.
     */
    public static Object getNewFactoryKey() {
        return new PortFactoryKey();
    }


    /**
     * Returns the next port in the port range. Note that this port is not
     * guaranteed be available and might already be bound.
     *
     * @param key the key created using getNewFactoryKey()
     * @return a suggested port
     * @throws SocketException
     */
    public static int getNextPort(Object key) throws SocketException {
        if (!(key instanceof PortFactoryKey))
            throw(new RuntimeException("Port Factory Exception: Invalid key, use getNewFactoryKey()"));

        last++;

        if (last > max)
            last = min;

        if (((PortFactoryKey) key).getInitialPort() == -1)
            ((PortFactoryKey) key).setInitialPort(last);
        else if (((PortFactoryKey) key).getInitialPort() == last)
            throw(new SocketException("Port Factory Exception: Out of available ports, expand port range"));

        return last;
    }

}
