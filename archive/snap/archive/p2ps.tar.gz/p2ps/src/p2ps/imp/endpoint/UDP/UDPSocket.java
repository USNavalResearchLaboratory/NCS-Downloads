package p2ps.imp.endpoint.UDP;

import p2ps.endpoint.Endpoint;
import p2ps.endpoint.EndpointAddress;
import p2ps.endpoint.EndpointAdvertisement;
import p2ps.endpoint.EndpointMessageListener;
import p2ps.imp.endpoint.EndpointAddressImp;
import p2ps.imp.endpoint.PortFactory;
import p2ps.peer.Peer;

import java.io.IOException;
import java.net.*;
import java.util.ArrayList;

import org.apache.log4j.Logger;

/**
 * A class that sends and receives message bytes to/from a Datagram Socket. If
 * the message bytes exceed the packet size the message is split into multiple
 * packets.
 *
 * @author Ian Wang
 * @version $Revision: 1.9 $
 * @created 17th March 2003
 * @date $Date: 2004/07/16 16:13:13 $ modified by $Author: ian $
 * @todo
 */

public class UDPSocket implements Endpoint, UDPEndpointTypes {

    static Logger logger = Logger.getLogger(UDPSocket.class);

    public static int PACKET_SIZE = 10000;
    public static int HEADER_SIZE = 200;

    public static int SEND_BUFFER_SIZE = 100000;
    public static int RECEIVE_BUFFER_SIZE = 100000;


    /**
     * a thread that monitors all input sockets and launches threads to
     * handle incoming messages
     */
    private static UDPInputMonitor monitorthread = new UDPInputMonitor();

    /**
     * the socket data is sent to
     */
    private DatagramSocket socket;

    /**
     * the inet address and port for the receive/group
     */
    private InetAddress inet;
    private int port;

    /**
     * an advert for this endpoint
     */
    private EndpointAdvertisement advert;

    /**
     * an array of the listeners that receive messages from this socket
     */
    private ArrayList listeners = new ArrayList();


    /**
     * Creates a standard UDP socket for an available port
     */
    public UDPSocket(String pipeid, String protocol, Peer peer) throws IOException {
        logger.info("Entering");
        Object key = PortFactory.getNewFactoryKey();
        boolean success = false;
        int port;

        while (!success) {
            port = PortFactory.getNextPort(key);

            try {
                socket = new DatagramSocket(port);
                success = true;
            } catch (IOException except) {
            }
        }

        initSocket();
        initUnicastAdvert(pipeid, protocol, peer);
        logger.info("Exiting");
    }


    /**
     * Creates a standard UDP socket for the specified port
     */
    public UDPSocket(int port, String pipeid, String protocol, Peer peer) throws IOException {
        logger.info("Entering");
        socket = new DatagramSocket(port);

        initSocket();
        initUnicastAdvert(pipeid, protocol, peer);
        logger.info("Exiting");
    }


    /**
     * Creates a multicast socket attaches to the specified group address and
     * port
     */
    public UDPSocket(String groupaddr, int port, String pipeid, String protocol, Peer peer) throws IOException {
        logger.info("Entering");
        try {
            this.inet = InetAddress.getByName(groupaddr);
            this.port = port;

            socket = new MulticastSocket(port);
            ((MulticastSocket) socket).joinGroup(inet);

            initSocket();
            initMulticastAdvert(groupaddr, port, pipeid, protocol, peer);
        } catch (UnknownHostException except) {
            throw(new IOException(except.getMessage()));
        }
        logger.info("Exiting");
    }

    /**
     * Initialises the buffer size on the socket
     */
    private void initSocket() throws IOException {
        logger.info("Entering");
        socket.setReuseAddress(true);
        socket.setReceiveBufferSize(RECEIVE_BUFFER_SIZE);
        socket.setSendBufferSize(SEND_BUFFER_SIZE);

        monitorthread.monitorSocket(this);
        logger.info("Exiting");
    }

    /**
     * Initialises the advert for this socket
     */
    private void initUnicastAdvert(String pipeid, String protocol, Peer peer) throws IOException {
        logger.info("Entering");
        String address = InetAddress.getLocalHost().getHostAddress() + ":" + socket.getLocalPort();

        advert = (EndpointAdvertisement) peer.getAdvertisementFactory().newAdvertisement(EndpointAdvertisement.ENDPOINT_ADVERTISEMENT_TYPE);
        advert.setPipeID(pipeid);
        advert.setEndpointAddress(peer.getEndpointAddressFactory().newEndpointAddress(protocol, address, UDP_UNICAST));
        logger.info("Exiting");
    }


    /**
     * Initialises the advert for this socket
     */
    private void initMulticastAdvert(String addr, int port, String pipeid, String protocol, Peer peer) throws IOException {
        logger.info("Entering");
        String address = addr + ":" + port;

        advert = (EndpointAdvertisement) peer.getAdvertisementFactory().newAdvertisement(EndpointAdvertisement.ENDPOINT_ADVERTISEMENT_TYPE);
        advert.setPipeID(pipeid);
        advert.setEndpointAddress(peer.getEndpointAddressFactory().newEndpointAddress(protocol, address, UDP_MULTICAST));
        logger.info("Exiting");
    }


    /**
     * Adds a listener to receive data from this endpoint
     */
    public void addEndpointMessageListener(EndpointMessageListener listener) {
        logger.info("Entering");
        if (!listeners.contains(listener))
            listeners.add(listener);
        logger.info("Exiting");
    }

    /**
     * Removes a listener from this endpoint
     */
    public void removeEndpointMessageListener(EndpointMessageListener listener) {
        listeners.remove(listener);
    }

    /**
     * @return an array of the listeners to this socket
     */
    EndpointMessageListener[] getEndpointMessageListeners() {
        return (EndpointMessageListener[]) listeners.toArray(new EndpointMessageListener[listeners.size()]);
    }

    /**
     * @return the datagram socket for this udp socket
     */
    DatagramSocket getSocket() {
        return socket;
    }


    /**
     * @return the transport protocol for this socket
     */
    public EndpointAddress getEndpointAddress() {
        return advert.getEndpointAddress();
    }

    /**
     * @return an EndpointAdvertisement for this endpoint
     */
    public EndpointAdvertisement getAdvertisement() {
        return advert;
    }


    /**
     * @return true if this endpoint is input enabled
     */
    public boolean isInputEndpoint() {
        return true;
    }

    /**
     * @return true if this endpoint is output enabled
     */
    public boolean isOutputEndpoint() {
        return (inet != null);
    }


    /**
     * Connects the socket to the specified address
     */
    public void connect(String address, int port) throws IOException {
        logger.info("Entering");
        this.inet = InetAddress.getByName(address);
        this.port = port;
        logger.info("Exiting");
    }


    /**
     * Send a message from the socket
     */
    public void send(byte[] message) throws IOException {
        send(message, null);
    }


    /**
     * Sends a message from the socket to the specified address
     */
    public void send(byte[] message, EndpointAddress address) throws IOException {
        logger.info("Entering");
        DatagramPacket packet;
        byte[] data;
        InetAddress sendinet = inet;
        int sendport = port;

        if ((address == null) && (inet == null))
            throw (new IOException("Unspecified address on send from non-multicast socket"));

        if (address != null) {
            sendinet = InetAddress.getByName(UDPResolver.getHostAddress(address));
            sendport = UDPResolver.getPort(address);
        }

        DataMessageImp datamess = new DataMessageImp(message);

        for (int count = 0; count < datamess.getPacketCount(); count++) {
            data = datamess.getPacket(count);
            packet = new DatagramPacket(data, data.length, sendinet, sendport);

            socket.send(packet);
        }
        logger.info("Exiting");
    }


    /**
     * Closes the socket
     */
    public void close() throws IOException {
        logger.info("Entering");
        if (!socket.isClosed()) {
            socket.close();
            monitorthread.unmonitorSocket(this);
            listeners.clear();
        }
        logger.info("Exiting");
    }

    /**
     * @return true is the socket is closed
     */
    public boolean isClosed() {
        return socket.isClosed();
    }

}
