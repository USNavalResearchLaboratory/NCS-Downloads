package p2ps.imp.pipe;

import org.apache.log4j.Logger;
import p2ps.endpoint.Endpoint;
import p2ps.pipe.OutputPipe;
import p2ps.pipe.PipeAdvertisement;

import java.io.IOException;

/**
 * An implementation of the output pipe interface.
 *
 * @author Ian Wang
 * @version $Revision: 1.3 $
 * @created 19th March 2003
 * @date $Date: 2004/07/02 11:20:58 $ modified by $Author: spxinw $
 * @todo
 */

public class OutputPipeImp implements OutputPipe {

    static Logger logger = Logger.getLogger(OutputPipeImp.class);

    private String pipeid;
    private String pipename;

    private Endpoint socket;


    public OutputPipeImp(PipeAdvertisement pipead, Endpoint socket) {
        logger.info("entering");
        this.pipeid = pipead.getPipeID();
        this.pipename = pipead.getPipeName();
        this.socket = socket;
        logger.info("exiting");
    }


    /**
     * @return the id of the pipe
     */
    public String getPipeID() {
        return pipeid;
    }

    /**
     * @return the name of the pipe
     */
    public String getPipeName() {
        return pipename;
    }


    /**
     * Sends a message from the pipe
     */
    public void send(byte[] message) throws IOException {
        logger.info("entering");
        socket.send(message);
        logger.info("exiting");
    }


    public void close() throws IOException {
        logger.info("entering");
        socket.close();
        logger.info("exiting");
    }

    /**
     * @return true if the socket is closed
     */
    public boolean isClosed() {
        return socket.isClosed();
    }

}
