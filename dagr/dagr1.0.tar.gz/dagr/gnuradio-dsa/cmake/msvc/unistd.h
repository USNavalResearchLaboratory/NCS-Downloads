#ifndef _MSC_VER // [
#error "Use this header only with Microsoft Visual C++ compilers!"
#endif // _MSC_VER ]

#ifndef _MSC_UNISTD_H_ // [
#define _MSC_UNISTD_H_

#include <process.h>

#endif // _MSC_UNISTD_H_ ]
