import dsapacket

#Create a dictionary with the msgid as the key, and the value
#contains

#First four bytes of every DSA packet is a message id, a string
#of ascii numbers designating each unique packet needed



class dsapacketfactory(object):
    def __init__(self):
        pass
    def create(self, payload):
        msgid = payload[0:4]
        if msgid == dsapacket.PKT_IP_DATA:
            return dsapacket.ip_data(payload)

        elif msgid == dsapacket.PKT_TIME_REQ:
            return dsapacket.time_req(payload)

        elif msgid == dsapacket.PKT_TIME_ACK:
            return dsapacket.time_ack(payload)

        elif msgid == dsapacket.PKT_FFT_SENSE:
            return dsapacket.fft_sense(payload)

        elif msgid == dsapacket.PKT_FFT_FINAL:
            return dsapacket.fft_final(payload)
        
        elif msgid == dsapacket.PKT_RNDVS_BEACON:
            return dsapacket.rndvs_beacon(payload)

        elif msgid == dsapacket.PKT_SENSING_FUSED:
            return dsapacket.sensing_fused(payload)

        else:
            return dsapacket.null(payload)
        

