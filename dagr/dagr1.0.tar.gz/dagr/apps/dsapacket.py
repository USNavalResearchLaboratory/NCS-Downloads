# Contains classes for all the various MAC-layer packets that could be received

# Header is 20 bytes
# First 4 bytes contain a MSGID, which is a 4 digit number represented in string format
# Next 4 bytes contain the macid src, 4 digit number in string format
# Next 4 bytes contain the  macid dst, 4 digit number in string format, not needed currently
# Next 8 bytes contain the timestamp, packed string double precision float

# List of MSG ID
PKT_IP_DATA = '0000'
PKT_TIME_REQ = '0010'
PKT_TIME_ACK = '0011'
PKT_FFT_SENSE = '0020'
PKT_FFT_FINAL = '0021'
PKT_SENSING_FUSED = '0022'
PKT_RNDVS_BEACON = '0030'
PKT_RNDVS_RESPONSE = '0031'
PKT_RNDVS_ACK = '0032'
PKT_SENSING_SIGHOUND = '0040'
PKT_POLICY = '0050'

#MACID
ALLNODES=255

import struct 
import os
import time
from gnuradio import gr
import sensing

class dsapacket(object):
    def __init__(self, payload):
        self.payload = payload
        self.msgid = payload[0:4]
        self.src = int(payload[4:8])
        self.dst = int(payload[8:12])
        (self.timestamp,) = struct.unpack('>d', payload[12:20])
        
    def process_from_rx(self, mac):
        pass

    @staticmethod
    def make_header(msgid, src, dst):
        now = time.time()
        timestamp = struct.pack('>d', now)
        header = msgid + ('%04d' % src) + ('%04d' % dst) + timestamp         
        return header
        
    # Used for TX to get as close to the real send time as possible
    @staticmethod
    def insert_timestamp(payload):
        now = time.time()
        timestamp = struct.pack('>d', now)
        return payload[0:12] + timestamp + payload[20:] 

class null(dsapacket):
    def __init__(self, payload):
        dsapacket.__init__(self, payload)
    def process_from_rx(self, mac):
        pass

class ip_data(dsapacket):
    def __init__(self, payload):
        dsapacket.__init__(self, payload)
        self.tun_data = payload[20:]

    def process_from_rx(self, mac):
        os.write(mac.tun_fd, self.tun_data)

    @staticmethod
    def make_tx_payload(src, dst, tun_data):
        header = dsapacket.make_header(PKT_IP_DATA, src, dst)
        payload = header + tun_data
        return payload
        
class fft_sense(dsapacket):
    def __init__(self, payload):
        dsapacket.__init__(self, payload)
        assert(self.msgid == PKT_FFT_SENSE)
        (self.inband, self.outband, self.outbandfreq) = struct.unpack('>iid', payload[20:36])
     
       
    def process_from_rx(self, mac):
        msg = gr.message_from_string(self.payload, 0, time.time(), 0.0)
        mac.pktqs.fft_sense.insert_tail(msg)

    @staticmethod
    def make_tx_payload(src, dst, inband, outband, outbandfreq):
        header = dsapacket.make_header(PKT_FFT_SENSE, src, dst)
        payload = header + struct.pack('>iid', inband, outband, outbandfreq)
        return payload 
        

class fft_final(dsapacket):
    def __init__(self, payload):
        dsapacket.__init__(self, payload)
        assert(self.msgid == PKT_FFT_FINAL)
        (self.inband, self.outband, self.outbandfreq) = struct.unpack('>iid', payload[20:36])

    def process_from_rx(self, mac):
        msg = gr.message_from_string(self.payload, 0, time.time(), 0.0)
        mac.pktqs.fft_final.insert_tail(msg)

    @staticmethod
    def make_tx_payload(src, dst, inband, outband, outbandfreq):
        header = dsapacket.make_header(PKT_FFT_FINAL, src, dst)
        payload = header + struct.pack('>iid', inband, outband, outbandfreq) 
        return payload

class sensing_fused(dsapacket):
    def __init__(self, payload):
        dsapacket.__init__(self, payload)
        assert(self.msgid == PKT_SENSING_FUSED)
        (self.startfreq, self.stepfreq, self.numchannels, self.chanlen) = struct.unpack('>ddii', payload[20:44])
        self.available_channels = []
        for char in payload[44:]:
            (chan,) = struct.unpack('>B', char)
            self.available_channels.append(chan)

    def process_from_rx(self, mac):
        msg = gr.message_from_string(self.payload, 0, time.time(), 0.0)
        mac.pktqs.sensing_fused.insert_tail(msg)

    @staticmethod
    def make_tx_payload(src, dst, startfreq, stepfreq, numchannels, available_channels):
        header = dsapacket.make_header(PKT_SENSING_FUSED, src, dst)
        chanlen = len(available_channels)
        #print "Chanlen", chanlen
        payload = header + struct.pack('>ddii', startfreq, stepfreq, numchannels, chanlen)
        for c in available_channels:
            payload = payload + struct.pack('>B', c) 
        return payload
       
        
class rndvs_beacon(dsapacket):
    def __init__(self, payload):
        dsapacket.__init__(self, payload)
        
    def process_from_rx(self, mac):
        msg = gr.message_from_string(self.payload, 0, time.time(), 0.0)
        mac.pktqs.rndvs_beacon.insert_tail(msg)
        
    @staticmethod
    def make_tx_payload(src, dst):
        payload = dsapacket.make_header(PKT_RNDVS_BEACON, src, dst)
        return payload
    
class rndvs_response(dsapacket):
    def __init__(self, payload):
        dsapacket.__init__(self, payload)
        
    @staticmethod
    def make_tx_payload(src, dst):
        payload = dsapacket.make_header(PKT_RNDVS_RESPONSE, src, dst)
        return payload

class rndvs_ack(dsapacket):
    def __init__(self, payload):
        dsapacket.__init__(self, payload)
        
    @staticmethod
    def make_tx_payload(src, dst):
        payload = dsapacket.make_header(PKT_RNDVS_ACK, src, dst)
        return payload

class time_req(dsapacket):
    def __init__(self, payload):
        dsapacket.__init__(self, payload)
        
    def process_from_rx(self, mac):
        if mac.is_server:
            time_req_rcvd = time.time()
            msg = gr.message_from_string(self.payload, 0, arg1=time_req_rcvd)
            mac.pktqs.time_req.insert_tail(msg)
        
    @staticmethod
    def make_tx_payload(src, dst):
        header = dsapacket.make_header(PKT_TIME_REQ, src, dst)
        return header
        
class time_ack(dsapacket):
    def __init__(self, payload):
        dsapacket.__init__(self, payload)
        (self.time_req_sent,) = struct.unpack('>d', payload[20:28])
        (self.time_req_rcvd,) = struct.unpack('>d', payload[28:36])


    def process_from_rx(self, mac):
        if not mac.is_server:
            time_ack_rcvd = time.time()
            msg = gr.message_from_string(self.payload, 0, arg1=time_ack_rcvd)
            mac.pktqs.time_ack.insert_tail(msg)

#    def process_from_rx(self, mac):
#        if self.dst == mac.macid:
#            time_ack_rcvd = time.time()
#            a = self.time_req_rcvd - self.time_req_sent
#            b = self.timestamp  - time_ack_rcvd
#            offset = (a+b)/2.0
#            delay = a - b
            #make OS system call to offset
#            newtime = time.time() + 0.1*offset
#            sensing.settime(newtime)
            #print "\nTime Request: %f %f" % (self.time_req_sent, self.time_req_rcvd)
            #print "Time Acknowl: %f %f" % (self.time_ack_sent, time_ack_rcvd)
 #           print "Time Synch offset: %.4f delay %.4f" % (offset, delay)
            #print "Delay a: %.4f b: %.4f" % (a, -b)
  #          if offset < 0:
   #             pass
                #print "Warning Setting Back in Time Offset: %f" % offset

    @staticmethod
    def make_tx_payload(src, dst, trsent, trrcvd):
        header = dsapacket.make_header(PKT_TIME_ACK, src, dst)
        payload = header + struct.pack('>dd', trsent, trrcvd) 
        return payload
        
class sensing_sighound(dsapacket):
    def __init__(self, payload):
        dsapacket.__init__(self, payload)
        (self.start_freq, self.stop_freq) = stuct.unpack('>qq', payload[20:36])
        (self.policy_start_freq, self.policy_stop_freq) = stuct.unpack('>qq', payload[36:52])
        (self.chan_used_bitmap,) = stuct.unpack('>i', payload[52:56])
        
    def process_from_rx(self, mac):
        self.sensing_sighound_bitmap = self.chan_used_bitmap
        print "Received Sighound bitmap %d", self.chan_used_bitmap
        if mac.is_server:
            if (mac.policy_start_freq is not self.start_freq or 
               mac.policy_stop_freq is not self.stop_freq):
                mac.send_policy_sighound = True
        
    @staticmethod
    def make_tx_payload(src, dst, startfreq, stopfreq, policystart, policystop, bitmap):
        header = dsapacket.make_header(PKT_SENSING_SIGHOUND, src, dst)
        payload = header + struct.pack('>qqqqi', startfreq, stopfreq, policystart, policystop, bitmap)
        return payload
        
class policy_data(dsapacket):
    def __init__(self, payload):
        dsapacket.__init__(self, payload)
        (self.start_freq, self.stop_freq) = struct.unpack('>qq', payload[20:36])
        
    def process_from_rx(self, mac):
        self.policy_start_freq = self.start_freq
        self.policy_stop_freq = self.stop_freq
        
    @staticmethod
    def make_tx_payload(startfreq, stopfreq):
        header = dsapacket.make_header(PKT_POLICY, src, dst)
        payload = header + struct.pack('>qq', startfreq, stopfreq)
        return payload
    
        
        

