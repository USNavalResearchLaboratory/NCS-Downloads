import time, random, math


# Transmission Frames during Quiet Time
SENSING_START = 0.000
SENSING_MID =   0.050
SENSING_END =   0.100
FFT_SENSE =     0.100
FFT_FINAL_SEND =     0.150
FFT_FINAL_RECV =     0.200
TIME_REQ =      0.200
TIME_ACK =      0.250

MIN_RANDOM_OFFSET = 4.0
MAX_RANDOM_OFFSET = 8.0

class mac_times(object):
    def __init__(self, options, starttime=-1):
        if options.periodic_sensing > 0:
            self.method = 'periodic'
            self.period = options.periodic_sensing
        else:
            self.method = 'random'
        if starttime == -1:
            self.start_time = self.get_start_of_day()
        else:
            self.start_time = starttime
            
    def get_start_of_day(self):
        now = time.time()
        seconds_per_day = 24.0*60*60
        total_days_since_1970 = math.floor(now/seconds_per_day)
        return total_days_since_1970 * seconds_per_day 
        
    def init(self):
        self.sensing_start = self.init_sensing_start_time()
        self.update_other_times()
                
        
    def init_sensing_start_time(self):
        now = time.time()
        if self.method == 'periodic':
            sensing_start = (now - (now % self.period)) + self.period
        else:
            sensing_start = self.start_time
            sensing_start = self.get_next_random_time(sensing_start)
            while sensing_start < now:
                sensing_start = self.get_next_random_time(sensing_start)
                now = time.time()
        return sensing_start
    
    def get_next_random_time(self,prev_random_time):
        #use prev_random_time as seed to ensure all nodes get the same result
        random.seed(prev_random_time)
        time_offset = random.uniform(MIN_RANDOM_OFFSET, MAX_RANDOM_OFFSET)
        #now reseed so any other us of random function wont create exact same results
        random.seed(time.time())
        return prev_random_time + time_offset
            
        
    def update(self):
        if self.method == 'periodic':
            self.sensing_start = self.sensing_start + self.period
        else:
            self.sensing_start = self.get_next_random_time(self.sensing_start)
        self.update_other_times()

    #update remainder of transmit times, based on sensing_start        
    def update_other_times(self):
        self.sensing_mid = self.sensing_start + SENSING_MID
        self.sensing_end = self.sensing_start + SENSING_END
        self.fft_sense = self.sensing_start + FFT_SENSE
        self.fft_final_send = self.sensing_start + FFT_FINAL_SEND
        self.fft_final_recv = self.sensing_start + FFT_FINAL_RECV        
        self.time_req = self.sensing_start + TIME_REQ
        self.time_ack = self.sensing_start + TIME_ACK
        
    def in_quiet_time(self):
        now = time.time()
        if now >= self.sensing_start:
            return True
        else:
            return False
            
            
    
        
