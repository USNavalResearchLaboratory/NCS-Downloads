#!/usr/bin/env python
# Rendezvous protocol using CMA

from gnuradio import gr, gru
from gnuradio import eng_notation
from gnuradio.eng_option import eng_option
from optparse import OptionParser

import random
import time
import struct
import sys
import os
import Queue

# from current dir
import dsapacket
import sensing
#constants
TICK_DURATION = 0.25
BEACON_HDR = dsapacket.PKT_RNDVS_BEACON
RESPONSE_HDR = dsapacket.PKT_RNDVS_RESPONSE
ACK_HDR = dsapacket.PKT_RNDVS_ACK
ALLNODES = dsapacket.ALLNODES


# /////////////////////////////////////////////////////////////////////////////
#                             rendezvous protocol
# /////////////////////////////////////////////////////////////////////////////


class rendezvous_mac(object):
    def __init__(self, tb, startfreq, stepfreq, numchannels, options):
        self.tb = tb
        self.options = options
        self.verbose = options.verbose
        self.rcvd_msg_q = Queue.Queue()
        self.start_freq = startfreq
        self.step_freq = stepfreq
        self.num_channels = numchannels
        self.chan0 = startfreq + 0.5*stepfreq
        #self.sensing_freq = sensingfreq
        self.prime_numbers = self.find_prime_numbers(numchannels)
        random.seed()
        self.initialize_rv_variables()
        self.macid = options.hst
        self.rcvd_timestamp = 0.0
    
    def find_prime_numbers(self, num_channels):
        #find all prime numbers between NUM_CHANNELS to 2*NUM_CHANNELS-1
        primes = []
        for chan in range(num_channels, 2*num_channels-1):
            if self.is_prime(chan):
                primes.append(chan)
        return primes

    def is_prime(self, n):
        # make sure n is a positive integer
        n = abs(int(n))
        # 0 and 1 are not primes
        if n < 2:
            return False
        # 2 is the only even prime number
        if n == 2: 
            return True    
        # all other even numbers are not primes
        if not n & 1: 
            return False
        # range starts with 3 and only needs to go up the squareroot of n
        # for all odd numbers
        for x in range(3, int(n**0.5)+1, 2):
            if n % x == 0:
                return False
        return True

    def initialize_rv_variables(self):
        #Allows randomized channel names
        channel_indices = range(0,self.num_channels)
        channel_assignments = range(0,self.num_channels)
        random.shuffle(channel_assignments)

        self.channel_mapping = dict( zip(channel_indices,channel_assignments) )
        self.prime_modulus = self.get_prime_modulus()
        self.channel_rate = random.randint(1, self.prime_modulus-1)
        self.current_channel = random.randint(0, self.num_channels-1)
        self.current_mapped_channel = self.map_channel(self.current_channel)
        self.state = "START"
        self.numticks = 1
        self.maxticks = 2 * self.prime_modulus * self.prime_modulus
        self.tick_start = time.time()
        self.tick_extension = 0.0
    
    def get_prime_modulus(self):
        prime_numbers_sz = len(self.prime_numbers)
        random_index = random.randint(0, prime_numbers_sz-1)
        prime_modulus = self.prime_numbers[random_index]
        return prime_modulus

    def map_channel(self, chan):
        #map channel number, based on prime modulus, which may be unusable, to
        #a usable channel.  Modulo arithemetic is the easiest way to do this, but
        #we can also do some randomization if desired.

        #map large values of channel index to usable channels randomly    
        if chan >= self.num_channels:
            channel = random.randint(0, self.num_channels - 1)
        else:
            channel = chan

        #channel = chan % NUM_CHANNELS
 
        #results seem better than expected, test with random function, see if its seeding
        #return self.channel_mapping[chan]
        #channel = random.randint(0,self.num_channels-1)
        return self.channel_mapping[channel]


    def phy_rx_callback(self, ok, payload_str):
        """
        Invoked by thread associated with PHY to pass received packet up.

        @param ok: bool indicating whether payload CRC was OK
        @param payload: contents of the packet (string)
        """

        if self.verbose:
            print "Rx: ok = %r  hdr %s len payload = %4d" % (ok, payload_str[0:4],len(payload_str))
            self.print_payload_info(ok, payload_str)
        if ok:
            pkt = dsapacket.dsapacket(payload_str)
            if pkt.src != self.macid:
                print "Rx: ok = %r  hdr %s len payload = %4d" % (ok, payload_str[0:4],len(payload_str))
                self.rcvd_msg_q.put(payload_str)

    def print_payload_info(self, ok, payload_str):
        if self.is_beacon(payload_str):
            type = "BEACON"
        elif self.is_response(payload_str):
            type = "RESPONSE"
        elif self.is_ack(payload_str):
            type = "ACK"
        else:
            type = "UKNOWN"
        print "Rx: %s ok = %r len(payload) = %4d" % (type, ok,len(payload_str))

    

###################
## START BLIND RENDEZVOUS
###################


    def perform_blind_rendezvous(self):
        self.initialize_rv_variables()
        """
        Start rendezvous protocol
        """
        print "\nENTERING BLIND RENDEZVOUS \n"
        print "prime: %d channel rate: %d\n" % (self.prime_modulus, self.channel_rate)
        print "chan %d map %d" % (self.current_channel,self.current_mapped_channel)
        self.tick_start = time.time()
        self.totalticks=1
        self.set_freq(self.current_mapped_channel)
        while self.state != "DONE":
            #Check to see if it's time to change channel
            if self.tick_expired():
                self.update_channel()
                print "\nchan %d map %d" % (self.current_channel,self.current_mapped_channel)
                self.state = "START"
                self.numticks = self.numticks + 1
                self.tick_start = time.time()
                self.totalticks = self.totalticks+1
                self.tick_extension = 0.0

            if self.numticks > self.maxticks:
                self.initialize_rv_variables()
                print "prime: %d channel rate: %d" % (self.prime_modulus, self.channel_rate) 

            #Perform actions based on state
            if self.state == "START":
                self.perform_start()
            elif self.state == "WAIT_FOR_RESPONSE":
                self.perform_wait_for_response()
            elif self.state == "WAIT_FOR_ACK":
                self.perform_wait_for_ack()
            elif self.state == "WAIT_FOR_RESPONSE_OR_ACK":
                self.perform_wait_for_response_or_ack()
            time.sleep(0.001)

        print "\nRENDEZVOUS COMPLETE!!!\n"
        print "Time: %.3f Number Ticks: %d  Rendezvous Channel: %d" % (time.time(), self.totalticks, self.current_mapped_channel)
        freq = self.calculate_freq(self.current_mapped_channel)
        return freq

    def synch_time(self, payload):
        if self.options.server is False and self.options.synch is True:
            #pkt = dsapacket.dsapacket(payload)
            #sensing.settime(pkt.timestamp)
            pass   


#################################
#Finite state machine functions
#################################
    def perform_start(self):
        payload_found, payload_str = self.check_received_msg()
        if payload_found:
            if self.is_beacon(payload_str):
                self.send_response()
                self.tick_extension = self.tick_extension + 0.3
                self.state = 'WAIT_FOR_ACK'
        else:

        #So you can see it on the spectral analyzer
        #now = time.time()        
        #while time.time()<now+1:
            #    self.send_beacon()
            self.send_beacon()
        self.state = 'WAIT_FOR_RESPONSE'

    def perform_wait_for_response(self):
        result = False
        payload_found, payload_str = self.check_received_msg()
        if payload_found:
            if self.is_response(payload_str):
                self.synch_time(payload_str)
                self.send_ack()
                self.state = "DONE"
                result = True
            elif self.is_beacon(payload_str):
                self.send_response()
                self.tick_extension = self.tick_extension + 0.3
                self.state = 'WAIT_FOR_RESPONSE_OR_ACK'
            else:
                #we got something so stick around longer, extend time and resend beacon
                self.tick_extension = self.tick_extension + 0.3
                self.send_beacon()
        return result

    def perform_wait_for_ack(self):
        payload_found, payload_str = self.check_received_msg()
        if payload_found:
            if self.is_ack(payload_str):
                self.synch_time(payload_str)
                self.state = "DONE"

    def perform_wait_for_response_or_ack(self):
        payload_found, payload_str = self.check_received_msg()
        if payload_found:
            if self.is_response(payload_str):
                self.synch_time(payload_str)
                self.state = "DONE"
            if self.is_ack(payload_str):
                self.synch_time(payload_str)
                self.state = "DONE"

#################
#HELPER FUNCTIONS
#################

    def get_timestamp(self, payload_str):
        pkt = dsapacket.dsapacket(payload_str)
        self.rcvd_timestamp = pkt.timestamp    
   
    def tick_expired(self):
        now = time.time()
        return now - self.tick_start > TICK_DURATION + self.tick_extension

    def update_channel(self):
        self.current_channel = (self.current_channel + self.channel_rate) % self.prime_modulus
        self.current_mapped_channel = self.map_channel(self.current_channel)
        self.set_freq(self.current_mapped_channel)

    #logfile = open('node_log.txt', 'a')    
    #logfile.write(str(self.current_mapped_channel) + '\n')
    #logfile.close()


    def set_freq(self, channel):
        freq = self.chan0 + channel*self.step_freq
        self.tb.set_freq(freq)


    def check_received_msg(self):
        payload_str = ""
        if self.rcvd_msg_q.empty():
            payload_found = False
        else:
            payload_found = True
            payload_str = self.rcvd_msg_q.get()

    #for checking for correlated RNG's    
    #payload_found = False

        return (payload_found, payload_str)
        

###########################
#PAYLOAD SPECIFIC FUNCTIONS
###########################

    def is_beacon(self, payload_str):
        return (payload_str[0:4] == BEACON_HDR)

    def is_response(self, payload_str):
        return (payload_str[0:4] == RESPONSE_HDR)

    def is_ack(self, payload_str):
        return (payload_str[0:4] == ACK_HDR)
   
    def send_beacon(self):
        payload_str = dsapacket.rndvs_beacon.make_tx_payload(self.macid, ALLNODES)
        if self.verbose:
            print "Tx: BEACON len(payload) = %4d" % (len(payload_str),)
        self.send(payload_str)

    def send_response(self):
        payload_str = dsapacket.rndvs_response.make_tx_payload(self.macid, ALLNODES)
        if self.verbose:
            print "Tx: RESPONSE len(payload) = %4d" % (len(payload_str),)
        self.send(payload_str)

    def send_ack(self):
        payload_str = dsapacket.rndvs_ack.make_tx_payload(self.macid, ALLNODES)
        if self.verbose:
            print "Tx: ACK  len(payload) = %4d" % (len(payload_str),)
        self.send(payload_str)

    def send(self, payload):
        min_delay = 0.001
        delay = min_delay
        backoffs=0
        jammed = False
        while self.tb.carrier_sensed():
            backoffs = backoffs+1
            sys.stderr.write('B')
            time.sleep(delay)
            if delay < 0.050:
                delay = delay * 2       # exponential back-off
            if backoffs > 8:
                jammed = True
                break;

        if not jammed:
            self.tb.send_pkt_complete(payload)
        else:
            print "Channel Appears Jammed No Message Sent"


#############################
# Non-blind section
#############################

    def start(self):
        "Start Rendezvous"
        self.stabilize_receiver()
        connected, freq = self.listen_and_attempt_connection()
        if not connected:
            freq = self.perform_blind_rendezvous()
        return freq

    def stabilize_receiver(self):
        self.tb.set_freq(self.start_freq)
        time.sleep(0.200)

    def listen_and_attempt_connection(self):
        print "Listen Channels and Attempt Connection"
        channels_to_ignore = []
        connected = False
        freq = 0
        MAX_TRIES = 5
        for n in range (MAX_TRIES):
            potential_channels = self.find_potential_channels(channels_to_ignore)   
            print "potential channels"
            print potential_channels
            connected, freq, channels_to_ignore = self.attempt_connection(potential_channels, channels_to_ignore)
            if connected:
                break;
        return connected, freq


    def attempt_connection(self,potential_channels, channels_to_ignore):
        connected = False
        freq = 0
        while len(potential_channels) > 0 and not connected:
            chan = self.pick_channel(potential_channels)
            print "try chan %f" % chan
            connected = self.attempt_connection_on_channel(chan)
            if not connected:
                channels_to_ignore.append(chan)
                potential_channels.remove(chan)
        if connected:
            freq = self.calculate_freq(chan)
        return connected, freq, channels_to_ignore
        


    def find_potential_channels(self, channels_to_ignore):
        freqs = self.get_sensing_data()
        numpts = len(freqs)
        channels = []
        for f in freqs:
            channelnum = self.calculate_channel(f)
            if channelnum not in channels_to_ignore and channelnum not in channels:
                channels.append(channelnum)
        return channels


    def get_sensing_data(self):
        sensing_freq = self.start_freq + 12.5e6
        stop_freq = self.start_freq + self.num_channels * self.step_freq
        freqs = []
        while sensing_freq < stop_freq:
            self.tb.set_freq(sensing_freq)
            self.tb.switch_sensing_mode()
            sensing_data = self.tb.sensingpath.get_data()
            freqs_one_band = self.unpack_sensing_data(sensing_data, sensing_freq)
            freqs.extend(freqs_one_band)
            self.tb.sensingpath.clear_data()
            sensing_freq = sensing_freq + 25e6
        self.tb.switch_com_mode()
        return freqs


    def unpack_sensing_data(self,rawdata, sensing_freq):
        freqs = []
        bws = []
        for n in range(0, len(rawdata), 8):
            freq_and_bw = struct.unpack('ff', rawdata[n:n+8])
            freq, bw = freq_and_bw
            allfreqs = self.create_freq_list(freq, bw, sensing_freq)
            freqs.extend(allfreqs)
        return freqs

    #create a list of all frequencies, corresponding to the fft bins, given
    #the freq, bw, and sensing_freq of the collected sensing data
    def create_freq_list(self,freq, bw, sensing_freq):
        FREQ_BIN_WIDTH = self.options.sensing_rate/self.options.fftlen
        allfreqs = []
        centerfreq = freq + sensing_freq
        if freq != -12.5e6: #ignore nyquist freq
            allfreqs.append(centerfreq)
        nextfreq = centerfreq + FREQ_BIN_WIDTH
        binlen = int(round(bw/FREQ_BIN_WIDTH))
        for n in range (binlen-1):
            allfreqs.append(nextfreq)
            nextfreq = nextfreq + FREQ_BIN_WIDTH
        return allfreqs


    def calculate_channel(self,freq):
        chan = round( (freq - self.chan0)/self.step_freq)
        if chan < 0:
            chan = 0.0
        return chan

    def calculate_freq(self, chan):
        return self.chan0 + chan*self.step_freq

    def pick_channel(self, channels):
        numchannels = len(channels)
        indx = random.randint(0, numchannels-1)
        return channels[indx]


###################
#  Attempt connection on one channel
###################
    def attempt_connection_on_channel(self, chan):
        # bug in libboost -- multiple tb.stop() calls will hang the computer
        # fix only in v1.48.  No upgrade available in apt-get yet.
        #self.tb.stop()
        #self.tb.wait()
        self.tb.set_freq(self.start_freq-1e6) #set to inoperable frequency to flush q
        self.qflush()
        self.set_freq(chan)
        connected = False
        got_packets = self.listen_for_packets(duration=2.1)
        if got_packets:
            #self.send_beacon()
            #got_response = self.wait_for_response(duration=1.0)
            #if (got_response):
            #    self.send_ack()
            #    connected = True
            connected = True

        return connected

    def listen_for_packets(self, duration):
        result = False
        now = time.time()
        stoptime = now+duration
        while (now < stoptime):
            payload_found, payload_str = self.check_received_msg()
            not_beacon = not self.is_beacon(payload_str)
            if payload_found and not_beacon:
                result = True;
                break;
            time.sleep(0.001)
            now = time.time()
        return result

            
    def wait_for_response(self, duration):
        result = False
        now = time.time()
        stoptime = now+duration
        while (now < stoptime):
            payload_found, payload_str = self.check_received_msg()
            if payload_found:
                if self.is_response(payload_str):
                    result = True;
                    break;
                else:
                    stoptime += 0.1
                    self.send_beacon()
            time.sleep(0.001)
            now = time.time()
        return result


    def qflush(self):
        while not self.rcvd_msg_q.empty():
            self.rcvd_msg_q.get()
     
    def main():
        pass       

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass
