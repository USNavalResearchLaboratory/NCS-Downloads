import os, sys, time, random
import select
import dsapacketfactory
import dsapacketbuffers
import dsapacket
import sensing
#import policy
import mac_times
from rendezvous_mac import rendezvous_mac
from spectrum_sensing import spectrum_sensing
from cooperative_sensing import cooperative_sensing
from spectrum_decision import spectrum_decision
from time_synch import time_synch
from comstats import comstats

# Constants
START_FREQ = 1600e6
STOP_FREQ = 2000e6
CHANNELS_PER_BAND = 16
SENSING_BAND = 25e6
STEP_FREQ  = SENSING_BAND/CHANNELS_PER_BAND 
NUM_CHANNELS = int ((STOP_FREQ - START_FREQ)/STEP_FREQ)
CHANNEL_ZERO = START_FREQ + STEP_FREQ/2

SENSING_PERIOD = 4

ALLNODES = dsapacket.ALLNODES




# ////////////////////////////////////////////////////////////////////
#                           Carrier Sense MAC
# ////////////////////////////////////////////////////////////////////

class cs_mac(object):
    """
    Prototype carrier sense MAC

    Reads packets from the TUN/TAP interface, and sends them to the
    PHY. Receives packets from the PHY via phy_rx_callback, and sends
    them into the TUN/TAP interface.

    Of course, we're not restricted to getting packets via TUN/TAP,
    this is just an example.
    """

    def __init__(self, tun_fd, options):
        self.tun_fd = tun_fd       # file descriptor for TUN/TAP interface
        self.verbose = options.verbose
        self.tb = None             # top block (access to PHY)
        self.is_server = options.server
        self.synch = options.synch
        self.macid = options.hst
        self.pktfactory = dsapacketfactory.dsapacketfactory()
        self.pktqs = dsapacketbuffers.dsapacketbuffers()
        self.channel = self.freq_to_chan(options.freq)
        self.options = options
        self.comstats = comstats()
        self.in_rendezvous = options.rndvs
        self.sensing = spectrum_sensing(options, START_FREQ, STEP_FREQ, NUM_CHANNELS)
        self.coop_sense = cooperative_sensing(START_FREQ, STEP_FREQ, NUM_CHANNELS, options.server,self.pktqs.fft_sense, self.pktqs.sensing_fused,options.hst, SENSING_PERIOD)
        self.spectrum_decision = spectrum_decision(START_FREQ, STEP_FREQ,NUM_CHANNELS, self.channel)
        self.time_synch = time_synch(self.is_server, self.pktqs.time_req, self.pktqs.time_ack,self.macid )
        self.mac_times = mac_times.mac_times(options)

    def freq_to_chan(self, freq):
        result = int(round((freq - CHANNEL_ZERO)/STEP_FREQ))
        if result < 0:
            result = 0
        if result > NUM_CHANNELS -1:
            result = NUM_CHANNELS - 1
        return result

    def chan_to_freq(self, channelnum):
        return CHANNEL_ZERO + channelnum * STEP_FREQ


    def set_top_block(self, tb):
        self.tb = tb

    def phy_rx_callback(self, ok, payload):
        """
        Invoked by thread associated with PHY to pass received packet up.

        @param ok: bool indicating whether payload CRC was OK
        @param payload: contents of the packet (string)
        """
        if (self.in_rendezvous):
            self.rvmac.phy_rx_callback(ok, payload)
        
        else:
            self.comstats.rxpkts = self.comstats.rxpkts + 1
            if self.verbose:
                print "Rx: ok = %r  len payload = %4d" % (ok, len(payload))
                #self.print_payload_contents(payload)
        
            if ok:
                self.comstats.rxgoodpkts = self.comstats.rxgoodpkts + 1
                pkt = self.pktfactory.create(payload)
                if pkt.src != self.macid:
                    pkt.process_from_rx(self) 
                    
    def print_payload_contents(self, payload):
        import struct
        for n in range(34):
            (val,) = struct.unpack('B', payload[n])
            print "%X" % (val),
        print
    

    def main_loop(self):
        """
        Main loop for MAC.
        FIXME: may want to check for EINTR and EAGAIN and reissue read
        """

        self.rvmac = rendezvous_mac(self.tb, START_FREQ, STEP_FREQ, NUM_CHANNELS, self.options)
        self.rendezvous()
        self.wait_for_first_synch()
        self.mac_times.init()
        while True:
            if self.mac_times.in_quiet_time():
                currentchan = self.channel
                self.print_header(currentchan)
                comfreq = self.chan_to_freq(currentchan)
                inband, outband, outbandfreq = self.sensing.collect_data(self.tb, comfreq, self.mac_times)
                spectrum = self.coop_sense.exchange_data(comfreq, inband, outband, outbandfreq, self.send_pkt, self.mac_times)
                self.channel = self.spectrum_decision.process_sensing_data(currentchan, spectrum)
                if self.synch:
                    self.time_synch.send_packets(self.send_pkt, self.mac_times)                
                self.tb.set_freq(self.chan_to_freq(self.channel))
                self.print_info(currentchan)
                self.comstats.clear()
                self.mac_times.update()

            else:  #check for packets that need to be sent
                self.send_time_ack() 
                self.send_rndvs_response()
                self.send_tun_packet()

    def wait_for_first_synch(self):
        if not self.is_server and self.synch:
            last_try = 0.0
            synched = False
            while not synched:
                self.send_rndvs_response()  #in case server has not completed rendezvous
                time_since_last_try = time.time() - last_try
                if time_since_last_try > 1.0:
                    synched = self.time_synch.get_initial_synch(self.send_pkt)
                    last_try = time.time()
                time.sleep(0.001)
            time.sleep(SENSING_PERIOD)
            self.pktqs.time_ack.flush()
                                                                 
    def rendezvous(self):
        tstamp = 0.0
        if self.options.rndvs:
            self.in_rendezvous = True
            freq = self.rvmac.start()
            self.channel = self.freq_to_chan(freq)
            self.in_rendezvous = False            
        self.tb.set_freq(self.chan_to_freq(self.channel))
        

    def send_tun_packet(self):
        #check tun interface, make non-blocking
        inputready, outputready, exceptready = select.select([self.tun_fd], [], [], 0.0001)
        if len(inputready) > 0:
            ip_data = os.read(self.tun_fd, 10*1024)
            payload = dsapacket.ip_data.make_tx_payload(self.macid, ALLNODES, ip_data)
            time_til_sense = self.mac_times.sensing_start - time.time()
            maxdelay = min(time_til_sense, 0.5)
            #if maxdelay < 0.2:
                #print maxdelay
            self.send_pkt(payload, maxdelay)

    def send_time_ack(self):
        #In case a client completed rendezvous and trying to get initial synch
        #Also helps if time req message received outside window
        if self.is_server and self.synch:
            self.time_synch.check_msgq_and_send_time_ack(self.send_pkt)
            
    def send_rndvs_response(self):
        beacons_received = self.pktqs.rndvs_beacon.count()
        while beacons_received > 0:
            msg = self.pktqs.rndvs_beacon.delete_head()
            payload_beacon = msg.to_string()
            beaconpkt = dsapacket.rndvs_beacon(payload_beacon)
            payload_response = dsapacket.rndvs_response.make_tx_payload(self.macid, beaconpkt.src)
            maxdelay = 0.5
            if self.time_synch.synched:
                maxdelay = self.mac_times.sensing_start - time.time()
            self.send_pkt(payload_response, maxdelay)
            beacons_received = self.pktqs.rndvs_beacon.count()


    def send_pkt(self, payload, maxdelay = 0.5):
        if self.perform_csma_backoff(maxdelay):
            self.tb.comswitch.turn_off() #prevent rx from seeing its own pkts
            self.tb.send_pkt_complete(payload)
            self.tb.comswitch.turn_on()
            self.comstats.txpkts = self.comstats.txpkts + 1
            #sys.stdout.write('t'); sys.stdout.flush()
            
    # Change from exponential to linear backoff
    # randomized backoff not implemented yet        
    def perform_csma_backoff(self, maxdelay):
        result = True
        delay = 0.001               # seconds
        totaldelay = 0
        backoffs = 0
        
        while self.tb.carrier_sensed():
            delay = random.uniform(0.001, 0.003)
            time.sleep(delay)
            backoffs = backoffs + 1
            totaldelay = totaldelay + delay
            if totaldelay >= maxdelay:
                print "Error: Channel Appears Jammed, Dropping Packet"
                result = False
                break
        if backoffs > 0:
            sys.stdout.write('B%02d' % backoffs); sys.stdout.flush()        
        self.comstats.backoffs = self.comstats.backoffs + backoffs
        return result       
        

####################
# Printing Functions
####################

    def print_asterisks(self):
        print "******************************************************"        


    def print_info(self, currentchan):
        print "\nSensing Results:"
        print self.sensing.inband_list, " Bitmap: %d" % self.sensing.inband_bitmap
        print self.sensing.outband_list, " Bitmap: %d" % self.sensing.outband_bitmap, "Freq: %.0f" % (self.sensing.outband_freq/1e6)
        #print "\nFusion  Results:"
        if self.is_server:
            print "Sensing Reports Received from Nodes: ", self.coop_sense.fft_sense_macids
        #print self.coop_sense.fused_inband_list, " Bitmap: %d" % self.coop_sense.fuseinband
        #print self.coop_sense.fused_outband_list, " Bitmap: %d" % self.coop_sense.fuseoutband, "Freq:", self.coop_sense.fuseoutbandfreq
        print "\nSpectrum Decision Results:"
        if self.channel == currentchan:
           act = "Stay"
        else:
           act = "Move"
        print act, "Channel", self.channel, "Freq %.1f" % self.chan_to_freq(self.channel)
        #self.spectrum_decision.print_channels_occupied()
        print "\nAvailable Channels"
        print self.coop_sense.spectrum.available_channels[0:10]
        self.comstats.printout()
        self.print_asterisks()
                
                
    def print_header(self, currentchan):
        self.print_asterisks()
        print "IP Addr 192.168.200.%d" % self.options.hst, "  Sensing Time:", self.mac_times.sensing_start
        print "Server Status: ", self.is_server
        freqmhz = self.chan_to_freq(currentchan)/1e6
        print "Current Channel:", currentchan, "      Freq: %f MHz" % freqmhz
     

