# This is a list of all packet buffers that are needed by the MAC.  This
# especially designed because certain MAC messages, like time request,
# beacon, and fft_sense will result in a response message.  However, the
# received packets are on the phy_rx_callback thread but the transmitting
# should be on the cs_mac thread.  Therefore these queues are used so the
# mac mainloop thread knows when messages are received.

from gnuradio import gr

class dsapacketbuffers(object):
    def __init__(self):
        self.fft_sense = gr.msg_queue()
        self.fft_final = gr.msg_queue()
        self.time_req = gr.msg_queue()
        self.time_ack = gr.msg_queue()
        self.rndvs_beacon = gr.msg_queue()
        self.sensing_fused = gr.msg_queue()
