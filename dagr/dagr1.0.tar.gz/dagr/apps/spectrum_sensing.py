import time, random

class spectrum_sensing(object):
    def __init__(self, options, startfreq, stepfreq, numchannels, start=0.0, mid=0.0, end=0.0):
        self.options = options
        self.startfreq = startfreq
        self.stepfreq = stepfreq
        self.numchannels = numchannels
        self.channels_per_band = int(25e6/stepfreq)
        self.time_start = start
        self.time_mid = mid
        self.time_end = end
        
    def set_times(self, start, mid, end):
        now = time.time()
        #self.time_start = (now - (now % self.period)) + self.period
        self.time_start = start
        self.time_mid = mid
        self.time_end = end
        
    def update_times(self):
        self.time_start = self.time_start + self.period
        self.time_mid = self.time_mid + self.period
        self.time_end = self.time_end + self.period

    def get_sensing_freq(self, comfreq):
        channel = int(round(comfreq-self.startfreq)/self.stepfreq)
        band = channel/self.channels_per_band
        startfreqband = self.startfreq + band*25e6
        return startfreqband + 12.5e6    
        
    def collect_data(self, tb, comfreq, mactimes):
        sensingfreq = self.get_sensing_freq(comfreq)
        tb.set_freq(sensingfreq)

        #wait until middle of window
        now = time.time()
        if now < mactimes.sensing_mid:
            time_until_sensing = mactimes.sensing_mid - now
            time.sleep(time_until_sensing)
        else:
            print "Warning: Entered perform_sensing at %.3f, past mid point: %.2f" % (now, mactimes.sensing_mid)
 
        #in-band sensing
        tb.switch_sensing_mode() 
        self.inband_bitmap, self.inband_list = tb.sensingpath.get_sensing_data()

        #out-of-band
        self.outband_bitmap, self.outband_list, self.outband_freq = self.get_outband_sensing(tb) 

        #switch back to com
        tb.switch_com_mode() 
        tb.set_freq(comfreq)

        #wait until end of window
        now = time.time()
        if now < mactimes.sensing_end:
            time_until_end = mactimes.sensing_end - now
            time.sleep(time_until_end)

        tb.sensingpath.clear_data()
        #self.update_times()

        #Make chan 11, 1842.9MHz occupied -- GMSK does not work!!
        #self.inband_list[11] = 1
        #self.inband_bitmap = self.inband_bitmap | (1<<11)
        return self.inband_bitmap, self.outband_bitmap, self.outband_freq

    def get_outband_sensing(self, tb):
        outband_start_freq, sensingfreq = self.get_outband_freqs('random')
        tb.set_freq(sensingfreq)
        tb.sensingpath.clear_data()
        tb.sensingswitch.skip_samples_then_turn_on(1024, 1024)
        outband_channels_bitmap, outband_channels_list = tb.sensingpath.get_sensing_data()
        return outband_channels_bitmap, outband_channels_list, outband_start_freq
        
    def get_outband_freqs(self, method):
        if method == 'linear':
            #outband sensing freq based on sensing time and total number of 25 MHz bands available
            sensing_time = self.time_start
            total_num_bands = self.numchannels/self.channels_per_band
            #band number determined explicitly by sensing time
            #band number 0 chosen at sensing time 0.  Every period, the band number increments and
            #modulo arithmetic performed based on total number of bands
            bandnum = int(round(sensing_time/self.period)) % total_num_bands
            outbandfreq = self.startfreq + bandnum * 25e6
            sensingfreq = outbandfreq + 12.5e6
            return outbandfreq, sensingfreq
        elif method == 'random':
            total_num_bands = self.numchannels/self.channels_per_band
            bandnum = random.randint(0, total_num_bands-1)
            outbandfreq = self.startfreq + bandnum * 25e6
            sensingfreq = outbandfreq + 12.5e6
            return outbandfreq, sensingfreq
        
        
        
    


        
        
    
