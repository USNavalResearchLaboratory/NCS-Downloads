from gnuradio import gr, uhd
from uhd_interface import uhd_receiver
from uhd_interface import uhd_transmitter
from transmit_path import transmit_path
from receive_path import receive_path
from sensing_path import sensing_path
import sensing
import sys
import time
import dsapacket
# ////////////////////////////////////////////////////////////////////
#                     the flow graph
# ////////////////////////////////////////////////////////////////////

class dsa_top_block(gr.top_block):

    def __init__(self, mod_class, demod_class,
                 rx_callback, options):

        gr.top_block.__init__(self)

        # Get the modulation's bits_per_symbol
        args = mod_class.extract_kwargs_from_options(options)
        symbol_rate = options.bitrate / mod_class(**args).bits_per_symbol()

        self.source = uhd_receiver(options.args, symbol_rate,
                                   options.samples_per_symbol,
                                   options.rx_freq, options.rx_gain,
                                   options.spec, options.antenna,
                                   options.verbose)
        
        self.sink = uhd_transmitter(options.args, symbol_rate,
                                    options.samples_per_symbol,
                                    options.tx_freq, options.tx_gain,
                                    options.spec, options.antenna,
                                    options.verbose)
                                    
        self.amsgq = gr.msg_queue()
        self.amsg = uhd.amsg_source(options.args, self.amsgq)
        
        options.samples_per_symbol = self.source._sps
        self.verbose = options.verbose

        self.txpath = transmit_path(mod_class, options)
        self.rxpath = receive_path(demod_class, rx_callback, options)
        self.sensingpath = sensing_path(options)
        self.comswitch = sensing.switch_cc(is_on = True)
        self.sensingswitch = sensing.switch_cc(is_on = False)

        self.connect(self.txpath, self.sink)
        self.connect(self.source, self.comswitch, self.rxpath)
        self.connect(self.source, self.sensingswitch, self.sensingpath)

    def send_pkt(self, payload='', eof=False):
        return self.txpath.send_pkt(payload, eof)



    # Blocking version of send_pkt, so function returns only when USRP 
    # has finished transmission. This function may not be thread-safe, 
    # however.
    # make sure only one thread is calling this function
    def send_pkt_complete(self, payload='', eof=False):
        self.amsgq.flush()
        payload = self.insert_timestamp(payload)
        self.txpath.send_pkt(payload)
        self.wait_for_packet_completion()
        if self.verbose:
            print "Tx: len(payload) = %4d" % (len(payload),)
        #else:
        #    sys.stdout.write('t')
        #    sys.stdout.flush()
        
    # Due to backoff latency, insert the timestamp in the packet only
    # after backoff performed.  To further reduce error, the timestamp
    # could be done further into the send_pkt functions in
    # transmit_path, or mod_pkts.  Another optimization is to do this
    # within the function, so that the function does not have to return
    # a modified copy of the payload
    
    def insert_timestamp(self, payload):
        return dsapacket.dsapacket.insert_timestamp(payload)
        
        
    def wait_for_packet_completion(self):
        msg = self.amsgq.delete_head()
        data = self.amsg.msg_to_async_metadata_t(msg)
        #print dir(data)
        if data.event_code != data.EVENT_CODE_BURST_ACK:
            print "Error: Did not get BURST_OK from USRP Code:", data.event_code
            self.wait_for_packet_completion()
        
    def carrier_sensed(self):
        """
        Return True if the receive path thinks there's carrier
        """
        return self.rxpath.carrier_sensed()

    def set_freq(self, target_freq):
        """
        Set the center frequency we're interested in.
        """

        self.sink.set_freq(target_freq)
        self.source.set_freq(target_freq)
        
    def set_rx_freq(self, target_freq):
        self.source.set_freq(target_freq)

    def switch_sensing_mode(self):
        self.comswitch.turn_off()
        self.source.u.set_samp_rate(self.sensingpath._sample_rate)
        self.sensingswitch.skip_samples_then_turn_on(1024, 1024)        

    def switch_com_mode(self):
        self.sensingswitch.turn_off()
        self.source.u.set_samp_rate(self.source._rate)
        self.comswitch.turn_on()
