#

from gnuradio import gr, gru, blks2
from gnuradio import eng_notation

import copy
import sys

import sensing
import struct

# /////////////////////////////////////////////////////////////////////////////
#                              sensing path
# /////////////////////////////////////////////////////////////////////////////

class sensing_path(gr.hier_block2):
    def __init__(self, options):
        '''
        See below for what options should hold
        '''
	gr.hier_block2.__init__(self, "sensing_path",
				gr.io_signature(1, 1, gr.sizeof_gr_complex),  # Input signature
				gr.io_signature(0, 0, 0)) # Output signature        
        options = copy.copy(options)    # make a copy so we can destructively modify
        self._fftlen = options.fftlen
        self._verbose = options.verbose
        self._sample_rate = options.sensing_rate

    
        # blocks
        self._blk_stream2vec = gr.stream_to_vector(gr.sizeof_gr_complex, self._fftlen)
        self._blk_fft = gr.fft_vcc(self._fftlen, forward=True, window=(), shift=True) 
        self._blk_vec2stream = gr.vector_to_stream(gr.sizeof_gr_complex, self._fftlen)
        self._blk_fftmag = gr.complex_to_mag()
        self._msgq = gr.msg_queue(4) # org 4
        self._blk_report = sensing.report_sink_f(self._fftlen, options.thres, options.sensing_rate, 0, options.verbose, self._msgq)
        # Display some information about the setup
        if self._verbose:
            self._print_verbage()

        # Connect components in the flowgraph
        #self.connect(self, self._blk_head, self._blk_stream2vec, self._blk_fft,
        #             self._blk_vec2stream, self._blk_fftmag, self._blk_report, self._blk_vecsnk)
        self.connect(self, self._blk_stream2vec, self._blk_fft,
                     self._blk_vec2stream, self._blk_fftmag, self._blk_report)


    def get_data(self):
        msg = self._msgq.delete_head()  #block until message found in queue
        return msg.to_string()       #format float array as string 

    def get_sensing_data(self):
        NUMCHANNELS = 16
        BINFREQ = self._sample_rate/self._fftlen
        MINFREQ = -self._sample_rate/2
        BINS_PER_CHANNEL = self._fftlen/NUMCHANNELS
        channels_occupied_list = [0]*NUMCHANNELS
        sensing_block_data = self.get_data()
        for byteno in range(0, len(sensing_block_data), 8):
            freq, bw = struct.unpack('ff', sensing_block_data[byteno:byteno+8])
            fftbin = int(round((freq - MINFREQ)/BINFREQ))
            fftbinlen = int(round(bw/BINFREQ))
            for n in range(fftbin, fftbin+fftbinlen):
                #disregard n=0 which is Nyquiest FFT bin
                #this bin is indeterminate and causes sensing errors
                if n > 0:  
                    channel = n/BINS_PER_CHANNEL
                    channels_occupied_list[channel] = 1
        channels_occupied_bitmap = 0
        bitmask = 1
        for chan in channels_occupied_list:
            if chan == 1:
                channels_occupied_bitmap = channels_occupied_bitmap | bitmask 
            bitmask = bitmask << 1
        return (channels_occupied_bitmap, channels_occupied_list)
       

            

    def clear_data(self):
        self._msgq.flush()

    def add_options(normal, expert):
        """
        Adds transmitter-specific options to the Options Parser
        """
        normal.add_option("-v", "--verbose", action="store_true", default=False)
        expert.add_option("--thres", type="eng_float", default=1.0,
                              help="Set sensing threshold [default=%default].")

#        expert.add_option("--sensing-rate", type="eng_float", default=5e6,
#                          help="set sample rate of sensing block [default=%default].")
        expert.add_option("--sensing-rate", type="eng_float", default=25e6,
                          help="set sample rate of sensing block [default=%default].")

        expert.add_option("--fftlen", type="int", default=1024,
                          help="set fft length of sensing block [default=%default].")


    # Make a static method to call before instantiation
    add_options = staticmethod(add_options)

    def _print_verbage(self):
        """
        Prints information about the transmit path
        """
        pass   

    def data(self):
        return self._blk_vecsnk.data()

    def clear(self):
        self._blk_vecsnk.clear()     
