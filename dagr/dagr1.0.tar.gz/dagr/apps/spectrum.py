import time, random
import numpy as np

SENSING_HISTORY = 64

class spectrum (object):
    def __init__(self, server, startfreq, stepfreq, num_channels):
        self.is_server = server
        self.startfreq = startfreq
        self.stepfreq = stepfreq
        self.num_channels = num_channels
        self.CHANNELS_PER_BAND = 16
        self.BAND_SIZE = 25e6
        self.channels_occupied = [0]*num_channels
        self.channels_history = np.zeros( (num_channels, SENSING_HISTORY), dtype=int)
        self.available_channels = []
        self.rcvd_sensing_fused = False
        
    def is_occupied(self, chan):
        return self.channels_occupied[chan] == 1

    def is_available(self, chan):
        result = chan in self.available_channels
        #print "result avail", result, self.available_channels
        if self.is_server is False and self.rcvd_sensing_fused is False:
            #self.available_channels is old so look at intband results
            inbandstartchan = int((self.inbandfreq - self.startfreq)/self.stepfreq)
            if chan in range(inbandstartchan, inbandstartchan + self.CHANNELS_PER_BAND):
                index = chan - inbandstartchan
                result = self.inband[index] == 0
        return result
            
    def clear_channels_occupied(self):
        for n in range(len(self.channels_occupied)):
            self.channels_occupied[n] = 0
    
    def set_rcvd_sensing_fused(self, boolval):
        self.rcvd_sensing_fused = boolval

    def set_inband_results(self, inbandfreq, inband):
        self.inbandfreq = inbandfreq
        self.inband = inband     
        
    def update_sensing_data(self, comfreq, inband, outbandfreqstart, outband):
        inbandfreqstart = self.get_start_band_freq(comfreq)        
        self.frequencies_reported = [inbandfreqstart]
        self.set_channels_occupied(inbandfreqstart, inband)
        if outbandfreqstart != inbandfreqstart:
            self.frequencies_reported.append(outbandfreqstart)
        self.set_channels_occupied(outbandfreqstart, outband) 
        
    def get_start_band_freq(self,freq):
        chan = int((freq - self.startfreq)/self.stepfreq)
        bandnum = int (chan/self.CHANNELS_PER_BAND)
        return self.startfreq + bandnum * self.BAND_SIZE

    def set_channels_occupied(self, startfreqband, sensingdata):
        start_index = int(round(startfreqband - self.startfreq)/self.stepfreq)
        self.channels_occupied[start_index:start_index + self.CHANNELS_PER_BAND] = sensingdata
                
    ##update history with new calculated channels_occupied data    
    def update_history(self):
        HISTORY_AXIS = 1
        co = np.array(self.channels_occupied, ndmin=2)
        co = co.transpose()
        self.channels_history = np.append(self.channels_history, co, HISTORY_AXIS)
        self.channels_history = np.delete(self.channels_history, 0, HISTORY_AXIS)
            
    def update_available_channels(self, current_channel, method):
        if method == "random":
            self.update_available_channels_random(current_channel)
        elif method == "increase-by-3":
            self.update_available_channels_increase3(current_channel)
        else:
            print "Cannot interpret method:", method
        return self.available_channels
        
    def print_sum_history(self):
        sum_history = np.sum(self.channels_history, 1)
        rows = len(sum_history)/16
        for n in range(rows):
            print 16*n, sum_history[16*n:16*(n+1)]

    def update_available_channels_random(self, current_channel):
        #self.print_sum_history()        
        (open_channels, open_channels_sum_history) = self.get_open_channels()
        sorted_index = np.argsort(open_channels_sum_history)
        shuffled_index = self.shuffle_min_indices(sorted_index, open_channels_sum_history)
        self.available_channels = []
        for n in shuffled_index:
            self.available_channels.append(open_channels[n])

    def get_open_channels(self):
        channels_occupied = np.array(self.channels_occupied)
        (open_channels,) = np.where(channels_occupied == 0)
        sum_history = np.sum(self.channels_history, 1)
        open_channels_sum_history = sum_history[open_channels]
        return open_channels, open_channels_sum_history


    #In the event that open_channels_sum_history contain more than one minimum,
    #take its corresponding sorted_index and randomize it
    def shuffle_min_indices(self,sorted_index, open_channels_sum_history):
        minval = np.min(open_channels_sum_history)
        (minimum_indices,) = np.where(open_channels_sum_history == minval)   
        mins_to_shuffle = len(minimum_indices)
        #print "mins", mins_to_shuffle, "minval", minval
        shuffled = sorted_index[0:mins_to_shuffle]
        np.random.shuffle(shuffled)
        
        nonshuffled = sorted_index[mins_to_shuffle :]
        return np.concatenate([shuffled, nonshuffled])
                            
    def update_available_channels_increase3(self, current_channel):            
        self.available_channels = []
        chan_index = current_channel + 3
        if chan_index >= self.num_channels:
            chan_index = chan_index - self.num_channels
        for n in range (self.num_channels):
            if chan_index != current_channel:
                if self.channels_occupied[chan_index] == 0:
                    self.available_channels.append(chan_index)
            chan_index = chan_index + 1
            if chan_index >= self.num_channels:
                chan_index = chan_index - self.num_channels

        if len(self.available_channels) == 0:
            print "Error: Could not create available channels"
            self.available_channels.append(current_channel)             
        
    def fuse_sensing_data(self, comfreq, fftsensepkt):
        inbandfreqstart = self.get_start_band_freq(comfreq)
        inband = self.chan_bitmap_to_list(fftsensepkt.inband, self.CHANNELS_PER_BAND)
    
        if inbandfreqstart not in self.frequencies_reported:
                self.frequencies_reported.append(inbandfreqstart)
                self.set_channels_occupied(inbandfreqstart, inband)
        else:
            self.fuse_channels_occupied(inbandfreqstart, inband)
            
        outbandfreqstart = fftsensepkt.outbandfreq
        outband = self.chan_bitmap_to_list(fftsensepkt.outband, self.CHANNELS_PER_BAND)
        if outbandfreqstart not in self.frequencies_reported:
            self.frequencies_reported.append(outbandfreqstart)
            self.set_channels_occupied(outbandfreqstart, outband)
        else:
            self.fuse_channels_occupied(outbandfreqstart, outband)
            
       
    def fuse_channels_occupied(self, bandfreq, sensingdata):
       startindex = int(round ((bandfreq - self.startfreq)/self.BAND_SIZE))
       sensingdataiter = iter(sensingdata)
       for n in range(startindex, startindex + self.CHANNELS_PER_BAND):
           s = sensingdataiter.next()
           self.channels_occupied[n] = self.channels_occupied[n] | s 
           
    def chan_bitmap_to_list(self, bitmap, channels):
        chanlist = [0]* channels
        newbitmap = self.extract_lower_bits(bitmap, channels)
       
        bitmask = 1  
        for n in range(channels):
            bitval = newbitmap & bitmask
            if bitval > 0:
                chanlist[n] = 1
            else:
                chanlist[n] = 0
            bitmask = bitmask << 1
        return chanlist
           
    def extract_lower_bits(self, bitmap, numbits):
       lower_bits_mask = 0
       for n in range(numbits):
           lower_bits_mask = lower_bits_mask | (1 << n)
       return (bitmap & lower_bits_mask)
    
    
    
    

