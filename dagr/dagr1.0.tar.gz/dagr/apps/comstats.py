
class comstats(object):
    def __init__(self):
        self.clear()
        
    def clear(self):
        self.rxpkts = 0
        self.rxgoodpkts = 0
        self.txpkts = 0
        self.backoffs = 0
        
    def printout(self):
        print "\nPackets Received Total:%4d          OK: %d" % (self.rxpkts, self.rxgoodpkts)
        print   "Packets Transmited    :%4d    Backoffs: %d" % (self.txpkts, self.backoffs) 
        if self.txpkts > 0:
            avg = float(self.backoffs)/self.txpkts
        else:
            avg = 0.0
        print "Backoffs per Transmit :  %.2f" % avg

    
    
    
