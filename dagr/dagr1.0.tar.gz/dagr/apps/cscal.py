#!/usr/bin/env python
#


# ////////////////////////////////////////////////////////////////////
#
#    This code sets up up a virtual ethernet interface (typically
#    gr0), and relays packets between the interface and the GNU Radio
#    PHY+MAC
#
#    What this means in plain language, is that if you've got a couple
#    of USRPs on different machines, and if you run this code on those
#    machines, you can talk between them using normal TCP/IP
#    networking.
#
# ////////////////////////////////////////////////////////////////////

START_FREQ = 1825.78125e6
STOP_FREQ  = 1849.21875e6
STEP_FREQ  = 1.5625e6
SENSING_FREQ = 1837.5e6
NUM_CHANNELS = 16


from gnuradio import gr, digital
from gnuradio import eng_notation
from gnuradio.eng_option import eng_option
from optparse import OptionParser

# from current dir
from receive_path  import receive_path
from transmit_path import transmit_path
from uhd_interface import uhd_transmitter
from uhd_interface import uhd_receiver
from dsa_top_block import dsa_top_block
from sensing_path import sensing_path
from cs_mac import cs_mac

import os, sys, math
import random, time, struct

#print os.getpid()
#raw_input('Attach and press enter')

# ////////////////////////////////////////////////////////////////////
#
#   Use the Universal TUN/TAP device driver to move packets to/from
#   kernel
#
#   See /usr/src/linux/Documentation/networking/tuntap.txt
#
# ////////////////////////////////////////////////////////////////////

# Linux specific...
# TUNSETIFF ifr flags from <linux/tun_if.h>

IFF_TUN		= 0x0001   # tunnel IP packets
IFF_TAP		= 0x0002   # tunnel ethernet frames
IFF_NO_PI	= 0x1000   # don't pass extra packet info
IFF_ONE_QUEUE	= 0x2000   # beats me ;)

def open_tun_interface(tun_device_filename):
    from fcntl import ioctl
    
    mode = IFF_TAP | IFF_NO_PI
    TUNSETIFF = 0x400454ca

    tun = os.open(tun_device_filename, os.O_RDWR)
    ifs = ioctl(tun, TUNSETIFF, struct.pack("16sH", "gr%d", mode))
    ifname = ifs[:16].strip("\x00")
    return (tun, ifname)
    


def set_options(mods, demods):        
    parser = OptionParser (option_class=eng_option, conflict_handler="resolve")
    expert_grp = parser.add_option_group("Expert")
    parser.add_option("-m", "--modulation", type="choice", choices=mods.keys(),
                      default='gmsk',
                      help="Select modulation from: %s [default=%%default]"
                            % (', '.join(mods.keys()),))

    parser.add_option("-s", "--size", type="eng_float", default=1500,
                      help="set packet size [default=%default]")
    parser.add_option("-v","--verbose", action="store_true", default=False)
    parser.add_option("", "--hst", type="int", default=1,
                          help="set virtual IP host number for 192.168.200.XXX")
    parser.add_option("", "--server", action="store_true", default=False,
                          help="set node as server for time synch and sensing")
    parser.add_option("", "--synch", action="store_true", default=False,
                          help="send time synchronization packets across MAC")
    expert_grp.add_option("-c", "--carrier-threshold", type="eng_float", default=-45,
                          help="set carrier detect threshold (dB) [default=%default]")
    expert_grp.add_option("","--tun-device-filename", default="/dev/net/tun",
                          help="path to tun device file [default=%default]")
    expert_grp.add_option("","--no-rndvs", action="store_false",default=True, dest="rndvs",
                          help="skip rendezvous initialization")
   

    transmit_path.add_options(parser, expert_grp)
    receive_path.add_options(parser, expert_grp)
    uhd_receiver.add_options(parser)
    uhd_transmitter.add_options(parser)
    sensing_path.add_options(parser, expert_grp)

    for mod in mods.values():
        mod.add_options(expert_grp)

    for demod in demods.values():
        demod.add_options(expert_grp)
   
    return parser, expert_grp

def enable_realtime_scheduling():
    r = gr.enable_realtime_scheduling()
    if r == gr.RT_OK:
        realtime = True
    else:
        realtime = False
        print "Note: failed to enable realtime scheduling"
    return r

def print_tb_specs(tb, options):
    if tb.txpath.bitrate() != tb.rxpath.bitrate():
        print "WARNING: Transmit bitrate = %sb/sec, Receive bitrate = %sb/sec" % (
            eng_notation.num_to_str(tb.txpath.bitrate()),
            eng_notation.num_to_str(tb.rxpath.bitrate()))
             
    print "modulation:     %s"   % (options.modulation,)
    print "freq:           %s"      % (eng_notation.num_to_str(options.tx_freq))
    print "bitrate:        %sb/sec" % (eng_notation.num_to_str(tb.txpath.bitrate()),)
    print "samples/symbol: %3d" % (tb.txpath.samples_per_symbol(),)

    tb.rxpath.set_carrier_threshold(options.carrier_threshold)
    print "Carrier sense threshold:", options.carrier_threshold, "dB"
    print

def allocate_virtual_ethernet(tun_ifname, options):
    print "Allocated virtual ethernet interface: %s" % (tun_ifname,)
    cmd = "sudo ifconfig %s 192.168.200.%d" % (tun_ifname, options.hst) 
    print "Automatically running command: '%s'" % cmd 
    time.sleep(1.0) 
    os.system(cmd)


# /////////////////////////////////////////////////////////////////////////////
#                                   main
# /////////////////////////////////////////////////////////////////////////////

def main():

    mods = digital.modulation_utils.type_1_mods()
    demods = digital.modulation_utils.type_1_demods()

    parser, expert_grp = set_options(mods, demods)
    (options, args) = parser.parse_args ()

    if len(args) != 0:
        parser.print_help(sys.stderr)
        sys.exit(1)

    # open the TUN/TAP interface
    (tun_fd, tun_ifname) = open_tun_interface(options.tun_device_filename)

    # Attempt to enable realtime scheduling
    r = enable_realtime_scheduling()
    
    #freq = perform_rendezvous(mods, demods, options)

    # instantiate the MAC
    mac = cs_mac(tun_fd, options)

    # build the graph (PHY)
    tb = dsa_top_block(mods[options.modulation],
                      demods[options.modulation],
                      mac.phy_rx_callback,
                      options)

    mac.set_top_block(tb)    # give the MAC a handle for the PHY
  
    print_tb_specs(tb, options)
    allocate_virtual_ethernet(tun_ifname, options)

    tb.start()    # Start executing the flow graph (runs in separate threads)

    while True:
        pwr = tb.rxpath.probe.level()
        if pwr > 0.0:
            print "Probe Level: %.2f dB " % (10.0*math.log10(tb.rxpath.probe.level()))
        time.sleep(0.25)


                

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass
