import dsapacket, sensing
import time, random

ALLNODES = dsapacket.ALLNODES
TIME_ACK_DELAY = 0.010

class time_synch(object):

    def __init__(self, is_server, msgq_time_req, msgq_time_ack,macid, start_time = 0.0):
        self.is_server = is_server
        self.start_time = start_time
        self.msgq_time_req = msgq_time_req
        self.msgq_time_ack = msgq_time_ack
        self.macid = macid
        self.synched = False
        

    def get_initial_synch(self, sendpktfunc):
        if not self.is_server:
            print "Attempting Initial Time Synchronization"
            self.send_time_req(sendpktfunc)
            time.sleep(0.010)
            self.synched = self.check_time_acks_and_synch(offset_factor=1.0)
            return self.synched
        

    def send_packets(self, sendpktfunc, mactimes):
        now = time.time()
        if self.is_server:
            self.wait_until (mactimes.time_ack)
            self.check_msgq_and_send_time_ack(sendpktfunc)
            self.wait_until (mactimes.time_ack + 2*TIME_ACK_DELAY)
        else:
            self.wait_until (mactimes.time_req)
            time.sleep(random.uniform(0.000, 0.010)) #give all nodes chance to be first
            self.send_time_req(sendpktfunc)
            self.wait_until (mactimes.time_ack + TIME_ACK_DELAY)
            self.check_time_acks_and_synch(offset_factor=0.1)
            self.wait_until (mactimes.time_ack + 2*TIME_ACK_DELAY)
        #self.update_times()
            
    def check_msgq_and_send_time_ack(self, sendpktfunc):
        msgq = self.msgq_time_req
        while not msgq.empty_p():
            msg = msgq.delete_head()
            time_req_rcvd = msg.arg1()    
            rxpayload = msg.to_string()
            rxpkt = dsapacket.time_req(rxpayload)
            #make time_ack
            src = self.macid
            dst = rxpkt.src
            txpayload = dsapacket.time_ack.make_tx_payload(src, dst, rxpkt.timestamp, time_req_rcvd)
            sendpktfunc(txpayload)

    def check_time_acks_and_synch(self, offset_factor):
        result = False
        while not self.msgq_time_ack.empty_p():
            msg = self.msgq_time_ack.delete_head()
            ack_rcvd = msg.arg1()
            payload = msg.to_string()
            pkt = dsapacket.time_ack(payload)
            if pkt.dst == self.macid:
                ack_sent = pkt.timestamp
                req_sent = pkt.time_req_sent
                req_rcvd = pkt.time_req_rcvd
                self.synch_time(req_sent, req_rcvd, ack_sent, ack_rcvd, offset_factor)
                result = True
                if offset_factor == 1.0:
                    break
        return result
            
    def synch_time(self, req_sent, req_rcvd, ack_sent, ack_rcvd, offset_factor):
        offset1 = req_rcvd - req_sent
        offset2 = ack_sent - ack_rcvd
        offset = (offset1 + offset2)/2.0
        delay = offset1 - offset2
        adjustment = offset_factor * offset
        newtime = time.time() + adjustment
        sensing.settime(newtime)
        print "Time Synch offset: %.4f delay %.4f factor %.2f" % (offset, delay, offset_factor)
            
    def wait_until (self, timeval):
        now = time.time()
        delay = timeval - now
        if delay > 0:
            time.sleep(delay)
                                   
    def send_time_req(self, sendpktfunc):
        #important to do a randomized backoff before send -- give other nodes a chance to win
        time.sleep(random.uniform(0.000, 0.010))
        now = time.time()
        payload = dsapacket.time_req.make_tx_payload(self.macid, ALLNODES)
        sendpktfunc(payload)

    
    def send_time_req_init(self, sendpktfunc):
        #important to do a randomized backoff before send -- give other nodes a chance to win
        time.sleep(random.uniform(0.000, 0.010))
        now = time.time()
        payload = dsapacket.time_req_init.make_tx_payload(self.macid, ALLNODES)
        sendpktfunc(payload)

