#!/usr/bin/env python

import sensing
import sys, time

time_offset = float(sys.argv[1])
newtime = time.time() + time_offset
sensing.settime(newtime)



