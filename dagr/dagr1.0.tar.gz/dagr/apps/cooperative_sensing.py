import dsapacket, time, random
import spectrum

ALLNODES = dsapacket.ALLNODES

class cooperative_sensing(object):
    def __init__(self, startfreq, stepfreq, num_channels, is_server, fftsenseq,fusedq, macid, period):
        self.is_server = is_server
        self.sensing_fused_q = fusedq
        self.fft_sense_q = fftsenseq
        self.macid = macid
        self.num_channels = num_channels
        self.period = period
        self.CHANNELS_PER_BAND = 16
        self.startfreq = startfreq
        self.stepfreq = stepfreq
        #self.channels_occupied = [0]*self.num_channels
        self.channels_available = [0]
        self.spectrum = spectrum.spectrum(is_server, startfreq, stepfreq, num_channels)
            

    def check_in_range(self, freq, startfreq, stopfreq):
        if (startfreq <= freq) and (freq <= stopfreq):
            result = 1
        else:
            result = 0
        return result



    def get_start_band_freq(self, freq):
        chan = int ((freq - self.startfreq)/self.stepfreq)
        bandnum = chan/self.CHANNELS_PER_BAND
        return bandnum * self.CHANNELS_PER_BAND*self.stepfreq + self.startfreq
    
    def exchange_data(self, comfreq, inband, outband, outbandfreq, sendpktfunction, mactimes):
        inlist = self.chan_bitmap_to_list(inband, self.CHANNELS_PER_BAND)
        inbandfreq = self.get_start_band_freq(comfreq)
        self.spectrum.set_inband_results(inbandfreq, inlist)
        outlist = self.chan_bitmap_to_list(outband, self.CHANNELS_PER_BAND)
        if self.is_server:
            self.fuseoutbandfreq = outbandfreq
            #wait 100 ms for all fft_sense to come in
            delay = self.wait_until(mactimes.fft_final_send)
            if delay > 0:
                self.spectrum.clear_channels_occupied()
                self.fuse_sensing_data(comfreq, inlist, outlist, outbandfreq)
                self.spectrum.update_history()
                self.spectrum.update_available_channels(comfreq, 'random')
                #SEND AVAILABLE CHANNELS

                payload = dsapacket.sensing_fused.make_tx_payload(self.macid, ALLNODES, self.startfreq, self.stepfreq, self.num_channels, self.spectrum.available_channels)
                sendpktfunction(payload)
            
        else:
            self.wait_until(mactimes.fft_sense)
            payload = dsapacket.fft_sense.make_tx_payload(self.macid, ALLNODES, inband, outband, outbandfreq)
            random_delay = random.uniform(0.0, 0.02)
            time.sleep(random_delay)
            sendpktfunction(payload)
            #print "rdel", random_delay
            #need new pkt that sends chan available
            pkt_found = self.wait_for_sensing_fused(mactimes.fft_final_recv)
                
        #self.update_times()
        return self.spectrum

    def wait_until(self, thistime):
        now = time.time()
        delay = thistime - now
        if delay > 0:
            time.sleep(delay)
        return delay
        

    def wait_for_sensing_fused(self, fft_final_recv):
        pkt_found = False
        msgq = self.sensing_fused_q
        self.wait_until(fft_final_recv)
        while not msgq.empty_p():
            payload = msgq.delete_head().to_string()
            dsapkt = dsapacket.sensing_fused(payload)
            print "Pkt Sensing Fused Received"
            pkt_found = True

        if pkt_found is True:
            self.spectrum.available_channels = dsapkt.available_channels
            self.spectrum.set_rcvd_sensing_fused(True)
        else:   
            self.spectrum.set_rcvd_sensing_fused(False)
            print "ERROR COULD NOT FIND SENSING_FUSED"

        return pkt_found

    def fuse_sensing_data(self, comfreq, inband, outband, outbandfreq):
        self.spectrum.update_sensing_data(comfreq, inband, outbandfreq, outband)
        msgq = self.fft_sense_q
        cnt = 0
        self.fft_sense_macids = []
        while(not msgq.empty_p()):
            msg = msgq.delete_head()
            payload = msg.to_string()
            sensepkt = dsapacket.fft_sense(payload)
            self.spectrum.fuse_sensing_data(comfreq, sensepkt)
            self.fft_sense_macids.append(sensepkt.src)

    def chan_list_to_bitmap(self,chanlist):
        bitmap = 0
        bitmask = 1
        for chan in chanlist:
            if chan == 1:
                bitmap = bitmap | bitmask 
            bitmask = bitmask << 1
        return bitmap

    def chan_bitmap_to_list(self, bitmap, channels):
        chanlist = [0]* channels
        newbitmap = self.extract_lower_bits(bitmap, channels)
       
        bitmask = 1  
        for n in range(channels):
            bitval = newbitmap & bitmask
            if bitval > 0:
                chanlist[n] = 1
            else:
                chanlist[n] = 0
            bitmask = bitmask << 1
        return chanlist
            
    def extract_lower_bits(self, bitmap, numbits):
       lower_bits_mask = 0
       for n in range(numbits):
           lower_bits_mask = lower_bits_mask | (1 << n)
       return (bitmap & lower_bits_mask)


