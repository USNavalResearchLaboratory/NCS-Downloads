import time, random

#Keep a list of channels that do not seem to work well on USRP2
usrp2_bad_channels = [27, 100, 59]


class spectrum_decision(object):
    def __init__(self, startfreq, stepfreq, num_channels, currentchan):
        self.startfreq = startfreq
        self.stepfreq = stepfreq
        self.num_channels = num_channels
        self.last_available_channels = [currentchan]

    def process_sensing_data(self, current_channel, spectrum):
        newchan = current_channel
        if spectrum.is_available(current_channel) is False:
            #jump on available channels created the sensing window beforehand
            #for easier debugging
            newchan = self.find_new_channel(spectrum)
        self.last_available_channels = spectrum.available_channels
        return newchan

    # find new channel to jump to, based on the last set of available
    # channels, this is done because the most recent available_chans
    # may contain incomplete data due to jamming
    def find_new_channel(self, spectrum):
        newchanfound = False
        for chan in self.last_available_channels:
            if spectrum.is_available(chan) and chan not in usrp2_bad_channels:
                new_channel = chan
                newchanfound = True
                break
        if newchanfound is False:
            print "Error: All Available channels are occupied!"
            new_channel = self.last_available_channels[0]
        return new_channel

 
