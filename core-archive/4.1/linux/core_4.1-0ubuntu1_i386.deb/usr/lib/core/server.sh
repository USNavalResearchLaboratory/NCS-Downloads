#! /bin/sh
#
# Copyright 2005-2010 the Boeing Company.
# See the LICENSE file included in this distribution.
#
LIBDIR=@CORE_LIB_LIBDIR@
PORT=2547
DEBUG=""
DO_DAEMON=0
DO=start
NEXT_LOG=0
LOG=/var/log/core_exec_server.log

# read command-line parameters
if test a$1 != "a"
then
for arg in $1 $2 $3 $4 $5 $6 $7 $8 $9
do
  case "$arg" in
    -d)
    	echo "Will run as background daemon."
	DO_DAEMON=1
	;;
    -l)
	NEXT_LOG=1
	;;
    -v)
    	echo "Verbose debugging turned on."
	DEBUG="debug"
	;;
    start|stop|restart)
	DO=$arg
	;;
    -h|*)
	# grab log file name
	if test $NEXT_LOG != 0
	then
	  LOG=$arg
	  NEXT_LOG=0
	  continue
	fi

	# help message
	echo "usage: $0 [-d] [-l logfile] [-v] [start|stop|restart]";
	echo "  -d   daemonize, run in background"
	echo "  -l logfile     specify log file path name"
	echo "  -v   verbose debugging"
	echo -n "  start|stop|restart   start/stop the server, "
	echo "default action is start"
	exit 1;
  esac
done
fi


# superuser check
if test `id -u` != 0
then
    echo This must be run as root.
    exit 1
fi

# locate tclsh8.x
TCLLIST="/usr/local/bin/tclsh8.5 /usr/bin/tclsh8.5"
TCLLIST="$TCLLIST /usr/local/bin/tclsh8.4 /usr/bin/tclsh8.4"
for tclbin in $TCLLIST
do
    if [ -x $tclbin ]; then
	TCL=$tclbin;
	break;
    fi;
done;

if [ a$TCL = a ]
then
    echo "CORE could not locate the Tclsh binary (tclsh8.5/tclsh8.4)."
    exit 1;
fi;

# kill processes
PID=`ps ax | grep "$TCL $LIBDIR/exec_s" | grep -v grep | awk '{ print $1}'`
SPAN_PID=`ps ax | grep "span -d" | grep -v grep | awk '{ print $1}'`

case "$DO" in
  start)
    if test a$PID != "a"
    then
	echo CORE exec_server.tcl is already running with PID $PID
	FATAL=1
    fi
    if test a$SPAN_PID != "a"
    then
	echo CORE span is already running with PID $SPAN_PID
	FATAL=1
    fi
    if test a$FATAL != a
    then
	echo Use the stop or restart commands.
	exit 1
    fi
    ;;

  stop|restart)
    echo Stopping exec_server.tcl and span servers...
    if test a$PID = "a"
    then
	echo CORE exec_server.tcl is not running.
    else
	echo Stopping CORE exec_server with PID $PID...
	kill $PID
    fi
    if test a$SPAN_PID = "a"
    then
	echo CORE span is not running.
    else
	echo Stopping CORE span with PID $SPAN_PID...
	kill $SPAN_PID
    fi
    if test $DO = "stop"
    then
	exit
    fi
    echo Removing logs /var/log/span.log and $LOG...
    rm -f /var/log/span.log $LOG
  ;;
esac

if test $DO = restart
then
    DO_DAEMON=1
fi

# launch processes
echo "Starting Span..."
span -d

echo "Launching $LIBDIR/exec_server.tcl on port $PORT..."
if test $DO_DAEMON != 0
then
    echo Running as daemon with log $LOG
    echo -n "--- starting exec_server.tcl " >> $LOG
    date >> $LOG
    $TCL $LIBDIR/exec_server.tcl $PORT $DEBUG >> $LOG 2>&1 < /dev/null &
else
    $TCL $LIBDIR/exec_server.tcl $PORT $DEBUG
fi
