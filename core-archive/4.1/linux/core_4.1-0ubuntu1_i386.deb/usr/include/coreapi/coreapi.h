/*
 * CORE API
 * (c)2008 the Boeing Company.
 * See the LICENSE file included in this distribution.
 *
 * Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
 *
 * CORE API definitions.
 *
 */

#ifndef COREAPI_H
#define COREAPI_H

/*
 * Constants
 */
#define CORE_API_VER 1.16
#define CORE_API_PORT			4038
#define CORE_API_SPAN_PORT		4039
#define CORE_API_EMU_PORT		4040

/* Message types */
#define CORE_API_NODE_MSG 		0x01
#define CORE_API_LINK_MSG 		0x02
#define CORE_API_EXEC_MSG 		0x03
#define CORE_API_REG_MSG 		0x04
#define CORE_API_CONF_MSG 		0x05
#define CORE_API_FILE_MSG		0x06
#define CORE_API_IFACE_MSG		0x07
#define CORE_API_EVENT_MSG		0x08
#define CORE_API_MSG_MAX 		0x09

/* Message Flags */
#define CORE_API_ADD_FLAG 		0x01
#define CORE_API_DEL_FLAG 		0x02
#define CORE_API_CRI_FLAG 		0x04
#define CORE_API_LOC_FLAG		0x08
#define CORE_API_STR_FLAG		0x10
#define CORE_API_TXT_FLAG		0x20
#define CORE_API_TTY_FLAG		0x40

/* Node Message TLV Types */
#define CORE_TLV_NODE_NUMBER		0x01
#define CORE_TLV_NODE_TYPE		0x02
#define CORE_TLV_NODE_NAME		0x03
#define CORE_TLV_NODE_IPADDR		0x04
#define CORE_TLV_NODE_MACADDR		0x05
#define CORE_TLV_NODE_IP6ADDR		0x06
#define CORE_TLV_NODE_MODEL		0x07
#define CORE_TLV_NODE_EMUSRV		0x08
#define CORE_TLV_NODE_XPOS		0x20
#define CORE_TLV_NODE_YPOS		0x21
#define CORE_TLV_NODE_CANVAS		0x22
#define CORE_TLV_NODE_EMUID		0x23
#define CORE_TLV_NODE_NETID		0x24
#define CORE_TLV_NODE_LAT		0x30
#define CORE_TLV_NODE_LONG		0x31
#define CORE_TLV_NODE_ALT		0x32
#define CORE_TLV_NODE_HEADING		0x33
#define CORE_TLV_NODE_PTYPE		0x40
#define CORE_TLV_NODE_PID		0x41
#define CORE_TLV_NODE_ICON		0x42
#define CORE_TLV_NODE_OPAQUE		0x50

/* Node Message TLV Values */
enum NodeTypeVals {
	router_quagga,
	router_xorp,
	host,
	PC,
	switch_,
	hub,
	wlan,
	rj45,
	tunnel,
	ktunnel,
	emane,
};

/* Node Model TLV Values for type=0 router_quagga */
enum NodeQuaggaModelVals {
	wireless,
	wired,
	static_,
	dummy,
	remote,
};

/* Node Model TLV Values for type=7 rj45 */
enum NodeRJ45ModelVals {
	rj45_linked,
	rj45_wireless,
	rj45_installed,
};


/* Link Message TLV Types */
#define CORE_TLV_LINK_N1NUMBER		0x01
#define CORE_TLV_LINK_N2NUMBER		0x02
#define CORE_TLV_LINK_DELAY		0x03
#define CORE_TLV_LINK_BW		0x04
#define CORE_TLV_LINK_PER		0x05
#define CORE_TLV_LINK_DUP		0x06
#define CORE_TLV_LINK_JITTER		0x07
#define CORE_TLV_LINK_MER		0x08
#define CORE_TLV_LINK_BURST		0x09
#define CORE_TLV_LINK_MBURST		0x10
#define CORE_TLV_LINK_TYPE		0x20
#define CORE_TLV_LINK_EMUID		0x23
#define CORE_TLV_LINK_NETID		0x24
#define CORE_TLV_LINK_IF1NUM		0x30
#define CORE_TLV_LINK_IF1IP4		0x31
#define CORE_TLV_LINK_IF1IP4MASK	0x32
#define CORE_TLV_LINK_IF1MAC		0x33
#define CORE_TLV_LINK_IF1IP6		0x34
#define CORE_TLV_LINK_IF1IP6MASK	0x35
#define CORE_TLV_LINK_IF2NUM		0x36
#define CORE_TLV_LINK_IF2IP4		0x37
#define CORE_TLV_LINK_IF2IP4MASK	0x38
#define CORE_TLV_LINK_IF2MAC		0x39
#define CORE_TLV_LINK_IF2IP6		0x40
#define CORE_TLV_LINK_IF2IP6MASK	0x41

/* Execute Message TLV Types */
#define CORE_TLV_EXEC_NODE		0x01
#define CORE_TLV_EXEC_NUM		0x02
#define CORE_TLV_EXEC_TIME		0x03
#define CORE_TLV_EXEC_CMD		0x04
#define CORE_TLV_EXEC_RESULT		0x05
#define CORE_TLV_EXEC_STATUS		0x06

/* Register Message TLV Types */
#define CORE_TLV_REG_WIRELESS		0x01
#define CORE_TLV_REG_MOBILITY		0x02
#define CORE_TLV_REG_UTILITY		0x03
#define CORE_TLV_REG_EXECSRV		0x04
#define CORE_TLV_REG_GUI		0x05
#define CORE_TLV_REG_EMULSRV		0x06

/* Configuration Message TLV Types */
#define CORE_TLV_CONF_NODE		0x01
#define CORE_TLV_CONF_OBJ		0x02
#define CORE_TLV_CONF_TYPE		0x03
#define CORE_TLV_CONF_DATA_TYPES	0x04
#define CORE_TLV_CONF_VALUES		0x05
#define CORE_TLV_CONF_CAPTIONS		0x06
#define CORE_TLV_CONF_BITMAP		0x07
#define CORE_TLV_CONF_POSSIBLE_VALUES	0x08
#define CORE_TLV_CONF_GROUPS		0x09
#define CORE_TLV_CONF_NETID	CORE_TLV_NODE_NETID

#define CONF_TYPE_FLAGS_NONE		0x00
#define CONF_TYPE_FLAGS_REQUEST		0x01
#define CONF_TYPE_FLAGS_UPDATE		0x02
#define CONF_TYPE_FLAGS_RESET		0x03

/* File Message TLV Types */
#define CORE_TLV_FILE_NODE		0x01
#define CORE_TLV_FILE_NAME		0x02
#define CORE_TLV_FILE_MODE		0x03
#define CORE_TLV_FILE_NUM		0x04
#define CORE_TLV_FILE_TYPE		0x05
#define CORE_TLV_FILE_SRCNAME		0x06
#define CORE_TLV_FILE_DATA		0x10
#define CORE_TLV_FILE_CMPDATA		0x11

/* Interface Message TLV Types */
#define CORE_TLV_IFACE_NODE		0x01
#define CORE_TLV_IFACE_NUMBER		0x02
#define CORE_TLV_IFACE_NAME		0x03
#define CORE_TLV_IFACE_IPADDR		0x04
#define CORE_TLV_IFACE_MASK		0x05
#define CORE_TLV_IFACE_MACADDR		0x06
#define CORE_TLV_IFACE_IP6ADDR		0x07
#define CORE_TLV_IFACE_IP6MASK		0x08
#define CORE_TLV_IFACE_TYPE		0x09
#define CORE_TLV_IFACE_STATE		0x0A
#define CORE_TLV_IFACE_EMUID	CORE_TLV_NODE_EMUID
#define CORE_TLV_IFACE_NETID	CORE_TLV_NODE_NETID

/* Event Message TLV Types */
#define CORE_TLV_EVENT_NODE		0x01
#define CORE_TLV_EVENT_TYPE		0x02
#define CORE_TLV_EVENT_NAME		0x03
#define CORE_TLV_EVENT_DATA		0x04

/* Event Type TLV Values */
enum EventTypeVals {
	event_none,
	definition_state,
	configuration_state,
	instantiation_state,
	runtime_state,
	shutdown_state,
	event_start,
	event_stop,
	event_pause,
};

#define FLUSH_FLAGS_ALL_NODES		0x01

/*
 * Data types
 */
struct core_api_msg {
	uint8_t  type;
	uint8_t  flags;
	uint16_t length;
	uint8_t  value[0];
};

struct core_api_tlv {
	uint8_t type;
	uint8_t length;
	uint8_t  value[0];
};

/* align TLV to 32-bit word boundary */
#define TLV_PAD(len) (((len + 2) % 4) ? \
			(4 - ((len + sizeof(struct core_api_tlv)) % 4)) : 0)

static __inline uint64_t __hton64( uint64_t i )
{
#if defined(__BIG_ENDIAN__)
        return i;
#endif
        return ((uint64_t)(htonl((uint32_t)(i) & 0xffffffff)) << 32)
                | htonl((uint32_t)(((i) >> 32) & 0xffffffff ));
}
#define hton64(i)   __hton64( i )
#define ntoh64(i)   __hton64( i )

struct sockaddr;

/*
 * Functions
 */
int core_api_create_message(uint8_t *buf, uint8_t type, uint8_t flags,
	uint16_t length, uint8_t *data);
void core_api_message_set_length(uint8_t *buf, uint16_t length);
uint8_t core_api_message_get_flags(uint8_t *buf);
int core_api_create_tlv(uint8_t *buf, uint8_t type, uint8_t length,
	uint8_t *data);
int core_api_create_tlv16(uint8_t *buf, uint8_t type, uint16_t data);
int core_api_create_tlv32(uint8_t *buf, uint8_t type, uint32_t data);
int core_api_create_tlv64(uint8_t *buf, uint8_t type, uint64_t data);

int core_api_parse_message(uint8_t *buf, uint16_t *length);
struct core_api_tlv *core_api_get_tlv(uint8_t *buf, uint8_t type);
struct core_api_tlv *core_api_get_next_tlv(uint8_t *buf,
	struct core_api_tlv *prev);
int core_api_get_tlv_val16(struct core_api_tlv *tlv, uint16_t *value);
int core_api_get_tlv_val32(struct core_api_tlv *tlv, uint32_t *value);
int core_api_get_tlv_val64(struct core_api_tlv *tlv, uint64_t *value);
int core_api_get_tlv_string(struct core_api_tlv *tlv, uint8_t *value, int max);
uint16_t core_api_get_tlv_length(struct core_api_tlv *tlv);
int core_api_get_tlv_address(uint8_t *buf, uint16_t tlvn, uint16_t tlvn_mask,
	int family, struct sockaddr *addr);
int core_api_print_message(uint8_t *buf, uint16_t *length, FILE *stream);

void core_api_node_tlv_to_str(struct core_api_tlv *tlv, char *dst);
void core_api_link_tlv_to_str(struct core_api_tlv *tlv, char *dst);
void core_api_exec_tlv_to_str(struct core_api_tlv *tlv, char *dst);
void core_api_iface_tlv_to_str(struct core_api_tlv *tlv, char *dst);

#endif /* COREAPI_H*/

