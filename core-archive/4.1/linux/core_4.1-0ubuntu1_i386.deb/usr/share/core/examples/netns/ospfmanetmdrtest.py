#!/usr/bin/python

# Copyright (c)2010 the Boeing Company.
# See the LICENSE file included in this distribution.

# create a random topology running ospf manet, wait and then check
# that all neighbor states are either full or two-way

import os, sys, random, time, optparse, datetime
from string import Template
from core import pycore
from core.misc import ipaddr
from core.misc.utils import mutecall
from core.constants import QUAGGA_STATE_DIR

try:
    mutecall(["zebra", "-v"])
except OSError:
    sys.stderr.write("ERROR: running zebra failed\n")
    sys.exit(1)

class ManetNode(pycore.nodes.LxcNode):
    conftemp = Template("""\
interface eth0
  ip address $ipaddr
  ipv6 ospf6 instance-id 65
  ipv6 ospf6 hello-interval 2
  ipv6 ospf6 dead-interval 6
  ipv6 ospf6 retransmit-interval 5
  ipv6 ospf6 network manet-designated-router
  ipv6 ospf6 diffhellos
  ipv6 ospf6 adjacencyconnectivity biconnected
  ipv6 ospf6 lsafullness mincostlsa
!
router ospf6
  router-id $routerid
  interface eth0 area 0.0.0.0
!
ip forwarding
""")

    def __init__(self, core, ipaddr, routerid = None,
                 objid = None, name = None, nodedir = None):
        if routerid is None:
            routerid = ipaddr.split("/")[0]
        self.ipaddr = ipaddr
        self.routerid = routerid
        pycore.nodes.LxcNode.__init__(self, core, objid, name, nodedir)

    def qconf(self):
        return self.conftemp.substitute(ipaddr = self.ipaddr,
                                        routerid = self.routerid)

    def config(self):
        filename = os.path.join(self.confdir, "Quagga.conf")
        f = self.opennodefile(filename, "w")
        f.write(self.qconf())
        f.close()
        pycore.nodes.LxcNode.config(self)

    def bootscript(self):
        return """\
#!/bin/sh -e

STATEDIR=%s

waitfile()
{
    fname=$1

    i=0
    until [ -e $fname ]; do
        i=$(($i + 1))
        if [ $i -eq 10 ]; then
            echo "file not found: $fname" >&2
            exit 1
        fi
        sleep 0.1
    done
}

mkdir -p $STATEDIR

zebra -d
waitfile $STATEDIR/zebra.vty

ospf6d -d
waitfile $STATEDIR/ospf6d.vty

vtysh -b
""" % QUAGGA_STATE_DIR

def topology(numnodes, linkprob, verbose = False):
    # node list
    n = []
    # IP subnet
    prefix = ipaddr.IPv4Prefix("10.14.0.0/16")
    session = pycore.Session()
    # emulated network
    net = session.addobj(cls = pycore.nodes.WlanNode)
    for i in xrange(1, numnodes + 1):
        addr = "%s/%s" % (prefix.addr(i), 32)
        tmp = session.addobj(cls = ManetNode, ipaddr = addr, name = "n%d" % i)
        tmp.newnetif(net, [addr])
        n.append(tmp)
    # connect nodes with probability linkprob
    for i in xrange(numnodes):
        for j in xrange(i + 1, numnodes):
            r = random.random()
            if r < linkprob:
                if verbose:
                    print "linking (%d,%d)" % (i, j)
                net.link(n[i].netif(0), n[j].netif(0))
        # force one link to avoid partitions (should check if this is needed)
        j = i
        while j == i:
            j = random.randint(0, numnodes - 1)
        if verbose:
            print "linking (%d,%d)" % (i, j)
        net.link(n[i].netif(0), n[j].netif(0))
        n[i].boot()
    return session, net, n

def ospf6neighstate(node):
    cmdid, cmdin, cmdout, cmderr = \
           node.popen(("vtysh", "-c", "show ipv6 ospf6 neighbor"))
    cmdout.readline()                   # skip first line
    numnbr = 0
    for line in cmdout:
        field = line.split()
        state = field[3].split("/")[0]
        if not state.lower() in ("full", "twoway"):
            print >> sys.stderr, "XXX %s: neighbor %s state: %s" % \
                  (node.routerid, field[0], state)
        numnbr += 1

    if numnbr == 0:
        print >> sys.stderr, "XXX %s: no neighbors" % node.routerid

    cmdin.close()
    cmdout.close()
    cmderr.close()

    tmp = cmdid.wait()
    if tmp:
        print "nonzero exit status:", tmp

def checkstate(nodes):
    for n in nodes:
        print "checking %s" % n.name
        ospf6neighstate(n)

def main():
    usagestr = "usage: %prog [-h] [options] [args]"
    parser = optparse.OptionParser(usage = usagestr)
    parser.set_defaults(numnodes = 10, linkprob = 0.35, delay = 20)

    parser.add_option("-n", "--numnodes", dest = "numnodes", type = int,
                      help = "number of nodes")
    parser.add_option("-p", "--linkprob", dest = "linkprob", type = float,
                      help = "link probabilty")
    parser.add_option("-d", "--delay", dest = "delay", type = float,
                      help = "wait time before checking")
    parser.add_option("-v", "--verbose", dest = "verbose",
                      action = "store_true", help = "be more verbose")

    def usage(msg = None, err = 0):
        sys.stdout.write("\n")
        if msg:
            sys.stdout.write(msg + "\n\n")
        parser.print_help()
        sys.exit(err)

    # parse command line options
    (options, args) = parser.parse_args()

    if options.numnodes < 2:
        usage("invalid numnodes: %s" % options.numnodes)
    if options.linkprob <= 0.0 or options.linkprob > 1.0:
        usage("invalid linkprob: %s" % options.linkprob)
    if options.delay < 0.0:
        usage("invalid delay: %s" % options.delay)

    for a in args:
        sys.stderr.write("ignoring command line argument: '%s'\n" % a)

    start = datetime.datetime.now()

    print "creating topology: numnodes = %s; linkprob = %s" % \
          (options.numnodes, options.linkprob)
    session, net, n = topology(options.numnodes, options.linkprob,
                               options.verbose)
    print "waiting %s sec" % options.delay
    time.sleep(options.delay)
    print "checking neighbor state"
    checkstate(n)
    print "done"

    print "elapsed time: %s" % (datetime.datetime.now() - start)

    return n

if __name__ == "__main__":
    n = main()
