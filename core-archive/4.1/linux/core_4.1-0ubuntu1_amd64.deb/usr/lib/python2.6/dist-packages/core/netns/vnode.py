#
# CORE
# Copyright (c)2010 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# authors: Tom Goff <thomas.goff@boeing.com>
#          Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
'''
vnode.py: PyCoreNode and LxcNode classes that implement the network namespace
virtual node.
'''

import os, signal, shutil, sys, subprocess, vnodeclient, threading, string
import random, time
from core.misc.utils import *
from core.constants import *
from core.coreobj import PyCoreObj, PyCoreNode, PyCoreNetIf, Position
from core.emane.nodes import EmaneNode

checkexec([IP_BIN])

class VEth(PyCoreNetIf):
    def __init__(self, node, name, localname, net = None,  start = True):
        PyCoreNetIf.__init__(self, node, name)
        self.localname = localname
        self.net = None
        self.addrlist = []
        self.hwaddr = None
        self.up = False
        if start:
            self.startup()

    def startup(self):
        check_call([IP_BIN, "link", "add", "name", self.localname,
                    "type", "veth", "peer", "name", self.name])
        check_call([IP_BIN, "link", "set", self.localname, "up"])
        self.up = True

    def shutdown(self):
        if not self.up:
            return
        if self.node:
            self.node.cmd([IP_BIN, "-6", "addr", "flush", "dev", self.name])
        if self.localname:
            mutedetach([IP_BIN, "link", "delete", self.localname])
        self.up = False

    def attachnet(self, net):
        if self.net:
            self.detachnet()
            self.net = None
        net.attach(self)
        self.net = net

    def detachnet(self):
        if self.net is not None:
            self.net.detach(self)

    def addaddr(self, addr):
        self.addrlist.append(addr)

    def deladdr(self, addr):
        self.addrlist.remove(addr)

    def sethwaddr(self, addr):
        self.hwaddr = addr

class TunTap(PyCoreNetIf):
    '''TUN/TAP virtual device in TAP mode'''
    def __init__(self, node, name, localname, net = None, start = True):
        PyCoreNetIf.__init__(self, node, name)
        self.localname = localname
        self.net = None
        self.addrlist = []
        self.hwaddr = None
        self.up = False
        if start:
            self.startup()

    def startup(self):
        # TODO: more sophisticated TAP creation here
        #   Debian does not support -p (tap) option, RedHat does.
        # For now, this is disabled to allow the TAP to be created by another 
        # system (e.g. EMANE's emanetransportd)
        #check_call(["tunctl", "-t", self.name])
        # self.install()
        self.up = True

    def shutdown(self):
        if not self.up:
            return
        self.node.cmd([IP_BIN, "-6", "addr", "flush", "dev", self.name])
        #if self.name:
        #    mutedetach(["tunctl", "-d", self.localname])
        self.up = False

    def attachnet(self, net):
        if self.net:
            self.detachnet()
            self.net = None
        net.attach(self)
        self.net = net

    def detachnet(self):
        if self.net is not None:
            self.net.detach(self)

    def addaddr(self, addr):
        self.addrlist.append(addr)

    def deladdr(self, addr):
        self.addrlist.remove(addr)

    def sethwaddr(self, addr):
        self.hwaddr = addr

    def install(self):
        ''' Install this TAP into its namespace. This is not done from the
            startup() method but called at a later time when a userspace
            program (running on the host) has had a chance to open the socket
            end of the TAP.
        '''
        netns = str(self.node.pid)
        # check for presence of device - tap device may not appear right away
        attempts = 5
        while attempts > 0:
            try:
                mutecheck_call([IP_BIN, "link", "show", self.localname])
                break
            except Exception, e:
                msg = "ip link show %s error (%d): %s" % \
                        (self.localname, attempts, e)
                if attempts > 0:
                    msg += ", retrying..."
                self.node.info(msg)
            time.sleep(0.025)
            attempts -= 1
        # install tap device into namespace
        try:
            check_call([IP_BIN, "link", "set", self.localname, "netns", netns])
        except Exception, e:
            msg = "error installing TAP interface %s, command:" % self.localname
            msg += "ip link set %s netns %s" % (self.localname, netns)
            self.node.info(msg)
            return
        self.node.cmd([IP_BIN, "link", "set", self.localname,
                       "name", self.name])
        for addr in self.addrlist:
            self.node.cmd([IP_BIN, "addr", "add", str(addr),
                  "dev", self.name])
        self.node.cmd([IP_BIN, "link", "set", self.name,  "up"])


class SimpleLxcNode(PyCoreNode):
    def __init__(self, session, objid = None, name = None, nodedir = None,
                 verbose = False):
        PyCoreNode.__init__(self, session, objid, name)
        self.nodedir = nodedir
        self.verbose = verbose
        self.ctrlchnlname = \
            os.path.abspath(os.path.join(self.session.sessiondir, self.name))
        self.vnodeclient = None
        self.pid = None
        self.up = False
        self.ifindex = 0
        self.lock = threading.RLock()
        self._netif = {}
        self._mounts = []

    def alive(self):
        try:
            os.kill(self.pid, 0)
        except OSError:
            return False
        return True

    def startup(self):
        ''' Start a new namespace node by invoking the vnoded process that
            allocates a new namespace. Bring up the loopback device and set
            the hostname.
        '''
        if self.up:
            raise Exception, "already up"
        vnoded = ["%s/vnoded" % CORE_SBIN_DIR, "-v", "-c", self.ctrlchnlname,
                  "-l", self.ctrlchnlname + ".log",
                  "-p", self.ctrlchnlname + ".pid"]
        if self.nodedir:
            vnoded += ["-C", self.nodedir]
        try:
            tmp = subprocess.Popen(vnoded, stdout = subprocess.PIPE)
        except OSError:
            raise Exception, ("vnode command not found while running: %s" %
                              vnoded)
        self.pid = int(tmp.stdout.read())
        tmp.stdout.close()
        if tmp.wait():
            raise Exception, ("command failed: %s" % vnoded)
        self.vnodeclient = vnodeclient.VnodeClient(self.name,
                                                   self.ctrlchnlname)
        self.info("bringing up loopback interface")
        self.cmd([IP_BIN, "link", "set", "lo", "up"])
        self.info("setting hostname: %s" % self.name)
        self.cmd(["hostname", self.name])
        self.up = True

    def shutdown(self):
        if not self.up:
            return
        while self._mounts:
            source, target = self._mounts.pop(-1)
            self.umount(target)
        #print "XXX del vnodeclient:", self.vnodeclient
        # XXX XXX XXX this causes a serious crash
        #del self.vnodeclient
        for netif in self.netifs():
            netif.shutdown()
        try:
            os.kill(self.pid, signal.SIGTERM)
            os.waitpid(self.pid, 0)
        except OSError:
            pass
        try:
            os.unlink(self.ctrlchnlname)
        except OSError:
            pass
        self._netif.clear()
        del self.session
        # print "XXX del vnodeclient:", self.vnodeclient
        del self.vnodeclient
        self.up = False

    def cmd(self, args, wait = True):
        return self.vnodeclient.cmd(args, wait)

    def cmdresult(self, args):
        return self.vnodeclient.cmdresult(args)

    def popen(self, args):
        return self.vnodeclient.popen(args)

    def icmd(self, args):
        return self.vnodeclient.icmd(args)

    def term(self, sh = "/bin/sh"):
        return self.vnodeclient.term(sh = sh)

    def termcmdstring(self, sh = "/bin/sh"):
	return self.vnodeclient.termcmdstring(sh = sh)

    def shcmd(self, cmsdtr, sh = "/bin/sh"):
        return self.vnodeclient.shcmd(cmsdtr, sh = sh)

    def info(self, msg):
        if self.verbose:
            print "%s: %s" % (self.name, msg)
            sys.stdout.flush()

    def warn(self, msg):
        print >> sys.stderr, "%s: %s" % (self.name, msg)
        sys.stderr.flush()

    def boot(self):
        pass

    def mount(self, source, target):
        source = os.path.abspath(source)
        self.info("mounting %s at %s" % (source, target))
        try:
            shcmd = "mkdir -p '%s' && mount -n --bind '%s' '%s'" % \
                (target, source, target)
            self.shcmd(shcmd)
            self._mounts.append((source, target))
        except:
            self.warn("mounting failed for %s at %s" % (source, target))

    def umount(self, target):
        self.info("unmounting '%s'" % target)
        try:
            self.cmd(["umount", "-n", "-l", target])
        except:
            self.warn("unmounting failed for %s" % target)

    def newifindex(self):
        self.lock.acquire()
        try:
            while self.ifindex in self._netif:
                self.ifindex += 1
            ifindex = self.ifindex
            self.ifindex += 1
            return ifindex
        finally:
            self.lock.release()

    def getifindex(self, netif):
        for ifindex in self._netif:
            if self._netif[ifindex] is netif:
                return ifindex
        return -1

    def addnetif(self, netif, ifindex):
        if ifindex in self._netif:
            raise ValueError, "ifindex %s already exists" % ifindex
        self._netif[ifindex] = netif

    def delnetif(self, ifindex):
        if ifindex not in self._netif:
            raise ValueError, "ifindex %s does not exist" % ifindex
        netif = self._netif.pop(ifindex)
        netif.shutdown()
        del netif

    def newveth(self, ifindex = None, ifname = None, net = None):
        self.lock.acquire()
        try:
            if ifindex is None:
                ifindex = self.newifindex()
            if ifname is None:
                ifname = "eth%d" % ifindex
            sessionid = (self.session.sessionid >> 8) ^ \
                        (self.session.sessionid & ((1 << 8) - 1))
            name = "n%s.%s.%s" % (self.objid, ifindex, sessionid)
            localname = "n%s.%s.%s" % (self.objid, ifname, sessionid)
            ifclass = VEth
            veth = ifclass(self, name, localname, net, start = self.up)
            if self.up:
                check_call([IP_BIN, "link", "set", veth.name,
                            "netns", str(self.pid)])
                self.cmd([IP_BIN, "link", "set", veth.name, "name", ifname])
            veth.name = ifname
            try:
                self.addnetif(veth, ifindex)
            except:
                veth.shutdown()
                del veth
                raise
            return ifindex
        finally:
            self.lock.release()

    def newtuntap(self, ifindex = None, ifname = None, net = None):
        self.lock.acquire()
        try:
            if ifindex is None:
                ifindex = self.newifindex()
            if ifname is None:
                ifname = "eth%d" % ifindex
            sessionid = (self.session.sessionid >> 8) ^ \
                        (self.session.sessionid & ((1 << 8) - 1))
            localname = "n%s.%s.%s" % (self.objid, ifindex, sessionid)
            name = ifname
            ifclass = TunTap
            tuntap = ifclass(self, name, localname, net, start = self.up)
            try:
                self.addnetif(tuntap, ifindex)
            except:
                tuntap.shutdown()
                del tuntap
                raise
            return ifindex
        finally:
            self.lock.release()

    def netif(self, ifindex, net = None):
        return self._netif[ifindex]

    def netifs(self):
        return self._netif.itervalues()

    def ifname(self, ifindex):
        return self.netif(ifindex).name

    def sethwaddr(self, ifindex, addr):
        self._netif[ifindex].sethwaddr(addr)
        if self.up:
            self.cmd([IP_BIN, "link", "set", "dev", self.ifname(ifindex),
                "address", str(addr)])

    def addaddr(self, ifindex, addr):
        if self.up:
            self.cmd([IP_BIN, "addr", "add", str(addr),
                  "dev", self.ifname(ifindex)])
        self._netif[ifindex].addaddr(addr)

    def deladdr(self, ifindex, addr):
        try:
            self._netif[ifindex].deladdr(addr)
        except ValueError:
            self.warn("trying to delete unknown address: %s" % addr)
        if self.up:
            self.cmd([IP_BIN, "addr", "del", str(addr),
                  "dev", self.ifname(ifindex)])

    valid_deladdrtype = ("inet", "inet6", "inet6link")
    def delalladdr(self, ifindex, addrtypes = valid_deladdrtype):
        addr = self.getaddr(self.ifname(ifindex), rescan = True)
        for t in addrtypes:
            if t not in self.valid_deladdrtype:
                raise ValueError, "addr type must be in: " + \
                    " ".join(self.valid_deladdrtype)
            for a in addr[t]:
                self.deladdr(ifindex, a)
        # update cached information
        self.getaddr(self.ifname(ifindex), rescan = True)

    def ifup(self, ifindex):
        if self.up:
            self.cmd([IP_BIN, "link", "set", self.ifname(ifindex), "up"])

    def newnetif(self, net = None, addrlist = [], hwaddr = None,
                 ifindex = None, ifname = None):
        self.lock.acquire()
        try:
            if isinstance(net, EmaneNode):
                ifindex = self.newtuntap(ifindex = ifindex, ifname = ifname,
                                         net = net)
                # TUN/TAP is not ready for addressing yet; the device may
                #   take some time to appear, and installing it into a
                #   namespace after it has been bound removes addressing;
                #   save addresses with the interface now
                self.attachnet(ifindex, net)
                netif = self.netif(ifindex)
                netif.sethwaddr(hwaddr)
                for addr in maketuple(addrlist):
                    netif.addaddr(addr)
                return ifindex
            else:
                ifindex = self.newveth(ifindex = ifindex, ifname = ifname,
                                       net = net)
            if net is not None:
                self.attachnet(ifindex, net)
            if hwaddr:
                self.sethwaddr(ifindex, hwaddr)
            for addr in maketuple(addrlist):
                self.addaddr(ifindex, addr)
            self.ifup(ifindex)
            return ifindex
        finally:
            self.lock.release()

    def connectnode(self, ifname, othernode, otherifname):
        tmplen = 8
        tmp1 = "tmp." + "".join([random.choice(string.ascii_lowercase)
                                 for x in xrange(tmplen)])
        tmp2 = "tmp." + "".join([random.choice(string.ascii_lowercase)
                                 for x in xrange(tmplen)])
        check_call([IP_BIN, "link", "add", "name", tmp1,
                    "type", "veth", "peer", "name", tmp2])

        check_call([IP_BIN, "link", "set", tmp1, "netns", str(self.pid)])
        self.cmd([IP_BIN, "link", "set", tmp1, "name", ifname])
        self.addnetif(PyCoreNetIf(self, ifname), self.newifindex())

        check_call([IP_BIN, "link", "set", tmp2, "netns", str(othernode.pid)])
        othernode.cmd([IP_BIN, "link", "set", tmp2, "name", otherifname])
        othernode.addnetif(PyCoreNetIf(othernode, otherifname),
                           othernode.newifindex())

    def attachnet(self, ifindex, net):
        self._netif[ifindex].attachnet(net)

    def detachnet(self, ifindex):
        self._netif[ifindex].detachnet()

    def addfile(self, srcname, filename):
        shcmd = "mkdir -p $(dirname '%s') && mv '%s' '%s' && sync" % \
            (filename, srcname, filename)
        self.shcmd(shcmd)

    def getaddr(self, ifname, rescan = False):
        return self.vnodeclient.getaddr(ifname = ifname, rescan = rescan)

    def netifstats(self, ifname = None):
        return self.vnodeclient.netifstats(ifname = ifname)

    def setposition(self, x = None, y = None, z = None):
        self.info("updating position: x: %s; y: %s; z: %s" % (x, y, z))
        PyCoreObj.setposition(self, x = x, y = y, z = z)
        for ifindex in self._netif:
            netif = self._netif[ifindex]
            if isinstance(netif, TunTap):
                netif.setposition(x, y, z)

class LxcNode(SimpleLxcNode):

    confdir = "/usr/local/etc/quagga"
    # these are other config dir choices
    #confdir = "/opt/router/etc"
    #confdir = "/opt/bmr/etc"

    def __init__(self, session, objid = None, name = None,
                 nodedir = None, bootsh = "boot.sh", verbose = False,
                 start = True):
        super(LxcNode, self).__init__(session = session, objid = objid,
                                      name = name, nodedir = nodedir,
                                      verbose = verbose)
        self.bootsh = bootsh
        if not start:
            return
        # below here is considered node startup/instantiation code
        if self.nodedir is None:
            self.nodedir = \
                os.path.join(session.sessiondir, self.name + ".conf")
            os.makedirs(self.nodedir)
            self.tmpnodedir = True
        else:
            self.tmpnodedir = False
        self.startup()

    def bootscript(self):
        return ""

    def config(self):
        tmp = self.bootscript()
        if tmp:
            self.nodefile(self.bootsh, tmp, mode = 0755)

    def boot(self):
        self.config()
        self.session.services.bootnodeservices(self)
        #if self.bootsh:
        #    filename = self.bootsh
        #   self.info("running boot script: %s" % filename)
        #    try:
        #        self.cmd(["./%s" % filename])
        #    except:
        #        self.warn("boot script failed")

    def startup(self):
        self.lock.acquire()
        try:
            super(LxcNode, self).startup()
            #self.privatedir(self.confdir)
            self.privatedir("/var/run")
            self.privatedir("/var/log")
        finally:
            self.lock.release()

    def shutdown(self):
        if not self.up:
            return
        self.lock.acquire()
        # services are instead stopped when session enters datacollect state
        #self.session.services.stopnodeservices(self)
        try:
            super(LxcNode, self).shutdown()
        finally:
            if self.tmpnodedir:
                shutil.rmtree(self.nodedir, ignore_errors = True)
            self.lock.release()

    def privatedir(self, path):
        if path[0] != "/":
            raise ValueError, "path not fully qualified: " + path
        hostpath = os.path.join(self.nodedir, path[1:].replace("/", "."))
        try:
            os.mkdir(hostpath)
        except OSError:
            pass
        except Exception, e:
            raise Exception, e
        self.mount(hostpath, path)

    def opennodefile(self, filename, mode = "w"):
        dirname, basename = os.path.split(filename)
        if not basename:
            raise ValueError, "no basename for filename: " + filename
        if dirname and dirname[0] == "/":
            dirname = dirname[1:]
        dirname = dirname.replace("/", ".")
        dirname = os.path.join(self.nodedir, dirname)
        if not os.path.isdir(dirname):
            os.makedirs(dirname, mode = 0755)
        hostfilename = os.path.join(dirname, basename)
        return open(hostfilename, mode)

    def nodefile(self, filename, contents, mode = 0644):
        f = self.opennodefile(filename, "w")
        f.write(contents)
        os.chmod(f.name, mode)
        f.close()
        self.info("created nodefile: '%s'; mode: 0%o" % (f.name, mode))

    def setposition(self, x = None, y = None, z = None):
        super(LxcNode, self).setposition(x = x, y = y, z = z)
