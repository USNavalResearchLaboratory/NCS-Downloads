#
# CORE
# Copyright (c)2010 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# author: Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
'''
rfpipe.py: EMANE RF-PIPE model for CORE
'''

import sys
import string
from core.api import coreapi

from core.constants import *
from emane import EmaneModel

class EmaneRfPipeModel(EmaneModel):
    def __init__(self, session, objid = None, verbose = False):
        EmaneModel.__init__(self, session, objid, verbose)

    # model name
    _name = "emane_rfpipe"
    # data types for configuration message fields (from the CORE API)
    _confdatatypes = (coreapi.CONF_DATA_TYPE_BOOL,
                      coreapi.CONF_DATA_TYPE_STRING,
                      coreapi.CONF_DATA_TYPE_UINT16,
                      coreapi.CONF_DATA_TYPE_UINT16,
                      coreapi.CONF_DATA_TYPE_UINT8,
                      coreapi.CONF_DATA_TYPE_UINT8,
                      coreapi.CONF_DATA_TYPE_UINT16,
                      coreapi.CONF_DATA_TYPE_UINT32,
                      coreapi.CONF_DATA_TYPE_UINT32,
                      coreapi.CONF_DATA_TYPE_BOOL,
                      coreapi.CONF_DATA_TYPE_BOOL,
                      coreapi.CONF_DATA_TYPE_UINT16,
                      coreapi.CONF_DATA_TYPE_UINT16,
                      coreapi.CONF_DATA_TYPE_BOOL)
    # default values for configuration message
    _confdefaultvalues = ('0','','2437','20','0','0','0','0','0','1','0',
                          '90','110','1')
    # possible values for configuration message
    _confpossiblevalues = "True,False|||||||||position-based,event-based|" \
                          "2-ray flat earth,free space|||On,Off"
    # captions used for configuration message
    _confcaptions = "enable promiscuous mode|" \
                    "tx control map (nem:rate:freq:tx_dBm)|" \
                    "frequency (MHz)|bandwidth (KHz)|txpower (dBm)|" \
                    "antenna gain (dBi)|bitrate (kbps)|" \
                    "propagation delay (usec)|jitter (usec)|pathloss source|" \
                    "pathloss algorithm|" \
                    "rxpowernoloss threshold (dBm)|" \
                    "rxpowerfullloss threshold (dBm)|default connectivity"
    # value groupings
    _confgroups = "RF-PIPE MAC Parameters:1-2|RF-PIPE PHY Parameters:3-14"

    def buildnemxmlfiles(self, e, ifc):
        ''' Build the necessary nem, mac, and phy XMLs in the given path.
            If an individual NEM has a nonstandard config, we need to build
            that file also. Otherwise the WLAN-wide nXX.rfpipenem.xml,
            nXX.rfpipemac.xml, nXX.rfpipephy.xml are used.
        '''
        # use the network-wide config values or interface(NEM)-specific values?
        if ifc is None:
            values = e.getconfig(self.objid, self._name,
                                 self._confdefaultvalues)[1]
        else:
            nodenum = self.interfacetonodenumber(ifc)
            values = e.getconfig(nodenum, self._name, None)[1]
            if values is None:
                # do not build specific files for this NEM when config is same
                # as the network
                return
        nemdoc = e.xmldoc("nem")
        nem = nemdoc.getElementsByTagName("nem").pop()
        nem.setAttribute("name", "RF-PIPE NEM")
        mactag = nemdoc.createElement("mac")
        mactag.setAttribute("definition", self.macxmlname(ifc))
        nem.appendChild(mactag)
        phytag = nemdoc.createElement("phy")
        phytag.setAttribute("definition", self.phyxmlname(ifc))
        nem.appendChild(phytag)
        e.xmlwrite(nemdoc, self.nemxmlname(ifc))

        macdoc = e.xmldoc("mac")
        mac = macdoc.getElementsByTagName("mac").pop()
        mac.setAttribute("name", "RF-PIPE MAC")
        mac.setAttribute("library", "rfpipemaclayer")
        mac.appendChild(e.xmlparam(macdoc, "enablepromiscuousmode",
                                   e.booltooffon(values[0])))
        if values[1] is not "":
            mac.appendChild(e.xmlparam(macdoc, "transmissioncontrolmap",
                                       e.booltooffon(values[1])))

        e.xmlwrite(macdoc, self.macxmlname(ifc))

        phydoc = e.xmldoc("phy")
        phy = phydoc.getElementsByTagName("phy").pop()
        phy.setAttribute("name", "RF-PIPE PHY")
        phy.setAttribute("library", "rfpipephylayer")
        phy.appendChild(e.xmlparam(phydoc, "txpower", values[4]))
        phy.appendChild(e.xmlparam(phydoc, "antennagain", values[5]))
        phy.appendChild(e.xmlparam(phydoc, "bitrate", values[6]))
        phy.appendChild(e.xmlparam(phydoc, "jitter", values[8]))
        phy.appendChild(e.xmlparam(phydoc, "frequency", values[2]))
        phy.appendChild(e.xmlparam(phydoc, "bandwidth", values[3]))
        phy.appendChild(e.xmlparam(phydoc, "propagationdelay", values[7]))
        phy.appendChild(e.xmlparam(phydoc, "pathlosssource", values[9]))
        phy.appendChild(e.xmlparam(phydoc, "pathlossalgorithm", values[10]))
        phy.appendChild(e.xmlparam(phydoc, "defaultconnectivity",
                                   e.booltooffon(values[13])))
        phy.appendChild(e.xmlparam(phydoc, "rxpowernolossthreshold",
                                   values[11]))
        phy.appendChild(e.xmlparam(phydoc, "rxpowerfulllossthreshold",
                                   values[12]))
        e.xmlwrite(phydoc, self.phyxmlname(ifc))

        transdoc = e.xmldoc("transport")
        trans = transdoc.getElementsByTagName("transport").pop()
        trans.setAttribute("name", "TAP Transport")
        trans.setAttribute("library", "transvirtual")
        trans.appendChild(e.xmlparam(transdoc, "bitrate", "0"))
        trans.appendChild(e.xmlparam(transdoc, "devicepath", "/dev/net/tun"))
        e.xmlwrite(transdoc, self.transportxmlname())

