#
# CORE
# Copyright (c)2010 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# author: Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
'''
nrl.py: defines services provided by NRL protolib tools hosted here:
http://cs.itd.nrl.navy.mil/products/
'''

from core.service import CoreService, addservice
#from core.misc.ipaddr import IPv4Prefix

class NrlService(CoreService):
    ''' Parent class for NRL services. Defines properties and methods
        common to NRL's routing daemons.
    '''
    _name = "NRLDaemon"
    _group = "NRL"
    _depends = ()
    _dirs = ()
    _configs = ()
    _startindex = 30
    _startup = ()
    _shutdown = ()

    @classmethod
    def generateconfig(cls,  node, filename, services):
        return ""


class NrlSmf(NrlService):
    ''' Simplified Multicast Forwarding for MANET networks.
    '''
    _name = "SMF"
    _startup = ("nrlsmf", )
    _shutdown = ("killall nrlsmf", )
    
    @classmethod
    def getstartup(cls,  node,  services):
        ''' Generate the appropriate command-line based on node interfaces.
        '''
        cmd = cls._startup[0]
        cmd += " instance %s" % node.name
        netifs = list(node.netifs())
        if len(netifs) > 0:
            cmd += " cf "
            interfacenames = map(lambda x: x.name,  netifs)
            cmd += ",".join(interfacenames)
            
        cmd += " hash MD5"
        return (cmd, )
     
addservice(NrlSmf)

class NrlNorm(NrlService):
    ''' NACK-Oriented Reliable Multicast Forwarding.
    '''
    _name = "NORM"
    _startup = ()
    _shutdown = ()
    
    # TODO: complete this
    
addservice(NrlNorm)

class NrlOlsr(NrlService):
    ''' Optimized Link State Routing protocol for MANET networks.
    '''
    _name = "OLSR"
    _startup = ("nrlolsrd", )
    _shutdown = ("killall nrlolsrd", )
    
    @classmethod
    def getstartup(cls,  node,  services):
        ''' Generate the appropriate command-line based on node interfaces.
        '''
        cmd = cls._startup[0]
        # are multiple interfaces supported?
        netifs = list(node.netifs())
        if len(netifs) > 0:
            ifc = netifs[0]
            cmd += " -i %s" % ifc.name
            
        cmd += " -l /var/log/nrlolsrd.log"
        return (cmd, )
        
        
addservice(NrlOlsr)

