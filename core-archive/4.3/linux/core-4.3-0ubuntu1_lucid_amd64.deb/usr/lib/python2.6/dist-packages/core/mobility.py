#
# CORE
# Copyright (c)2011-2012 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# author: Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
'''
mobility.py: mobility helpers for moving nodes and calculating wireless range.
'''
import sys, string, math
from core.api import coreapi
from core.coreobj import PyCoreNode
from core.misc.ipaddr import IPAddr

class MobilityManager(object):
    ''' Member of session class for handling configuration data for mobility and
    range models.
    '''
    def __init__(self, session):
        self.session = session
        self.verbose = self.session.getcfgitembool('verbose', False)
        # configurations for basic range, indexed by WLAN node number
        self.configs = {}
        # mapping from model names to their classes
        self._modelclsmap = {}
        # dummy node objects for tracking position of nodes on other servers
        self.phys = {}
        self.physnets = {}
        self.register()
        self.session.broker.handlers += (self.physnodehandlelink, )

    def info(self, msg):
        ''' Utility method for printing informational messages.
        '''
        print msg
        sys.stdout.flush()

    def warn(self, msg):
        print >> sys.stderr, msg
        sys.stderr.flush()

    def startup(self):
        ''' Session is transitioning from instantiation to runtime state.
        Instantiate any mobility models that have been configured for a WLAN.
        '''
        for nodenum in self.configs:
            v = self.configs[nodenum]
            try:
                n = self.session.obj(nodenum)
            except KeyError:
                self.session.warn("Skipping mobility configuration for unknown"
                                "node %d." % nodenum)
                continue
            cls = self._modelclsmap[v[0][0]]
            n.setmodel(cls, v)
            if self.session.master:
                self.installphysnodes(n)

    def reset(self):
        ''' Reset to initial state.
        '''
        self.clearconfig()

    def register(self):
        ''' Register models as configurable object(s) with the Session object.
        '''
        models = [BasicRangeModel, ]
        for m in models:
            self.session.addconfobj(m._name, coreapi.CORE_TLV_REG_WIRELESS,
                                    m.configure_mob)
            self._modelclsmap[m._name] = m

    def setconfig(self, nodenum, conftype, values):
        ''' add configuration values for a node to a dictionary; values are
            usually received from a Configuration Message, and may refer to a
            node for which no object exists yet
        '''
        conflist = []
        if nodenum in self.configs:
            oldlist = self.configs[nodenum]
            found = False
            for (t, v) in oldlist:
                if (t == conftype):
                    # replace existing config
                    found = True
                    conflist.append((conftype, values))
                else:
                    conflist.append((t, v))
            if not found:
                conflist.append((conftype, values))
        else:
            conflist.append((conftype, values))
        self.configs[nodenum] = conflist

    def getconfig(self, nodenum, conftype, defaultvalues):
        ''' get configuration values for a node; if the values don't exist in
            our dictionary then return the default values supplied
        '''
        if nodenum in self.configs:
            # return configured values
            conflist = self.configs[nodenum]
            for (t, v) in conflist:
                if (conftype is None) or (t == conftype):
                    return (t, v)
        # return default values provided (may be None)
        return (conftype, defaultvalues)

    def clearconfig(self, nodenum):
        ''' remove configuration values for all nodes
        '''
        if nodenum in self.configs:
            self.configs.pop(nodenum)

    def addphys(self, netnum, node):
        ''' Keep track of PhysicalNodes and which network they belong to.
        '''
        nodenum = node.objid
        self.phys[nodenum] = node
        if netnum not in self.physnets:
            self.physnets[netnum] = [nodenum,]
        else:
            self.physnets[netnum].append(nodenum)
        
    def physnodehandlelink(self,  msg):
        ''' Broker handler. Snoop Link add messages to get
            node numbers of PhyiscalNodes and their nets.
            Physical nodes exist only on other servers, but a shadow object is
            created here for tracking node position.
        '''
        if msg.msgtype == coreapi.CORE_API_LINK_MSG and \
           msg.flags & coreapi.CORE_API_ADD_FLAG:
            nn = msg.nodenumbers()
            # first node is always link layer node in Link add message
            if nn[0] not in self.session.broker.nets:
                return
            if nn[1] in self.session.broker.phys:
                # record the fact that this PhysicalNode is linked to a net
                dummy = PyCoreNode(session=self.session, objid=nn[1],
                                  name="n%d" % nn[1], start=False)
                self.addphys(nn[0], dummy)
            
    def physnodeupdateposition(self, msg):
        ''' Snoop node messages belonging to physical nodes. The dummy object
        in self.phys[] records the node position.
        '''
        nodenum = msg.nodenumbers()[0]
        try:
            dummy = self.phys[nodenum]
            nodexpos = msg.gettlv(coreapi.CORE_TLV_NODE_XPOS)
            nodeypos = msg.gettlv(coreapi.CORE_TLV_NODE_YPOS)
            dummy.setposition(nodexpos, nodeypos, None)
        except KeyError:
            pass
    
    def installphysnodes(self, net):
        ''' After installing a mobility model on a net, include any physical
        nodes that we have recorded. Use the GreTap tunnel to the physical node
        as the node's interface.
        '''
        try:
            nodenums = self.physnets[net.objid]
        except KeyError:
            return
        for nodenum in nodenums:
            node = self.phys[nodenum]
            servers = self.session.broker.getserversbynode(nodenum)
            (host, port, sock) = self.session.broker.getserver(servers[0])
            netif = self.session.broker.gettunnel(net.objid, IPAddr.toint(host))
            node.addnetif(netif, 0)
            netif.node = node
            (x,y,z) = netif.node.position.get()
            netif.poshook(netif, x, y, z)


class WirelessModel(object):
    ''' Base class used by EMANE models and the basic range model. 
    Used for managing arbitrary configuration parameters.
    '''
    _name = ""
    _confmatrix = []
    _confgroups = None
    _bitmap = None
    _postioncallback = None

    def __init__(self, session, objid, verbose = False):
        self.session = session
        self.objid = objid
        self.verbose = verbose

    @classmethod
    def getdefaultvalues(cls):
        return tuple( map(lambda x: x[2], cls._confmatrix) )
    
    @classmethod
    def getnames(cls):
        return tuple( map( lambda x: x[0], cls._confmatrix) )

    @classmethod
    def configure(cls, mgr, msg):
        ''' Handle configuration messages for setting up a model.
        '''
        reply = None
        nodenum = msg.gettlv(coreapi.CORE_TLV_CONF_NODE)
        objname = msg.gettlv(coreapi.CORE_TLV_CONF_OBJ)
        conftype = msg.gettlv(coreapi.CORE_TLV_CONF_TYPE)

        if mgr.verbose:
            mgr.info("received configure message for %s model" % cls._name)
        if conftype == coreapi.CONF_TYPE_FLAGS_REQUEST:
            if mgr.verbose:
                mgr.info("replying to configure request for %s model" %
                           cls._name)
            # when object name is "all", the reply to this request may be None
            # if this node has not been configured for this model; otherwise we
            # reply with the defaults for this model
            if objname == "all":
                defaults = None
                typeflags = coreapi.CONF_TYPE_FLAGS_UPDATE
            else:
                defaults = cls.getdefaultvalues()
                typeflags = coreapi.CONF_TYPE_FLAGS_NONE
            values = mgr.getconfig(nodenum, cls._name, defaults)[1]
            if values is None:
                # node has no active config for this model (don't send defaults)
                return None
            # reply with config options
            reply = cls.toconfmsg(0, nodenum, typeflags, values)
        elif conftype == coreapi.CONF_TYPE_FLAGS_RESET:
            if objname == "all":
                mgr.clearconfig(nodenum)
        #elif conftype == coreapi.CONF_TYPE_FLAGS_UPDATE:
        else:
            # store the configuration values for later use, when the EmaneNode
            # object has been created
            if objname is None:
                mgr.info("no configuration object for node %s" % nodenum)
                return None
            values_str = msg.gettlv(coreapi.CORE_TLV_CONF_VALUES)
            if values_str is None:
                # use default or preconfigured values
                defaults = cls.getdefaultvalues()
                values = mgr.getconfig(nodenum, cls._name, defaults)[1]
            else:
                # use new values supplied from the conf message
                values = values_str.split('|')
            mgr.setconfig(nodenum, objname, values)
        return reply

    @classmethod
    def toconfmsg(cls, flags, nodenum, typeflags, values):
        ''' Convert this class to a Config API message. Some TLVs are defined
            by the class, but node number, conf type flags, and values must
            be passed in.
        '''
        values_str = string.join(values, '|')
        tlvdata = ""
        tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_NODE, nodenum)
        tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_OBJ,
                                            cls._name)
        tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_TYPE,
                                            typeflags) 
        datatypes = tuple( map(lambda x: x[1], cls._confmatrix) )
        tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_DATA_TYPES,
                                            datatypes)
        tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_VALUES,
                                            values_str)
        captions = reduce( lambda a,b: a + '|' + b, \
                           map(lambda x: x[4], cls._confmatrix))
        tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_CAPTIONS,
                                            captions)
        possiblevals = reduce( lambda a,b: a + '|' + b, \
                           map(lambda x: x[3], cls._confmatrix))
        tlvdata += coreapi.CoreConfTlv.pack(
            coreapi.CORE_TLV_CONF_POSSIBLE_VALUES, possiblevals)
        if cls._bitmap is not None:
            tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_BITMAP,
                                                cls._bitmap)
        if cls._confgroups is not None:
            tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_GROUPS,
                                                cls._confgroups)
        msg = coreapi.CoreConfMessage.pack(flags, tlvdata)
        return msg

    @staticmethod
    def booltooffon(value):
        ''' Convenience helper turns bool into on (True) or off (False) string.
        '''
        if value == "1" or value == "true" or value == "on":
            return "on"
        else:
            return "off"

    def valueof(self, name,  values):
        ''' Helper to return a value by the name defined in confmatrix.
            Checks if it is boolean'''
        i = self.getnames().index(name)
        if self._confmatrix[i][1] == coreapi.CONF_DATA_TYPE_BOOL and \
           values[i] != "":
            return self.booltooffon( values[i] )
        else:
            return values[i]


class BasicRangeModel(WirelessModel):
    ''' Basic Range wireless model, calculates range between nodes and links
    and unlinks nodes based on this distance. This was formerly done from
    the GUI.
    '''
    _name = "basic_range"

    # configuration parameters are
    #  ( 'name', 'type', 'default', 'possible-value-list', 'caption')
    _confmatrix = [
        ("range", coreapi.CONF_DATA_TYPE_UINT32, '275',
         '', 'wireless range (pixels)'),
        ("bandwidth", coreapi.CONF_DATA_TYPE_UINT32, '54000', 
         '', 'bandwidth (bps)'),
        ("jitter", coreapi.CONF_DATA_TYPE_FLOAT, '0.0', 
         '', 'transmission jitter (usec)'),
        ("delay", coreapi.CONF_DATA_TYPE_FLOAT, '5000.0', 
         '', 'transmission delay (usec)'),
        ("error", coreapi.CONF_DATA_TYPE_FLOAT, '0.0', 
         '', 'error rate (%)'),
    ]

    # value groupings
    _confgroups = "Basic Range Parameters:1-%d" % len(_confmatrix)
    
    def __init__(self, session, objid, verbose = False):
        ''' Range model is only instantiated during runtime.
        '''
        super(BasicRangeModel, self).__init__(session = session, objid = objid,
                                              verbose = verbose)
        self.wlan = session.obj(objid)
        self._netifs = {}
        values = session.mobility.getconfig(objid, self._name,
                                            self.getdefaultvalues())[1]
        self.range = float(self.valueof("range",  values))
        if self.verbose:
            self.session.info("Basic range model configured for WLAN %d using" \
                " range %d" % (objid, self.range))
        self.bw = int(self.valueof("bandwidth", values))
        if self.bw == 0.0:
            self.bw = None
        self.delay = float(self.valueof("delay", values))
        if self.delay == 0.0:
            self.delay = None
        self.loss = float(self.valueof("error", values))
        if self.loss == 0.0:
            self.loss = None
        self.jitter = float(self.valueof("jitter", values))
        if self.jitter == 0.0:
            self.jitter = None

    @classmethod
    def configure_mob(cls, session, msg):
        ''' Handle configuration messages for setting up a model.
        Pass the MobilityManager object as the manager object.
        '''
        return cls.configure(session.mobility, msg)
        
    def setlinkparams(self):
        ''' Apply link parameters to all interfaces. This is invoked from
        WlanNode.setmodel() after the position callback has been set.
        '''
        for netif in self._netifs:
            self.wlan.linkconfig(netif, bw=self.bw, delay=self.delay,
                                 loss=self.loss, duplicate=None,
                                 jitter=self.jitter)
    
    def set_position(self, netif, x = None, y = None, z = None):
        ''' A node has moved; given an interface, a new (x,y,z) position has
        been set; calculate the new distance between other nodes and link or
        unlink node pairs based on the configured range.
        '''
        #print "set_position(%s, x=%s, y=%s, z=%s)" % (netif.localname, x, y, z)
        self._netifs[netif] = (x, y, z)
        if x is None or y is None:
            return
        for netif2 in self._netifs:
            if netif == netif2:
                continue
            (x2, y2, z2) = self._netifs[netif2]
            if x2 is None or y2 is None:
                continue
            d = self.calcdistance( (x,y,z), (x2,y2,z2) )
            # ordering is important, to keep the wlan._linked dict organized
            if netif < netif2:
                a = netif
                b = netif2
            else:
                a = netif2
                b = netif
            try:
                self.wlan._linked_lock.acquire()
                linked = self.wlan.linked(a, b)
            except KeyError:
                continue
            finally:
                self.wlan._linked_lock.release()
            if d > self.range:
                if linked:
                    self.wlan.unlink(a, b)
                    self.sendlinkmsg(a, b, unlink=True)
            else:
                if not linked:
                    self.wlan.link(a, b)
                    self.sendlinkmsg(a, b)
    
    _positioncallback = set_position
    
    def calcdistance(self, p1, p2):
        ''' Calculate the distance between two points.
        '''
        a = (p1[0] - p2[0]) ** 2
        b = (p1[1] - p2[1]) ** 2
        c = 0
        if p1[2] is not None and p2[2] is not None:
            c = (p1[2] - p2[2]) ** 2
        return math.sqrt(a + b + c)
        
    def sendlinkmsg(self, netif, netif2, unlink=False):
        ''' Send a wireless link/unlink API message to the GUI.
        '''
        n1 = netif.localname.split('.')[0]
        n2 = netif2.localname.split('.')[0]
        #print "sendlinkmsg(%s, %s, %s)" % (n1, n2, unlink)
        tlvdata = coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_N1NUMBER,
                                            netif.node.objid)
        tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_N2NUMBER,
                                            netif2.node.objid)
        tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_NETID,
                                            self.wlan.objid)
        #tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_IF1NUM,
        #                                    netif.index)
        #tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_IF2NUM,
        #                                    netif2.index)
        tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_TYPE,
                                            coreapi.CORE_LINK_WIRELESS)
        if unlink:
            flags = coreapi.CORE_API_DEL_FLAG
        else:
            flags = coreapi.CORE_API_ADD_FLAG
        msg = coreapi.CoreLinkMessage.pack(flags, tlvdata)
        self.session.broadcastraw(src=None, data=msg)





