#
# CORE
# Copyright (c)2010-2012 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# author: Tom Goff <thomas.goff@boeing.com>
#
'''
utils.py: miscellaneous utility functions, wrappers around some subprocess
procedures.
'''

import subprocess, os

def checkexec(execlist):
    for bin in execlist:
        # note that os.access() uses real uid/gid; that should be okay
        # here
        if not os.access(bin, os.X_OK):
            raise EnvironmentError, "executable not found: %s" % bin

def ensurepath(pathlist):
    searchpath = os.environ["PATH"].split(":")
    for p in set(pathlist):
        if p not in searchpath:
            os.environ["PATH"] += ":" + p

def maketuple(obj):
    if hasattr(obj, "__iter__"):
        return tuple(obj)
    else:
        return (obj,)
        
def maketuplefromstr(s, type):
    #return tuple(type(i) for i in s[1:-1].split(','))
    r = ()
    for i in s.strip("()").split(','):
        r += (i.strip("' "), )
    # chop empty last element from "('a',)" strings
    if r[-1] == '':
        r = r[:-1]
    return r

def call(*args, **kwds):
    return subprocess.call(*args, **kwds)

def mutecall(*args, **kwds):
    kwds["stdout"] = open(os.devnull, "w")
    kwds["stderr"] = subprocess.STDOUT
    return call(*args, **kwds)

def check_call(*args, **kwds):
    return subprocess.check_call(*args, **kwds)

def mutecheck_call(*args, **kwds):
    kwds["stdout"] = open(os.devnull, "w")
    kwds["stderr"] = subprocess.STDOUT
    return subprocess.check_call(*args, **kwds)

def spawn(*args, **kwds):
    return subprocess.Popen(*args, **kwds).pid

def mutespawn(*args, **kwds):
    kwds["stdout"] = open(os.devnull, "w")
    kwds["stderr"] = subprocess.STDOUT
    return subprocess.Popen(*args, **kwds).pid

def detachinit():
    if os.fork():
        os._exit(0)                 # parent exits
    os.setsid()

def detach(*args, **kwds):
    kwds["preexec_fn"] = detachinit
    return subprocess.Popen(*args, **kwds).pid

def mutedetach(*args, **kwds):
    kwds["preexec_fn"] = detachinit
    kwds["stdout"] = open(os.devnull, "w")
    kwds["stderr"] = subprocess.STDOUT
    return subprocess.Popen(*args, **kwds).pid

def hexdump(s, bytes_per_word = 2, words_per_line = 8):
    dump = ""
    count = 0
    bytes = bytes_per_word * words_per_line
    while s:
        line = s[:bytes]
        s = s[bytes:]
        tmp = map(lambda x: ("%02x" * bytes_per_word) % x,
                  zip(*[iter(map(ord, line))] * bytes_per_word))
        if len(line) % 2:
            tmp.append("%x" % ord(line[-1]))
        dump += "0x%08x: %s\n" % (count, " ".join(tmp))
        count += len(line)
    return dump[:-1]

def filemunge(pathname, header, text):
    ''' Insert text at the end of a file, surrounded by header comments.
    '''
    filedemunge(pathname, header) # prevent duplicates
    f = open(pathname, 'a')
    f.write("# BEGIN %s\n" % header)
    f.write(text)
    f.write("# END %s\n" % header)
    f.close()

def filedemunge(pathname, header):
    ''' Remove text that was inserted in a file surrounded by header comments.
    '''
    f = open(pathname, 'r')
    lines = f.readlines()
    f.close()
    start = None
    end = None
    for i in range(len(lines)):
        if lines[i] == "# BEGIN %s\n" % header:
            start = i
        elif lines[i] == "# END %s\n" % header:
            end = i + 1
    if start is None or end is None:
        return
    f = open(pathname, 'w')
    lines = lines[:start] + lines[end:]
    f.write("".join(lines))
    f.close()
  
def sysctldevname(devname):
    ''' Translate a device name to the name used with sysctl.
    '''
    if devname is None:
        return None
    return devname.replace(".", "/")
