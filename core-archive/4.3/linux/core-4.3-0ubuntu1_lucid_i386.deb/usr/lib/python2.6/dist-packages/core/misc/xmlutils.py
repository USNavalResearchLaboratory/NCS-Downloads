#
# CORE
# Copyright (c)2011-2012 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# author: Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
'''
helpers for loading and saving XML files
'''
from xml.dom.minidom import parseString, Document
from core import pycore


def addnetstodom(dom, netplan, session):
    ''' Add PyCoreNet objects as NetworkDefinition XML elements.
    '''
    session._objslock.acquire()
    for net in session.objs():
        if not isinstance(net, pycore.nodes.PyCoreNet):
            continue
        n = dom.createElement("NetworkDefinition")
        netplan.appendChild(n)
        n.setAttribute("name", net.name)
        n.setAttribute("id", "%s" % net.objid)
        n.setAttribute("type", "%s" % net.__class__.__name__)
        addpositiontodom(dom, n, net)
    session._objslock.release()


def addnodestodom(dom, net, session):
    ''' Add PyCoreNode objects as node XML elements.
    '''
    session._objslock.acquire()
    for node in session.objs():
        if not isinstance(node, pycore.nodes.PyCoreNode):
            continue
        n = dom.createElement("node")
        net.appendChild(n)
        n.setAttribute("name", node.name)
        n.setAttribute("id", "%s" % node.nodeid())
        if node.type:
            n.setAttribute("type", node.type)
        addinterfacestodom(dom, n, node)
        addpositiontodom(dom, n, node)
        if node.icon:
            icon = dom.createElement("param")
            n.appendChild(icon)
            icon.setAttribute("name", "icon")
            icon.setAttribute("value", node.icon)
        if len(node.services) > 0:
            defaults = session.services.getdefaultservices(node.type)
            if node.services != defaults:
                svc = dom.createElement("param")
                n.appendChild(svc)
                svc.setAttribute("name", "services")
                svc.setAttribute("value", "%s" % \
                                 map(lambda(x): x._name, node.services))

    session._objslock.release()

def addinterfacestodom(dom, n, node):
    ''' Add PyCoreNetIfs to node XML elements.
    '''
    for ifc in node.netifs():
        i = dom.createElement("interface")
        n.appendChild(i)
        i.setAttribute("name", ifc.name)
        if ifc.net:
            i.setAttribute("net", ifc.net.name)
        addaddressestodom(dom, i, ifc)

def addpositiontodom(dom, n, node):
    ''' Add object coordinates as location XML element.
    '''
    (x,y,z) = node.position.get()
    if x is None or y is None:
        return
    loc = dom.createElement("location")
    n.appendChild(loc)
    loc.setAttribute("type", "cartesian")
    coordstxt = "%s,%s" % (x,y)
    if z:
        coordstxt += ",%s" % z
    coords = dom.createTextNode(coordstxt)
    loc.appendChild(coords)


def addaddressestodom(dom, i, netif):
    ''' Add MAC and IP addresses to interface XML elements.
    '''
    if netif.hwaddr:
        h = dom.createElement("address")
        i.appendChild(h)
        h.setAttribute("type", "mac")
        htxt = dom.createTextNode("%s" % netif.hwaddr)
        h.appendChild(htxt)
    for addr in netif.addrlist:
        a = dom.createElement("address")
        i.appendChild(a)
        # a.setAttribute("type", )
        atxt = dom.createTextNode("%s" % addr)
        a.appendChild(atxt)
    

def savesessionxml(session, filename):
    ''' Export a session to the EmulationScript XML format.
    '''
    dom = Document()
    net = dom.createElement("NetworkPlan")
    dom.appendChild(net)
    addnetstodom(dom, net, session)
    addnodestodom(dom, net, session)
    session.info("saving session XML file %s" % filename)
    f = open(filename, "w")
    dom.writexml(writer=f, indent="", addindent="  ", newl="\n", \
                encoding="UTF-8")
    f.close()
    
