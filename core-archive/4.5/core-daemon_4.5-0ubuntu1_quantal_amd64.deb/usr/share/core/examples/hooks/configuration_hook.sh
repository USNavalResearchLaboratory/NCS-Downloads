#!/bin/sh
# experiment hook script; write commands here to execute on the host at the
# specified state

sh /usr/local/share/core/examples/hooks/timesyncstop.sh
sh /usr/local/share/core/examples/hooks/perflogstart.sh
