# Copyright (c)2010 the Boeing Company.
# See the LICENSE file included in this distribution.

"""core

Top-level Python package containing CORE components.

See http://cs.itd.nrl.navy.mil/work/core/ and
http://code.google.com/p/coreemu/ for more information on CORE.

Pieces can be imported individually, for example

    import core.netns.vnode

or everything listed in __all__ can be imported using

    from core import *
"""

__all__ = []
