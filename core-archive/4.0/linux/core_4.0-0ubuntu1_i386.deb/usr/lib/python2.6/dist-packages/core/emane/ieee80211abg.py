#
# CORE
# Copyright (c)2010 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# author: Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
'''
ieee80211abg.py: EMANE IEEE 802.11abg model for CORE
'''

import sys
import string
from core.api import coreapi

from core.constants import *
from emane import EmaneModel

class EmaneIeee80211abgModel(EmaneModel):
    def __init__(self, session, objid = None, verbose = False):
        EmaneModel.__init__(self, session, objid, verbose)

    # model name
    _name = "emane_ieee80211abg"
    # data types for configuration message fields (from the CORE API)
    _confdatatypes = (coreapi.CONF_DATA_TYPE_BOOL,
                      coreapi.CONF_DATA_TYPE_UINT8,
                      coreapi.CONF_DATA_TYPE_UINT32,
                      coreapi.CONF_DATA_TYPE_UINT32,
                      coreapi.CONF_DATA_TYPE_BOOL,
                      coreapi.CONF_DATA_TYPE_UINT8,
                      coreapi.CONF_DATA_TYPE_UINT8,
                      coreapi.CONF_DATA_TYPE_UINT16,
                      coreapi.CONF_DATA_TYPE_BOOL,
                      coreapi.CONF_DATA_TYPE_UINT8,
                      coreapi.CONF_DATA_TYPE_BOOL,
                      coreapi.CONF_DATA_TYPE_STRING,
                      coreapi.CONF_DATA_TYPE_STRING,
                      coreapi.CONF_DATA_TYPE_STRING,
                      coreapi.CONF_DATA_TYPE_STRING,
                      coreapi.CONF_DATA_TYPE_STRING,
                      coreapi.CONF_DATA_TYPE_STRING,
                      coreapi.CONF_DATA_TYPE_STRING,
                      coreapi.CONF_DATA_TYPE_UINT8,
                      coreapi.CONF_DATA_TYPE_UINT16,
                      coreapi.CONF_DATA_TYPE_UINT16,
                      coreapi.CONF_DATA_TYPE_UINT8,
                      coreapi.CONF_DATA_TYPE_UINT8,
                      coreapi.CONF_DATA_TYPE_UINT8,
                      coreapi.CONF_DATA_TYPE_UINT8,
                      coreapi.CONF_DATA_TYPE_UINT8,
                      coreapi.CONF_DATA_TYPE_UINT8,
                      coreapi.CONF_DATA_TYPE_STRING,
                      coreapi.CONF_DATA_TYPE_BOOL,
                      coreapi.CONF_DATA_TYPE_BOOL)
    # default values for configuration message
    _confdefaultvalues = ('0','0','0','1000','0','0','0','0',
                          '0','0','0','0:255 1:255 2:255 3:255',
                          '0:31 1:31 2:15 3:7',
                          '0:1023 1:1023 2:63 3:15',
                          '0:2 1:2 2:2 3:1',
                          '0:0 1:0 2:0 3:0',
                          '0:3 1:3 2:3 3:3',
                          '0:0 1:0 2:0 3:0',
                          '0', '2347','20','95',
                          '0','0','0','0','0',
              '/usr/share/emane/models/ieee80211abg/xml/ieee80211bercurves.xml',
                          '0','1')
    # possible values for configuration message
    _confpossiblevalues = "True,False|" \
                          "0 802.11b (DSSS only),1 802.11b (DSSS only)," \
                          "2 802.11a or g (OFDM),3 802.11b/g (DSSS and OFDM)|" \
                          "||On,Off|" \
                          "0 11 Mbps,1 1 Mbps,2 2 Mbps,3 5.5 Mbps,4 11 Mbps," \
                          "5 6 Mbps,6 9 Mbps,7 12 Mbps,8 18 Mbps,9 24 Mbps," \
                          "10 36 Mbps,11 48 Mbps,12 54 Mbps|" \
                          "0 1 Mbps,1 1 Mbps,2 2 Mbps,3 5.5 Mbps,4 11 Mbps," \
                          "5 6 Mbps,6 9 Mbps,7 12 Mbps,8 18 Mbps,9 24 Mbps," \
                          "10 36 Mbps,11 48 Mbps,12 54 Mbps|" \
                          "|Enable,Disable||Enable,Disable|" \
                          "|||||||" \
                          "0 802.11b (DSSS only),1 802.11b (DSSS only)," \
                          "2 802.11a or g (OFDM),3 802.11b/g (DSSS and OFDM)|" \
                          "|||||0 Omni,1 Directional||||Enable,Disable|On,Off"
    # captions used for configuration message
    _confcaptions = "enable promiscuous mode|mode|beacon interval|" \
                    "distance (m)|adaptive data rate and power|" \
                    "unicast rate (Mbps)|multicast rate (Mbps)|" \
                    "RTS threshold (bytes)|enable RTS/CTS/ACK|" \
                    "fragmentation threshold|WiFi Multimedia (WMM)|" \
                    "queue size (0-4:size)|" \
                    "min contention window (0-4:minw)|" \
                    "max contention window (0-4:maxw)|" \
                    "arbitration inter frame space (0-4:aifs)|" \
                    "txop (0-4:usec)|retry limit (0-4:numretries)|" \
                    "max msdu (packet size)(0-4:bytes)|" \
                    "802.11 mode|frequency (MHz)|bandwidth (KHz)|" \
                    "system noise floor (dB)|carrier sense threshold (dB)|" \
                    "tx power (dBm)|antenna type|antenna gain (dBi)|" \
                    "antenna beam width (deg)|BER curve file|force pass|" \
                    "default connectivity"
    # value groupings
    _confgroups = "802.11 MAC Parameters:1-18|802.11 PHY Parameters:19-30"

    def buildnemxmlfiles(self, e, ifc):
        ''' Build the necessary nem, mac, and phy XMLs in the given path.
            If an individual NEM has a nonstandard config, we need to build
            that file also. Otherwise the WLAN-wide nXXieee80211abgnem.xml,
            nXXieee80211abgemac.xml, nXXieee80211abgphy.xml are used.
        '''
        # use the network-wide config values or interface(NEM)-specific values?
        if ifc is None:
            values = e.getconfig(self.objid, self._name,
                                 self._confdefaultvalues)[1]
        else:
            nodenum = self.interfacetonodenumber(ifc)
            values = e.getconfig(nodenum, self._name, None)[1]
            if values is None:
                # do not build specific files for this NEM when config is same
                # as the network
                return
        nemdoc = e.xmldoc("nem")
        nem = nemdoc.getElementsByTagName("nem").pop()
        nem.setAttribute("name", "ieee80211abg NEM")
        mactag = nemdoc.createElement("mac")
        mactag.setAttribute("definition", self.macxmlname(ifc))
        nem.appendChild(mactag)
        phytag = nemdoc.createElement("phy")
        phytag.setAttribute("definition", self.phyxmlname(ifc))
        nem.appendChild(phytag)
        e.xmlwrite(nemdoc, self.nemxmlname(ifc))

        macdoc = e.xmldoc("mac")
        mac = macdoc.getElementsByTagName("mac").pop()
        mac.setAttribute("name", "ieee80211abg MAC")
        mac.setAttribute("library", "ieee80211abgmaclayer")
        macparamlist = ("enablepromiscuousmode", "mode", "beaconinterval",
                        "distance", "atpenable", "unicastrate",
                        "multicastrate", "rtsthreshold", "enablertsctsack",
                        "fragmentationthreshold", "wmmenable", "queuesize",
                        "cwmin", "cwmax", "aifs", "txop", "retrylimit",
                        "maxmsdu")
        i = 0
        for p in macparamlist:
            val = values[i]
            if self._confdatatypes[i] == coreapi.CONF_DATA_TYPE_BOOL:
                val = e.booltooffon(val)
            mac.appendChild(e.xmlparam(macdoc, p, val))
            i += 1

        e.xmlwrite(macdoc, self.macxmlname(ifc))

        phydoc = e.xmldoc("phy")
        phy = phydoc.getElementsByTagName("phy").pop()
        phy.setAttribute("name", "ieee80211abg PHY")
        phy.setAttribute("library", "ieee80211abgphylayer")
        phyparamlist = ("mode", "frequency", "bandwidth", "systemnoisefloor",
                       "carriersensethreshold", "txpower", "antennatype",
                       "antennagain", "antennabeamwidth", "bercurves",
                       "forcepass", "defaultconnectivity")
        # i already set to past last MAC model value
        for p in phyparamlist:
            val = values[i]
            if self._confdatatypes[i] == coreapi.CONF_DATA_TYPE_BOOL:
                val = e.booltooffon(val)
            phy.appendChild(e.xmlparam(phydoc, p, val))
            i += 1
        e.xmlwrite(phydoc, self.phyxmlname(ifc))

        transdoc = e.xmldoc("transport")
        trans = transdoc.getElementsByTagName("transport").pop()
        trans.setAttribute("name", "TAP Transport")
        trans.setAttribute("library", "transvirtual")
        trans.appendChild(e.xmlparam(transdoc, "bitrate", "0"))
        trans.appendChild(e.xmlparam(transdoc, "devicepath", "/dev/net/tun"))
        e.xmlwrite(transdoc, self.transportxmlname())

