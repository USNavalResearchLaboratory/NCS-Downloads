#
# CORE
# Copyright (c)2010 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# author: Tom Goff <thomas.goff@boeing.com>
#
'''
nodes.py: definition of an LxcNode and CoreNode classes, and other node classes that inherit from the CoreNode, implementing specific node types.
'''

from vnode import *
from vnet import *
from core.misc.ipaddr import *
from core.api import coreapi

class CtrlIfLxcNode(LxcNode):

    class CtrlNet(LxBrNet):
        policy = "ACCEPT"

        def __init__(self, session, objid = "ctrlnet", name = None,
                     verbose = False, netid = 1):
            self.prefix = IPv4Prefix("172.16.%d.0/24" % netid)
            LxBrNet.__init__(self, session, objid = objid, name = name,
                             verbose = verbose)

        def startup(self):
            LxBrNet.startup(self)
            check_call([IP_BIN, "addr", "add",
                        "%s/%s" % (self.prefix.maxaddr(),
                                   self.prefix.prefixlen), "dev", self.brname])

    def __init__(self, *args, **kwds):
        LxcNode.__init__(self, *args, **kwds)
        if "ctrlid" in kwds:
            self.ctrlid = kwds.pop("ctrlid")
        else:
            self.ctrlid = self.nodeid()
        ctrlnet = self.ctrlnet()
        self.newnetif(net = ctrlnet, ifindex = -1, ifname = "ctrl0",
                      addrlist = ["%s/%s" % (ctrlnet.prefix.addr(self.ctrlid),
                                             ctrlnet.prefix.prefixlen)])

    def ctrlnet(self, ctrlnetid = "ctrlnet"):
        try:
            tmp = self.session.obj(ctrlnetid)
        except KeyError:
            tmp = self.session.addobj(cls = self.CtrlNet, objid = ctrlnetid)
        return tmp

    def boot(self):
        self.shcmd("mkdir -p /var/run/sshd && chmod 0700 /var/run/sshd")
        self.cmd(["/usr/sbin/sshd"])
        LxcNode.boot(self)

# class CoreNode(CtrlIfLxcNode):
class CoreNode(LxcNode):
    def bootconf(self):
        return os.path.join(self.confdir, "boot.conf")

    def quaggaconf(self):
        return os.path.join(self.confdir, "Quagga.conf")

    def bootscript(self):
        # read Quagga search paths from core.conf file
        try:
            quagga_bin_search = self.session.cfg['quagga_bin_search']
            quagga_sbin_search = self.session.cfg['quagga_sbin_search']
        except KeyError:
            quagga_bin_search = "/usr/bin"
            quagga_sbin_search = "/usr/sbin"
        bootconf = self.bootconf()
        quaggaconf = self.quaggaconf()
        return """\
#!/bin/sh

QUAGGA_SBIN_SEARCH=%s
QUAGGA_BIN_SEARCH=%s
QUAGGA_STATE_DIR=%s
CONF_DIR=%s

startup()
{
    cmd=$1
    file=$2

    if [ -r "$file" ]; then
        bootcmd=$(awk '
            /bootcmd/ {
                for(i=0;i<=NF;i++)
                    if ($i == "bootcmd")
                        print $(i+1);
                    exit;
                }
            ' $file)

        if [ "$bootcmd" ]; then
            $bootcmd $file
        else
            $cmd $file
        fi
    fi
}

searchforprog()
{
    prog=$1
    searchpath=$@
    ret=
    for p in $searchpath; do
        if [ -x $p/$prog ]; then
            ret=$p
            break
        fi
    done
    echo $ret
}

bootconf()
{
    /bin/sh $1
}

bootquagga()
{
    /sbin/sysctl -w net.ipv4.conf.all.forwarding=1
    /sbin/sysctl -w net.ipv6.conf.all.forwarding=1
    /sbin/sysctl -w net.ipv4.conf.all.send_redirects=0

    QUAGGA_BIN_DIR=$(searchforprog vtysh $QUAGGA_BIN_SEARCH)
    if [ "z$QUAGGA_BIN_DIR" = "z" ]; then
        echo "ERROR: Quagga's 'vtysh' daemon not found in search path:"
        echo "  $QUAGGA_BIN_SEARCH"
        return 1
    fi
    QUAGGA_SBIN_DIR=$(searchforprog zebra $QUAGGA_SBIN_SEARCH)
    if [ "z$QUAGGA_SBIN_DIR" = "z" ]; then
        echo "ERROR: Quagga's 'zebra' daemon not found in search path:"
        echo "  $QUAGGA_SBIN_SEARCH"
        return 1
    fi
    mkdir -p $QUAGGA_STATE_DIR
    $QUAGGA_SBIN_DIR/zebra -d

    # if /etc/quagga exists, point /etc/quagga/Quagga.conf -> CONF_DIR
    if [ "$CONF_DIR" != "/etc/quagga" ] && [ -d /etc/quagga ] && [ ! -e /etc/quagga/Quagga.conf ]; then
        ln -s $CONF_DIR/Quagga.conf /etc/quagga/Quagga.conf
    fi

    vtyfiles="zebra.vty"
    for r in rip ripng ospf6 ospf bgp; do
        if grep -q "^router \<${r}\>" $1; then
            $QUAGGA_SBIN_DIR/${r}d -d
            vtyfiles="$vtyfiles ${r}d.vty"
        fi
    done

    for f in $vtyfiles; do
        count=1
        until [ -e $QUAGGA_STATE_DIR/$f ]; do
            if [ $count -eq 10 ]; then
                echo "ERROR: vty file not found: $QUAGGA_STATE_DIR/$f" >&2
                return 1
            fi
            sleep 0.1
            count=$(($count + 1))
        done
    done

    $QUAGGA_BIN_DIR/vtysh -b
}

startup bootquagga $CONF_DIR/%s
startup bootconf $CONF_DIR/%s
startup bootconf $CONF_DIR/%s
""" % (quagga_sbin_search, quagga_bin_search, QUAGGA_STATE_DIR,
       self.confdir, "Quagga.conf", "boot.conf", self.name + ".conf")

class QuaggaNode(CoreNode):
    apitype = coreapi.CORE_NODE_QUAGGA

class HostNode(CoreNode):
    apitype = coreapi.CORE_NODE_HOST

class PcNode(CoreNode):
    apitype = coreapi.CORE_NODE_PC

class PtpNet(LxBrNet):
    policy = "ACCEPT"

    def attach(self, netif):
        if len(self._netif) > 1:
            raise ValueError, \
                  "Point-to-point links support at most 2 network interfaces"
        LxBrNet.attach(self, netif)

    def tonodemsg(self, flags):
        ''' Do not generate a Node Message for point-to-point links. They are
            built using a link message instead.
        '''
        pass

    def tolinkmsgs(self, flags):
        ''' Build CORE API TLVs for a point-to-point link. One Link message
            describes this network.
        '''
        tlvdata = ""
        if len(self._netif) != 2:
            return tlvdata
        (if1, if2) = self._netif.items()
        if1 = if1[1]
        if2 = if2[1]
        tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_N1NUMBER,
                                            if1.node.objid)
        tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_N2NUMBER,
                                            if2.node.objid)
        tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_TYPE,
                                            self.linktype)

        tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_IF1NUM, \
                                            if1.node.getifindex(if1))
        for addr in if1.addrlist:
            (ip, sep, mask)  = addr.partition('/')
            mask = int(mask)
            if isIPv4Address(ip):
                family = AF_INET
                tlvtypeip = coreapi.CORE_TLV_LINK_IF1IP4
                tlvtypemask = coreapi.CORE_TLV_LINK_IF1IP4MASK
            else:
                family = AF_INET6
                tlvtypeip = coreapi.CORE_TLV_LINK_IF1IP6
                tlvtypemask = coreapi.CORE_TLV_LINK_IF1IP6MASK
            ipl = socket.inet_pton(family, ip)
            tlvdata += coreapi.CoreLinkTlv.pack(tlvtypeip,
                                                IPAddr(af=family, addr=ipl))
            tlvdata += coreapi.CoreLinkTlv.pack(tlvtypemask, mask)

        tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_IF2NUM, \
                                            if2.node.getifindex(if2))
        for addr in if2.addrlist:
            (ip, sep, mask)  = addr.partition('/')
            mask = int(mask)
            if isIPv4Address(ip):
                family = AF_INET
                tlvtypeip = coreapi.CORE_TLV_LINK_IF2IP4
                tlvtypemask = coreapi.CORE_TLV_LINK_IF2IP4MASK
            else:
                family = AF_INET6
                tlvtypeip = coreapi.CORE_TLV_LINK_IF2IP6
                tlvtypemask = coreapi.CORE_TLV_LINK_IF2IP6MASK
            ipl = socket.inet_pton(family, ip)
            tlvdata += coreapi.CoreLinkTlv.pack(tlvtypeip,
                                                IPAddr(af=family, addr=ipl))
            tlvdata += coreapi.CoreLinkTlv.pack(tlvtypemask, mask)

        # TODO: add link effects: BW, DELAY, JITTER, ERROR, etc
        msg = coreapi.CoreLinkMessage.pack(flags, tlvdata)
        return [msg,]

class SwitchNode(LxBrNet):
    apitype = coreapi.CORE_NODE_SWITCH
    policy = "ACCEPT"

class HubNode(LxBrNet):
    apitype = coreapi.CORE_NODE_HUB
    policy = "ACCEPT"

class WlanNode(LxBrNet):
    apitype = coreapi.CORE_NODE_WLAN
    linktype = coreapi.CORE_LINK_WIRELESS
    policy = "DROP"

class RJ45Node(LxBrNet):
    apitype = coreapi.CORE_NODE_RJ45
    policy = "ACCEPT"

    def __init__(self, session, objid, name, verbose):
        LxBrNet.__init__(self, session, objid, name, verbose)
        check_call([BRCTL_BIN, "addif", self.brname, name])

    def attach(self, netif):
        if len(self._netif) > 0:
            raise ValueError, \
                  "RJ45 networks support at most 1 network interface"
        LxBrNet.attach(self, netif)

class TunnelNode(LxBrNet):
    apitype = coreapi.CORE_NODE_TUNNEL
    policy = "ACCEPT"

