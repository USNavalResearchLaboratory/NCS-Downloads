# Constants created by autoconf ./configure script
COREDPY_VERSION		= "2.0"
CORE_STATE_DIR		= "/var"
CORE_CONF_DIR		= "/etc/core"
CORE_LIB_DIR		= "/usr/lib/core"
CORE_SBIN_DIR		= "/usr/sbin"

BRCTL_BIN               = "/usr/sbin/brctl"
IP_BIN                  = "/sbin/ip"
TC_BIN                  = "/sbin/tc"
EBTABLES_BIN            = "/sbin/ebtables"
QUAGGA_STATE_DIR        = "/var/run/quagga"
