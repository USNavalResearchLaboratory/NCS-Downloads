#
# CORE
# Copyright (c)2010 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# author: Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
'''
broker.py: definition of CoreBroker class that is part of the
pycore session object. Handles distributing parts of the emulation out to
other emulation servers. The broker is consulted during the 
CoreRequestHandler.handlemsg() loop to determine if messages should be handled
locally or forwarded on to another emulation server.
'''

import socket, select, threading, sys
from core.api import coreapi
from core.coreobj import PyCoreNet

class CoreBroker():
    ''' Member of pycore session class for handling global emulation server
        data.
    '''
    def __init__(self, session, verbose = False):
        self.session = session
        self.verbose = verbose
        # dict containing tuples of (host, port, sock)
        self.servers = {}
        self.servers_lock = threading.Lock()
        self.addserver("localhost", None, None)
        # dict containing node number to server name mapping
        self.nodemap = {}
        self.nets = []
        self.handlers = ()
        self.dorecvloop = False
        self.recvthread = None
        self.register()

    def shutdown(self):
        ''' Close all active sockets.
        '''
        self.servers_lock.acquire()
        try:
            while len(self.servers) > 0:
                (server, v) = self.servers.popitem()
                (host, port, sock) = v
                if sock is None:
                    continue
                if self.verbose:
                    self.session.info("closing connection with %s @ %s:%s" % \
                                      (server, host, port))
                sock.close()
        finally:
            self.servers_lock.release()
        self.dorecvloop = False
        if self.recvthread is not None:
            self.recvthread.join()

    def reset(self):
        ''' Reset to initial state.
        '''
        self.nodemap.clear()
        del self.nets[:]
        # TODO: need to decide on a good time to hang up with remote server,
        #       e.g. after receiving all node delete reply messages

    def startrecvloop(self):
        ''' Spawn the recvloop() thread if it hasn't been already started.
        '''
        if self.recvthread is not None:
            if self.recvthread.isAlive():
                return
            else:
                # self.recvthread.join() ?
                pass
        # start reading data from connected sockets
        self.dorecvloop = True
        self.recvthread = threading.Thread(target = self.recvloop)
        self.recvthread.daemon = True
        self.recvthread.start()

    def recvloop(self):
        ''' Thread target that receives messages from server sockets.
        '''

        self.dorecvloop = True
        while self.dorecvloop:
            rlist = []
            # build a socket list for select call
            self.servers_lock.acquire()
            for name in self.servers:
                (h, p, sock) = self.servers[name]
                if sock is not None:
                    rlist.append(sock.fileno())
            self.servers_lock.release()
            r, w, x = select.select(rlist, [], [], 1.0)
            self.servers_lock.acquire()
            try:
                for name in self.servers:
                    (h, p, sock) = self.servers[name]
                    if sock is None:
                        continue
                    if sock.fileno() in r:
                        rcvlen = self.recv(sock, h)
                        if rcvlen == 0:
                            if self.verbose:
                                self.session.info("connection with %s @ %s:%s" \
                                                  " has closed" % (name, h, p))
                            self.servers[name] = (h, p, None)
            finally:
                self.servers_lock.release()
            # we may want to exit this thread when there are no servers left

    def recv(self, sock, host):
        ''' Receive data on an emulation server socket and broadcast it to
            all connected session handlers. Returns the length of data recevied
            and forwarded. Return value of zero indicuates the socket has closed
            and should be removed from the self.servers dict.
        '''
        msghdr = sock.recv(coreapi.CoreMessage.hdrsiz)
        if len(msghdr) == 0:
            # server disconnected
            sock.close()
            return 0
        if len(msghdr) != coreapi.CoreMessage.hdrsiz:
            if self.verbose:
                self.session.info("warning: broker received not enough data " \
                                  "len=%s" % len(msghdr))
            return len(msghdr)

        msgtype, msgflags, msglen = coreapi.CoreMessage.unpackhdr(msghdr)
        msgdata = sock.recv(msglen)
        data = msghdr + msgdata

        # snoop exec response for remote interactive TTYs
        if msgtype == coreapi.CORE_API_EXEC_MSG and \
           msgflags & coreapi.CORE_API_TTY_FLAG:
            data = self.fixupremotetty(msghdr, msgdata, host)

        self.session.broadcastraw(None, data)
        return len(data)

    def addserver(self, name, host, port):
        ''' Add a new server, and try to connect to it. If we're already
            connected to this (host, port), then leave it alone. When host,port
            is None, do not try to connect.
        '''
        self.servers_lock.acquire()
        if name in self.servers:
            (oldhost, oldport, sock) = self.servers[name]
            if host == oldhost or port == oldport:
                # leave this socket connected
                if sock is not None:
                    self.servers_lock.release()
                    return
            if self.verbose and host is not None and sock is not None:
                self.session.info("closing connection with %s @ %s:%s" % \
                                  (server, host, port))
            if sock is not None:
                sock.close()
        self.servers_lock.release()
        if self.verbose and host is not None:
            self.session.info("adding server %s @ %s:%s" % (name, host, port))
        if host is None:
            sock = None
        else:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            #sock.setblocking(0)
            #error = sock.connect_ex((host, port))
            try:
                sock.connect((host, port))
                self.startrecvloop()
            except Exception, e:
                self.session.warn("error connecting to server %s:%s:\n\t%s" % \
                                  (host, port, e))
                sock.close()
                sock = None
        self.servers_lock.acquire()
        self.servers[name] = (host, port, sock)
        self.servers_lock.release()

    def getserver(self, name):
        ''' Return the (host, port, sock) tuple, or raise a KeyError exception.
        '''
        if name not in self.servers:
            raise KeyError, "emulation server %s not found" % name
        return self.servers[name]

    def addnodemap(self, server, nodenum):
        ''' Record a node number to emulation server mapping.
        '''
        if nodenum in self.nodemap:
            if server in self.nodemap[nodenum]:
                return
            self.nodemap[nodenum].append(server)
        else:
            self.nodemap[nodenum] = [server,]

    def getserversbynode(self, nodenum):
        ''' Retrieve a list of emulation servers given a node number.
        '''
        if nodenum not in self.nodemap:
            return []
        return self.nodemap[nodenum]

    def addnet(self, nodenum):
        '''
        '''
        if nodenum not in self.nets:
            self.nets.append(nodenum)

    def register(self):
        ''' Register as a configurable object with the Session object.
        '''
        self.session.addconfobj("broker", coreapi.CORE_TLV_REG_UTILITY,
                                self.configure)

    def configure(self, pycore, msg):
        ''' Receive configuration message with a list of server:host:port
            combinations that we'll need to connect with.
        '''
        objname = msg.gettlv(coreapi.CORE_TLV_CONF_OBJ)
        conftype = msg.gettlv(coreapi.CORE_TLV_CONF_TYPE)
        if conftype == coreapi.CONF_TYPE_FLAGS_REQUEST:
            # ignore configuration requests
            # in the future, distribution schemes might be configured here
            pass
        elif conftype == coreapi.CONF_TYPE_FLAGS_RESET:
            if objname == "all" or objname == "broker":
                self.reset()
        else:
            values_str = msg.gettlv(coreapi.CORE_TLV_CONF_VALUES)
            if values_str is None:
                self.session.info("emulation server data missing")
                return None
            values = values_str.split('|')
            # string of "server:ip:port,server:ip:port,..."
            serverstrings = values[0]
            server_list = serverstrings.split(',')
            for server in server_list:
                server_items = server.split(':')
                (name, host, port) = server_items[:3]
                if host == '':
                    host = None
                if port == '':
                    port = None
                else:
                    port = int(port)
                # this connects to the server immediately; maybe we should wait
                # or spin off a new "client" thread here
                self.addserver(name, host, port)
                self.setupserver(name)

    def handlemsg(self, msg):
        ''' Handle an API message. Determine whether this needs to be handled
            by the local server or forwarded on to another one. 
            Returns True when message does not need to be handled locally,
            and performs forwarding if required.
            Returning False indicates this message should be handled locally.
        '''
        serverlist = []
        handle_locally = False

        #
        # Decide whether message should be handled locally or forwarded, or both
        #
        if msg.msgtype == coreapi.CORE_API_NODE_MSG:
            # snoop Node Message for emulation server TLV and record mapping
            n = msg.tlvdata[coreapi.CORE_TLV_NODE_NUMBER]
            # replicate link-layer nodes on all servers
            nodetype = msg.gettlv(coreapi.CORE_TLV_NODE_TYPE)
            if nodetype is not None:
                try:
                    nodecls = coreapi.node_class(nodetype)
                except KeyError:
                    self.session.warn("broker invalid node type %s" % nodetype)
                    return False
                if issubclass(nodecls, PyCoreNet):
                    self.servers_lock.acquire()
                    serverlist = self.servers.keys()
                    self.servers_lock.release()
                    handle_locally = True
                    self.addnet(n)
                    for server in serverlist:
                        self.addnodemap(server, n)
            # emulation server TLV specifies server
            server = msg.gettlv(coreapi.CORE_TLV_NODE_EMUSRV)
            if server is not None:
                self.addnodemap(server, n)
                if server not in serverlist:
                    serverlist.append(server)
        elif msg.msgtype == coreapi.CORE_API_EVENT_MSG:
            # broadcast events everywhere
            self.servers_lock.acquire()
            serverlist = self.servers.keys()
            self.servers_lock.release()
        elif msg.msgtype == coreapi.CORE_API_CONF_MSG:
            # broadcast location configuration everywhere
            confobj = msg.gettlv(coreapi.CORE_TLV_CONF_OBJ)
            if confobj == "location":
                self.servers_lock.acquire()
                serverlist = self.servers.keys()
                self.servers_lock.release()

        # prepare serverlist from node numbers
        if msg.msgtype == coreapi.CORE_API_LINK_MSG:
            # determine link message destination using non-network nodes
            nn = msg.nodenumbers()
            if nn[0] in self.nets:
                serverlist = self.getserversbynode(nn[1])
            elif nn[1] in self.nets:
                serverlist = self.getserversbynode(nn[0])
            else:
                serverset1 = set(self.getserversbynode(nn[0]))
                serverset2 = set(self.getserversbynode(nn[1]))
                if serverset1 != serverset2:
                    # TODO: build bridge tunnels here
                    self.session.info("TODO: link between nodes not suppo" \
                                      "rted yet (%s - %s)" % (nn[0], nn[1]))
                    handle_locally = False
                    serverlist = []
                else:
                    serverlist = list(serverset1 | serverset2)
        elif len(serverlist) == 0:
            # check for servers based on node numbers in all messages but link
            nn = msg.nodenumbers()
            if len(nn) == 0:
                return False
            serverlist = self.getserversbynode(nn[0])

        if len(serverlist) == 0: 
            handle_locally = True

        # allow other handlers to process this message
        # (this is used by e.g. EMANE to use the link add message to keep counts
        # of interfaces on other servers)
        for handler in self.handlers:
            handler(msg)

        #
        # Perform any message forwarding
        #
        for server in serverlist:
            try:
                (host, port, sock) = self.getserver(server)
            except KeyError:
                # server not found, don't handle this message locally
                self.session.info("broker could not find server %s, message " \
                                  "with type %s dropped" % \
                                  (server, msg.msgtype))
                continue
            if host is None and port is None:
                # local emulation server, handle this locally
                handle_locally = True
            else:
                if sock is None:
                    self.session.info("server %s @ %s:%s is disconnected" % \
                                      (server, host, port))
                else:
                    sock.send(msg.rawmsg)
        return not handle_locally

    def setupserver(self, server):
        ''' Send the appropriate API messages for configuring the specified
            emulation server.
        '''
        (host, port, sock) = self.getserver(server)
        if host is None or sock is None:
            return
        # send a Configuration message for the broker object and inform the
        # server of its local name (using empty host:port fields)
        tlvdata = ""
        tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_OBJ, "broker")
        tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_TYPE,
                                            coreapi.CONF_TYPE_FLAGS_UPDATE)
        tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_DATA_TYPES,
                                            (coreapi.CONF_DATA_TYPE_STRING,))
        tlvdata += coreapi.CoreConfTlv.pack(coreapi.CORE_TLV_CONF_VALUES,
                                            "%s::" % server)
        msg = coreapi.CoreConfMessage.pack(0, tlvdata)
        sock.send(msg)

    @staticmethod
    def fixupremotetty(msghdr, msgdata, host):
        ''' When an interactive TTY request comes from the GUI, snoop the reply
            and add an SSH command to the appropriate remote server.
        '''
        msgtype, msgflags, msglen = coreapi.CoreMessage.unpackhdr(msghdr)
        msgcls = coreapi.msg_class(msgtype)
        msg = msgcls(msgflags, msghdr, msgdata)

        nodenum = msg.gettlv(coreapi.CORE_TLV_EXEC_NODE)
        execnum = msg.gettlv(coreapi.CORE_TLV_EXEC_NUM)
        cmd = msg.gettlv(coreapi.CORE_TLV_EXEC_CMD)
        res = msg.gettlv(coreapi.CORE_TLV_EXEC_RESULT)

        tlvdata = ""
        tlvdata += coreapi.CoreExecTlv.pack(coreapi.CORE_TLV_EXEC_NODE, nodenum)
        tlvdata += coreapi.CoreExecTlv.pack(coreapi.CORE_TLV_EXEC_NUM, execnum)
        tlvdata += coreapi.CoreExecTlv.pack(coreapi.CORE_TLV_EXEC_CMD, cmd)
        title = "\\\"CORE: n%s @ %s\\\"" % (nodenum, host)
        res = "ssh -X -f " + host + " xterm -sb -rightbar -T " + title + \
              " -e " + res
        tlvdata += coreapi.CoreExecTlv.pack(coreapi.CORE_TLV_EXEC_RESULT, res)

        return coreapi.CoreExecMessage.pack(msgflags, tlvdata)







