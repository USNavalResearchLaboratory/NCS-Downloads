#
# CORE
# Copyright (c)2010 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# author: Tom Goff <thomas.goff@boeing.com>
#
'''
vnet.py: PyCoreNet and LxBrNet classes that implement virtual networks using
Linux Ethernet bridging and ebtables rules.
'''

import sys, threading

from core.misc.utils import *
from core.constants import *
from core.coreobj import PyCoreNet

checkexec([BRCTL_BIN, IP_BIN, EBTABLES_BIN, TC_BIN])

ebtables_lock = threading.Lock()

def ebtablescmds(call, cmds):
    ebtables_lock.acquire()
    try:
        for cmd in cmds:
            call(cmd)
    finally:
        ebtables_lock.release()

class LxBrNet(PyCoreNet):

    policy = "DROP"

    def __init__(self, session, objid = None, name = None, verbose = False):
        PyCoreNet.__init__(self, session, objid, name)
	# XXX jeffa the following line has no effect?
        if name is None:
            name = str(self.objid)
        self.name = name
        self.brname = "b.%s.%s" % (str(self.objid), self.session.sessionid)
        self.verbose = verbose
        self._netif = {}
        self._linked = {}
        self.up = False
        self.startup()

    def info(self, msg):
        if self.verbose:
            print "%s: %s" % (self.name, msg)
            sys.stdout.flush()

    def warn(self, msg):
        print >> sys.stderr, "%s: %s" % (self.name, msg)
        sys.stderr.flush()

    def startup(self):
        check_call([BRCTL_BIN, "addbr", self.brname])
        check_call([BRCTL_BIN, "stp", self.brname, "off"])
        check_call([BRCTL_BIN, "setfd", self.brname, "0"])
        # the following line causes a huge performance hit for bridges having
        # many joined interfaces, but may be required for some multicast scen.
        #check_call([BRCTL_BIN, "setageing", self.brname, "0"])
        check_call([IP_BIN, "link", "set", self.brname, "up"])
        # create a new ebtables chain for this bridge
        ebtablescmds(check_call, [
            [EBTABLES_BIN, "-N", self.brname, "-P", self.policy],
            [EBTABLES_BIN, "-A", "FORWARD",
             "--logical-in", self.brname, "-j", self.brname]])
        self.up = True

    def shutdown(self):
        if not self.up:
            return
        mutecall([IP_BIN, "link", "set", self.brname, "down"])
        mutecall([BRCTL_BIN, "delbr", self.brname])
	ebtablescmds(mutecall, [
            [EBTABLES_BIN, "-D", "FORWARD",
             "--logical-in", self.brname, "-j", self.brname],
            [EBTABLES_BIN, "-X", self.brname]])
        self._netif.clear()
        self._linked.clear()
        del self.session
        self.up = False

    def netif(self):
        return self._netif.itervalues()

    def numnetif(self):
        return len(self._netif)

    def attach(self, netif):
        check_call([BRCTL_BIN, "addif", self.brname, netif.localname])
        self._netif[netif] = netif
        self._linked[netif] = {}

    def detach(self, netif):
        check_call([BRCTL_BIN, "delif", self.brname, netif.localname])
        del self._netif[netif]
        del self._linked[netif]

    def linked(self, netif1, netif2):
        # check if the network interfaces are attached to this network
        if self._netif[netif1] != netif1:
            raise ValueError, "inconsistency for netif %s" % netif1.name
        if self._netif[netif2] != netif2:
            raise ValueError, "inconsistency for netif %s" % netif2.name
        try:
            linked = self._linked[netif1][netif2]
        except KeyError:
            if self.policy == "ACCEPT":
                linked = True
            elif self.policy == "DROP":
                linked = False
            else:
                raise Exception, "unknown policy: %s" % self.policy
            self._linked[netif1][netif2] = linked
        return linked

    def unlink(self, netif1, netif2):
        if not self.linked(netif1, netif2):
            return
        if self.policy == "DROP":
            ebtablescmds(check_call, [
                [EBTABLES_BIN, "-D", self.brname, "-i", netif1.localname,
                 "-o", netif2.localname, "-j", "ACCEPT"],
                [EBTABLES_BIN, "-D", self.brname, "-o", netif1.localname,
                 "-i", netif2.localname, "-j", "ACCEPT"]])
        elif self.policy == "ACCEPT":
            ebtablescmds(check_call, [
                [EBTABLES_BIN, "-A", self.brname, "-i", netif1.localname,
                 "-o", netif2.localname, "-j", "DROP"],
                [EBTABLES_BIN, "-A", self.brname, "-o", netif1.localname,
                 "-i", netif2.localname, "-j", "DROP"]])
        else:
            raise Exception, "unknown policy: %s" % self.policy
        self._linked[netif1][netif2] = False

    def link(self, netif1, netif2):
        if self.linked(netif1, netif2):
            return
        if self.policy == "DROP":
            ebtablescmds(check_call, [
                [EBTABLES_BIN, "-A", self.brname, "-i", netif1.localname,
                 "-o", netif2.localname, "-j", "ACCEPT"],
                [EBTABLES_BIN, "-A", self.brname, "-o", netif1.localname,
                 "-i", netif2.localname, "-j", "ACCEPT"]])
        elif self.policy == "ACCEPT":
            ebtablescmds(check_call, [
                [EBTABLES_BIN, "-D", self.brname, "-i", netif1.localname,
                 "-o", netif2.localname, "-j", "DROP"],
                [EBTABLES_BIN, "-D", self.brname, "-o", netif1.localname,
                 "-i", netif2.localname, "-j", "DROP"]])
        else:
            raise Exception, "unknown policy: %s" % self.policy
        self._linked[netif1][netif2] = True

    def linkconfig(self, netif, bw = None, delay = None,
                   loss = None, duplicate = None, jitter = None):
        tc = [TC_BIN, "qdisc", "replace", "dev", netif.localname]
        parent = ["root"]
        if bw > 0:
            # TOOD: make this configurable instead of hard-coded
            mtu = 1500
            # from tc-tbf(8): minimum value for burst is rate / kernel_hz
            burst = max(2 * mtu, bw / 1000)
            limit = 0xffff # max IP payload
            tbf = ["tbf", "rate", str(bw),
                   "burst", str(burst), "limit", str(limit)]
            check_call(tc + parent + ["handle", "1:"] + tbf)
            parent = ["parent", "1:1"]
        netem = ["netem"]
        if delay > 0:
            netem += ["delay", "%sus" % delay]
        if loss > 0:
            netem += ["loss", "%s%%" % min(loss, 100)]
        if duplicate > 0:
            netem += ["duplicate", "%s%%" % min(duplicate, 100)]
        if jitter > 0:
            pass                        # XXX
        if len(netem) > 1:
            check_call(tc + parent + ["handle", "10:"] + netem)

# class VNet(BrNet):
#     def __init__(self, session, objid, name = None,
#                  ipv4subnet = None, ipv6subnet = None):
#         self.name = name
#         self.ipv4subnet = ipv4subnet
#         self.ipv6subnet = ipv6subnet
#         BrNet.__init__(self, session, objid)
