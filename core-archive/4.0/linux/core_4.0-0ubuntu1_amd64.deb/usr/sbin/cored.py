#!/usr/bin/env python
#
# CORE
# Copyright (c)2010 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# authors: Tom Goff <thomas.goff@boeing.com>
#          Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
'''
cored.py: the CORE Python daemon is a server process that receives CORE API messages and instantiates emulated nodes and networks within the kernel. Various message handlers are defined and some support for sending messages.
'''

import SocketServer, fcntl, struct, sys, threading, time, traceback
import os, sys, optparse, ConfigParser, gc, shlex
import atexit
import signal

try:
    from core import pycore
except ImportError:
    # hack for Fedora autoconf that uses the following pythondir:
    sys.path.append("/usr/local/lib/python2.6/site-packages")
    from core import pycore
from core.constants import *
from core.api import coreapi
from core.coreobj import PyCoreNet
from core.misc.utils import hexdump

DEFAULT_MAXFD = 1024

# garbage collection debugging
# gc.set_debug(gc.DEBUG_STATS | gc.DEBUG_LEAK)


coreapi.add_node_class("CORE_NODE_QUAGGA",
                       coreapi.CORE_NODE_QUAGGA, pycore.nodes.QuaggaNode)
coreapi.add_node_class("CORE_NODE_HOST",
                       coreapi.CORE_NODE_HOST, pycore.nodes.HostNode)
coreapi.add_node_class("CORE_NODE_PC",
                       coreapi.CORE_NODE_PC, pycore.nodes.PcNode)
coreapi.add_node_class("CORE_NODE_SWITCH",
                       coreapi.CORE_NODE_SWITCH, pycore.nodes.SwitchNode)
coreapi.add_node_class("CORE_NODE_HUB",
                       coreapi.CORE_NODE_HUB, pycore.nodes.HubNode)
coreapi.add_node_class("CORE_NODE_WLAN",
                       coreapi.CORE_NODE_WLAN, pycore.nodes.WlanNode)
coreapi.add_node_class("CORE_NODE_RJ45",
                       coreapi.CORE_NODE_RJ45, pycore.nodes.RJ45Node)
coreapi.add_node_class("CORE_NODE_TUNNEL",
                       coreapi.CORE_NODE_TUNNEL, pycore.nodes.TunnelNode)
coreapi.add_node_class("CORE_NODE_EMANE",
                       coreapi.CORE_NODE_EMANE, pycore.nodes.EmaneNode)

def closeonexec(fd):
    fdflags = fcntl.fcntl(fd, fcntl.F_GETFD)
    fcntl.fcntl(fd, fcntl.F_SETFD, fdflags | fcntl.FD_CLOEXEC)

class CoreRequestHandler(SocketServer.BaseRequestHandler):

    maxmsgqueuedtimes = 8
    #positionscale = 0.2
    positionscale = 1.0

    def __init__(self, request, client_address, server):
        self.done = False
        self.msghandler = {
            coreapi.CORE_API_NODE_MSG: self.handlenodemsg,
            coreapi.CORE_API_LINK_MSG: self.handlelinkmsg,
            coreapi.CORE_API_EXEC_MSG: self.handleexecmsg,
            coreapi.CORE_API_REG_MSG: self.handleregmsg,
            coreapi.CORE_API_CONF_MSG: self.handleconfmsg,
            coreapi.CORE_API_FILE_MSG: self.handlefilemsg,
            coreapi.CORE_API_IFACE_MSG: self.handleifacemsg,
            coreapi.CORE_API_EVENT_MSG: self.handleeventmsg,
            coreapi.CORE_API_SESS_MSG: self.handlesessionmsg,
        }
        self.msgq = []
        self.msgcv = threading.Condition()
        numthreads = int(server.cfg['numthreads'])
        if numthreads < 1:
            raise ValueError, \
                  "invalid number of threads: %s" % numthreads
        self.handlerthreads = []
        while numthreads:
            t = threading.Thread(target = self.handlemsg)
            self.handlerthreads.append(t)
            t.start()
            numthreads -= 1
        self.master = False
        self.verbose = bool(server.cfg['verbose'].lower() == "true")
        self.debug = bool(server.cfg['debug'].lower() == "true")
        #self.numwlan = 0
        closeonexec(request.fileno())
        SocketServer.BaseRequestHandler.__init__(self, request,
                                                 client_address, server)

    def setup(self):
        ''' Client has connected, set up a new connection.
        '''
        self.info("new connection: %s:%s" % self.client_address)
        #self.register()


    def finish(self):
        ''' Client has disconnected, end this request handler and disconnect
            from the session. Shutdown sessions that are not running.
        '''
        if self.verbose:
            self.info("request done: notifying threads")
        self.msgcv.acquire()
        self.done = True
        self.msgcv.notifyAll()
        self.msgcv.release()
        for t in self.handlerthreads:
            if self.verbose:
                self.info("waiting for thread: %s" % t.getName())
            timeout = 2.0               # seconds
            t.join(timeout)
            if t.isAlive():
                self.warn("joining %s failed: still alive after %s sec" %
                          (t.getName(), timeout))
        self.info("connection closed: %s:%s" % self.client_address)
        self.session.disconnect(self)
        return SocketServer.BaseRequestHandler.finish(self)


    def info(self, msg):
        ''' Utility method for writing output to stdout.
        '''
        print msg
        sys.stdout.flush()


    def warn(self, msg):
        ''' Utility method for writing output to stderr.
        '''
        print >> sys.stderr, msg
        sys.stderr.flush()

    def register(self):
        ''' Send a Register Message
        '''
        self.info("registering 'cored.py' as emulation and execution server")
        tlvdata = ""
        tlvdata += coreapi.CoreRegTlv.pack(coreapi.CORE_TLV_REG_EXECSRV,
                                                    "cored.py")
        tlvdata += coreapi.CoreRegTlv.pack(coreapi.CORE_TLV_REG_EMULSRV,
                                                    "cored.py")
        tlvdata += self.session.confobjs_to_tlvs()
        reply = coreapi.CoreRegMessage.pack(coreapi.CORE_API_ADD_FLAG,
                                             tlvdata)
        self.request.sendall(reply)

    def sendsessions(self):
        ''' Send information on the current running sessions.
        '''
        msg = self.server.tosessionmsg()
        if msg is not None:
            self.request.sendall(msg)


    def sendobjs(self):
        ''' Send node and link messages announcing currently running nodes.
        '''
        nn = 0
        # send node messages for node and network objects
        for obj in self.session.objs():
            msg = obj.tonodemsg(flags = coreapi.CORE_API_ADD_FLAG)
            if msg is not None:
                self.request.sendall(msg)
                nn += 1

        nl = 0
        # send link messages from net objects
        for obj in self.session.objs():
            linkmsgs = obj.tolinkmsgs(flags = coreapi.CORE_API_ADD_FLAG)
            for msg in linkmsgs:
                self.request.sendall(msg)
                nl += 1

        self.info("informed GUI about %d nodes and %d links" % (nn, nl))

    def recvmsg(self):
        ''' Receive data and return a CORE API message object.
        '''
        try:
            msghdr = self.request.recv(coreapi.CoreMessage.hdrsiz)
            if self.debug:
                self.info("received message header:\n%s" % hexdump(msghdr))
        except:
            raise IOError
        if len(msghdr) != coreapi.CoreMessage.hdrsiz:
            raise IOError
        msgtype, msgflags, msglen = coreapi.CoreMessage.unpackhdr(msghdr)
        data = ""
        if msglen:
            data = self.request.recv(msglen)
            if self.debug:
                self.info("received message data:\n%s" % hexdump(data))
        else:
            self.warn("received message with no data")
        if len(data) != msglen:
            raise IOError
        try:
            msgcls = coreapi.msg_class(msgtype)
            msg = msgcls(msgflags, msghdr, data)
        except KeyError:
            msg = coreapi.CoreMessage(msgflags, msghdr, data)
            msg.msgtype = msgtype
            self.warn("unimplemented core message type: %s" % msg.typestr())
        return msg


    def queuemsg(self, msg):
        ''' Queue an API message for later processing.
        '''
        if msg.queuedtimes >= self.maxmsgqueuedtimes:
            self.warn("dropping message queued %d times: %s" %
                      (msg.queuedtimes, msg))
            return
        if self.verbose:
            self.info("queueing msg (queuedtimes = %s): type %s" %
                      (msg.queuedtimes, msg.msgtype))
        msg.queuedtimes += 1
        self.msgcv.acquire()
        self.msgq.append(msg)
        self.msgcv.notify()
        self.msgcv.release()

    def handlemsg(self):
        ''' CORE API message handling loop that is spawned for each server
            thread; get CORE API messages from the incoming message queue,
            and dispatch based on message type, optionally sending a reply.
        '''
        while not self.done:
            # get a coreapi.CoreMessage() from the incoming queue
            self.msgcv.acquire()
            while not self.msgq:
                self.msgcv.wait()
                if self.done:
                    self.msgcv.release()
                    return
            msg = self.msgq.pop(0)
            self.msgcv.release()

            if self.session.broker.handlemsg(msg):
                if self.verbose:
                    self.info("%s forwarding message:\n%s" %
                              (threading.currentThread().getName(), msg))
                continue

            if self.verbose:
                self.info("%s handling message:\n%s" %
                          (threading.currentThread().getName(), msg))

            if msg.msgtype not in self.msghandler:
                self.warn("XXX: no handler for message type: %s" %
                          msg.typestr())
                continue
            msghandler = self.msghandler[msg.msgtype]

            try:
                reply = msghandler(msg)
                if reply:
                    if self.verbose:
                        # XXX for debugging: print reply
                        msgtype, msgflags, msglen = \
                            coreapi.CoreMessage.unpackhdr(reply)
                        rmsg = coreapi.msg_class(msgtype)(msgflags,
                                             reply[:coreapi.CoreMessage.hdrsiz],
                                             reply[coreapi.CoreMessage.hdrsiz:])
                        self.info("%s: reply msg:\n%s" %
                                  (threading.currentThread().getName(), rmsg))
                    self.request.sendall(reply)
            except Exception, e:
                self.warn("%s: exception while handling msg:\n%s\n%s" %
                          (threading.currentThread().getName(), msg,
                           traceback.format_exc()))

    def handle(self):
        ''' Handle a new connection request from a client. Dispatch to the
            recvmsg() method for receiving data into CORE API messages, and
            add them to an incoming message queue.
        '''
        # use port as session id
        port = self.request.getpeername()[1]
        self.session = self.server.getsession(sessionid = port, 
                                              useexisting = False)
        self.session.connect(self)
        while True:
            try:
                msg = self.recvmsg()
            except IOError:
                break
            msg.queuedtimes = 0
            self.queuemsg(msg)
            self.session.broadcast(self, msg)
        #self.session.shutdown()
        #del self.session
        gc.collect()
#         print "gc count:", gc.get_count()
#         for o in gc.get_objects():
#             if isinstance(o, pycore.PyCoreObj):
#                 print "XXX XXX XXX PyCoreObj:", o
#                 for r in gc.get_referrers(o):
#                     print "XXX XXX XXX referrer:", gc.get_referrers(o)


    def handlenodemsg(self, msg):
        ''' Node Message handler
        '''

        reply = None
        if msg.flags & coreapi.CORE_API_ADD_FLAG and \
                msg.flags & coreapi.CORE_API_DEL_FLAG:
            self.warn("ignoring invalid message: "
                      "add and delete flag both set")
            return
        nodenum = msg.tlvdata[coreapi.CORE_TLV_NODE_NUMBER]

        if msg.flags & coreapi.CORE_API_ADD_FLAG:
            nodetype = msg.tlvdata[coreapi.CORE_TLV_NODE_TYPE]
            try:
                nodecls = coreapi.node_class(nodetype)
            except KeyError:
                try:
                    nodetypestr = " (%s)" % coreapi.node_types[nodetype]
                except KeyError:
                    nodetypestr = ""
                self.warn("warning: unimplemented node type: %s%s" % \
                          (nodetype, nodetypestr))
                return

            nodename =  msg.tlvdata[coreapi.CORE_TLV_NODE_NAME]
            n = self.session.addobj(cls = nodecls, objid = nodenum,
                                    name = nodename, verbose = self.verbose)
            nodexpos = msg.gettlv(coreapi.CORE_TLV_NODE_XPOS)
            nodeypos = msg.gettlv(coreapi.CORE_TLV_NODE_YPOS)
            if nodexpos is not None and nodeypos is not None:
                n.setposition(nodexpos, nodeypos, None)
            # The following code is used by some scripts to distinguish
            #  wireless subnets.
            #if isinstance(n, pycore.WlanNode):
            #    n.wlanid = self.numwlan
            #    self.numwlan += 1

            if msg.flags & coreapi.CORE_API_STR_FLAG:
                tlvdata = ""
                tlvdata += coreapi.CoreNodeTlv.pack(coreapi.CORE_TLV_NODE_NUMBER,
                                                    nodenum)
                tlvdata += coreapi.CoreNodeTlv.pack(coreapi.CORE_TLV_NODE_EMUID,
                                                    n.objid)
                reply = coreapi.CoreNodeMessage.pack(coreapi.CORE_API_ADD_FLAG \
                                                   | coreapi.CORE_API_LOC_FLAG,
                                                     tlvdata)
            self.session.checkruntime()

        elif msg.flags & coreapi.CORE_API_DEL_FLAG:

            try:
                n = self.session.obj(nodenum)
                #if isinstance(n, pycore.WlanNode):
                #    self.numwlan -= 1
            except KeyError:
                pass

            self.session.delobj(nodenum)

            if msg.flags & coreapi.CORE_API_STR_FLAG:
                tlvdata = ""
                tlvdata += coreapi.CoreNodeTlv.pack(coreapi.CORE_TLV_NODE_NUMBER,
                                                    nodenum)
                reply = coreapi.CoreNodeMessage.pack(coreapi.CORE_API_DEL_FLAG \
                                                   | coreapi.CORE_API_LOC_FLAG,
                                                     tlvdata)
            self.session.checkshutdown()
        # Node modify message (no add/del flag)
        else:
            nodeemuid = msg.gettlv(coreapi.CORE_TLV_NODE_EMUID)
            nodexpos = msg.gettlv(coreapi.CORE_TLV_NODE_XPOS)
            nodeypos = msg.gettlv(coreapi.CORE_TLV_NODE_YPOS)
            if nodeemuid is None or nodexpos is None or nodeypos is None:
                if self.verbose:
                    self.info("ignoring node message: nothing to do")
            else:
                try:
                    n = self.session.obj(nodeemuid)
                except KeyError:
                    self.warn("unknown node emuid: %s" % nodeemuid)
                    n = None
                if n:
                    x = self.positionscale * nodexpos
                    y = self.positionscale * nodeypos
                    n.setposition(x = x, y = y)
        return reply

    def handlelinkmsg(self, msg):
        ''' Link Message handler
        '''

        nodenum1 = msg.gettlv(coreapi.CORE_TLV_LINK_N1NUMBER)
        ifindex1 = msg.gettlv(coreapi.CORE_TLV_LINK_IF1NUM)
        ipv41 = msg.gettlv(coreapi.CORE_TLV_LINK_IF1IP4)
        ipv4mask1 = msg.gettlv(coreapi.CORE_TLV_LINK_IF1IP4MASK)
        mac1 = msg.gettlv(coreapi.CORE_TLV_LINK_IF1MAC)
        ipv61 = msg.gettlv(coreapi.CORE_TLV_LINK_IF1IP6)
        ipv6mask1 = msg.gettlv(coreapi.CORE_TLV_LINK_IF1IP6MASK)

        nodenum2 = msg.gettlv(coreapi.CORE_TLV_LINK_N2NUMBER)
        ifindex2 = msg.gettlv(coreapi.CORE_TLV_LINK_IF2NUM)
        ipv42 = msg.gettlv(coreapi.CORE_TLV_LINK_IF2IP4)
        ipv4mask2 = msg.gettlv(coreapi.CORE_TLV_LINK_IF2IP4MASK)
        mac2 = msg.gettlv(coreapi.CORE_TLV_LINK_IF2MAC)
        ipv62 = msg.gettlv(coreapi.CORE_TLV_LINK_IF2IP6)
        ipv6mask2 = msg.gettlv(coreapi.CORE_TLV_LINK_IF2IP6MASK)

        node1 = None
        node2 = None
        net = None

        if nodenum1 is not None:
            try:
                n = self.session.obj(nodenum1)
            except KeyError:
                # XXX wait and queue this message to try again later
                # XXX maybe this should be done differently
                time.sleep(0.125)
                self.queuemsg(msg)
                return
            if isinstance(n, pycore.nodes.PyCoreNode):
                node1 = n
            elif isinstance(n, pycore.nodes.PyCoreNet):
                net = n
            else:
                raise ValueError, "unexpected object class: %s" % n

        if nodenum2 is not None:
            try:
                n = self.session.obj(nodenum2)
            except KeyError:
                # XXX wait and queue this message to try again later
                # XXX maybe this should be done differently
                time.sleep(0.125)
                self.queuemsg(msg)
                return
            if isinstance(n, pycore.nodes.PyCoreNode):
                node2 = n
            elif isinstance(n, pycore.nodes.PyCoreNet):
                net = n
            else:
                raise ValueError, "unexpected object class: %s" % n

        linktype = msg.gettlv(coreapi.CORE_TLV_LINK_TYPE)

        if node1:
            node1.lock.acquire()
        if node2:
            node2.lock.acquire()

        try:
            # add a new link
            if msg.flags & coreapi.CORE_API_ADD_FLAG:
                ''' Add a new link.
                '''
                if node1 and node2 and not net and \
                        linktype == coreapi.CORE_LINK_WIRED:
                    # a new wired link
                    net = self.session.addobj(cls = pycore.nodes.PtpNet,
                                              verbose = self.verbose)

                bw = msg.gettlv(coreapi.CORE_TLV_LINK_BW)
                delay = msg.gettlv(coreapi.CORE_TLV_LINK_DELAY)
                if delay and isinstance(net, pycore.nodes.PtpNet):
                    delay = delay / 2.0
                loss = msg.gettlv(coreapi.CORE_TLV_LINK_PER)
                duplicate = msg.gettlv(coreapi.CORE_TLV_LINK_DUP)
                jitter = msg.gettlv(coreapi.CORE_TLV_LINK_JITTER)

                if node1 and net:
                    addrlist = []
                    if ipv41 is not None and ipv4mask1 is not None:
                        addrlist.append("%s/%s" % (ipv41, ipv4mask1))
                    if ipv61 is not None and ipv6mask1 is not None:
                        addrlist.append("%s/%s"% (ipv61, ipv6mask1))
                    node1.newnetif(net, addrlist = addrlist,
                                   hwaddr = mac1, ifindex = ifindex1)
                    net.linkconfig(node1.netif(ifindex1, net), bw = bw,
                                   delay = delay, loss = loss,
                                   duplicate = duplicate, jitter = jitter)
                if node2 and net:
                    addrlist = []
                    if ipv42 is not None and ipv4mask2 is not None:
                        addrlist.append("%s/%s" % (ipv42, ipv4mask2))
                    if ipv62 is not None and ipv6mask2 is not None:
                        addrlist.append("%s/%s"% (ipv62, ipv6mask2))
                    node2.newnetif(net, addrlist = addrlist,
                                   hwaddr = mac2, ifindex = ifindex2)
                    net.linkconfig(node2.netif(ifindex2, net), bw = bw,
                                   delay = delay, loss = loss,
                                   duplicate = duplicate, jitter = jitter)
                if node1 and node2 and not net and \
                       linktype == coreapi.CORE_LINK_WIRELESS:
                    # a wireless link event
                    numwlan = 0
                    for netif1 in node1.netifs():
                        for netif2 in node2.netifs():
                            if netif1.net == netif2.net and \
                                   isinstance(netif1.net, pycore.nodes.WlanNode):
                                netif1.net.link(netif1, netif2)
                                numwlan += 1
                    if numwlan == 0:
                        raise ValueError, "no common network found"
            # delete a link
            elif msg.flags & coreapi.CORE_API_DEL_FLAG:
                ''' Remove a link.
                '''
                if node1 and node2:
                    if linktype == coreapi.CORE_LINK_WIRED:
                        # TODO: fix this for the case where ifindex[1,2] are
                        #       not specified
                        # a wired unlink event, delete the connecting bridge
                        netif1 = node1.netif(ifindex1)
                        netif2 = node2.netif(ifindex2)
                        if netif1.net or netif2.net:
                            if netif1.net != netif2.net:
                                raise ValueError, "no common network found"
                            net = netif1.net
                            netif1.detachnet()
                            netif2.detachnet()
                            if net.numnetif() == 0:
                                self.session.delobj(net.objid)
                            node1.delnetif(ifindex1)
                            node2.delnetif(ifindex2)
                    elif linktype == coreapi.CORE_LINK_WIRELESS:
                        # a wireless unlink event
                        numwlan = 0
                        for netif1 in node1.netifs():
                            for netif2 in node2.netifs():
                                if netif1.net == netif2.net and \
                                       isinstance(netif1.net, pycore.nodes.WlanNode):
                                    netif1.net.unlink(netif1, netif2)
                                    numwlan += 1
                        if numwlan == 0:
                            raise ValueError, "no common network found"
            else:
                ''' Modify a link.
                '''
                bw = msg.gettlv(coreapi.CORE_TLV_LINK_BW)
                delay = msg.gettlv(coreapi.CORE_TLV_LINK_DELAY)
                #if delay and isinstance(net, pycore.nodes.PtpNet):
                #    delay = delay / 2.0
                loss = msg.gettlv(coreapi.CORE_TLV_LINK_PER)
                duplicate = msg.gettlv(coreapi.CORE_TLV_LINK_DUP)
                jitter = msg.gettlv(coreapi.CORE_TLV_LINK_JITTER)
                numnet = 0
                if node1 is None and node2 is None:
                    raise ValueError, "modify link for unknown nodes"
                elif node1 is None:
                    # node1 = layer 2node, node2 = layer3 node
                    net.linkconfig(node2.netif(ifindex2, net), bw = bw,
                                   delay = delay, loss = loss, 
                                   duplicate = duplicate, jitter = jitter)
                elif node2 is None:
                    # node2 = layer 2node, node1 = layer3 node
                    net.linkconfig(node1.netif(ifindex1, net), bw = bw,
                                   delay = delay, loss = loss, 
                                   duplicate = duplicate, jitter = jitter)
                else:
                    # node1 and node2 are layer3; search for common net
                    for netif1 in node1.netifs():
                        for netif2 in node2.netifs():
                            if netif1.net == netif2.net:
			        net = netif1.net
                                if ifindex1 is None:
                                    ifindex1 = node1.getifindex(netif1)
                                numnet += 1
                        if numnet == 0:
                            raise ValueError, "no common network found"
                    net.linkconfig(node1.netif(ifindex1, net), bw = bw,
                                   delay = delay, loss = loss,
                                   duplicate = duplicate, jitter = jitter)
                    net.linkconfig(node2.netif(ifindex2, net), bw = bw,
                                   delay = delay, loss = loss,
                                   duplicate = duplicate, jitter = jitter)

        finally:
            if node1:
                node1.lock.release()
            if node2:
                node2.lock.release()

    def handleexecmsg(self, msg):
        ''' Execute Message handler
        '''
        nodenum = msg.tlvdata[coreapi.CORE_TLV_EXEC_NODE]
        execnum = msg.tlvdata[coreapi.CORE_TLV_EXEC_NUM]
        cmd = msg.tlvdata[coreapi.CORE_TLV_EXEC_CMD]

        try:
            n = self.session.obj(nodenum)
        except KeyError:
            # XXX wait and queue this message to try again later
            # XXX maybe this should be done differently
            time.sleep(0.125)
            self.queuemsg(msg)
            return
        # build common TLV items for reply
        tlvdata = ""
        tlvdata += coreapi.CoreExecTlv.pack(coreapi.CORE_TLV_EXEC_NODE, nodenum)
        tlvdata += coreapi.CoreExecTlv.pack(coreapi.CORE_TLV_EXEC_NUM, execnum)
        tlvdata += coreapi.CoreExecTlv.pack(coreapi.CORE_TLV_EXEC_CMD, cmd)

        if msg.flags & coreapi.CORE_API_TTY_FLAG:
            # echo back exec message with cmd for spawning interactive terminal
            if cmd is "bash":
                cmd = "/bin/bash"
            res = CORE_SBIN_DIR + "/vcmd -c " + n.ctrlchnlname + " -- " + cmd
            tlvdata += coreapi.CoreExecTlv.pack(coreapi.CORE_TLV_EXEC_RESULT,
                                                res)
            reply = coreapi.CoreExecMessage.pack(coreapi.CORE_API_TTY_FLAG,
                                                 tlvdata)
            self.request.sendall(reply)
        else:
            if self.verbose:
                self.info("execute message with cmd = '%s'" % cmd)
            # execute command and send a response
            if msg.flags & coreapi.CORE_API_STR_FLAG or \
               msg.flags & coreapi.CORE_API_TXT_FLAG:
                # shlex.split() handles quotes within the string
                status, res = n.cmdresult(shlex.split(cmd))
                if self.verbose:
                    self.info("done exec cmd='%s' with status=%d res=(%d bytes)"
                              % (cmd, status, len(res)))
                if msg.flags & coreapi.CORE_API_TXT_FLAG:
                    tlvdata += coreapi.CoreExecTlv.pack( \
                                        coreapi.CORE_TLV_EXEC_RESULT, res)
                if msg.flags & coreapi.CORE_API_STR_FLAG:
                    tlvdata += coreapi.CoreExecTlv.pack( \
                                        coreapi.CORE_TLV_EXEC_STATUS, status)
                reply = coreapi.CoreExecMessage.pack(0, tlvdata)
                self.request.sendall(reply)
            # execute the command with no response
            else:
                n.cmd(shlex.split(cmd), wait=False)


    def handleregmsg(self, msg):
        ''' Register Message Handler
        '''
        gui = msg.gettlv(coreapi.CORE_TLV_REG_GUI)
        if gui is None:
            self.info("ignoring Register message")
        else:
            # register capabilities with the GUI
            self.master = True
            found = self.server.setsessionmaster(self)
            self.register()
            self.sendsessions()

    def handleconfmsg(self, msg):
        ''' Configuration Message handler
        '''
        nodenum = msg.gettlv(coreapi.CORE_TLV_CONF_NODE)
        objname = msg.gettlv(coreapi.CORE_TLV_CONF_OBJ)
        if self.verbose:
            self.info("Configuration message for %s node %s" % \
                      (objname, nodenum))
        # dispatch to any registered callback for this object type
        replies = self.session.confobj(objname, self.session, msg)
        # config requests usually have a reply with default data
        for reply in replies:
            self.request.sendall(reply)

    def handlefilemsg(self, msg):
        ''' File Message handler
        '''
        if msg.flags & coreapi.CORE_API_ADD_FLAG:
            nodenum = msg.gettlv(coreapi.CORE_TLV_NODE_NUMBER)
            filename = msg.gettlv(coreapi.CORE_TLV_FILE_NAME)
            srcname = msg.gettlv(coreapi.CORE_TLV_FILE_SRCNAME)
            data = msg.gettlv(coreapi.CORE_TLV_FILE_DATA)
            cmpdata = msg.gettlv(coreapi.CORE_TLV_FILE_CMPDATA)

            if cmpdata is not None:
                self.warn("Compressed file data not implemented for File " \
                          "message.")
                return
            if srcname is not None and data is not None:
                self.warn("ignoring invalid File message: source and data " \
                         "TLVs are both present")
                return

            try:
                n = self.session.obj(nodenum)
            except KeyError:
                # XXX wait and queue this message to try again later
                # XXX maybe this should be done differently
                time.sleep(0.125)
                self.queuemsg(msg)
                return
            if srcname is not None:
                n.addfile(srcname, filename)
            elif data is not None:
                n.nodefile(filename, data)
            # XXX assume node can be booted now
            n.boot()
        else:
            raise NotImplementedError

    def handleifacemsg(self, msg):
        ''' Interface Message handler
        '''
        self.info("ignoring Interface message")

    def handleeventmsg(self, msg):
        ''' Event Message handler
        '''
        eventtype = msg.tlvdata[coreapi.CORE_TLV_EVENT_TYPE]
        #self.info("EVENT %d: %s at %s" % \
        #          (eventtype, coreapi.event_types[eventtype], time.ctime()))
        self.session.setstate(state=eventtype, info=True, sendevent=False)
        if eventtype == coreapi.CORE_EVENT_INSTANTIATION_STATE:
            # done receiving node/link configuration, ready to instantiate
            self.session.emane.reset()
            for obj in self.session.objs():
                if isinstance(obj, pycore.nodes.EmaneNode):
                    self.session.emane.addobj(obj)
            self.session.emane.startup()
        elif eventtype == coreapi.CORE_EVENT_DATACOLLECT_STATE:
            self.session.emane.shutdown()
            # TODO: launch any data collection scripts here


    def handlesessionmsg(self, msg):
        ''' Session Message handler
        '''
        sid_str = msg.gettlv(coreapi.CORE_TLV_SESS_NUMBER)
        name_str = msg.gettlv(coreapi.CORE_TLV_SESS_NAME)
        file_str = msg.gettlv(coreapi.CORE_TLV_SESS_FILE)
        nc_str = msg.gettlv(coreapi.CORE_TLV_SESS_NODECOUNT)
        thumb = msg.gettlv(coreapi.CORE_TLV_SESS_THUMB)
        sids = coreapi.str_to_list(sid_str)
        names = coreapi.str_to_list(name_str)
        files = coreapi.str_to_list(file_str)
        ncs = coreapi.str_to_list(nc_str)
        self.info("SESSION message sessions=%s" % sid_str)

        if msg.flags == 0:
            # modify a session
            i = 0
            for sid in sids:
                sid = int(sid)
                if sid == 0:
                    session = self.session
                else:
                    session = self.server.getsession(sessionid = sid, 
                                                     useexisting = True)
                if session is None:
                    self.info("session %s not found" % sid)
                    i += 1
                    continue
                self.info("request to modify to session %s" % session.sessionid)
                if names is not None:
                    session.name = names[i]
                if files is not None:
                    session.filename = files[i]
                if ncs is not None:
                    session.node_count = ncs[i]
                if thumb is not None:
                    session.setthumbnail(thumb)
                i += 1
        else:
            if msg.flags & coreapi.CORE_API_STR_FLAG:
                # status request flag: send list of sessions
                self.sendsessions()
                return
            # handle ADD or DEL flags
            for sid in sids:
                sid = int(sid)
                session = self.server.getsession(sessionid = sid, 
                                                 useexisting = True)
                if session is None:
                    self.info("session %s not found" % sid)
                    continue
                if msg.flags & coreapi.CORE_API_ADD_FLAG:
                    # connect to the first session that exists
                    self.info("request to connect to session %s" % sid)
                    self.session.disconnect(self)
                    self.session = session
                    self.session.connect(self)
                    self.sendobjs()
                elif msg.flags & coreapi.CORE_API_DEL_FLAG:
                    # shut down the specified session(s)
                    self.info("request to terminate session %s" % sid)
                    session.setstate(state=coreapi.CORE_EVENT_DATACOLLECT_STATE,
                                    info=True, sendevent=True)
                    session.shutdown()
                else:
                    self.warn("unhandled session flags for session %s" % sid)


class CoreServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer):
    ''' TCP server class, manages sessions and spawns request handlers for
        incoming connections.
    '''
    daemon_threads = True
    allow_reuse_address = True
    servers = set()

    def __init__(self, server_address, RequestHandlerClass, cfg = None):
        ''' Server class initialization takes configuration data and calls
            the SocketServer constructor
        '''
        self.cfg = cfg
        self._sessions = {}
        self._sessionslock = threading.Lock()
        self.newserver(self)
        SocketServer.TCPServer.__init__(self, server_address,
                                        RequestHandlerClass)

    @classmethod
    def newserver(cls, server):
        cls.servers.add(server)

    @classmethod
    def delserver(cls, server):
        try:
            cls.servers.remove(server)
        except KeyError:
            pass

    def shutdown(self):
        for session in self._sessions.values():
            session.shutdown()
        self.delserver(self)

    def addsession(self, session):
        ''' Add a session to our dictionary of sessions, ensuring a unique
            session number
        '''
        self._sessionslock.acquire()
        try:
            if session.sessionid in self._sessions:
                raise KeyError, "non-unique session id %s for %s" % \
                    (session.sessionid, session)
            self._sessions[session.sessionid] = session
        finally:
            self._sessionslock.release()
        return session

    def delsession(self, session):
        ''' Remove a session from our dictionary of sessions.
        '''
        self._sessionslock.acquire()
        try:
            if session.sessionid not in self._sessions:
                raise KeyError, "session id %s not found" % (session.sessionid)
            del(self._sessions[session.sessionid])
        finally:
            self._sessionslock.release()
        return session

    def getsession(self, sessionid = None, useexisting = True):
        ''' Create a new session or retrieve an existing one from our
            dictionary of sessions.
        '''
        if useexisting:
            self._sessionslock.acquire()
            try:
                # look for the specified session id
                if sessionid in self._sessions:
                    session = self._sessions[sessionid]
                else:
                    session = None
            finally:
                self._sessionslock.release()
        else:
            session = pycore.Session(sessionid, cfg = self.cfg, server = self)
            self.addsession(session)
        return session

    def tosessionmsg(self, flags = 0):
        ''' Build CORE API Sessions message based on current session info.
        '''
        idlist = []
        namelist = []
        filelist = []
        nclist = []
        datelist = []
        thumblist = []
        num_sessions = 0

        self._sessionslock.acquire()
        try:
            for sessionid in self._sessions:
                session = self._sessions[sessionid]
                # debug: session.dumpsession()
                num_sessions += 1
                idlist.append(str(sessionid))
                name = session.name
                if name is None:
                    name = ""
                namelist.append(name)
                file = session.filename
                if file is None:
                    file = ""
                filelist.append(file)
                nc = session.node_count
                if nc is None:
                    nc = ""
                nclist.append(nc)
                datelist.append(time.ctime(session._date))
                thumb = session.thumbnail
                if thumb is None:
                    thumb = ""
                thumblist.append(thumb)
        finally:
            self._sessionslock.release()

        sids = "|".join(idlist)
        names = "|".join(namelist)
        files = "|".join(filelist)
        ncs = "|".join(nclist)
        dates = "|".join(datelist)
        thumbs = "|".join(thumblist)

        if num_sessions > 0:
            tlvdata = ""
            if len(sids) > 0:
                tlvdata += coreapi.CoreSessionTlv.pack( \
                                        coreapi.CORE_TLV_SESS_NUMBER, sids)
            if len(names) > 0:
                tlvdata += coreapi.CoreSessionTlv.pack( \
                                        coreapi.CORE_TLV_SESS_NAME, names)
            if len(files) > 0:
                tlvdata += coreapi.CoreSessionTlv.pack( \
                                        coreapi.CORE_TLV_SESS_FILE, files)
            if len(ncs) > 0:
                tlvdata += coreapi.CoreSessionTlv.pack( \
                                        coreapi.CORE_TLV_SESS_NODECOUNT, ncs)
            if len(dates) > 0:
                tlvdata += coreapi.CoreSessionTlv.pack( \
                                        coreapi.CORE_TLV_SESS_DATE, dates)
            if len(thumbs) > 0:
                tlvdata += coreapi.CoreSessionTlv.pack( \
                                        coreapi.CORE_TLV_SESS_THUMB, thumbs)
            msg = coreapi.CoreSessionMessage.pack(flags, tlvdata)
        else:
            msg = None
        return(msg)

    def dumpsessions(self):
        ''' Debug print all session info.
        '''
        print "sessions:"
        self._sessionslock.acquire()
        try:
            for sessionid in self._sessions:
                print sessionid,
        finally:
            self._sessionslock.release()
        print ""
        sys.stdout.flush()

    def setsessionmaster(self, handler):
        ''' Call the setmaster() method for every session. Returns True when
            a session having the given handler was updated.
        '''
        found = False
        self._sessionslock.acquire()
        try:
            for sessionid in self._sessions:
                found = self._sessions[sessionid].setmaster(handler)
                if found is True:
                    break
        finally:
            self._sessionslock.release()
        return found


def banner():
    ''' Output the program banner printed to the terminal or log file.
    '''
    sys.stdout.write("CORE Python daemon v.%s started %s\n" % \
                     (COREDPY_VERSION, time.ctime()))
    sys.stdout.flush()


def cored(cfg = None):
    ''' Start the CoreServer object and enter the server loop.
    '''
    host = cfg['listenaddr']
    port = int(cfg['port'])
    if host == '' or host is None:
        host = "localhost"
    try:
        server = CoreServer((host, port), CoreRequestHandler, cfg)
    except Exception, e:
        sys.stderr.write("error starting server on:  %s:%s\n\t%s\n" % \
                         (host, port, e))
        sys.stderr.flush()
        sys.exit(1)
    closeonexec(server.fileno())
    sys.stdout.write("server started, listening on: %s:%s\n" % (host, port))
    sys.stdout.flush()
    server.serve_forever()

def cleanup():
    while CoreServer.servers:
        server = CoreServer.servers.pop()
        server.shutdown()

atexit.register(cleanup)

def sighandler(signum, stackframe):
    print >> sys.stderr, "terminated by signal:", signum
    sys.exit(signum)

signal.signal(signal.SIGTERM, sighandler)

def daemonize(rootdir = "/", umask = 0, close_fds = False, dontclose = (),
              stdin = os.devnull, stdout = os.devnull, stderr = os.devnull,
              stdoutmode = 0644, stderrmode = 0644, pidfilename = None):
    ''' Run the background process as a daemon.
    '''
    if not hasattr(dontclose, "__contains__"):
        if not isinstance(dontclose, int):
            raise TypeError, "dontclose must be an integer"
        dontclose = (int(dontclose),)
    else:
        for fd in dontclose:
            if not isinstance(fd, int):
                raise TypeError, "dontclose must contain only integers"
    # redirect stdin
    if stdin:
        fd = os.open(stdin, os.O_RDONLY)
        os.dup2(fd, 0)
        os.close(fd)
    # redirect stdout
    if stdout:
        fd = os.open(stdout, os.O_WRONLY | os.O_CREAT | os.O_APPEND,
                     stdoutmode)
        os.dup2(fd, 1)
        if (stdout == stderr):
            os.dup2(1, 2)
        os.close(fd)
    # redirect stderr
    if stderr and (stderr != stdout):
        fd = os.open(stderr, os.O_WRONLY | os.O_CREAT | os.O_APPEND,
                     stderrmode)
        os.dup2(fd, 2)
        os.close(fd)
    if os.fork():
        os._exit(0)                 # parent exits
    os.setsid()
    pid = os.fork()
    if pid:
        if pidfilename:
            try:
                f = open(pidfilename, "w")
                f.write("%s\n" % pid)
                f.close()
            except:
                pass
        os._exit(0)                 # parent exits
    if rootdir:
        os.chdir(rootdir)
    os.umask(umask)
    if close_fds:
        try:
            maxfd = resource.getrlimit(resource.RLIMIT_NOFILE)[1]
            if maxfd == resource.RLIM_INFINITY:
                raise ValueError
        except:
            maxfd = DEFAULT_MAXFD
        for fd in xrange(3, maxfd):
            if fd in dontclose:
                continue
            try:
                os.close(fd)
            except:
                pass


def getMergedConfig(filename):
    ''' Return a configuration after merging config file and command-line
        arguments.
    '''
    # these are the defaults used in the config file
    defaults = { 'port' : '%d' % coreapi.CORE_API_PORT,
                 'listenaddr' : 'localhost',
                 'pidfile' : '%s/run/coredpy.pid' % CORE_STATE_DIR,
                 'logfile' : '%s/log/coredpy.log' % CORE_STATE_DIR,
                 'numthreads' : '1',
                 'verbose' : 'False',
                 'daemonize' : 'False',
                 'debug' : 'False',
               }

    usagestr = "usage: %prog [-h] [options] [args]\n\n" + \
               "CORE Python daemon v.%s instantiates Linux network namespace " \
               "nodes." % COREDPY_VERSION
    parser = optparse.OptionParser(usage = usagestr)
    parser.add_option("-f", "--configfile", dest = "configfile",
                      type = "string",
                      help = "read config from specified file; default = %s" %
                      filename)
    parser.add_option("-d", "--daemonize", dest = "daemonize",
                      action="store_true",
                      help = "run in background as daemon; default=%s" % \
                      defaults["daemonize"])
    parser.add_option("-l", "--logfile", dest = "logfile", type = "string",
                      help = "log output to specified file; default = %s" %
                      defaults["logfile"])
    parser.add_option("-p", "--port", dest = "port", type = int,
                      help = "port number to listen on; default = %s" % \
                      defaults["port"])
    parser.add_option("-i", "--pidfile", dest = "pidfile",
                      help = "filename to write pid to; default = %s" % \
                      defaults["pidfile"])
    parser.add_option("-t", "--numthreads", dest = "numthreads", type = int,
                      help = "number of server threads; default = %s" % \
                      defaults["numthreads"])
    parser.add_option("-v", "--verbose", dest = "verbose", action="store_true",
                      help = "enable verbose logging; default = %s" % \
                      defaults["verbose"])
    parser.add_option("-g", "--debug", dest = "debug", action="store_true",
                      help = "enable debug logging; default = %s" % \
                      defaults["debug"])

    # parse command line options
    (options, args) = parser.parse_args()

    # read the config file
    if options.configfile is not None:
        filename = options.configfile
    del options.configfile
    cfg = ConfigParser.SafeConfigParser(defaults)
    cfg.read(filename)

    # merge command line with config file
    section = "cored.py"
    if not cfg.has_section(section):
        cfg.add_section(section)

    for opt in options.__dict__:
        val = options.__dict__[opt]
        if val is not None:
            cfg.set(section, opt, val.__str__())

    return dict(cfg.items(section)), args


def main():
    ''' Main program startup.
    '''
    # get a configuration merged from config file and command-line arguments
    cfg, args = getMergedConfig("%s/core.conf" % CORE_CONF_DIR)
    for a in args:
        sys.stderr.write("ignoring command line argument: '%s'\n" % a)

    if cfg['daemonize'] == 'True':
        daemonize(rootdir = None, umask = 0, close_fds = False,
                  stdin = os.devnull,
                  stdout = cfg['logfile'], stderr = cfg['logfile'],
                  pidfilename = cfg['pidfile'])

    banner()
    try:
        cored(cfg)
    except KeyboardInterrupt:
        pass

    sys.exit(0)


if __name__ == "__main__":
    main()
