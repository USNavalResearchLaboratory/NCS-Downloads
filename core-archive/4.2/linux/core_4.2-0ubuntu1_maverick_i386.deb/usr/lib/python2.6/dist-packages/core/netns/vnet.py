#
# CORE
# Copyright (c)2010-2011 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# author: Tom Goff <thomas.goff@boeing.com>
#
'''
vnet.py: PyCoreNet and LxBrNet classes that implement virtual networks using
Linux Ethernet bridging and ebtables rules.
'''

import sys, threading

from core.misc.utils import *
from core.constants import *
from core.coreobj import PyCoreNet, PyCoreObj
from core.netns.vif import VEth, GreTap

checkexec([BRCTL_BIN, IP_BIN, EBTABLES_BIN, TC_BIN])

ebtables_lock = threading.Lock()

def ebtablescmds(call, cmds):
    ebtables_lock.acquire()
    try:
        for cmd in cmds:
            call(cmd)
    finally:
        ebtables_lock.release()

class LxBrNet(PyCoreNet):

    policy = "DROP"

    def __init__(self, session, objid = None, name = None, verbose = False,
                        start = True, policy = None):
        PyCoreNet.__init__(self, session, objid, name)
        if name is None:
            name = str(self.objid)
        if policy is not None:
            self.policy = policy
        self.name = name
        self.brname = "b.%s.%s" % (str(self.objid), self.session.sessionid)
        self.up = False
        if start:
            self.startup()

    def info(self, msg):
        if self.verbose:
            print "%s: %s" % (self.name, msg)
            sys.stdout.flush()

    def warn(self, msg):
        print >> sys.stderr, "%s: %s" % (self.name, msg)
        sys.stderr.flush()

    def startup(self):
        check_call([BRCTL_BIN, "addbr", self.brname])
        # turn off spanning tree protocol and forwarding delay
        check_call([BRCTL_BIN, "stp", self.brname, "off"])
        check_call([BRCTL_BIN, "setfd", self.brname, "0"])
        # the following line causes a huge performance hit for bridges having
        # many joined interfaces, but may be required for some multicast scen.
        #check_call([BRCTL_BIN, "setageing", self.brname, "0"])
        check_call([IP_BIN, "link", "set", self.brname, "up"])
        # create a new ebtables chain for this bridge
        ebtablescmds(check_call, [
            [EBTABLES_BIN, "-N", self.brname, "-P", self.policy],
            [EBTABLES_BIN, "-A", "FORWARD",
             "--logical-in", self.brname, "-j", self.brname]])
        # turn off multicast snooping so mcast forwarding occurs w/o IGMP joins
        snoop = "/sys/devices/virtual/net/%s/bridge/multicast_snooping" % \
                self.brname
        if os.path.exists(snoop):
            open(snoop, "w").write('0')
        self.up = True

    def shutdown(self):
        if not self.up:
            return
        mutecall([IP_BIN, "link", "set", self.brname, "down"])
        mutecall([BRCTL_BIN, "delbr", self.brname])
        ebtablescmds(mutecall, [
            [EBTABLES_BIN, "-D", "FORWARD",
             "--logical-in", self.brname, "-j", self.brname],
            [EBTABLES_BIN, "-X", self.brname]])
        for netif in self.netifs():
            # removes veth pairs used for bridge-to-bridge connections
            netif.shutdown()
        self._netif.clear()
        self._linked.clear()
        del self.session
        self.up = False

    def attach(self, netif):
        if self.up:
            check_call([BRCTL_BIN, "addif", self.brname, netif.localname])
            check_call([IP_BIN, "link", "set", netif.localname, "up"])
        self._netif[netif] = netif
        self._linked[netif] = {}

    def detach(self, netif):
        if self.up:
            check_call([BRCTL_BIN, "delif", self.brname, netif.localname])
        del self._netif[netif]
        del self._linked[netif]

    def linked(self, netif1, netif2):
        # check if the network interfaces are attached to this network
        if self._netif[netif1] != netif1:
            raise ValueError, "inconsistency for netif %s" % netif1.name
        if self._netif[netif2] != netif2:
            raise ValueError, "inconsistency for netif %s" % netif2.name
        try:
            linked = self._linked[netif1][netif2]
        except KeyError:
            if self.policy == "ACCEPT":
                linked = True
            elif self.policy == "DROP":
                linked = False
            else:
                raise Exception, "unknown policy: %s" % self.policy
            self._linked[netif1][netif2] = linked
        return linked

    def unlink(self, netif1, netif2):
        if not self.linked(netif1, netif2):
            return
        if self.policy == "DROP":
            ebtablescmds(check_call, [
                [EBTABLES_BIN, "-D", self.brname, "-i", netif1.localname,
                 "-o", netif2.localname, "-j", "ACCEPT"],
                [EBTABLES_BIN, "-D", self.brname, "-o", netif1.localname,
                 "-i", netif2.localname, "-j", "ACCEPT"]])
        elif self.policy == "ACCEPT":
            ebtablescmds(check_call, [
                [EBTABLES_BIN, "-A", self.brname, "-i", netif1.localname,
                 "-o", netif2.localname, "-j", "DROP"],
                [EBTABLES_BIN, "-A", self.brname, "-o", netif1.localname,
                 "-i", netif2.localname, "-j", "DROP"]])
        else:
            raise Exception, "unknown policy: %s" % self.policy
        self._linked[netif1][netif2] = False

    def link(self, netif1, netif2):
        if self.linked(netif1, netif2):
            return
        if self.policy == "DROP":
            ebtablescmds(check_call, [
                [EBTABLES_BIN, "-A", self.brname, "-i", netif1.localname,
                 "-o", netif2.localname, "-j", "ACCEPT"],
                [EBTABLES_BIN, "-A", self.brname, "-o", netif1.localname,
                 "-i", netif2.localname, "-j", "ACCEPT"]])
        elif self.policy == "ACCEPT":
            ebtablescmds(check_call, [
                [EBTABLES_BIN, "-D", self.brname, "-i", netif1.localname,
                 "-o", netif2.localname, "-j", "DROP"],
                [EBTABLES_BIN, "-D", self.brname, "-o", netif1.localname,
                 "-i", netif2.localname, "-j", "DROP"]])
        else:
            raise Exception, "unknown policy: %s" % self.policy
        self._linked[netif1][netif2] = True

    def linkconfig(self, netif, bw = None, delay = None,
                   loss = None, duplicate = None, jitter = None):
        ''' Configure link parameters by applying tc queuing disciplines on the
            interface.
        '''
        if not self.up:
            return
        tc = [TC_BIN, "qdisc", "replace", "dev", netif.localname]
        parent = ["root"]
        changed = False
        if netif.setparam('bw', bw):
            # TODO: make this configurable instead of hard-coded
            mtu = 1500
            # from tc-tbf(8): minimum value for burst is rate / kernel_hz
            if bw is not None:
                burst = max(2 * mtu, bw / 1000)
            limit = 0xffff # max IP payload
            tbf = ["tbf", "rate", str(bw),
                   "burst", str(burst), "limit", str(limit)]
            if bw > 0:
                check_call(tc + parent + ["handle", "1:"] + tbf)
                netif.setparam('has_tbf', True)
                changed = True
            elif netif.getparam('has_tbf') and bw <= 0:
                tcd = [] + tc
                tcd[2] = "delete"
                check_call(tcd + parent)
                netif.setparam('has_tbf', False)
                # removing the parent removes the child
                netif.setparam('has_netem', False)
                changed = True
        if jitter:
            netif.setparam('jitter', jitter)
            self.warn("jitter parameter ignored for link %s" % self.name)
        if netif.getparam('has_tbf'):
            parent = ["parent", "1:1"]
        netem = ["netem"]
        changed = max(changed, netif.setparam('delay', delay))
        changed = max(changed, netif.setparam('loss', loss))
        changed = max(changed, netif.setparam('duplicate', duplicate))
        if not changed:
            return
        if delay is not None:
            netem += ["delay", "%sus" % delay]
        if loss is not None:
            netem += ["loss", "%s%%" % min(loss, 100)]
        if duplicate is not None:
            netem += ["duplicate", "%s%%" % min(duplicate, 100)]
        if delay <= 0 and loss <= 0 and duplicate <= 0:
            # possibly remove netem if it exists and parent queue wasn't removed
            if not netif.getparam('has_netem'):
                return
            tc[2] = "delete"
            check_call(tc + parent + ["handle", "10:"])
            netif.setparam('has_netem', False)
        elif len(netem) > 1:
            check_call(tc + parent + ["handle", "10:"] + netem)
            netif.setparam('has_netem', True)

    def linknet(self, net):
        ''' Link this bridge with another by creating a veth pair and installing
            each device into each bridge.
        '''
        sessionid = self.session.sessionid
        localname = "n%s.%s.%s" % (self.objid, net.objid, sessionid)
        name = "n%s.%s.%s" % (net.objid, self.objid, sessionid)
        netif = VEth(None, name, localname, self, self.up)        
        self.attach(netif)
        if net.up:
            # this is similar to net.attach() but uses netif.name instead 
            # of localname
            check_call([BRCTL_BIN, "addif", net.brname, netif.name])
            check_call([IP_BIN, "link", "set", netif.name, "up"])
            net._netif[netif] = netif
            net._linked[netif] = {}
            netif.net = self

    def addrconfig(self, addrlist):
        ''' Set addresses on the bridge.
        '''
        if not self.up:
            return
        for addr in addrlist:
            check_call([IP_BIN, "addr", "add", str(addr), "dev", self.brname])

class GreTapBridge(LxBrNet):
    ''' A network consisting of a bridge with a gretap device for tunneling to 
        another system.
    '''
    def __init__(self, session, remoteip = None, objid = None, name = None,
                 policy = "ACCEPT", localip = None, ttl = 255, key = None,
                 verbose = False, start = True):
        LxBrNet.__init__(self, session = session, objid = objid,
                      name = name, verbose = verbose, policy = policy,
                      start = False)
        self.grekey = key
        if self.grekey is None:
            self.grekey = self.session.sessionid ^ self.objid
        self.localnum = None
        self.remotenum = None
        self.remoteip = remoteip
        self.localip = localip
        self.ttl = ttl
        if remoteip is None:
            self.gretap = None
        else:
            self.gretap = GreTap(node = self, name = None, session = session,
                                    remoteip = remoteip, objid = None, localip = localip, ttl = ttl,
                                    key = self.grekey)
        if start:
            self.startup()

    def startup(self):
        ''' Creates a bridge and adds the gretap device to it.
        '''
        LxBrNet.startup(self)
        if self.gretap:
            self.attach(self.gretap)

    def shutdown(self):
        ''' Detach the gretap device and remove the bridge.
        '''
        if self.gretap:
            self.detach(self.gretap)
            self.gretap.shutdown()
            self.gretap = None
        LxBrNet.shutdown(self)
    
    def addrconfig(self, addrlist):
        ''' Set the remote tunnel endpoint. This is a one-time method for 
            creating the GreTap device, which requires the remoteip at startup.
            The 1st address in the provided list is remoteip, 2nd optionally
            specifies localip.
        '''
        if self.gretap:
            raise ValueError, "gretap already exists for %s" % self.name
        remoteip = addrlist[0].split('/')[0]
        localip = None
        if len(addrlist) > 1:
            localip = addrlist[1].split('/')[0]
        self.gretap = GreTap(session = self.session, remoteip = remoteip,
                             objid = None, name = None,
                             localip = localip, ttl = self.ttl, key = self.grekey)
        self.attach(self.gretap)

    def setkey(self, key):
        ''' Set the GRE key used for the GreTap device. This needs to be set
            prior to instantiating the GreTap device (before addrconfig).
        '''
        self.grekey = key
