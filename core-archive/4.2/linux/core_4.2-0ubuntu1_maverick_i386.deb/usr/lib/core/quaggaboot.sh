#!/bin/sh
#
# Copyright 2005-2011 the Boeing Company.
# See the LICENSE file included in this distribution.
#


zebra -d

vtysh -b

for f in rip ripng ospf6 ospf bgp; do
    grep -q "router \<${f}\>" $1 && ${f}d -d
done

return 0;
