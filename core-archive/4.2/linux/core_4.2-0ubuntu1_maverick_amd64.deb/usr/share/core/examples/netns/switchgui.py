#!/usr/bin/python -i

# Copyright (c)2010-2011 the Boeing Company.
# See the LICENSE file included in this distribution.

# connect n nodes to a virtual switch/hub
# launch CORE services (cored.py) so that GUI may be connected 

### begin from cored.py
import SocketServer, fcntl, struct, sys, threading, time, traceback
import os, sys, optparse, ConfigParser, gc, shlex
import atexit
import signal
### end from cored.py
import datetime

from core import pycore
from core.misc import ipaddr
### begin from cored.py
from core.constants import *
from core.api import coreapi
from core.coreobj import PyCoreNet
from core.misc.utils import hexdump
### end from cored.py

import cored


# node list (count from 1)
n = [None]

def main():
    usagestr = "usage: %prog [-h] [options] [args]"
    parser = optparse.OptionParser(usage = usagestr)
    parser.set_defaults(numnodes = 5)

    parser.add_option("-n", "--numnodes", dest = "numnodes", type = int,
                      help = "number of nodes")

    def usage(msg = None, err = 0):
        sys.stdout.write("\n")
        if msg:
            sys.stdout.write(msg + "\n\n")
        parser.print_help()
        sys.exit(err)

    # parse command line options
    (options, args) = parser.parse_args()

    if options.numnodes < 1:
        usage("invalid number of nodes: %s" % options.numnodes)

    for a in args:
        sys.stderr.write("ignoring command line argument: '%s'\n" % a)

    start = datetime.datetime.now()

    # IP subnet
    prefix = ipaddr.IPv4Prefix("10.83.0.0/16")
    session = pycore.Session(persistent=True)
    # emulated Ethernet switch
    switch = session.addobj(cls = pycore.nodes.SwitchNode, name = "switch")
    switch.setposition(x=80,y=50)
    print "creating %d nodes with addresses from %s" % \
          (options.numnodes, prefix)
    for i in xrange(1, options.numnodes + 1):
        tmp = session.addobj(cls = pycore.nodes.PcNode, name = "n%d" % i)
        tmp.newnetif(switch, ["%s/%s" % (prefix.addr(i), prefix.prefixlen)])
        tmp.cmd(["sysctl", "net.ipv4.icmp_echo_ignore_broadcasts=0"])
        tmp.setposition(x=150*i,y=150)
        n.append(tmp)

    # start a shell on node 1
    n[1].term("bash")

    print "elapsed time: %s" % (datetime.datetime.now() - start)

    # now we launch cored.py services so GUI can connect to this script
    print "launching cored services"
    # the following lines are from cored.py cored()
    cfg, args = cored.getMergedConfig("%s/core.conf" % CORE_CONF_DIR)
    cored.banner()
    server = cored.CoreServer(("localhost", coreapi.CORE_API_PORT),
                              cored.CoreRequestHandler, cfg)
    print "adding session %s to cored.server" % session.sessionid
    server.addsession(session)
    print "running cored server - you may now connect the GUI"
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    main()
