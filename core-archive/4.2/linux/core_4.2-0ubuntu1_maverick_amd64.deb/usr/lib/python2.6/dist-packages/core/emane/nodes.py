#
# CORE
# Copyright (c)2010-2011 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# author: Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
'''
nodes.py: definition of an EmaneNode class for implementing configuration 
control of an EMANE emulation. An EmaneNode has several attached NEMs that
share the same MAC+PHY model.
'''

import sys

from core.api import coreapi
from core.coreobj import PyCoreNet
try:
    import emaneeventservice
    import emaneeventlocation
except Exception, e:
    ''' Don't require all CORE users to have EMANE libeventservice and its
        Python bindings installed.
    ''' 
    pass


class EmaneNet(PyCoreNet):
    ''' EMANE network base class.
    '''
    apitype = coreapi.CORE_NODE_EMANE
    linktype = coreapi.CORE_LINK_WIRELESS


class EmaneNode(EmaneNet):
    ''' EMANE node contains NEM configuration and causes connected nodes
        to have TAP interfaces (instead of VEth). These are managed by the
        Emane controller object that exists in a session.
    '''
    def __init__(self, session, objid = None, name = None, verbose = False,
                start = True):
        PyCoreNet.__init__(self, session, objid, name)
        self.verbose = verbose
        self._netif = {}
        self.conf = ""
        self.up = False
        self.nemidmap = {}
        self.model = None

    def attach(self, netif):
        ''' record the new netif without doing anything else
        '''
        self._netif[netif] = netif

    def detach(self, netif):
        ''' remove a netif
        '''
        del self._netif[netif]

    def linkconfig(self, netif, bw = None, delay = None,
                loss = None, duplicate = None, jitter = None):
        #print "emane", self.name, "ignoring link config"
        pass

    def config(self, conf):
        print "emane", self.name, "got config:", conf
        self.conf = conf

    def shutdown(self):
        pass

    def setmodel(self, model):
        ''' set the EmaneModel associated with this node
        '''
        self.model = model(session=self.session, objid=self.objid,
                           verbose=self.verbose)

    def info(self, msg):
        print msg
        sys.stdout.flush()

    def numnems(self):
        ''' Return the number of NEMs (interfaces) attached to this network.
        '''
        return len(self._netif)

    def setnemid(self, name, nemid):
        ''' Record a name to numerical ID mapping. The Emane controller object
            manages and assigns these IDs for all NEMs.
        '''
        self.nemidmap[name] = nemid

    def getnemid(self, name):
        ''' Given a NEM name, return its numerical ID.
        '''
        if name not in self.nemidmap:
            return None
        else:
            return self.nemidmap[name]

    def getnemname(self, nemid):
        ''' Given a numerical NEM ID, return its name. This returns the first
            name that matches the given NEM ID.
        '''
        for name in self.nemidmap:
            if self.nemidmap[name] == nemid:
                return name
        return None

    def buildplatformxmlentry(self, doc):
        ''' Return a dictionary of XML elements describing the NEMs
            connected to this EmaneNode for inclusion in the platform.xml file.
        '''
        ret = {}
        if self.model is None:
            self.info("warning: EmaneNode %s has no associated model" % \
                      self.name)
            return ret
        for netif in self._netif:
            # <nem name="NODE-001" definition="rfpipenem.xml">
            nementry = doc.createElement("nem")
            nementry.setAttribute("name", netif.localname)
            # if this netif contains a non-standard (per-interface) config,
            #  then we need to use a more specific xml file here
            nementry.setAttribute("definition", \
                                  self.model.nemxmlname(netif.localname))
            # <transport definition="transvirtual.xml" group="1">
            #    <param name="device" value="n1.eth0.158" />
            # </transport>
            trans = doc.createElement("transport")
            trans.setAttribute("definition", self.model.transportxmlname())
            trans.setAttribute("group", "1")
            param = doc.createElement("param")
            param.setAttribute("name", "device")
            param.setAttribute("value", netif.localname)

            trans.appendChild(param)
            nementry.appendChild(trans)

            ret[netif.localname] = nementry

        return ret

    def buildnemxmlfiles(self, emane):
        ''' Let the configured model build the necessary nem, mac, and phy
            XMLs.
        '''
        if self.model is None:
            return
        # build XML for overall network (EmaneNode) configs
        self.model.buildnemxmlfiles(emane, ifc=None)
        # build XML for specific interface (NEM) configs
        for netif in self._netif:
            self.model.buildnemxmlfiles(emane, ifc=netif.localname)

    def installnetifs(self):
        ''' Install TAP devices into their namespaces. This is done after
            EMANE daemons have been started, because that is their only chance
            to bind to the TAPs.
        '''
        for netif in self._netif:
            netif.install()
            # at this point we register location handlers for generating
            # EMANE location events
            netif.poshook = self.setnemposition
            (x,y,z) = netif.node.position.get()
            self.setnemposition(netif.localname, x, y, z)
    
    def deinstallnetifs(self):
        ''' Uninstall TAP devices. This invokes their shutdown method for 
            any required cleanup; the device may be actually removed when
            emanetransportd terminates.
        '''
        for netif in self._netif:
            netif.shutdown()
            netif.poshook = None

    def setnemposition(self, ifname, x, y, z):
        ''' Publish a NEM location change event using the EMANE event service.
        '''
        if self.session.emane.service is None:
            if self.verbose:
                self.info("position service not available")
            return
        nemid =  self.getnemid(ifname)
        if nemid is None:
            self.info("nemid for %s is unknown" % ifname)
            return
        (lat, long, alt) = self.session.location.getgeo(x, y, z)
        if self.verbose:
            self.info("setnemposition %s (%s) x,y,z=(%d,%d,%s)"
                      "(%.6f,%.6f,%.6f)" % \
                      (ifname, nemid, x, y, z, lat, long, alt))
        event = emaneeventlocation.EventLocation(1)
        # altitude must be an integer or warning is printed
        alt = int(round(alt))
        event.set(0, nemid, lat, long, alt)
        self.session.emane.service.publish(emaneeventlocation.EVENT_ID,
                                           emaneeventservice.PLATFORMID_ANY,
                                           emaneeventservice.NEMID_ANY,
                                           emaneeventservice.COMPONENTID_ANY,
                                           event.export())

