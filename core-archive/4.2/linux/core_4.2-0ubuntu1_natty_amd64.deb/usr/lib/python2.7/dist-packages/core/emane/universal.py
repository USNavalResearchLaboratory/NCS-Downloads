#
# CORE
# Copyright (c)2010-2011 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# author: Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
'''
universal.py: EMANE Universal PHY model for CORE. Enumerates configuration items
used for the Universal PHY.
'''

import sys
import string
from core.api import coreapi

from core.constants import *
from emane import EmaneModel

class EmaneUniversalModel(EmaneModel):
    ''' This Univeral PHY model is meant to be imported by other models,
        not instantiated.
    '''
    def __init__(self, session, objid = None, verbose = False):
        raise SyntaxError

    _name = "emane_universal"
    _xmlname = "universalphy"
    _xmllibrary = "universalphylayer"

    # universal PHY parameters
    _confmatrix = [
        ("bandwidth", coreapi.CONF_DATA_TYPE_UINT16, '1000',
         '', 'bandwidth (KHz)'),
        ("antennagain", coreapi.CONF_DATA_TYPE_FLOAT, '0.0',
         '','antenna gain (dBi)'),
        ("systemnoisefigure", coreapi.CONF_DATA_TYPE_FLOAT, '4.0',
         '','system noise figure (dB)'),
        ("frequency", coreapi.CONF_DATA_TYPE_UINT32, '2347000',
         '','frequency (KHz)'),
        ("frequencyofinterest", coreapi.CONF_DATA_TYPE_UINT32, '2347000',
         '','frequency of interest (KHz)'),
        ("pathlossmode", coreapi.CONF_DATA_TYPE_STRING, '2ray',
         'pathloss,2ray,freespace','pathloss mode'),
        ("noiseprocessingmode", coreapi.CONF_DATA_TYPE_BOOL, '0',
         'On,Off','noise processing'),
        ("defaultconnectivitymode", coreapi.CONF_DATA_TYPE_BOOL, '1',
         'On,Off','default connectivity'),
        ("txpower", coreapi.CONF_DATA_TYPE_FLOAT, '0.0',
         '','transmit power (dBm)'),
        ("antennaazimuthbeamwidth", coreapi.CONF_DATA_TYPE_FLOAT, '360.0',
         '','azimith beam width (deg)'),
        ("antennaelevationbeamwidth", coreapi.CONF_DATA_TYPE_FLOAT, '180.0',
         '','elevation beam width (deg)'),
        ("antennaazimuth", coreapi.CONF_DATA_TYPE_FLOAT, '0.0',
         '','antenna azimuth (deg)'),
        ("antennaelevation", coreapi.CONF_DATA_TYPE_FLOAT, '0.0',
         '','antenna elevation (deg)'),
        ("antennatype", coreapi.CONF_DATA_TYPE_STRING, 'omnidirectional',
         'omnidirectional,unidirectional','antenna type'),
        ("subid", coreapi.CONF_DATA_TYPE_UINT16, '1',
         '','subid'),
        ]

