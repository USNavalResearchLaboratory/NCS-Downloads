#
# CORE
# Copyright (c)2010-2011 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# authors: Tom Goff <thomas.goff@boeing.com>
#          Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
'''
coreobj.py: defines the basic objects for emulation: the PyCoreObj base class, 
along with PyCoreNode, PyCoreNet, and PyCoreNetIf
'''

from core.api import coreapi
from core.misc.ipaddr import *

class Position(object):
    ''' Helper class for Cartesian coordinate position
    '''
    def __init__(self, x = None, y = None, z = None):
        self.set(x, y, z)

    def set(self, x = None, y = None, z = None):
        self.x = x
        self.y = y
        self.z = z

    def get(self):
        return (self.x, self.y, self.z)

class PyCoreObj(object):
    ''' Base class for pycore objects (nodes and nets)
    '''
    apitype = None

    def __init__(self, session, objid = None, name = None, verbose = False, 
                start = True):
        self.session = session
        if objid is None:
            objid = (((id(self) >> 16) ^ (id(self) & 0xffff)) & 0xffff)
        self.objid = objid
        if name is None:
            name = "o%s" % self.objid
        self.name = name
        self.icon = None
        self.opaque = None
        self.verbose = verbose
        self.position = Position()

    def startup(self):
        ''' Each object implements its own startup method.
        '''
        raise NotImplementedError

    def shutdown(self):
        ''' Each object implements its own shutdown method.
        '''
        raise NotImplementedError

    def setposition(self, x = None, y = None, z = None):
        ''' Set the (x,y,z) position of the object.
        '''
        self.position.set(x = x, y = y, z = z)

    def getposition(self):
        ''' Return an (x,y,z) tuple representing this object's position.
        '''
        return self.position.get()

    def tonodemsg(self, flags):
        ''' Build a CORE API Node Message for this object. Both nodes and
            networks can be represented by a Node Message.
        '''
        if self.apitype is None:
            return None
        tlvdata = ""
        (x, y, z) = self.getposition()
        tlvdata += coreapi.CoreNodeTlv.pack(coreapi.CORE_TLV_NODE_NUMBER,
                                            self.objid)
        tlvdata += coreapi.CoreNodeTlv.pack(coreapi.CORE_TLV_NODE_TYPE,
                                            self.apitype)
        tlvdata += coreapi.CoreNodeTlv.pack(coreapi.CORE_TLV_NODE_NAME,
                                            self.name)
        if hasattr(self, "type") and self.type is not None:
            tlvdata += coreapi.CoreNodeTlv.pack(coreapi.CORE_TLV_NODE_MODEL,
                                                self.type)

        if x is not None:
            tlvdata += coreapi.CoreNodeTlv.pack(coreapi.CORE_TLV_NODE_XPOS, x)
        if y is not None:
            tlvdata += coreapi.CoreNodeTlv.pack(coreapi.CORE_TLV_NODE_YPOS, y)
        tlvdata += coreapi.CoreNodeTlv.pack(coreapi.CORE_TLV_NODE_EMUID,
                                            self.objid)
        if self.icon is not None:
            tlvdata += coreapi.CoreNodeTlv.pack(coreapi.CORE_TLV_NODE_ICON,
                                                self.icon)
        if self.opaque is not None:
            tlvdata += coreapi.CoreNodeTlv.pack(coreapi.CORE_TLV_NODE_OPAQUE,
                                                self.opaque)
        msg = coreapi.CoreNodeMessage.pack(flags, tlvdata)
        return msg

    def tolinkmsgs(self, flags):
        ''' Build CORE API Link Messages for this object. There is no default
            method for PyCoreObjs as PyCoreNodes do not implement this but
            PyCoreNets do.
        '''
        return []


class PyCoreNode(PyCoreObj):
    ''' Base class for nodes
    '''
    def __init__(self, session, objid = None, name = None, verbose = False,
                 start = True):
        ''' Initialization for node objects.
        '''
        PyCoreObj.__init__(self,  session,  objid,  name, verbose=verbose,
                           start=start)
        self._netif = {}
        self.services = []
        self.type = None

    def nodeid(self):
        return self.objid
        
    def addservice(self,  service):
        if service is not None:
            self.services.append(service)

    def netifs(self):
        return self._netif.itervalues()
        
    def commonnets(self, obj):
        ''' Given another node or net object, return common networks between
            this node and that object. A list of tuples is returned, with each tuple
            consisting of (network, interface1, interface2).
        '''
        r = []
        for netif1 in self.netifs():
            for netif2 in obj.netifs():
                if netif1.net == netif2.net:
                    r += (netif1.net, netif1, netif2),                    
        return r



class PyCoreNet(PyCoreObj):
    ''' Base class for networks
    '''
    linktype = coreapi.CORE_LINK_WIRED

    def __init__(self, session, objid, name, verbose = False, start = True):
        ''' Initialization for network objects.
        '''
        PyCoreObj.__init__(self, session, objid, name, verbose=verbose,
                           start=start)
        self._netif = {}
        self._linked = {}

    def netifs(self):
        ''' Iterate over attached network interfaces.
        '''
        return self._netif.itervalues()

    def numnetif(self):
        ''' Return the attached interface count.
        '''
        return len(self._netif)

    def tolinkmsgs(self, flags):
        ''' Build CORE API Link Messages for this network. Each link message
            describes a link between this network and a node.
        '''
        msgs = []
        # build a link message from this network node to each node having a
        # connected interface
        for netif in self.netifs():
            if not hasattr(netif, "node"):
                continue
            tlvdata = ""
            tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_N1NUMBER,
                                                self.objid)
            tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_N2NUMBER,
                                                netif.node.objid)
            delay = netif.getparam('delay')
            bw = netif.getparam('bw')
            loss = netif.getparam('loss')
            duplicate = netif.getparam('duplicate')
            jitter = netif.getparam('jitter')
            if delay is not None:
                tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_DELAY,
                                                    delay)
            if bw is not None:
                tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_BW,
                                                    bw)
            if loss is not None:
                tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_PER, 
                                                    loss)
            if duplicate is not None:
                tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_DUP,
                                                    duplicate)
            if jitter is not None:
                tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_JITTER,
                                                    jitter)
            tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_TYPE,
                                                self.linktype)
            tlvdata += coreapi.CoreLinkTlv.pack(coreapi.CORE_TLV_LINK_IF2NUM,
                                                netif.node.getifindex(netif))
            for addr in netif.addrlist:
                (ip, sep, mask)  = addr.partition('/')
                mask = int(mask)
                if isIPv4Address(ip):
                    family = AF_INET
                    tlvtypeip = coreapi.CORE_TLV_LINK_IF2IP4
                    tlvtypemask = coreapi.CORE_TLV_LINK_IF2IP4MASK
                else:
                    family = AF_INET6
                    tlvtypeip = coreapi.CORE_TLV_LINK_IF2IP6
                    tlvtypemask = coreapi.CORE_TLV_LINK_IF2IP6MASK
                ipl = socket.inet_pton(family, ip)
                tlvdata += coreapi.CoreLinkTlv.pack(tlvtypeip, \
                                                    IPAddr(af=family, addr=ipl))
                tlvdata += coreapi.CoreLinkTlv.pack(tlvtypemask, mask)

            msg = coreapi.CoreLinkMessage.pack(flags, tlvdata)
            msgs.append(msg)
        return msgs 

class PyCoreNetIf(object):
    ''' Base class for interfaces.
    '''
    def __init__(self, node, name):
        self.node = node
        self.name = name
        self.net = None
        self._params = {}
        self.addrlist = []
        self.hwaddr = None
        self.poshook = None

    def startup(self):
        pass

    def shutdown(self):
        pass
    
    def attachnet(self, net):
        if self.net:
            self.detachnet()
            self.net = None
        net.attach(self)
        self.net = net

    def detachnet(self):
        if self.net is not None:
            self.net.detach(self)

    def addaddr(self, addr):
        self.addrlist.append(addr)

    def deladdr(self, addr):
        self.addrlist.remove(addr)

    def sethwaddr(self, addr):
        self.hwaddr = addr

    def getparam(self, key):
        ''' Retrieve a parameter from the _params dict,
            or None if the parameter does not exist.
        '''
        if key not in self._params:
            return None
        return self._params[key]
    
    def setparam(self, key, value):
        ''' Set a parameter in the _params dict.
            Returns True if the parameter has changed.
        '''
        if key in self._params:
            if self._params[key] == value:
                return False
        self._params[key] = value
        return True

    def setposition(self, x, y, z):
        ''' Dispatch to any position hook (self.poshook) handler.
        '''
        if self.poshook is not None:
            self.poshook(self.localname, x, y, z)




