#
# CORE
# Copyright (c)2010-2012 the Boeing Company.
# See the LICENSE file included in this distribution.
#
# author: Jeff Ahrenholz <jeffrey.m.ahrenholz@boeing.com>
#
'''
nodes.py: definition of an EmaneNode class for implementing configuration 
control of an EMANE emulation. An EmaneNode has several attached NEMs that
share the same MAC+PHY model.
'''

import sys

from core.api import coreapi
from core.coreobj import PyCoreNet
try:
    import emaneeventservice
    import emaneeventlocation
except Exception, e:
    ''' Don't require all CORE users to have EMANE libeventservice and its
        Python bindings installed.
    ''' 
    pass


class EmaneNet(PyCoreNet):
    ''' EMANE network base class.
    '''
    apitype = coreapi.CORE_NODE_EMANE
    linktype = coreapi.CORE_LINK_WIRELESS


class EmaneNode(EmaneNet):
    ''' EMANE node contains NEM configuration and causes connected nodes
        to have TAP interfaces (instead of VEth). These are managed by the
        Emane controller object that exists in a session.
    '''
    def __init__(self, session, objid = None, name = None, verbose = False,
                start = True):
        PyCoreNet.__init__(self, session, objid, name, verbose, start)
        self.verbose = verbose
        self._netif = {}
        self.conf = ""
        self.up = False
        self.nemidmap = {}
        self.model = None
        self.mobility = None

    def attach(self, netif):
        ''' record the new netif without doing anything else
        '''
        self._netif[netif] = netif

    def detach(self, netif):
        ''' remove a netif
        '''
        del self._netif[netif]

    def linkconfig(self, netif, bw = None, delay = None,
                loss = None, duplicate = None, jitter = None):
        #print "emane", self.name, "ignoring link config"
        pass

    def config(self, conf):
        print "emane", self.name, "got config:", conf
        self.conf = conf

    def shutdown(self):
        pass

    def setmodel(self, model):
        ''' set the EmaneModel associated with this node
        '''
        if (self.verbose):
            self.info("adding model %s" % model._name)
        # EmaneModel does not currently use 'values=' argument of WirelessModel
        self.model = model(session=self.session, objid=self.objid,
                           verbose=self.verbose)

    def numnems(self):
        ''' Return the number of NEMs (interfaces) attached to this network.
        '''
        return len(self._netif)

    def setnemid(self, netif, nemid):
        ''' Record an interface to numerical ID mapping. The Emane controller 
            object manages and assigns these IDs for all NEMs.
        '''
        self.nemidmap[netif] = nemid

    def getnemid(self, netif):
        ''' Given an interface, return its numerical ID.
        '''
        if netif not in self.nemidmap:
            return None
        else:
            return self.nemidmap[netif]

    def getnemnetif(self, nemid):
        ''' Given a numerical NEM ID, return its interface. This returns the
            first interface that matches the given NEM ID.
        '''
        for netif in self.nemidmap:
            if self.nemidmap[netif] == nemid:
                return netif
        return None
        
    def netifs(self):
        ''' Retrieve list of linked interfaces sorted by node number.
        '''
        return sorted(self._netif.keys(), key=lambda n: n.node.objid)

    def buildplatformxmlentry(self, doc):
        ''' Return a dictionary of XML elements describing the NEMs
            connected to this EmaneNode for inclusion in the platform.xml file.
        '''
        ret = {}
        if self.model is None:
            self.info("warning: EmaneNode %s has no associated model" % \
                      self.name)
            return ret
        for netif in self.netifs():
            # <nem name="NODE-001" definition="rfpipenem.xml">
            nementry = doc.createElement("nem")
            nementry.setAttribute("name", netif.localname)
            # if this netif contains a non-standard (per-interface) config,
            #  then we need to use a more specific xml file here
            nementry.setAttribute("definition", \
                                  self.model.nemxmlname(netif))
            # <transport definition="transvirtual.xml" group="1">
            #    <param name="device" value="n1.0.158" />
            # </transport>
            type = netif.transport_type
            if not type:
                self.info("warning: %s interface type unsupported!" % 
                          netif.name)
                type = "raw"
            trans = doc.createElement("transport")
            trans.setAttribute("definition", self.transportxmlname(type))
            trans.setAttribute("group", "1")
            param = doc.createElement("param")
            param.setAttribute("name", "device")
            if type == "raw":
                # raw RJ45 name e.g. 'eth0'
                param.setAttribute("value", netif.name)
            else:
                # virtual TAP name e.g. 'n3.0.17'
                param.setAttribute("value", netif.localname)

            trans.appendChild(param)
            nementry.appendChild(trans)

            ret[netif] = nementry

        return ret

    def buildnemxmlfiles(self, emane):
        ''' Let the configured model build the necessary nem, mac, and phy
            XMLs.
        '''
        if self.model is None:
            return
        # build XML for overall network (EmaneNode) configs
        self.model.buildnemxmlfiles(emane, ifc=None)
        # build XML for specific interface (NEM) configs
        need_virtual = False
        need_raw = False
        for netif in self.netifs():
            self.model.buildnemxmlfiles(emane, netif)
            if netif.transport_type == "virtual":
                need_virtual = True
            else:
                need_raw = True
        # build transport XML files depending on type of interfaces involved
        if need_virtual:
            self.buildtransportxml(emane, "Virtual")
        if need_raw:
            self.buildtransportxml(emane, "Raw")
            
    def buildtransportxml(self, emane, type):
        ''' Write a transport XML file for the Virtual or Raw Transport.
        '''
        transdoc = emane.xmldoc("transport")
        trans = transdoc.getElementsByTagName("transport").pop()
        trans.setAttribute("name", "%s Transport" % type)
        trans.setAttribute("library", "trans%s" % type.lower())
        trans.appendChild(emane.xmlparam(transdoc, "bitrate", "0"))
        if type == "Virtual":
            trans.appendChild(emane.xmlparam(transdoc, "devicepath",
                              "/dev/net/tun"))
        emane.xmlwrite(transdoc, self.transportxmlname(type.lower()))
        
    def transportxmlname(self, type):
        ''' Return the string name for the Transport XML file, 
            e.g. 'n3transvirtual.xml'
        '''
        return "n%strans%s.xml" % (self.objid, type)


    def installnetifs(self):
        ''' Install TAP devices into their namespaces. This is done after
            EMANE daemons have been started, because that is their only chance
            to bind to the TAPs.
        '''
        if not self.session.emane.doeventmonitor() and \
            self.session.emane.service is None:
            warntxt = "unable to publish EMANE events because the eventservice "
            warntxt += "Python bindings failed to load"
            self.session.exception(coreapi.CORE_EXCP_LEVEL_ERROR, self.name,
                                    self.objid, warntxt)

        for netif in self.netifs():
            if netif.transport_type == "virtual":
                netif.install()
            # if we are listening for EMANE events, don't generate them
            if self.session.emane.doeventmonitor():
                netif.poshook = None
                continue
            # at this point we register location handlers for generating
            # EMANE location events
            netif.poshook = self.setnemposition
            (x,y,z) = netif.node.position.get()
            self.setnemposition(netif, x, y, z)
    
    def deinstallnetifs(self):
        ''' Uninstall TAP devices. This invokes their shutdown method for 
            any required cleanup; the device may be actually removed when
            emanetransportd terminates.
        '''
        for netif in self.netifs():
            if netif.transport_type == "virtual":
                netif.shutdown()
            netif.poshook = None

    def setnemposition(self, netif, x, y, z):
        ''' Publish a NEM location change event using the EMANE event service.
        '''
        if self.session.emane.service is None:
            if self.verbose:
                self.info("position service not available")
            return
        nemid =  self.getnemid(netif)
        ifname = netif.localname
        if nemid is None:
            self.info("nemid for %s is unknown" % ifname)
            return
        (lat, long, alt) = self.session.location.getgeo(x, y, z)
        if self.verbose:
            self.info("setnemposition %s (%s) x,y,z=(%d,%d,%s)"
                      "(%.6f,%.6f,%.6f)" % \
                      (ifname, nemid, x, y, z, lat, long, alt))
        event = emaneeventlocation.EventLocation(1)
        # altitude must be an integer or warning is printed
        alt = int(round(alt))
        event.set(0, nemid, lat, long, alt)
        self.session.emane.service.publish(emaneeventlocation.EVENT_ID,
                                           emaneeventservice.PLATFORMID_ANY,
                                           emaneeventservice.NEMID_ANY,
                                           emaneeventservice.COMPONENTID_ANY,
                                           event.export())

