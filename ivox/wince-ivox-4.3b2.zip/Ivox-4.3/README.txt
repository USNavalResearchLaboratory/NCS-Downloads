		IVOX - The Interactive VOice eXchange

This directory contains an experimental release of
IVOX 4.0.  Most of the notes below (and the User's
Guide) apply to versions 4.1 and older.  There is a
special section  of notes for Ivox 4.2 and WinCE, in
particular provided while the 4.2 version is in its
inital release stages.  

IVOX is an "Internet phone" (VoIP) and voice conferencing 
application.  IVOX uses voice compression algorithms with
peak data rates ranging from as low as 600 bits/second up to
32 kbps.  IVOX provides for point-to-point (unicast) calls
and provides IP multicast conferencing.  IVOX is compatible
with University College of London's (UCL) Session Directory
(sdr) conference management tool.  IVOX is also capable of
Reservation Protocol (RSVP) operation  _and_ IP
type-of-service (TOS) control to attain a better
quality-of-service (QoS) for IVOX voice packets over
supporting networks.

Version 4.x of Ivox represents a major enhancement to Ivox
with support for dial-up users via "WebDirectory" directory
services.   Compatibility and interoperability with H.323 and
Session Initiation Protocol (SIP) are also planned.

IVOX has been successfully utilized on low data rate wireless
IP networks and on the Internet.  IVOX is currently available
for Sun Solaris/SunOS,  Linux, NetBSD, and
MacOS X, Windows 95/98/NT/XP, and WinCE operating systems. 

FILE DESCRIPTIONS:

README.txt			- this file

VERSION.TXT         - Version update change/ bug fix log.

Ivox4UsersGuide.doc - User's guide in Microsoft Word format. 
			      

ivox[.exe]          - Binary executable ivox application.

ReliableSettings.ivx - example Ivox settings file for 
                       reliable modes.  Load via "File" menu.



The executable binary file ("ivox") is large in size because
it has been compiled with a number of debugging features.  A
leaner version can be made available.

==============================================================
SPECIAL VERSION 4.2 and WINCE NOTES:

The Ivox 4.2 series are preliminary releases of code which
provides a new GUI for Ivox.  The new GUI does not yet have
all of the features of the old GUI, but the core capabilities
are provided.  Thus, while much of the user's guide and notes
below are applicable, there are some differences.  The Ivox 
settings file can be leverage to access features not present
in the GUI.  Note that "auto answer" is enabled by default
and _must_ be enabled for this initial 4.2 release.


IVOX-RELIABLE Protocol Notes:

The Ivox 4.2 release provides an option to use reliable
transport of real-time voice data using the NORM protocol
(for multicast and unicast Ivox sessions).  Note that for a
given multicast session, _all_ participants MUST use the same
protocol type setting (IVOX or IVOX-RELIABLE).

This capability is provided for experimental purposes and may
be improved as part of on-going work and testing.

WINCE NOTES:

The limited nature of the typical PocketPC (WinCE) platform
leads  to some additional limitations in Ivox features.  For
example, not all voice codecs are supported.  Even non-WinCE
platforms should not use different codecs if planning to
establish connections with WinCE users.

The "X" button in the top right corner of Ivox WinCE GUI
does _not_ exit the Ivox application, but merely hides it.
The user should use the File->Quit menu option to exit Ivox.

The "debug window" can be pretty CPU-intensive depending upon
the debug level selected.  This should be used with discretion.

The Ivox settings file (after Ivox is run for the first time)
is saved (the user is notified).  This text file is saved
by default in the "My Documents" folder and is titled
"IvoxSettings.txt".  This file may be edited as necessary.
Ivox locates the file via a Windows Registry entry under
the CURRENT_USER key.

==============================================================


GETTING STARTED:

1) Place the "ivox" file somewhere in your path.

2) Launch the "ivox" executable.

3) Edit your UserName setting under the "Settings" menu.

4) Edit your "IP TOS" value under the "Settings" menu.

5) Use the "New" button to create new unicast and/or
   multicast sessions.  Note that an Ivox user can
   participate in multiple voice groups/conversations
   simultaneously.
   
   MULTICAST EXAMPLE:
   
   a) Set the "Name" field to desired name.
   
   b) Select "DirectIP" call type.
   
   c) Type IP Multicast address (e.g. 224.3.2.1) into
      "Host | URL" field.
      
   d) Type port number into "Port" field and desired
      multicast TTL into "TTL" field.
      
   e) Hit "OK" button when done and join group by selecting
      the new session in Ivox's display and hit the "Call"
      button.
      
   f) Use the "End Call" button to terminate a
      point-to-point call or to leave a multicast group.

   UNICAST EXAMPLE:
   
   a) Set the "Name" field to desired name.
   
   b) Select "DirectIP" call type.
   
   c) Type host name or IP unicast address into
      "Host | URL" field.
      
   d) Leave "Port" set to zero or blank.  TTL is ignored
      for unicast sessions.
      
   e) Hit "OK" button when done and join group by selecting
      the new session in Ivox's display and hit the "Call"
      button.
      
    f) Use the "End Call" button to terminate a
       point-to-point call or to leave a multicast group.

   
(Note: Your settings are saved in a text-editable 
 "~/.ivoxrc" file.  This includes a history of recent
 unicast and/or multicast sessions you have participated
 in).  On Win32, the settings are saved elsewhere (user picks
the place to save the first time Ivox is exited).  The default
Win32 location is the users "My Documents" folder.
 
 IP TOS Notes:
 
 1) Ivox lets you set IP TOS value to any value 0x00 - 0xff.
    Some operating systems require root privileges for 
    setting some TOS values.  Some operating systems do
    not allow all TOS settings or will remap some values
    slightly.  Ivox leaves this to the user's discretion.
 
 2) Changing the "global" TOS setting only will affect newly
    placed calls (or newly joined groups).  For example, you
    can set the TOS = 0x20 and then "Call" (join) Group1.
    Packets transmitted to Group1 will have TOS = 0x20. 
    Then, change the TOS setting to 0x30 and subsequently
    join Group2.  Packets transmitted to Groups2 will have
    TOS = 0x30 while packets sent to Group1 will still have
    TOS = 0x20. To change the TOS for sessions that are
    already active, you must end the call ("End Call")
    first.

 3) While TOS is currently only settable on a global basis,
    it will soon be able to be set on a per-session basis.
 
KNOWN UNIX LIMITATIONS:
 
 1) RSVP operation has not yet been compiled into Unix
    version. Win32 RSVP operation currently works best on
    Win98 revision 2 platforms.  These will be addressed
    soon (or maybe not)

 2) The Ivox 3.x "sdr" (MBONE Session Directory) Plug-in
    does not work with Ivox 4.x.  A new sdr plug-in will
    be created soon.
    
 5) Ivox 3.x and Ivox 4.x are _not_ interoperable.
 
 6) "Debug" level/logging not settable via GUI on Unix version.  
    Note that debug level (0-12) can be set with command-line
    operation (e.g. "ivox debug 0" to turn off debug output or 
    another value to increase it)
    
Note there are a number of command-line options available
to Ivox _and_ Ivox's operation can be scripted from the
command-line even while it is already running.  This "remote
control" interface is described in the User's Guide.


Brian Adamson
<adamson@itd.nrl.navy.mil>
26 Feb 2007
